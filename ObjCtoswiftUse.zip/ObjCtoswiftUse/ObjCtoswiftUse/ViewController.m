//
//  ViewController.m
//  ObjCtoswiftUse
//
//  Created by AR on 04/10/19.
//  Copyright © 2019 DNK028. All rights reserved.
//

#import "ViewController.h"
#import "ObjCtoswiftUse-Swift.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}


@end
