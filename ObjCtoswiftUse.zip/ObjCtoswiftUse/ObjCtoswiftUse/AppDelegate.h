//
//  AppDelegate.h
//  ObjCtoswiftUse
//
//  Created by AR on 04/10/19.
//  Copyright © 2019 DNK028. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UINavigationController *navigationController;
@property (strong, nonatomic) UIWindow *window;


@end

