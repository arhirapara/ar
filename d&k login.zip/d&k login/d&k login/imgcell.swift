//
//  imgcell.swift
//  d&k login
//
//  Created by tops on 12/25/17.
//  Copyright © 2017 tops. All rights reserved.
//

import UIKit

class imgcell: UICollectionViewCell {

    @IBOutlet weak var btn: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
