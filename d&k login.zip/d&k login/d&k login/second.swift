//
//  second.swift
//  d&k login
//
//  Created by tops on 12/25/17.
//  Copyright © 2017 tops. All rights reserved.
//

import UIKit

class second: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource {


    @IBOutlet weak var cell1: UICollectionView!
    
    let arr = ["Circle-icons-image.svg.png","Circle-icons-image.svg.png","Circle-icons-image.svg.png","Circle-icons-image.svg.png","Circle-icons-image.svg.png","Circle-icons-image.svg.png","Circle-icons-image.svg.png","Circle-icons-image.svg.png","Circle-icons-image.svg.png"]
    let btn = ["a","b","c","a","b","c","a","b","c","a","b","c"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nib = UINib(nibName: "imgcell", bundle: nil)
        self.cell1.register(nib, forCellWithReuseIdentifier: "cell1")
       

        // Do any additional setup after loading the view.
    }

    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView.tag == 0
        {
            return arr.count
            
        }
        else{
            return btn.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        if collectionView.tag == 0
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! imgg
            
            cell.img.image = UIImage(named: arr[indexPath.row])
            cell.lbl.text = arr[indexPath.row]
            return cell
        }
            
        else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell1", for: indexPath) as! imgcell
             cell.btn.setTitle(btn[indexPath.row] , for: .normal)
            return cell
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
