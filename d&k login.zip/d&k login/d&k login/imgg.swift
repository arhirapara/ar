//
//  imgg.swift
//  d&k login
//
//  Created by tops on 12/25/17.
//  Copyright © 2017 tops. All rights reserved.
//

import UIKit

class imgg: UICollectionViewCell {
    
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var lbl: UILabel!
    
    
}
