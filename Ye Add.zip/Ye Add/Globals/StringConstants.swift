//
//  StringConstants.swift
//  OneTouch
//
//  Created by Kartum Infotech on 20/05/19.
//  Copyright © 2019 Kartum Infotech. All rights reserved.
//

import Foundation

struct StringConstants {
    
    static let SELECT_COUNTRY_CODE          =   "Please select country code"
    static let ENTER_MOBILE_NUMBER          =   "Enter mobile number"
}
