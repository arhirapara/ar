//
//  LocalizedString.swift
//  OneTouch
//
//  Created by Kartum on 05/06/19.
//  Copyright © 2019 Kartum Infotech. All rights reserved.
//

import Foundation

enum LocalizedString: String {
    
    case noNetworkConnection          =   "noNetworkConnection"
    case checkConnectionMsg           =   "checkConnectionMsg"
    case ConfirmPassword              =  "ConfirmPassword"
    case phoneNumberValidation        =   "phoneNumberValidation"

    //SIGNUP
    case AlredyAccount              = "AlredyAccount"
    case AlreadyHaveAnAccount       = "AlreadyHaveAnAccount"
    case Signup                     = "Signup"
    case LoginWithFacebook          = "LoginWithFacebook"
    case EmailORMobileNumber        = "EmailORMobileNumber"
    case SighnUpDescreption         = "SighnUpDescreption"
   
    case FirstName                  = "FirstName"
    case LastName                   = "LastName"
    case SamePassword               = "SamePassword"
    
    //LOGIN
    case Email                      = "Email"
    case enterValidEmail            = "enterValidEmail"
    case WelcomeBack                = "WelcomeBack"
    case FoodServrdDescreption      = "FoodServrdDescreption"
    case EmailId                    = "EmailId"
    case Password                   = "Password"
    case RememberMe                 = "RememberMe"
    case ForgotPassword             = "ForgotPassword"
    case Login                      = "Login"
    case DontHaveAnAccount          = "DontHaveAnAccount"     
    
    //TABLE LIST
    case TopOfTheWeek               = "TopOfTheWeek"
    
    //FOODIMAGE WITH DETAIL
    case AboutTheDish               = "AboutTheDish"
    
    //CHOOSE LANGUAGE
    case Arabic                     = "Arabic"
    case English                    = "English"
    case ChooseLanguage             = "ChooseLanguage"
    case Next                       = "Next"
    
    //HOME
    case SearchHome               =  "SearchHome"
    case SeeAll                   = "SeeAll"
    case Popular                  = "Popular"
    //PROFILE
    case AddReview                =  "AddReview"
    case Edit                     = "Edit"
    case EditProfile              = "EditProfile"
    case SendFeedback             = "SendFeedback"
    case Rate                     = "Rate"
    case LogOut                   = "LogOut"
    case PersonName               = "PersonName"
    case PersoneEmail             = "PersoneEmail"
    case MobileNUmber             = "MobileNUmber"
    case Address                  = "Address"
    case ZipCode                  = "ZipCode"
    case City                     = "City"
    case Confirm                  = "Confirm"
    case Message                  = "Message"
    case OK                       = "OK"
    case Cancel                   = "Cancel"
    case SelectPhoto              = "SelectPhoto"
    case MessageForProfilePhoto   = "MessageForProfilePhoto"
    case PhotoLibrary             = "PhotoLibrary"
    case Camera                   = "Camera"
    case Save                     = "Save"
    //ORDER
    case OrderTime                = "OrderTime"
    case YourOrder                = "YourOrder"
    case Unknown                  = "Unknown"
    case Confirmed                = "Confirmed"
    case WaintingForStatus        = "WaintingForStatus"
    case OrderId                  = "OrderId"
    case Total                    = "Total"
    case OrderOn                  = "OrderOn"
    case Repeat                   = "Repeat"
    case Items                   = "Items"
    case Price                   = "Price"

    
    //TABVIEW
    case Home                     = "Home"
    case Order                    = "Order"
    case Delivery                 = "Delivery"
    case Profile                  = "Profile"
    
    //DELIVERY
    case OrderPlaced              =  "OrderPlaced"
    case OrderSent                =  "OrderSent"
    case OrderRate                =  "OrderRate"
    case Waiting                  =  "Waiting"
    case HowItWork                = "HowItWork"
    case YourOrderDisplayed       = "YourOrderDisplayed"
    case DeliveryStatus           = "DeliveryStatus"
    
    //MYCART
    
   case MessageForRemoveCart      = "MessageForRemoveCart" 
    case NO                       = "NO"
    case YES                      = "YES"
    case Cart                     = "Cart"
    case AddToCart                = "AddToCart"
    
}
