//
//  Application.swift
//  TaskUp
//
//  Created by Kartum on 27/07/19.
//  Copyright © 2019 Kartum Infotech. All rights reserved.
//

import Foundation
import UIKit

/// Application
struct Application {
    
    /// Debug Log enable or not
    static let isDevelopmentMode = true
    static let debug: Bool = true
    
    static let appURL = "https://apps.apple.com/in/app/whatsapp-messenger/id310633997"
    
    static let API_KEY  =   ""
    
    static let YeminiApiKEY  = "kkcoswggwgwkkc8w4ok808o48kswc40c0www4wss"
    static let deviceType    = "ios"
    static let USER_NAME     = "YEMINI-API"
    static let PASSWORD      = "API@YEMINI!#$WEB$"
    
    static let GOOGLE_API_KEY   =   ""
    static let googleClientId = ""
    
    /// Application Mode
    static let mode = Mode.sendbox
    
    /// Application in production or sendbox
    enum Mode {
        case sendbox
        case production
    }
    
    /// App Color
    struct Color {
        static let TEXT_BOLD        = #colorLiteral(red: 0.0862745098, green: 0.09803921569, blue: 0.4392156863, alpha: 1)
        static let FONT_COLOR       = #colorLiteral(red: 0.6, green: 0.5607843137, blue: 0.6352941176, alpha: 1)
        static let FONT_BLACK_COLOR = #colorLiteral(red: 0.1411764706, green: 0.07450980392, blue: 0.1960784314, alpha: 1)
        static let BORDER_GRAY      = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
        static let SKY_COLOR      = #colorLiteral(red: 0.2862745098, green: 0.8117647059, blue: 1, alpha: 1)
        static let APP_THEME_COLOR  = UIColor.black
        
        static let GREENLITE_00B69C             =   UIColor(named: "GreenLite_00B69C")!
        static let GRAYLITE4_C4C4C4             =   UIColor(named: "grayLite4_C4C4C4")!
        static let GRAYLITE3_D9D9D9             =   UIColor(named: "grayLite3_D9D9D9")!
        static let GRAYLITE2_323640             =   UIColor(named: "grayLite2_ 323640")!
        static let BRIGHTBLUE2_2FA4EC           =   UIColor(named: "BrightBlue2_2FA4EC")!
        static let BRIGHTBLUE_2FA3EC            =   UIColor(named: "BrightBlue_2FA3EC")!
        static let BlUEBRIGHT_2EA3EC            =   UIColor(named: "BlueBright _2EA3EC")!
        static let ABBEY_575A5F                 =   UIColor(named: "Abbey_575A5F")!
        
        static let BLUELITE_1FA0EB              =   UIColor(named: "BlueLite_1FA0EB")!
        static let CHARADE_252932               =   UIColor(named: "Charade_ 252932")!
        static let GRAYISH_BLUE_30343E          =   UIColor(named: "grayish blue_30343E")
        static let LOCHMARA_1E9EEA              =   UIColor(named: "Lochmara_1E9EEA")!
        static let SHARK_21242C                 =   UIColor(named: "Shark_21242C")!
        static let NILE_BLUE_1B3A4E             =   UIColor(named: "NileBlue_1B3A4E")!
        static let GRAY_LITE_65696E             =   UIColor(named: "GrayLite_65696E")!
        static let BLUE_LITE_00B1D2             =   UIColor(named: "BlueLite_ 00B1D2")!
        static let GRAY_DARK_2C2F37             =   UIColor(named: "grayDark_2C2F37")!
        static let BLUE_2776EA                  =   UIColor(named: "Blue_ 2776EA")!
        static let GRAYISH_BLUE                 =   UIColor(named: "GrayishBlue_A5ACBC")
        static let darkGtay_1B1F27              =   UIColor(named: "darkGtay_ 1B1F27")!
        static let Color_407EE7                 =   UIColor(named: "Color_407EE7")!
        static let Color_30343E                 =   UIColor(named: "Color_30343E")!
        static let Color_32373F                 =   UIColor(named: "Color_EAF6FE")!
        
        static let SELECTED_OVERLAY_BG_COLOR    =   UIColor(named: "SelectedOverlayColor")!
        static let SELECTED_BORDER_COLOR        =   UIColor(named: "SelectedBorderColor")!
        static let SELECTED_TEXT_COLOR          =   UIColor(named: "Title Text")!
        static let NORMAL_TEXT_COLOR            =   UIColor(named: "TextColor1")!
        
        static let Light_grayish_orange_dfdbd7           =   UIColor(named: "Light_grayish_orange_dfdbd7")!
        static let Facebook_d19314                       =   UIColor(named: "Facebook_d19314")!
        static let Next_4d2612                     =   UIColor(named: "Next_4d2612")!
        static let Description_B8AFA7              =   UIColor(named: "Description_B8AFA7")!
        static let TAB_Select_Color_CF932A         =   UIColor(named: "Tab_Select_color_CF932A")!
        static let TAB_UnSelect_Color_C6C6C6                   =   UIColor(named: "Tab_unselect_color_c6c6c6")!
        static let Color_GreenType                 =   UIColor(named: "Color_GreenType")!
        
        
        //
        static let START_COLOR      = #colorLiteral(red: 0, green: 0.6862745098, blue: 0.9294117647, alpha: 1)
        static let END_COLOR        = #colorLiteral(red: 0.1098039216, green: 0.937254902, blue: 1, alpha: 1)
        static let TAB_SELECT       = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        static let TAB_UNSELECT     = #colorLiteral(red: 0.3411764706, green: 0.3529411765, blue: 0.3725490196, alpha: 1)
        static let GRADIENT: [UIColor]        = [#colorLiteral(red: 0.2588235294, green: 0.5176470588, blue: 0.9529411765, alpha: 1), #colorLiteral(red: 0.07450980392, green: 0.737254902, blue: 0.862745098, alpha: 1)]
        static let GRADIENT_TRANSFERNT_MENU_LIST: [UIColor]        = [#colorLiteral(red: 0.8745098039, green: 0.8588235294, blue: 0.8431372549, alpha: 1), #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)]
        static let PLACEHOLDER  =   #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.4195473031)
        static let SearchPlaceHolder = #colorLiteral(red: 0.8509803922, green: 0.8509803922, blue: 0.8509803922, alpha: 0.4712649829)
        
    }
    
    /// App Fonts
    struct Font {
        static let MONTSERRAT_REGULAR                = "Montserrat-Regular"
        
        //PROXIMANOVA
        static let PROXIMANOVA_EXTRABLD              = "ProximaNova-Extrabld"
        static let PROXIMANOVA_BLACK                 = "ProximaNova-Black"
        static let PROXIMANOVA_SEMIBOLD              = "ProximaNova-Semibold"
        static let PROXIMANOVA_REGULARIT             = "ProximaNova-RegularIt"
        static let PROXIMANOVA_BOLDIT                = "ProximaNova-BoldIt"
        static let PROXIMANOVAT_THIN                 = "ProximaNovaT-Thin"
        static let PROXIMANOVA_BOLD                  = "ProximaNova-Bold"
        static let PROXIMANOVA_THIN                  = "ProximaNova-Thin"
        static let PROXIMANOVA_SEMIBOLDIT            = "ProximaNova-SemiboldIt"
        static let PROXIMANOVA_REGULAR               = "ProximaNova-Regular"
        static let PROXIMANOVA_LIGHTIT               = "ProximaNova-LightIt"
        
        //
        
        
        
        
        
        
        
        
        
        
        //        static let PROXIMA_NOVA_ALT_CONDENSED_THIN    = "Proxima Nova Alt Condensed Thin"
        //        static let PROXIMA_NOVA_ALT_EXTRA_CONDENSED_THIN = "Proxima Nova Alt Extra Condensed Thin"
    }
    struct Device {
        static let version = UIDevice.current.systemVersion
    }
    
    struct CountryCode {
        static let code = isDevelopmentMode ? "+65" : "+65"
    }
}

extension Notification.Name {
    static let CHECK_LOCATION_PERMISSION    =   Notification.Name("CHECK_LOCATION_PERMISSION")
    static let USER_PROFILE_STATUS_CHANGED  =   Notification.Name("USER_PROFILE_STATUS_CHANGED")
    static let productAddedToCart   =   Notification.Name("productAddedToCart")
    static let becomeFirstResponderHomeSearch   =   Notification.Name("becomeFirstResponderHomeSearch")
    static let productRemovedFromCart   =   Notification.Name("productRemovedFromCart")
    static let orderPlacedNotification  =   Notification.Name("orderPlacedNotification")
}
