//
//  ForgotPasswordViewModel.swift
//  Yemeni
//
//  Created by Kartum Infotech on 12/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation

class ForgotPasswordViewModel: BaseViewModel {
    // MARK: - Properties
    
    var email: String = ""
    
   
    // MARK: - Functions
    ///Validation
    func validateForm() -> (isValid: Bool, title: String, message: String) {
        if Utility.isEmptyString(string: email) {
            return (false, "", getLocalizedString(key: .Email))
        }
        return (true, "", "")
    }
    
    ///API calls
    func forgotPasswordUser(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        let params = MultipartParameterRequest()
        
        params.addParameter(paramName: .email, value: email)
        
        _ = apiClient.forgotPassword(params: params.multipartFormData, completion: { (response, error) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            // DDLogDebug("httpStatusCode = \(String(describing: httpStatusCode))")
            if responseData.status == 200 {
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
}
