//
//  GetCatagoryViewModel.swift
//  Yemeni
//
//  Created by Kartum Infotech on 12/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
import Alamofire
import CocoaLumberjack

class GetCategoriesViewModel: BaseViewModel {
    
    var product_id : String = ""
    var category_id: String = ""
    var product_name: String = ""
    var categoryName: String = ""
    var arrHomeCategory = [HomeModelInfo]()
    var dictSelectedData = HomeModelInfo(json: [:])
    var categoryList = HomeModelInfo(json: [:])
    var userProfileList =  UserInfo(json: [:])
    var arrOfSearchProduct = [SearchCatagoryInfo]()
    
    var searchRequest: DataRequest?
    
    func categoryList(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        
        _ = apiClient.category(completion: { (response, error) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            // DDLogDebug("httpStatusCode = \(String(describing: httpStatusCode))")
            if responseData.status == 200 {
                if let arrResult = responseData.data as? [[String: Any]] {
                    self.arrHomeCategory = HomeModelInfo.toArray(arrJson: arrResult)
                    if self.arrHomeCategory.isEmpty {
                        self.dictSelectedData = HomeModelInfo(json: [:])
                    } else {
                        self.dictSelectedData = self.arrHomeCategory.first!
                    }
                    
                    print("Array : \(self.arrHomeCategory)")
                }
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
    
    func getItems(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        let params = MultipartParameterRequest()
        params.addParameter(paramName: .category_id, value: category_id)
        
        _ = apiClient.items(params: params.multipartFormData, completion: { (response, error) in
            
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            if responseData.status == 200 {
                if let resultObj = responseData.data as? [String : Any]{
                    self.categoryList = HomeModelInfo(json: resultObj)
                }
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
    
    func searchItems(keyword: String, completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        searchRequest?.cancel()
        
        let params = MultipartParameterRequest()
        params.addParameter(paramName: .product_name, value: keyword)
        
        searchRequest = apiClient.searchProduct(params: params.multipartFormData, completion: { (response, error) in
            
            guard error == nil else {
                if let afError = error?.asAFError, afError.isExplicitlyCancelledError {
                    DDLogError("afError = \(afError.localizedDescription)")
                    completion(false, "")
                } else {
                    completion(false, error!.messageForNetworking)
                }
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            if responseData.status == 200 {
                if let resultObj = responseData.data as? [String : Any] {
                    if let results = resultObj["result"] as? [[String:Any]] {
                        self.arrOfSearchProduct = SearchCatagoryInfo.toArray(arrJson: results)
                    }
                }
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
}
