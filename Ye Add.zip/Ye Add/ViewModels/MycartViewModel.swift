//
//  MycartViewModel.swift
//  Yemeni
//
//  Created by Kartum Infotech on 18/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
import CocoaLumberjack

class MyCartViewModel:BaseViewModel{
    
     var order_id : String?
    var cart_id : String = ""
    var product_id : String = ""
    var quantity  : String = ""
    var addTocartList = AddToCartInfo(json: [:])
    var arrMyCart = [ProductItemInfo]()
    var objectCartTotal: String = ""
    
    func myCart(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        
        _ = apiClient.myCart( completion: { (response, error) in
            
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            if responseData.status == 200 {
                self.objectCartTotal = responseData.main_total
                if let arrResult = responseData.data as? [[String: Any]] {
                    //                    self.objectCartTotal = responseData.main_total
                    self.arrMyCart = ProductItemInfo.toArray(arrJson: arrResult)
                    print("Array : \(self.arrMyCart)")
                }
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
    func removeCart(cartId: String, completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        
        let params = MultipartParameterRequest()
        params.addParameter(paramName: .cart_id , value: cartId)
        DDLogDebug("parameters = \(params.tempParamsRequest.params )")
        _ = apiClient.removeItemCart(params: params.multipartFormData, completion: { (response, error) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            let responseData = ResponseData(json: responseObj)
            // DDLogDebug("httpStatusCode = \(String(describing: httpStatusCode))")
            if responseData.status == 200 {
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
    
    
    // MARK: - Functions
    
    ///API calls

    func addToCart(qty: String, productId: String, completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        let params = MultipartParameterRequest()
        
        params.addParameter(paramName: .product_id , value: productId)
        params.addParameter(paramName: .quantity, value: qty)
        
        _ = apiClient.addToCart(params: params.multipartFormData, completion: { (response, error) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            // DDLogDebug("httpStatusCode = \(String(describing: httpStatusCode))")
            if responseData.status == 200 {
                completion(true, responseData.message)
                if let resultObj = responseData.data as? [String : Any]{
                    self.addTocartList = AddToCartInfo(json: resultObj)
                }
            } else {
                completion(false, responseData.message)
            }
        })
    }
    
    func placeOrder(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        
        _ = apiClient.placeOrder( completion: { (response, error) in
            
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            if responseData.status == 200 {
                if let arrResult = responseData.data as? [[String: Any]] {
                    self.arrMyCart = ProductItemInfo.toArray(arrJson: arrResult)
                    print("Array : \(self.arrMyCart)")
                }
                completion(true, responseData.message)
                }
            else {
                completion(false, responseData.message)
            }
        })
    }
}
