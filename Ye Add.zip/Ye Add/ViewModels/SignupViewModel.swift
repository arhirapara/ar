//
//  SignupViewModel.swift
//  Courtpals
//
//  Created by Sunil Zalavadiya on 24/06/20.
//  Copyright © 2020 Neuron Mac. All rights reserved.
//

import Foundation

class SignupViewModel: BaseViewModel {
    // MARK: - Properties
    var firstName: String = ""
    var lastName: String = ""
    var email: String = ""
    var password: String = ""
    var confirmPassword: String = ""
    var Phone: String = ""
    var Lang: String = ""
   
    
//    var userInfo = UserInfo(json: [:])
    // MARK: - Functions
    ///Validation
    func validateForm() -> (isValid: Bool, title: String, message: String) {
        if Utility.isEmptyString(string: firstName) {
            return (false, "", getLocalizedString(key: .FirstName))
        } else if Utility.isEmptyString(string: lastName) {
            return (false, "", getLocalizedString(key: .LastName))
        } else if Utility.isEmptyString(string: email) {
            return (false, "", getLocalizedString(key: .Email))
        } else if !email.isValidEmail {
              return (false, "", getLocalizedString(key: .enterValidEmail))
        } else if Utility.isEmptyString(string: password) {
              return (false, "", getLocalizedString(key: .Password))
        } else if Utility.isEmptyString(string: confirmPassword) {
             return (false, "", getLocalizedString(key: .ConfirmPassword))
        } else if password.count < 6 {
             return (false, "", getLocalizedString(key: .Password))
        } else if password != confirmPassword {
            return (false, "", getLocalizedString(key: .SamePassword))
        }
        return (true, "", "")
    }
    
    ///API calls
    func signupUser(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        let params = MultipartParameterRequest()
        params.addParameter(paramName: .firstname, value: firstName)
        params.addParameter(paramName: .lastname, value: lastName)
        params.addParameter(paramName: .email, value: email)
        params.addParameter(paramName: .password, value: password)
        params.addParameter(paramName: .confirm_password, value: confirmPassword)
        params.addParameter(paramName: .phone, value: Phone)
       // params.addParameter(paramName: .lang, value: Lang)
        
        _ = apiClient.register(params: params.multipartFormData, completion: { (response, error) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
           // DDLogDebug("httpStatusCode = \(String(describing: httpStatusCode))")
            if responseData.status == 200 {
//                if let resultObj = responseData.data as? [String : Any]{
//                    self.userInfo = UserInfo(json: resultObj)
//                  //  AppPrefsManager.shared.saveLoggedInUserInfo(userInfo: self.userInfo.toDictionary())
//                }
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
}

/*

curl --location --request POST 'https://wepixel.in/yemini/api/v1/auth/register' \
--header 'YEMINI-API-KEY: kkcoswggwgwkkc8w4ok808o48kswc40c0www4wss' \
--form 'firstname=MDK' \
--form 'lastname=SASA' \
--form 'email=mayur.webforest@gmail.com' \
--form 'password=123456' \
--form 'confirm_password=123456' \
--form 'phone=1234567890' \
--form 'lang=ar'

*/
