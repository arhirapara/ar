//
//  LogInViewModel.swift
//  Yemeni
//
//  Created by Kartum Infotech on 12/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation

class LogInViewModel: BaseViewModel{
    
    var email: String = ""
    var password: String = ""
    var device_id: String = ""
    
    var loginInfo = UserInfo(json: [:])
    var arrHomeCategory = [HomeModelInfo]()
    //VALIDATION
    func validateForm() -> (isValid: Bool, title: String, message: String) {
        
        if Utility.isEmptyString(string: email) {
            return (false, "", getLocalizedString(key: .Email))
        } else if !email.isValidEmail {
            return (false, "", getLocalizedString(key: .enterValidEmail))
        } else if Utility.isEmptyString(string: password) {
            return (false, "", getLocalizedString(key: .Password))
        } else if password.count < 6 {
            return (false, "", getLocalizedString(key: .Password))
        }
        return (true, "", "")
    }
    
    
    //MARK:- API CALL
    func loginUser(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        let params = MultipartParameterRequest()
        params.addParameter(paramName: .email, value: email)
        params.addParameter(paramName: .password, value: password)
        params.addParameter(paramName: .device_id, value: device_id)
        // params.addParameter(paramName: .lang, value: Lang)
        
        _ = apiClient.logIn(params: params.multipartFormData, completion: { (response, error) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            let responseData = ResponseData(json: responseObj)
            // DDLogDebug("httpStatusCode = \(String(describing: httpStatusCode))")
            if responseData.status == 200 {
                if let resultObj = responseData.data as? [String : Any]{
                    self.loginInfo = UserInfo(json: resultObj)
                    AppPrefsManager.shared.saveLoggedInUserInfo(userInfo: self.loginInfo.toDictionary())
                }
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
    
}
