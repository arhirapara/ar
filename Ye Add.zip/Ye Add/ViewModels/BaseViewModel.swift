//
//  BaseViewModel.swift
//  Drivo
//
//  Created by Sunil Zalavadiya on 03/05/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
import CocoaLumberjack

class BaseViewModel: NSObject {
    
    // MARK: - Properties
    lazy var apiClient = APIClient()
    lazy var messageToShow = ""
   
    override init() {
        super.init()
    }
    
    func updateFcmToken(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        guard AppPrefsManager.shared.isUserLogin() else {
            return
        }
        let params = ParameterRequest()
        params.addParameter(paramName: .firebase_token, value: AppPrefsManager.shared.getFcmToken())
        _ = apiClient.updateFcmToken(params: params, completion: { (response, error, httpStatusCode) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            if responseData.status == 200 {
                completion(true, responseData.message.isEmpty ? responseData.message : responseData.message)
            } else {
                completion(false, responseData.message.isEmpty ? responseData.message : responseData.message)
            }
        })
    }
}
