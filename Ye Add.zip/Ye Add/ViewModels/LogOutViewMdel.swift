//
//  LogOutViewMdel.swift
//  Yemeni
//
//  Created by Kartum Infotech on 16/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
class LogOutViewModel: BaseViewModel {
    // MARK: - Properties
    
    var device_id : String?
    
   
    // MARK: - Functions
 
    ///API calls
    func logOut(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
      let params = MultipartParameterRequest()
        _ = apiClient.logOut(params: params.multipartFormData,completion: { (response, error) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            let responseData = ResponseData(json: responseObj)
            // DDLogDebug("httpStatusCode = \(String(describing: httpStatusCode))")
            if responseData.status == 200 {
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
}
