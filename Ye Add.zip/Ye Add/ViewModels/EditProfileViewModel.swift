//
//  EditProfileViewModel.swift
//  Yemeni
//
//  Created by Kartum Infotech on 22/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
import UIKit

class UpdateProfileViewModel: BaseViewModel {
    // MARK: - Properties
    var first_name: String = ""
    var last_name: String = ""
    var email: String = ""
    var address: String = ""
    var city: String = ""
    var pincode: String = ""
    var phone: String = ""
    var profile_image:String = ""
    var loginInfo = UserInfo(json: [:])
    
    var profileImage: UIImage?

    // MARK: - Functions
   
    func validateForm() -> (isValid: Bool, title: String, message: String) {
        if Utility.isEmptyString(string: email) {
            return (false, "", getLocalizedString(key: .Email))
        } else if !email.isValidEmail {
            return (false, "", getLocalizedString(key: .enterValidEmail))
        }
        return (true, "", "")
    }
    
    ///API calls
    func UpdateProfileUser(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        let params = MultipartParameterRequest()
        params.addParameter(paramName: .first_name, value: first_name)
        params.addParameter(paramName: .last_name, value: last_name)
        params.addParameter(paramName: .email, value: email)
        params.addParameter(paramName: .city, value: city)
        params.addParameter(paramName: .pincode, value: pincode)
        params.addParameter(paramName: .phone, value: phone)
        params.addParameter(paramName: .address, value: address)
        
        if let image = profileImage {
            let resizedImage = image.aspectResize(maxSize: CGSize(width: 640, height: 640))
            if let imageData = resizedImage.jpegData(compressionQuality: 0.7) {
                params.addFile(paramName: .profile_image, fileData: imageData, fileName: "profile.jpg", mimeType: "image/jpeg")
            }
        }

        print("UpdateProfileUser = \(params.tempParamsRequest.params)")
        _ = apiClient.updateProfile(params: params.multipartFormData, completion: { (response, error) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
           // DDLogDebug("httpStatusCode = \(String(describing: httpStatusCode))")
            if responseData.status == 200 {
                self.profileImage = nil
                  //  AppPrefsManager.shared.saveLoggedInUserInfo(userInfo: self.userInfo.toDictionary())
                if let resultObj = responseData.data as? [String : Any] {
                    self.loginInfo = AppPrefsManager.shared.getLoggedInUserInfo()
                    self.loginInfo.mapUserObjectForUpdateProfile(json: resultObj)
                    AppPrefsManager.shared.saveLoggedInUserInfo(userInfo: self.loginInfo.toDictionary())
                }
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
}

/*

curl --location --request POST 'https://wepixel.in/yemini/api/v1/auth/register' \
--header 'YEMINI-API-KEY: kkcoswggwgwkkc8w4ok808o48kswc40c0www4wss' \
--form 'firstname=MDK' \
--form 'lastname=SASA' \
--form 'email=mayur.webforest@gmail.com' \
--form 'password=123456' \
--form 'confirm_password=123456' \
--form 'phone=1234567890' \
--form 'lang=ar'

*/
