//
//  LanguageViewModel.swift
//  Sunil Zalavadiya
//
//  Created by Kartum Infotech on 30/07/20.
//  Copyright © 2020 Sunil Zalavadiya. All rights reserved.
//

import Foundation
import UIKit

enum LanguageCode: String {
    case english    =   "en"
    case arabic     =   "ar"
    
    
    func name() -> String {
        switch self {
        case .english:
            return "English"
        case .arabic:
            return "Arabic"
        }
    }
    
    func icon() -> UIImage? {
        switch self {
        case .english:
            return UIImage(named: "englandFlag")
        case .arabic:
            return UIImage(named: "germanFlag")
        }
    }
    
    func codeForApi() -> String {
        switch self {
        case .english:
            return "en"
        case .arabic:
            return "ar"
        }
    }
}

class LanguageViewModel: BaseViewModel {
    // MARK: - Properties
    var arrLanguages = [LanguageCode]()
    
    // MARK: - Init
    override init() {
        super.init()
        generateLanguageArray()
    }
    
    // MARK: - Functions
    private func generateLanguageArray() {
        arrLanguages.append(.arabic)
        arrLanguages.append(.english)
    }
}
