//
//  DeliveryStatusViewMOdel.swift
//  Yemeni
//
//  Created by Kartum Infotech on 21/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
class DeliveryStatusViewModel: BaseViewModel {
    // MARK: - Properties
    
    var order_id : String = ""
    var arrMyCart = [ProductItemInfo]()
   
    // MARK: - Functions
 
    ///API calls
     func deliveryStatus(order_id: String,completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
           
           let params = MultipartParameterRequest()
           params.addParameter(paramName: .order_id , value: order_id)
//           DDLogDebug("parameters = \(params.tempParamsRequest.params )")
           _ = apiClient.deliveryStatus(params: params.multipartFormData, completion: { (response, error) in
               guard error == nil else {
                   completion(false, error!.messageForNetworking)
                   return
               }
               guard let responseObj = response as? [String: Any] else {
                   completion(false, "")
                   return
               }
               let responseData = ResponseData(json: responseObj)
                   
               // DDLogDebug("httpStatusCode = \(String(describing: httpStatusCode))")
               if responseData.status == 200 {
                   
                   completion(true, responseData.message)
               } else {
                   completion(false, responseData.message)
               }
           })
       }
}
