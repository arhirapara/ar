//
//  ProductDetailsViewModel.swift
//  Yemeni
//
//  Created by Sunil Zalavadiya on 23/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation

class ProductDetailsViewModel: BaseViewModel {
    // MARK: - Properties
    var productId: String = ""
    var productInfo = ItemInfo(json: [:])
    var categoryList = HomeModelInfo(json: [:])
    
    // MARK: - API calls
    func getProductDetails(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
           let params = MultipartParameterRequest()
           params.addParameter(paramName: .product_id, value: productId)
           
           _ = apiClient.productDetail(params: params, completion: { (response, error) in
               
               guard error == nil else {
                   completion(false, error!.messageForNetworking)
                   return
               }
               
               guard let responseObj = response as? [String: Any] else {
                   completion(false, "")
                   return
               }
               
               let responseData = ResponseData(json: responseObj)
               if responseData.status == 200 {
                if let dataDict = responseData.data as? [String: Any], let item = dataDict["item"] as? [String: Any] {
                    self.productInfo = ItemInfo(json: item)
                }
                   completion(true, responseData.message)
               } else {
                   completion(false, responseData.message)
               }
           })
       }
    
    func getItems(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        let params = MultipartParameterRequest()
        params.addParameter(paramName: .category_id, value: productInfo.category_id)
        
        _ = apiClient.items(params: params.multipartFormData, completion: { (response, error) in
            
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            if responseData.status == 200 {
                if let resultObj = responseData.data as? [String : Any]{
                    self.categoryList = HomeModelInfo(json: resultObj)
                }
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
}
