//
//  MyOrder.swift
//  Yemeni
//
//  Created by Kartum Infotech on 15/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation

class MyOrderViewModel: BaseViewModel {
    // MARK: - Properties
    var order_id :String = ""
    var arrOrders = [OrderInfo]()
    
    // MARK: - API calls
    func myOrder(completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        
        _ = apiClient.myOrder(completion: { (response, error) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            // DDLogDebug("httpStatusCode = \(String(describing: httpStatusCode))")
            if responseData.status == 200 {
                self.arrOrders.removeAll()
                if let arrResult = responseData.data as? [[String: Any]] {
                    self.arrOrders = OrderInfo.toArray(arrJson: arrResult)
                }
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
    
    func repeatOrder(orderId: String, completion: @escaping ((_ success: Bool, _ message: String) -> ())) {
        
        let params = MultipartParameterRequest()
        params.addParameter(paramName: .order_id , value: orderId)
        
        _ = apiClient.repeatOrder(params: params, completion: { (response, error) in
            guard error == nil else {
                completion(false, error!.messageForNetworking)
                return
            }
            
            guard let responseObj = response as? [String: Any] else {
                completion(false, "")
                return
            }
            
            let responseData = ResponseData(json: responseObj)
            if responseData.status == 200 {
                completion(true, responseData.message)
            } else {
                completion(false, responseData.message)
            }
        })
    }
}
