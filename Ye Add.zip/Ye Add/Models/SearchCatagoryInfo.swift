//
//  SearchCatagoryInfo.swift
//  Yemeni
//
//  Created by Kartum Infotech on 23/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation

class SearchCatagoryInfo {
      var category_id: String = ""
      var category_name: String = ""
      var is_category: Bool = false
      var lang:String = ""
      
   
    init(json: [String: Any]) {
        category_id = json["category_id"] as? String ?? ""
        category_name = json["category_name"] as? String ?? ""
        is_category = json["is_category"] as? Bool ?? false
        lang = json["lang"] as? String ?? ""
//        if let arrayjson = json["result"] as? [[String:Any]]{
//            item_list = ItemInfo.toArray(arrJson: arrayjson)
//        }
    }
    
    func toDictionary() -> [String: Any] {
        var dict = [String: Any]()
        dict["category_id"] = category_id
        dict["category_name"] = category_name
        dict["is_category"] = is_category
        dict["lang"] = lang
        
        return dict
    }
    
    class func toArray(arrJson: [[String: Any]]) -> [SearchCatagoryInfo] {
        var arrModels = [SearchCatagoryInfo]()
        for dict in arrJson {
            arrModels.append(SearchCatagoryInfo(json: dict))
        }
        return arrModels
    }
}
