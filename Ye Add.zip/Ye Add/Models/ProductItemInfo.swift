//
//  MyCartInfo.swift
//  Yemeni
//
//  Created by Kartum Infotech on 18/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation

class ProductItemInfo {
      var cart_id: String = ""
      var created_at: String = ""
      var price: String = "0"
      var product_id:String = ""
      var product_image: String = ""
      var product_name: String = ""
      var qty: String = "0"
      var user_id: String = ""
      var customer_address : String = ""
      var customer_name : String = ""
      var customer_phone : String = ""
      var order_id : String  = ""
      var subtotal : String = ""
    
    var id: String = "0"
    var order_status: OrderStatus = .Unknown
    var sub_total: String = "0"
   
    init(json: [String: Any]) {
        cart_id = json["cart_id"] as? String ?? ""
        created_at = json["created_at"] as? String ?? ""
        price = json["price"] as? String ?? "0"
        product_id = json["product_id"] as? String ?? ""
        product_image = json["product_image"] as? String ?? ""
        product_name = json["product_name"] as? String ?? ""
        qty = json["qty"] as? String ?? "0"
        sub_total = json["sub_total"] as? String ?? "0"
        user_id = json["user_id"] as? String ?? ""
        customer_address = json["customer_address"] as? String ?? ""
        customer_name = json["customer_name"] as? String ?? ""
        customer_phone = json["customer_phone"] as? String ?? ""
        order_id = json["order_id"] as? String ?? ""
        subtotal = json["subtotal"] as? String ?? ""
        
        id = json["id"] as? String ?? "0"
        if let status = json["order_status"] as? String, let ordStatus = OrderStatus(rawValue: status) {
            order_status = ordStatus
        }
        sub_total = json["sub_total"] as? String ?? "0"
    }
    
    func toDictionary() -> [String: Any] {
        var dict = [String: Any]()
        
        dict["cart_id"] = cart_id
        dict["created_at"] = created_at
        dict["price"] = price
        dict["product_id"] = product_id
        dict["product_image"] = product_image
        dict["product_name"] = product_name
        dict["sub_total"] = sub_total
        dict["qty"] = qty
        dict["user_id"] = user_id
        dict["customer_address"] = customer_address
        dict["customer_name"] = customer_name
        dict["customer_phone"] = customer_phone
        dict["order_id"] = order_id
        dict["subtotal"] = subtotal
        
        dict["id"] = id
        dict["order_status"] = order_status.rawValue
        dict["sub_total"] = sub_total
        
        return dict
    }
    
    class func toArray(arrJson: [[String: Any]]) -> [ProductItemInfo] {
        var arrModels = [ProductItemInfo]()
        for dict in arrJson {
            arrModels.append(ProductItemInfo(json: dict))
        }
        return arrModels
    }
    
    func formattedDateTime() -> String {
        let createdDate = created_at.getDateWithFormate(formate: "yyyy-MM-dd HH:mm:ss", timezone: "UTC")
        let dateString = createdDate.getDateStringWithFormate("MMMM dd, yyyy", timezone: TimeZone.current.abbreviation()!)
        let timeString = createdDate.getDateStringWithFormate("hh:mm a", timezone: TimeZone.current.abbreviation()!)
        return dateString + " at " + timeString
    }
    
    func formattedPrice() -> String {
        return price + " SAR"
    }
    func formattedSubTotal() -> String {
        return sub_total + " SAR"
    }
    func formattedSubTotalOfCart() -> String {
        return subtotal + " SAR"
    }
}
