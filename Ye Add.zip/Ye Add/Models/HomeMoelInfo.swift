//
//  HomeMoelInfo.swift
//  Yemeni
//
//  Created by Kartum Infotech on 12/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
class HomeModelInfo{
    var category_id: String = ""
    var category_name:String = ""
    var created_at:String = ""
    var image : String = ""
    var status : Int = 0
    var updated_at: String = ""
    var item_list: [ItemInfo] = []
    var pupularlist: [ItemInfo] = []
    
    init(json:[String:Any]) {
        category_id = json["category_id"] as? String ?? ""
        category_name = json["category_name"] as? String ?? ""
        created_at = json["created_at"] as? String ?? ""
        image = json["image"] as? String ?? ""
        updated_at = json ["updated_at"] as? String ?? ""
        status = json["status"] as? Int ?? 0
        if let arrayjson = json["item_list"] as? [[String:Any]]{
            item_list = ItemInfo.toArray(arrJson: arrayjson)
        }
        if let arrayjson = json["pupularlist"] as? [[String:Any]]{
            pupularlist = ItemInfo.toArray(arrJson: arrayjson)
        }
    }
    
    func toDictionary() -> [String: Any] {
        var dict = [String: Any]()
        dict["category_id"] = category_id
        dict["category_name"] = category_name
        dict["created_at"] = created_at
        dict["image"] = image
        dict["status"] = status
        dict["updated_at"] = updated_at
        return dict
    }
    
    class func toArray(arrJson: [[String: Any]]) -> [HomeModelInfo] {
        var arrModels = [HomeModelInfo]()
        for dict in arrJson {
            arrModels.append(HomeModelInfo(json: dict))
        }
        return arrModels
    }
    
}

class ItemInfo {
   var product_id: String = ""
   var category_id: String = ""
   var product_name: String = ""
   var product_image: String = ""
   var price: String = ""
   var product_details: String = ""
   var status: String = ""
   var popular: String = ""
   var created_at: String = ""
   var updated_at: String = ""
   var category_name: String = ""
    var quantity: String = "0"
    
    init(json:[String:Any]) {
        product_id = json["product_id"] as? String ?? ""
        category_id = json["category_id"] as? String ?? ""
        product_name = json["product_name"] as? String ?? ""
        product_image = json["product_image"] as? String ?? ""
        price = json["price"] as? String ?? ""
        product_details = json["product_details"] as? String ?? ""
        status = json["status"] as? String ?? ""
        popular = json["popular"] as? String ?? ""
        updated_at = json["updated_at"] as? String ?? ""
        category_name = json["category_name"] as? String ?? ""
        created_at = json["created_at"] as? String ?? ""
        quantity = json["quantity"] as? String ?? "0"
        //TODO: need to remove this after solution done
        if !product_image.hasPrefix("http://wepixel.in/yemini/uploads/Product/") {
            product_image = "http://wepixel.in/yemini/uploads/Product/" + product_image
        }
    }
    
    func toDictionary() -> [String: Any] {
        var dict = [String: Any]()
        dict["product_id"] = product_id
        dict["category_id"] = category_id
        dict["product_name"] = product_name
        dict["product_image"] = product_image
        dict["price"] = price
        dict["product_details"] = product_details
        dict["status"] = status
        dict["popular"] = popular
        dict["created_at"] = created_at
        dict["updated_at"] = updated_at
        dict["category_name"] = category_name
        dict["quantity"] = quantity
        return dict
    }
    
    class func toArray(arrJson: [[String: Any]]) -> [ItemInfo] {
        var arrModels = [ItemInfo]()
        for dict in arrJson {
            arrModels.append(ItemInfo(json: dict))
        }
        return arrModels
    }
    
    func increaseQuantity() {
        if let qty = Int(quantity) {
            quantity = "\(qty+1)"
        } else {
            quantity = "1"
        }
    }
    
    func decreaseQuantity() {
        if let qty = Int(quantity) {
            quantity = "\(qty-1)"
        } else {
            quantity = "0"
        }
    }
    
    func quantityInt() -> Int {
        return Int(quantity) ?? 0
    }
    func formattedPrice() -> String {
        return price + " SAR"
    }
}
