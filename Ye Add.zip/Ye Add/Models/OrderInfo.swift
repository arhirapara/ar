//
//  OrderInfo.swift
//  Yemeni
//
//  Created by Kartum Infotech on 21/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
import UIKit

enum OrderStatus: String {
    case Unknown
    case Confirmed
    case Waiting
    
    func localizedName() -> String {
        switch self {
        case .Unknown:
            return getLocalizedString(key: .Unknown)
        case .Confirmed:
            return getLocalizedString(key: .Confirmed)
        case .Waiting:
            return getLocalizedString(key: .WaintingForStatus)
        }
    }
    
    func statusColor() -> UIColor {
        switch self {
        case .Unknown:
            return .yellow
        case .Confirmed:
            return Application.Color.Color_GreenType
        case .Waiting:
            return Application.Color.Facebook_d19314
        }
    }
}

class OrderInfo {
    var order_id : String  = ""
    var created_at: String = ""
    var order_status: OrderStatus = .Unknown
    var total_price: String = "0"
    var data  = [ProductItemInfo]()
   
    init(json: [String: Any]) {
        order_id = json["order_id"] as? String ?? ""
        created_at = json["created_at"] as? String ?? ""
        if let status = json["order_status"] as? String, let ordStatus = OrderStatus(rawValue: status) {
            order_status = ordStatus
        }
        total_price = json["total_price"] as? String ?? "0"
        
        if let arrData = json["data"] as? [[String: Any]] {
            data = ProductItemInfo.toArray(arrJson: arrData)
        }
    }
    
    class func toArray(arrJson: [[String: Any]]) -> [OrderInfo] {
        var arrModels = [OrderInfo]()
        for dict in arrJson {
            arrModels.append(OrderInfo(json: dict))
        }
        return arrModels
    }
    
    func formattedDateTime() -> String {
        let createdDate = created_at.getDateWithFormate(formate: "yyyy-MM-dd HH:mm:ss", timezone: "UTC")
        let dateString = createdDate.getDateStringWithFormate("MMMM dd, yyyy", timezone: TimeZone.current.abbreviation()!)
        let timeString = createdDate.getDateStringWithFormate("hh:mm a", timezone: TimeZone.current.abbreviation()!)
        return dateString + " at " + timeString
    }
    
    func formattedPrice() -> String {
        return total_price + " SAR"
    }
}
