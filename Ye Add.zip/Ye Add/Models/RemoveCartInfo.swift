//
//  RemoveCartInfo.swift
//  Yemeni
//
//  Created by Kartum Infotech on 17/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
class RemoveCartIdInfo {
      var cart_id: String = ""
     
    init(json: [String: Any]) {
        cart_id = json["cart_id"] as? String ?? ""
    }
    func toDictionary() -> [String: Any] {
        var dict = [String: Any]()
        dict["cart_id"] = cart_id
        return dict
    }
    class func toArray(arrJson: [[String: Any]]) -> [RemoveCartIdInfo] {
        var arrModels = [RemoveCartIdInfo]()
        for dict in arrJson {
            arrModels.append(RemoveCartIdInfo(json: dict))
        }
        return arrModels
    }
}
