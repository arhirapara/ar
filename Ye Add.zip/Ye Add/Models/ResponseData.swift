//
//  ResponseData.swift
//  PushToTalk
//
//  Created by Sunil Zalavadiya on 23/07/20.
//  Copyright © 2020 Sunil Zalavadiya. All rights reserved.
//

import Foundation

class ResponseData {
    var status: Int = 0
    var data: Any?
    var message: String = ""
    var main_total: String = "0"
    
    init(json: [String: Any]) {
        status = json["status"] as? Int ?? 0
        message = json["message"] as? String ?? ""
         main_total = json["main_total"] as? String ?? ""
        data = json["data"]
        if let resultDict = data as? [String: Any] {
        
        }
    }
    
    class func toArray(arrJson: [[String: Any]]) -> [ResponseData] {
        var arrModels = [ResponseData]()
        for dict in arrJson {
            arrModels.append(ResponseData(json: dict))
        }
        return arrModels
    }
}
