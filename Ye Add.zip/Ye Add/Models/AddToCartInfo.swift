//
//  AddToCartInfo.swift
//  Yemeni
//
//  Created by Kartum Infotech on 14/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation

class AddToCartInfo {
      var price: String = ""
      var product_id: String = ""
      var product_name: String = ""
      var qty:String = ""
      var user_id: String = ""
      
   
    init(json: [String: Any]) {
        price = json["price"] as? String ?? ""
        product_id = json["product_id"] as? String ?? ""
        product_name = json["product_name"] as? String ?? ""
        qty = json["qty"] as? String ?? ""
        user_id = json["user_id"] as? String ?? ""
        
    }
    
    func toDictionary() -> [String: Any] {
        var dict = [String: Any]()
        dict["price"] = price
        dict["product_id"] = product_id
        dict["product_name"] = product_name
        dict["qty"] = qty
        dict["user_id"] = user_id
        return dict
    }
    
    class func toArray(arrJson: [[String: Any]]) -> [UserInfo] {
        var arrModels = [UserInfo]()
        for dict in arrJson {
            arrModels.append(UserInfo(json: dict))
        }
        return arrModels
    }
    
   
}
