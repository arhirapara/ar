//
//  LogInInfo.swift
//  Yemeni
//
//  Created by Kartum Infotech on 12/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
class UserInfo {
    var login_token: String = ""
    var user_id: String = ""
    var user: Any?
    var address: String = ""
    var city:String = ""
    var created_at:String = ""
    var email : String = ""
    var first_name: String = ""
    var image: String = ""
    var lang: String = ""
    var last_name: String = ""
    var mobile: String = ""
    var password: String = ""
    var pincode: String = ""
    var profile_image: String = ""
    var status: String = ""
    var updated_at: String = ""
    var verify_code: String = ""
    
    init(json: [String: Any]) {
        login_token = json["login_token"] as? String ?? ""
        user_id = json["user_id"] as? String ?? ""
        user = json["user"]
        if let resultDict = user as? [String: Any] {
            address = resultDict["address"] as? String ?? ""
            city   = resultDict["city"] as? String ?? ""
            created_at = resultDict["created_at"] as? String ?? ""
            email = resultDict["email"] as? String ?? ""
            first_name = resultDict["first_name"] as? String ?? ""
            image = resultDict["image"] as? String ?? ""
            lang = resultDict["lang"] as? String ?? ""
            last_name = resultDict["last_name"] as? String ?? ""
            mobile = resultDict["mobile"] as? String ?? ""
            password = resultDict["password"] as? String ?? ""
            pincode = resultDict["pincode"] as? String ?? ""
            profile_image = resultDict["profile_image"] as? String ?? ""
            status = resultDict["status"] as? String ?? ""
            updated_at = resultDict["updated_at"] as? String ?? ""
            verify_code = resultDict["verify_code"] as? String ?? ""
        }
        
    }
    
    func mapUserObjectForUpdateProfile(json: [String: Any]) {
        address = json["address"] as? String ?? ""
        city   = json["city"] as? String ?? ""
        first_name = json["first_name"] as? String ?? ""
        lang = json["lang"] as? String ?? ""
        last_name = json["last_name"] as? String ?? ""
        mobile = json["mobile"] as? String ?? ""
        pincode = json["pincode"] as? String ?? ""
        profile_image = json["profile_image"] as? String ?? ""
        updated_at = json["updated_at"] as? String ?? ""
    }
    
    func toDictionary() -> [String: Any] {
        var dict = [String: Any]()
        dict["login_token"] = login_token
        dict["user_id"] = user_id
        var userDict = [String: Any]()
        
        userDict["address"] = address
        userDict["city"] = city
        userDict["created_at"] = created_at
        userDict["email"] = email
        userDict["first_name"] = first_name
        userDict["image"] = image
        userDict["lang"] = lang
        userDict["last_name"] = last_name
        userDict["mobile"] = mobile
        userDict["password"] = password
        userDict["pincode"] = pincode
        userDict["profile_image"] = profile_image
        userDict["status"] = status
        userDict["updated_at"] = updated_at
        userDict["verify_code"] = verify_code
        
        dict["user"] = userDict
        
        return dict
    }
    
    func fullName() -> String {
        return (first_name + " " + last_name).trimmed()
    }
    func fullAdress() -> String {
        return (address + ", " + city).trimmed()
    }
    
    func isProfileCompleted() -> Bool {
        return !(fullName().trimmed().isEmpty ||
            city.trimmed().isEmpty ||
            pincode.trimmed().isEmpty ||
            address.trimmed().isEmpty)
    }
}
