//
//  CustomCollectionViewLayout.swift
//  SleepSoundsCollectionViewDemo
//
//  Created by Sunil Zalavadiya on 27/12/19.
//  Copyright © 2019 Sunil Zalavadiya. All rights reserved.
//

import UIKit

class CustomCollectionViewLayoutNew: UICollectionViewLayout {
    // MARK: - Public Properties
    
    override var collectionViewContentSize: CGSize {
        let topmostEdge = cachedItemsAttributes.values.map { $0.frame.minY }.min() ?? 0
        let bottommostEdge = cachedItemsAttributes.values.map { $0.frame.maxY }.max() ?? 0
        return CGSize(width: collectionView!.frame.width, height: bottommostEdge - topmostEdge)
    }
    
    // MARK: - Private Properties

    private var cachedItemsAttributes: [IndexPath: UICollectionViewLayoutAttributes] = [:]
    
    var numberOfItemsPerRow = 2
    var spacing: CGFloat = 10
    var spacingWhenFocused: CGFloat = 10
    var hightFocused: CGFloat = 35
    
    var insets = UIEdgeInsets(top: 10, left: 15, bottom: 10, right: 15)
    var itemSize = CGSize(width: ((UIScreen.main.bounds.width - (3 * 10)) / 2), height: 257.0)
    
    private var continuousFocusedIndex: CGFloat {
        guard let collectionView = collectionView else { return 0 }
        let offset = collectionView.bounds.width / 2 + collectionView.contentOffset.x - itemSize.width / 2
        return offset / (itemSize.width + spacing)
    }
    
    // MARK: - Public Methods
    
    override open func prepare() {
        super.prepare()
        var totalWidth = UIScreen.main.bounds.width - (insets.left + insets.right)
        totalWidth = totalWidth - (CGFloat(numberOfItemsPerRow - 1) * spacing)
        itemSize.width = totalWidth / 2.0
        itemSize.height = 257.0
        
        guard let collectionView = self.collectionView else { return }
        updateInsets()
        guard cachedItemsAttributes.isEmpty else { return }
        //collectionView.decelerationRate = UIScrollView.DecelerationRate.fast
        let itemsCount = collectionView.numberOfItems(inSection: 0)
        for item in 0..<itemsCount {
            let indexPath = IndexPath(item: item, section: 0)
            cachedItemsAttributes[indexPath] = createAttributesForItem(at: indexPath)
        }
    }
    
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        return cachedItemsAttributes
            .map { $0.value }
            .filter { $0.frame.intersects(rect) }
            .map { self.shiftedAttributes(from: $0) }
    }

    // MARK: - Invalidate layout
    
    override func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        if newBounds.size != collectionView?.bounds.size { cachedItemsAttributes.removeAll() }
        return true
    }
    
    override func invalidateLayout(with context: UICollectionViewLayoutInvalidationContext) {
        if context.invalidateDataSourceCounts { cachedItemsAttributes.removeAll() }
        super.invalidateLayout(with: context)
    }
    
    // MARK: - Items
    
    override func layoutAttributesForItem(at indexPath: IndexPath) -> UICollectionViewLayoutAttributes? {
        guard cachedItemsAttributes[indexPath] != nil else { fatalError("No attributes cached") }
        return createAttributesForItem(at: indexPath)//shiftedAttributes(from: attributes)
    }
    
    private func createAttributesForItem(at indexPath: IndexPath) -> UICollectionViewLayoutAttributes? {
        let attributes = UICollectionViewLayoutAttributes(forCellWith: indexPath)
        guard collectionView != nil else { return nil }
        let divisior = Int(indexPath.item / numberOfItemsPerRow)
//        let modulo = (indexPath.item+1) % numberOfItemsPerRow
        attributes.frame.size = itemSize
        if (indexPath.item % numberOfItemsPerRow) == 1 {
            attributes.frame.origin.y = (itemSize.height * CGFloat(divisior)) + CGFloat(((divisior + 1) * 10)) + hightFocused
        } else {
            attributes.frame.origin.y = (itemSize.height * CGFloat(divisior)) + CGFloat(((divisior + 1) * 10))
        }
//        print("indexpath = ", indexPath.item)
//        print("(CGFloat((indexPath.item % 3)) * itemSize.width) = ", (CGFloat((indexPath.item % numberOfItemsPerRow)) * itemSize.width))
//        print("(CGFloat(modulo) * 10) = ", (CGFloat(modulo) * 10))
//        print("\n")
        if (indexPath.item % numberOfItemsPerRow) == 1 {
            attributes.frame.origin.x = insets.left + (CGFloat((indexPath.item % numberOfItemsPerRow)) * itemSize.width) + (CGFloat((indexPath.item % numberOfItemsPerRow)) * 10)
        } else {
            attributes.frame.origin.x = insets.left + (CGFloat((indexPath.item % numberOfItemsPerRow)) * itemSize.width) + (CGFloat((indexPath.item % numberOfItemsPerRow)) * 10)
        }
        
        //attributes.frame.origin.x = CGFloat(indexPath.item) * (itemSize.width + 10)
        return attributes
    }
    
    private func shiftedAttributes(from attributes: UICollectionViewLayoutAttributes) -> UICollectionViewLayoutAttributes {
        return attributes
    }
    
    private func updateInsets() {
        guard let collectionView = collectionView else { return }
        collectionView.contentInset.bottom = hightFocused + 10
    }
}
