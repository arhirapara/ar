//
//  TabView.swift
//  Yemeni
//
//  Created by Kartum Infotech on 03/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class TabView: UIView {
    
    // MARK:- IBOutlets
    @IBOutlet var viewSubCorner: UIView!
    @IBOutlet var containerView: UIView!
    @IBOutlet var lblTabCollection: [UILabel]!
    @IBOutlet var imagviewTabCollection: [UIImageView]!
    @IBOutlet var btnTabCollection: UIButton!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setTabView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.setTabView()
    }
    
    //MARK:-Functions
    private func setTabView(){
        Bundle.main.loadNibNamed("TabView", owner: self, options: nil)
        addSubview(containerView)
        containerView.frame = self.bounds
        containerView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        viewSubCorner.addCornerRadius(viewSubCorner.frame.height/2.0)
        viewSubCorner.addShadow(color: UIColor.black, opacity: 0.5, offset: CGSize(width: 0, height: 1), radius: 3)
        
        for imageView in imagviewTabCollection {
            let stImageName = imageView.accessibilityIdentifier!
            if tag == imageView.tag {
                imageView.image = UIImage(named: stImageName)?.tintWithColor(Application.Color.TAB_Select_Color_CF932A)
            }
            else { imageView.image = UIImage(named: stImageName)?.tintWithColor(UIColor(named: "Description_B8AFA7")!) }
        }
        
        for lbl in lblTabCollection {
            lbl.textColor = tag == lbl.tag ? Application.Color.TAB_Select_Color_CF932A : UIColor(named: "Description_B8AFA7")!
            lbl.font = tag == lbl.tag ? UIFont(name: Application.Font.PROXIMANOVA_BOLD, size: 10) : UIFont(name: Application.Font.PROXIMANOVA_THIN, size: 10)
        }
        
    }
    
    //MARK:- IBAction
    @IBAction func onClickViewTab(_ sender: UIButton) {
        if (tag != sender.tag) {
            let tabTag = TabBarNavigationOptions(rawValue: sender.tag)!
            Utility.appDelegate().tabBarNavigation(tabTag)
        }
    }
}
