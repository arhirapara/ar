//
//  TabBarVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 11/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class TabBarVC: UITabBarController {
    
    // MARK: - Properties
    var customTabBarView: TabView!
    var forceHideTabBar = false
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.isNavigationBarHidden = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabBar.isHidden = true
        tabBar.barTintColor = UIColor.clear
        tabBar.backgroundImage = UIImage()
        tabBar.shadowImage = UIImage()
        
        customTabBarView = (Bundle.main.loadNibNamed("TabView", owner: nil, options: nil)!.first as! TabView)
        customTabBarView.delegate = self
        
        
        var tabBarHeight: CGFloat = tabBar.frame.size.height
        if #available(iOS 11.0, *) {
            if (UIApplication.shared.keyWindow?.safeAreaInsets.top)! > CGFloat(0.0) {
                tabBarHeight += UIApplication.shared.keyWindow!.safeAreaInsets.bottom
            }
        }
        
        if tabBarHeight < 60 { tabBarHeight = 68 }
        else { tabBarHeight += 20 }
        
        customTabBarView.frame = CGRect(x: 0.0, y: view.frame.size.height - tabBar.frame.size.height, width: view.frame.size.width, height: tabBarHeight)
        
        view.addSubview(customTabBarView)
        view.backgroundColor = .clear
        
        customTabBarView.translatesAutoresizingMaskIntoConstraints = false
        
        customTabBarView.heightAnchor.constraint(equalToConstant: tabBarHeight).isActive = true
        self.view.leadingAnchor.constraint(equalTo: customTabBarView!.leadingAnchor, constant: 0).isActive = true
        self.view.trailingAnchor.constraint(equalTo: customTabBarView!.trailingAnchor, constant: 0).isActive = true
        self.view.bottomAnchor.constraint(equalTo: customTabBarView!.bottomAnchor, constant: 0).isActive = true
        
        self.view.layoutIfNeeded()
        
        if forceHideTabBar {
            self.tabBar.isHidden = true
            self.customTabBarView.isHidden = true
        }
        
        setupViewControllers()
    }
    
    private func setupViewControllers() {
        var viewControllers = [AnyObject]()
        
        let navController1: UINavigationController = AppStoryboard.Home.instance.instantiateViewController(withIdentifier: "HomeNavVC") as! UINavigationController
        let navController2: UINavigationController = AppStoryboard.Order.instance.instantiateViewController(withIdentifier: "OrderNavVC") as! UINavigationController
        let navController3: UINavigationController = AppStoryboard.Delivery.instance.instantiateViewController(withIdentifier: "DeliveryNavVC") as! UINavigationController
        let navController4: UINavigationController = AppStoryboard.Profile.instance.instantiateViewController(withIdentifier: "ProfileNavVC") as! UINavigationController
        
        Utility.appDelegate().setupNavigationBarApperance(navigationBar: navController1.navigationBar, color: .clear)
        
        viewControllers = [navController1, navController2, navController3, navController4]
        
        self.viewControllers = viewControllers as? [UIViewController]
        if AppPrefsManager.shared.getLoggedInUserInfo().isProfileCompleted() == false {
            customTabBarView.selectTabAt(index: 3)
            tabSelecteAtIndex(tabIndex: 3)
        } else {
            customTabBarView.selectTabAt(index: 0)
            tabSelecteAtIndex(tabIndex: 0)
        }
    }
    
    func setTabBarHidden(tabBarHidden: Bool, vc: UIViewController?) {
        if tabBarHidden {
            self.tabBar.isHidden = true
            self.customTabBarView.isHidden = tabBarHidden
            
            vc?.edgesForExtendedLayout = UIRectEdge.bottom
        } else {
            if !forceHideTabBar {
                self.tabBar.isHidden = true
                self.customTabBarView.isHidden = tabBarHidden
                
                vc?.edgesForExtendedLayout = UIRectEdge.top
            }
        }
    }
    
}

// MARK: - CustomTabBarViewDelegate
extension TabBarVC: CustomTabBarViewDelegate {
    
    func tabSelecteAtIndex(tabIndex: Int) {
        
        let selectedVC = self.viewControllers![tabIndex]
        
        selectedIndex = tabIndex
        
        if self.selectedViewController == selectedVC {
            let navVc = self.selectedViewController as! UINavigationController
            navVc.popToRootViewController(animated: false)
        }
        
        super.selectedViewController = selectedViewController
        
    }
}
