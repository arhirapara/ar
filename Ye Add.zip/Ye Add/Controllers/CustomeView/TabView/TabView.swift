//
//  TabView.swift
//  Yemeni
//
//  Created by Kartum Infotech on 03/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

protocol CustomTabBarViewDelegate: AnyObject {
    func tabSelecteAtIndex(tabIndex: Int)
}

class TabView: UIView {
    
    // MARK:- IBOutlets
    @IBOutlet var viewSubCorner: UIView!
    @IBOutlet var lblTabCollection: [UILabel]!
    @IBOutlet var imagviewTabCollection: [UIImageView]!
    @IBOutlet var btnTab: [UIButton]!
    @IBOutlet weak var lblHome: UILabel!
    @IBOutlet weak var lblOrder: UILabel!
    @IBOutlet weak var lblDelivery: UILabel!
    @IBOutlet weak var lblProfile: UILabel!
    
    //MARK:-Properties
    private var normalColor = UIColor(named: "Description_B8AFA7")!
    private var selectedColor = Application.Color.TAB_Select_Color_CF932A
    private var lastIndex = 0
    weak var delegate: CustomTabBarViewDelegate?
    
    override func draw(_ rect: CGRect) {
        viewSubCorner.addCornerRadius(viewSubCorner.frame.height/2.0)
    }
    
    // MARK: - View Initialize
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        initializeSetup()
        setTabView()
    }
    
    // MARK: - Methods
    private func initializeSetup() {
        lblHome.text = getLocalizedString(key: .Home)
        lblOrder.text = getLocalizedString(key: .Order)
        lblProfile.text = getLocalizedString(key: .Profile)
        lblDelivery.text  = getLocalizedString(key: .Delivery)
    }
    
    //MARK:-Functions
    private func setTabView(){
        viewSubCorner.addShadow(color: UIColor.black, opacity: 0.5, offset: CGSize(width: 0, height: 1), radius: 3)
        for imageView in imagviewTabCollection {
            let stImageName = imageView.accessibilityIdentifier!
            if lastIndex == imageView.tag {
                imageView.image = UIImage(named: stImageName)?.tintWithColor(Application.Color.TAB_Select_Color_CF932A)
            }
            else { imageView.image = UIImage(named: stImageName)?.tintWithColor(UIColor(named: "Description_B8AFA7")!) }
        }
        
        for lbl in lblTabCollection {
            lbl.textColor = lastIndex == lbl.tag ? Application.Color.TAB_Select_Color_CF932A : UIColor(named: "Description_B8AFA7")!
            lbl.font = lastIndex == lbl.tag ? UIFont(name: Application.Font.PROXIMANOVA_BOLD, size: 10) : UIFont(name: Application.Font.PROXIMANOVA_THIN, size: 10)
        }
        
    }
    
    func selectTabAt(index: Int) {
        if AppPrefsManager.shared.getLoggedInUserInfo().isProfileCompleted() == false && index != 3 {
            Utility.windowMain()?.showToastAtBottom(message: "Please complete profile to continue")
            return
        }
        lastIndex = index
        setTabView()
        delegate?.tabSelecteAtIndex(tabIndex: lastIndex)
    }
    
    //MARK:- IBAction
    @IBAction func onClickViewTab(_ sender: UIButton) {
        lastIndex = sender.tag
        selectTabAt(index: lastIndex)
    }
}
