//
//  FeedbackView.swift
//  Yemeni
//
//  Created by Kartum Infotech on 07/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class FeedbackView: UIView {
    
    // MARK:- IBOutlets
    @IBOutlet var containerView: UIView!
    @IBOutlet var viewLogOut: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setFeedbackView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.setFeedbackView()
    }
    
    //MARK:-Functions
    private func setFeedbackView(){
        Bundle.main.loadNibNamed("TabView", owner: self, options: nil)
        addSubview(containerView)
        containerView.frame = self.bounds
        containerView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
    }
    
    private func hideShowButtion(){
        if self.tag == 10010{
            //LogOut Show
            //View Height :- 180
        }
        else {
            //LogOut Hide
            //View Height :- 146
        }
    }
    
    @IBAction func onBtnSendFeedback(_ sender: UIButton) {
    }
    @IBAction func onBtnRateUs(_ sender: UIButton) {
    }
    
    @IBAction func onBtnLogOut(_ sender: UIButton) {
    }
}
