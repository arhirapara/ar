//
//  SignUpVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 11/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class SignUpVC: BaseViewController {
    
    //MARK:- IBOUTLET
    @IBOutlet var viewOfTextField: [UIView]!
    @IBOutlet var txtfieldCollection: [UITextField]!
    @IBOutlet weak var btnSighup: UIView!
    @IBOutlet weak var btnOfSignUp: UIButton!
    @IBOutlet weak var lblOfSignUp: UILabel!
    @IBOutlet weak var lblEasyToSignUp: UILabel!
    @IBOutlet weak var txtFirstNAme: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtEmailId: UITextField!
    @IBOutlet weak var txtPasword: UITextField!
    @IBOutlet weak var txtComfirmPassword: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    
    // MARK: - Properties
    private let viewModel = SignupViewModel()
    
    //MARK:- LIFECYCLES
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUi()
          let data = AppPrefsManager.shared.getLoggedInUserInfo()
        DLog(data.mobile)
        DLog(data.password)
        DLog(data.user_id)
    }
    
    //MARK:- Functions
    func setUpUi(){
        for textView in txtfieldCollection{
            textView.addCornerRadius(textView.frame.size.height / 2)
            textView.applyBorder(0.3, borderColor: Application.Color.Facebook_d19314)
            textView.addLeftPadding(padding: 20)
        }
        btnSighup.addCornerRadius(btnSighup.frame.size .height / 2)
        btnSighup.addShadow(color: Application.Color.Facebook_d19314, opacity: 0.7, offset: CGSize(width: 0, height: 0), radius: 2)
        btnOfSignUp.setTitle(getLocalizedString(key:.Signup), for: .normal)
        lblOfSignUp.text = getLocalizedString(key: .Signup)
        lblEasyToSignUp.text = getLocalizedString(key: .SighnUpDescreption)
    }
    //MARK:- IBACTION
    @IBAction func onBtnSignUp(_ sender: UIButton) {
        view.endEditing(true)
        viewModel.firstName = txtFirstNAme.text!
        viewModel.lastName = txtLastName.text!
        viewModel.email = txtEmailId.text!
        viewModel.password = txtPasword.text!
        viewModel.confirmPassword = txtComfirmPassword.text!
        viewModel.Phone = txtPhone.text!
        viewModel.Lang = "ar"
        
        let validation = viewModel.validateForm()
        if validation.isValid {
            signupUserAtServer()
        } else {
            Utility.windowMain()?.showToastAtBottom(message: validation.message)
        }
    }
    
    @IBAction func OnBtnToBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    // MARK: - API calls
    private func signupUserAtServer() {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        LoaderManager.showLoader()
        viewModel.signupUser { (success, message) in
            LoaderManager.hideLoader()
            if success {
                DLog(AppPrefsManager.shared.getLoggedInUserInfo())
                Utility.windowMain()?.showToastAtBottom(message: message)
                self.navigationController?.popViewController(animated: true)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
}
