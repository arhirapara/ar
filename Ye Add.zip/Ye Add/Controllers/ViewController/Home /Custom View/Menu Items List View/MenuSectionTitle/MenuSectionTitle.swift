//
//  MenuSectionTitle.swift
//  Yemeni
//
//  Created by Kartum Infotech on 27/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class MenuSectionTitle: UIView {

    @IBOutlet var lblMenuTitle: UILabel!
    
    
}
