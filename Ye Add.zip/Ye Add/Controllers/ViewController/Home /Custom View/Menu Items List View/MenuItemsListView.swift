//
//  MenuItemsListView.swift
//  Yemeni
//
//  Created by Kartum Infotech on 27/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
protocol menuItemListDelegate {
    func selectedMenuIndex(_ index: Int)
}

class MenuItemsListView: UIView {
    
    // MARK:- IBOutlets
    @IBOutlet var tableViewMenuList: UITableView!
    
    //MARK:-Properties
    var delegate: menuItemListDelegate?
    var arrayItemsList = [ItemInfo]()
    var productId : String?
    var viewModel = MyCartViewModel()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        tableViewMenuList.delegate = self
        tableViewMenuList.dataSource = self
        tableViewMenuList.register(UINib.init(nibName: "MenuListCell", bundle: nil), forCellReuseIdentifier: "MenuListCell")
    }
    
    //MARK:-Functions
    func reloadData()  {
        var height = 160
        if arrayItemsList.count < 5{
            height += 30
        }
        heightAnchor.constraint(equalToConstant: CGFloat(160 * arrayItemsList.count)).isActive = true
        tableViewMenuList.rowHeight = 150
        tableViewMenuList.tableFooterView = UIView(frame: CGRect.zero)
        tableViewMenuList.reloadData()
    }
    
    private func postProductAddedToCartNotification(info: ItemInfo) {
        NotificationCenter.default.post(name: .productAddedToCart, object: info)
    }
//    NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: nil)
    //MARK- API CALL

    
    func addToCart(quantity: String, productId: String, increased: Bool, indexPath: IndexPath) {
        viewModel.addToCart(qty: quantity, productId: productId) { (success, message) in
            if success {
                let dataObject = self.arrayItemsList[indexPath.row]
                self.postProductAddedToCartNotification(info: dataObject)
            } else {
                if !message.isEmpty {
                    Utility.windowMain()?.showToastAtBottom(message: message)
                }
                
                if let cell = self.tableViewMenuList.cellForRow(at: indexPath) as? MenuListCell {
                    let dataObject = self.arrayItemsList[indexPath.row]
                    if increased {
                        dataObject.decreaseQuantity()
                    } else {
                        if dataObject.quantityInt() == 0 {
                            cell.viewCart.isHidden = false
                        }
                        dataObject.increaseQuantity()
                    }
                    cell.lblNumberOfItem.text = dataObject.quantity
                }
            }
        }
    }
}


extension MenuItemsListView: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //        if section == 0{
        return arrayItemsList.count
        //        }
        //        else {
//                    return 10
        //        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : MenuListCell = tableView.dequeueReusableCell(withIdentifier: "MenuListCell") as! MenuListCell
        cell.delegate = self
        cell.btnDecrease.tag = indexPath.row
        cell.btnIncrease.tag = indexPath.row
        let dictData = arrayItemsList[indexPath.row]
        cell.configItems(indexPath, data: dictData)
        cell.addToCart = { [weak self] (index) in
            print(index)
            let indexpath = IndexPath(item: index, section: 0)
            let cell = self!.tableViewMenuList.cellForRow(at: indexpath) as! MenuListCell
            let dataObject = self?.arrayItemsList[index]
            
            dataObject?.increaseQuantity()
            
            cell.lblNumberOfItem.text = dataObject?.quantity
            cell.viewCart.isHidden = false
            self?.addToCart(quantity: dataObject!.quantity, productId: dataObject!.product_id, increased: true, indexPath: indexPath)
               }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         self.delegate?.selectedMenuIndex(indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let menuSectionTitle: MenuSectionTitle = UIView.fromNib()
        menuSectionTitle.lblMenuTitle.text = getLocalizedString(key: .Popular)
        return menuSectionTitle
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 35
    }
}

extension MenuItemsListView: icreaseDecreaseItemDelegate {
    
    func increseItem(_ index: Int) {
        
        let indexPath = IndexPath(item: index, section: 0)
        let cell = tableViewMenuList.cellForRow(at: indexPath) as! MenuListCell
        let dataObject = arrayItemsList[index]
        dataObject.increaseQuantity()
        cell.viewCart.isHidden = false
        cell.lblNumberOfItem.text = dataObject.quantity
        addToCart(quantity: dataObject.quantity, productId: dataObject.product_id, increased: true, indexPath: indexPath)
    }

    func decreseItem(_ index: Int) {
        let indexPath = IndexPath(item: index, section: 0)
        let cell = tableViewMenuList.cellForRow(at: indexPath) as! MenuListCell
        cell.viewCart.isHidden = false
        let dataObject = arrayItemsList[index]
        dataObject.decreaseQuantity()
        cell.lblNumberOfItem.text = dataObject.quantity
        addToCart(quantity: dataObject.quantity, productId: dataObject.product_id, increased: true, indexPath: indexPath)
        if dataObject.quantityInt() == 0 {
            cell.viewCart.isHidden = true
        }
    }
}
