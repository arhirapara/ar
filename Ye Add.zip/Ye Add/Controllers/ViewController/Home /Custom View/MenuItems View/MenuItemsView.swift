//
//  MenuItemsView.swift
//  Yemeni
//
//  Created by Kartum Infotech on 27/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
protocol menuItemViewDelegate {
    func selectedCellIndex(_ index: Int, totalAddItem: Int)
    func navigationToDetailVC(_ index: Int, totalAddItem: Int)
    func toAllItem()
}

class MenuItemsView: UIView {
    
    // MARK:- IBOutlets
    @IBOutlet var collectionViewMenuItemList: UICollectionView!
    @IBOutlet weak var btnSeeAll: UIButton!
    
    //MARK:-Properties
    var delegate: menuItemViewDelegate?
    var arrayItems = [ItemInfo]()
    var viewModel = MyCartViewModel()
//    var numberOfItem:Int = 0
    var coutArray:Int = -1
    
    //MARK: Constant
    let HARIZONTAL_SPCE_IMAGE: CGFloat          = 2
    let VERTICAL_SPCE_IMAGE: CGFloat            = 15
    let COLUMN_IMAGE: CGFloat                   = 2
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        btnSeeAll.setTitle(getLocalizedString(key: .SeeAll), for: .normal)
        collectionViewMenuItemList.delegate = self
        collectionViewMenuItemList.dataSource = self
        collectionViewMenuItemList.register(UINib(nibName: "MenuCell", bundle: nil), forCellWithReuseIdentifier: "MenuCell")
        
    }
    
    //MARK:-Functions
    func reloadData()  {
        heightAnchor.constraint(equalToConstant: CGFloat(300)).isActive = true
        coutArray = arrayItems.count
        if coutArray > 4{
           coutArray = 4
        }
        collectionViewMenuItemList.reloadData()
    }
    
    func setCartView(_ cartIndex: Int){
        
    }
   
    private func postProductAddedToCartNotification(info: ItemInfo) {
        NotificationCenter.default.post(name: .productAddedToCart, object: info)
    }
    
     //MARK:- API CALL

    func addToCart(quantity: String, productId: String, increased: Bool, indexPath: IndexPath) {
        LoaderManager.showLoader()
        viewModel.addToCart(qty: quantity, productId: productId) { (success, message) in
               LoaderManager.hideLoader()
            if success {
             
                let dataObject = self.arrayItems[indexPath.row]
                self.postProductAddedToCartNotification(info: dataObject)
            } else {
                if !message.isEmpty {
                    Utility.windowMain()?.showToastAtBottom(message: message)
                }
                
                if let cell = self.collectionViewMenuItemList.cellForItem(at: indexPath) as? MenuCell {
                    let dataObject = self.arrayItems[indexPath.row]
                    if increased {
                        dataObject.decreaseQuantity()
                    } else {
                        if dataObject.quantityInt() == 0 {
                            cell.viewCartAdd.isHidden = false
                        }
                        dataObject.increaseQuantity()
                    }
                    cell.lblTotalItemCount.text = dataObject.quantity
                }
            }
        }
    }
    
    // MARK: - Actions
    @objc func onBtnMarkerNext(_ sender : UIButton) {
        let indexPath = IndexPath.init(row: sender.tag, section: 0)
        let dataObject = arrayItems[sender.tag]
        DLog("onBtnMarkerNext index = \(sender.tag)")
        DLog("onBtnMarkerNext = \(dataObject.toDictionary())")
        let cell = collectionViewMenuItemList.cellForItem(at: indexPath) as! MenuCell
        let item: Int = Int(cell.lblTotalItemCount.text ?? "0") ?? 0
        delegate?.navigationToDetailVC(sender.tag, totalAddItem: item)
    }
    @IBAction func btnSeeAllItem(_ sender: UIButton) {
        delegate?.toAllItem()
    }
}

extension MenuItemsView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return coutArray
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MenuCell", for: indexPath) as! MenuCell
        cell.delegate = self
        let objData = arrayItems[indexPath.row]
        cell.configItems(indexPath, data: objData)
        cell.btnNextFood.addTarget(self, action: #selector(onBtnMarkerNext), for: .touchUpInside)
        cell.addToCart = { [weak self] (index) in
            print(index)
            self?.setCartView(index)
            let indexPath = IndexPath.init(row: index, section: 0)
            let dataObject = self?.arrayItems[index]
            let cell = self?.collectionViewMenuItemList.cellForItem(at: indexPath) as! MenuCell
            dataObject?.increaseQuantity()
            cell.viewCartAdd.isHidden = false
            cell.lblTotalItemCount.text = dataObject?.quantity
//            self?.addToCart(1, productid: dataObject!.product_id)
            self?.addToCart(quantity: dataObject!.quantity, productId: dataObject!.product_id, increased: true, indexPath: indexPath)
            
            cell.addCornerRadius(22.5)
            cell.contentView.addCornerRadius(22.5)
            cell.addShadow(color: UIColor.gray, opacity: 0.5, offset: CGSize(width: 0, height: 1), radius: 4)
        }
        cell.id = objData.product_id
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionViewMenuItemList.cellForItem(at: indexPath) as! MenuCell
        let item: Int = Int(cell.lblTotalItemCount.text ?? "0") ?? 0
        delegate?.selectedCellIndex(indexPath.row, totalAddItem: item)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat { return HARIZONTAL_SPCE_IMAGE }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat { return VERTICAL_SPCE_IMAGE }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //let width: CGFloat = (collectionView.frame.width - ((COLUMN_IMAGE - 1) * HARIZONTAL_SPCE_IMAGE)) / COLUMN_IMAGE
        return CGSize(width: (collectionView.frame.width / 2) - 10, height: 257)
    }
}

extension MenuItemsView: icreaseItemDelegate {
    
    
    func increseItem(_ index: Int) {
        let indexPath = IndexPath.init(row: index, section: 0)
        let cell = collectionViewMenuItemList.cellForItem(at: indexPath) as! MenuCell
        
         let objData = arrayItems[index]
        objData.increaseQuantity()
        
//        numberOfItem = Int(cell.lblTotalItemCount.text ?? "1") ?? 1
        cell.viewCartAdd.isHidden = false
        cell.lblTotalItemCount.text = objData.quantity
        addToCart(quantity: objData.quantity, productId: objData.product_id, increased: true, indexPath: indexPath)
//        self.addToCart(objData.quantityInt(), productid: objData.product_id)
        
//        print(numberOfItem)
    }
    
    func decreseItem(_ index: Int) {
        let indexPath = IndexPath.init(row: index, section: 0)
        let cell = collectionViewMenuItemList.cellForItem(at: indexPath) as! MenuCell
        cell.viewCartAdd.isHidden = false
        let objData = arrayItems[index]
        objData.decreaseQuantity()
//        numberOfItem = Int(cell.lblTotalItemCount.text ?? "1") ?? 1
        cell.lblTotalItemCount.text = objData.quantity
        addToCart(quantity: objData.quantity, productId: objData.product_id, increased: true, indexPath: indexPath)
        
        if objData.quantityInt() == 0 {
            cell.viewCartAdd.isHidden = true
        }
        
//        objData.product_id
//        if(numberOfItem != 0){
//            numberOfItem -= 1
//            self.addToCart(numberOfItem, productid: objData.product_id)
//            cell.lblTotalItemCount.text = "\(numberOfItem)"
//            print(numberOfItem)
//        }
//        if numberOfItem == 0{
//            cell.viewCartAdd.isHidden = true
//        }
    }
}

    
    

