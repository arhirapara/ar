//
//  HomeVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 27/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class HomeVC: BaseViewController {
    
    // MARK: - IBOutlets
    //@IBOutlet var lblAddress: MarqueeLabel!
    @IBOutlet var lblAddress: UILabel!
    @IBOutlet var imageViewProfile: UIImageView!
    @IBOutlet var txtSearch: UITextField!
    @IBOutlet var collectionViewMenuItems: UICollectionView!
    @IBOutlet var viewScrollable: ScrollableStackView!
    @IBOutlet weak var viewOfImageview: UIView!
    @IBOutlet weak var btntoProfile: UIButton!
    @IBOutlet weak var viewContainerSearch: UIView!
    @IBOutlet weak var tblSearchItem: UITableView!
    
    // MARK: - Properties
    var viewModel = GetCategoriesViewModel()
    var viewMOdelOfProfile = UpdateProfileViewModel()
    var numberOfItem:Int = 0
    var items : Int?
    var arrOfFilteredItem = [""]
    
    private var avatarImage = UIImage(named: "user_avatar")?.tintWithColor(UIColor(named: "foodNameLable_ce7c37")!)
    
    //MARK: - LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        getCategoryList()
        addProductAddedToCartNotificationObservers()
        addProductRemovedfromCartNotificationObservers()
        addOrderPlacedNotificationObservers()
        registerKeyboardNotificationObservers()
        NotificationCenter.default.addObserver(self, selector: #selector(onBecomeFirstResponderHomeSearchNotification(_:)), name: .becomeFirstResponderHomeSearch, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        imageViewProfile.sd_setImage(with: URL(string: AppPrefsManager.shared.getLoggedInUserInfo().profile_image.encodedUrlQueryString()), placeholderImage: avatarImage)
    }
    
    override func viewLayoutMarginsDidChange() {
        
                imageViewProfile.addCornerRadius(imageViewProfile.frame.height/2.0)
//        btntoProfile.addCornerRadius(btntoProfile.frame.size.width / 2)
        viewOfImageview.addShadow(color: UIColor.gray, opacity: 0.6, offset: CGSize(width: 0, height: 0), radius: 6)
    }
    
    // MARK: - Functions
    func setupUI() {
        //lblAddress.type = .continuous
        //lblAddress.speed = .duration(25)
        //        lblAddress.fadeLength = 35.0
        //        lblAddress.trailingBuffer = 20.0
        txtSearch.placeholder = getLocalizedString(key: .SearchHome)
        //        imageViewProfile.applyBorder(0.5, borderColor: Application.Color.Next_4d2612)
        
        self.collectionViewSetup()
        
        self.viewScrollable.stackView.translatesAutoresizingMaskIntoConstraints = false
        viewScrollable.scrollView.contentInset  = UIEdgeInsets(top: 0, left: 0, bottom: 80, right: 0)
        
         let profileInfo = AppPrefsManager.shared.getLoggedInUserInfo()
        lblAddress.text = profileInfo.fullAdress()
        setupTextField()
        setupTableViews()
      

    }
    
    private func setupTextField() {
        txtSearch.addTarget(self, action: #selector(onTextFieldTextDidChange(sender:)), for: .editingChanged)
    }
    
    private func setupTableViews() {
        tblSearchItem.register(HomeSearchTableViewCell.nib, forCellReuseIdentifier: HomeSearchTableViewCell.identifier)
        tblSearchItem.delegate = self
        tblSearchItem.dataSource = self
    }
    
    func setScrollUIView()  {
        let _ = viewScrollable.stackView.subviews.map {$0.removeFromSuperview()}
        for i in 0..<2 {
            if i == 0 {
                if !viewModel.categoryList.item_list.isEmpty{
                    let menuItemsView: MenuItemsView = UIView.fromNib()
                    viewScrollable.stackView.addArrangedSubview(menuItemsView)
                    menuItemsView.arrayItems = viewModel.categoryList.item_list
                    menuItemsView.delegate = self
                    menuItemsView.reloadData()
                }
            }
            else {
                if !viewModel.categoryList.pupularlist.isEmpty{
                    let menuItemsListView: MenuItemsListView = UIView.fromNib()
                    menuItemsListView.delegate = self
                    menuItemsListView.arrayItemsList = viewModel.categoryList.pupularlist
                    viewScrollable.stackView.addArrangedSubview(menuItemsListView)
                    menuItemsListView.reloadData()
                }
            }
        }
    }
    
    func collectionViewSetup()  {
        collectionViewMenuItems.delegate = self
        collectionViewMenuItems.dataSource = self
        collectionViewMenuItems.register(UINib(nibName: "MenuitemsCell", bundle: nil), forCellWithReuseIdentifier: "MenuitemsCell")
    }
    
    func setupProductUI(_ productObject : ItemInfo, qty: Int) {
        if let menucell = view.view(withId: productObject.product_id) as? MenuCell{
            menucell.lblTotalItemCount.text = "\(qty)"
        }
    }
    
    private func goToProductDetailsScreen(productInfo: ItemInfo, productId: String, fromSearch: Bool = false) {
        let nextVc = MenuDetailsVC.instantiate(fromAppStoryboard: .Home)
        nextVc.viewModel.productInfo = productInfo
        nextVc.viewModel.productId = productId
        nextVc.fromSearch = fromSearch
        navigationController?.pushViewController(nextVc, animated: true)
    }
    
    // MARK: - Events
    @objc private func onTextFieldTextDidChange(sender: UITextField) {
        if sender == txtSearch {
            searchItemList()
        }
    }
    
    @objc private func onBecomeFirstResponderHomeSearchNotification(_ notification: Notification) {
        txtSearch.becomeFirstResponder()
    }
    
    override func onProductAddedToCartNotification(_ notification: Notification) {
        if let info = notification.object as? ItemInfo {
            for currentInfo in viewModel.categoryList.item_list {
                if currentInfo.product_id == info.product_id {
                    currentInfo.quantity = info.quantity
                    break
                }
            }
            for currentInfo in viewModel.categoryList.pupularlist {
                if currentInfo.product_id == info.product_id {
                    currentInfo.quantity = info.quantity
                    break
                }
            }
            for subview in viewScrollable.stackView.arrangedSubviews {
                if let currentView = subview as? MenuItemsView {
                    currentView.reloadData()
                }
                if let currentView = subview as? MenuItemsListView {
                    currentView.reloadData()
                }
            }
        }
    }
    
    override func onProductRemovedFromCartNotification(_ notification: Notification) {
        if let info = notification.object as? ProductItemInfo {
            for currentInfo in viewModel.categoryList.item_list {
                if currentInfo.product_id == info.product_id {
                    currentInfo.quantity = "0"
                    break
                }
            }
            for currentInfo in viewModel.categoryList.pupularlist {
                if currentInfo.product_id == info.product_id {
                    currentInfo.quantity = "0"
                    break
                }
            }
            for subview in viewScrollable.stackView.arrangedSubviews {
                if let currentView = subview as? MenuItemsView {
                    currentView.reloadData()
                }
                if let currentView = subview as? MenuItemsListView {
                    currentView.reloadData()
                }
            }
        }
    }
    
    override func onOrderPlacedNotification(_ notification: Notification) {
        if var arrInfo1 = notification.object as? [ProductItemInfo] {
            var arrInfo2 = [ProductItemInfo]()
            arrInfo2.append(contentsOf: arrInfo1)
            for currentInfo in viewModel.categoryList.item_list {
                for (index, palcedInfo) in arrInfo1.enumerated() {
                    if currentInfo.product_id == palcedInfo.product_id {
                        currentInfo.quantity = "0"
                        arrInfo1.remove(at: index)
                        break
                    }
                }
            }
            for currentInfo in viewModel.categoryList.pupularlist {
                for (index, palcedInfo) in arrInfo2.enumerated() {
                    if currentInfo.product_id == palcedInfo.product_id {
                        currentInfo.quantity = "0"
                        arrInfo2.remove(at: index)
                        break
                    }
                }
            }
            for subview in viewScrollable.stackView.arrangedSubviews {
                if let currentView = subview as? MenuItemsView {
                    currentView.reloadData()
                }
                if let currentView = subview as? MenuItemsListView {
                    currentView.reloadData()
                }
            }
        }
    }
    
    //MARK:- API CALL
    private func getCategoryList() {
        LoaderManager.showLoader()
        viewModel.categoryList { (success, message) in
            LoaderManager.hideLoader()
            if success {
                self.getCategoryItems(self.viewModel.dictSelectedData.category_id)
                // self.performSegue(withIdentifier: "segueSignupSuccess", sender: nil)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
    
    private func getCategoryItems(_ categoryId: String) {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        LoaderManager.showLoader()
        viewModel.category_id = categoryId
        viewModel.getItems { (success, message) in
            LoaderManager.hideLoader()
            if success {
                self.collectionViewMenuItems.reloadData()
                self.setScrollUIView()
            }
            else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
    
    private func searchItemList() {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        guard let keyword = txtSearch.text, !keyword.trimmed().isEmpty else {
            viewModel.searchRequest?.cancel()
            viewModel.arrOfSearchProduct.removeAll()
            tblSearchItem.reloadData()
            viewContainerSearch.isHidden = true
            return
        }
        LoaderManager.showLoader()
        viewModel.searchItems(keyword: keyword) { (success, message) in
            LoaderManager.hideLoader()
            if success {
                self.viewContainerSearch.isHidden = self.viewModel.arrOfSearchProduct.isEmpty
                self.tblSearchItem.reloadData()
                // self.performSegue(withIdentifier: "segueSignupSuccess", sender: nil)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
    
    private func fetchItemsForCategoryAndGoToListingScreen(searchInfo: SearchCatagoryInfo) {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        
        let categoryViewModel = GetCategoriesViewModel()
        categoryViewModel.category_id = searchInfo.category_id
        categoryViewModel.categoryName = searchInfo.category_name
        LoaderManager.showLoader()
        categoryViewModel.getItems { (success, message) in
            LoaderManager.hideLoader()
            if success {
                let nextVc = MenuItemsListVC.instantiate(fromAppStoryboard: .Home)
                nextVc.viewModelCategory = categoryViewModel
                self.navigationController?.pushViewController(nextVc, animated: true)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
    
    // MARK: - Actions
    @IBAction func btnToEditProflile(_ sender: UIButton) {
        if let customTabVc = navigationController?.tabBarController as? TabBarVC {
            customTabVc.customTabBarView.selectTabAt(index: 3)
        } else {
            let nextVc = ProfileVC.instantiate(fromAppStoryboard: .Profile)
            navigationController?.pushViewController(nextVc, animated: true)
        }
    }
    
    // MARK: -
    deinit {
        removeProductAddedToCartNotificationObservers()
    }
}

//MARK: - menuItemListDelegate
extension HomeVC: menuItemListDelegate {
    func selectedMenuIndex(_ index: Int) {
        let itemInfo = viewModel.categoryList.item_list[index]
        goToProductDetailsScreen(productInfo: itemInfo, productId: itemInfo.product_id, fromSearch: false)
    }
}

// MARK: - menuItemViewDelegate
extension HomeVC: menuItemViewDelegate {
    func navigationToDetailVC(_ index: Int, totalAddItem: Int) {
        let itemInfo = viewModel.categoryList.item_list[index]
        DLog("navigationToDetailVC = \(itemInfo.toDictionary())")
        goToProductDetailsScreen(productInfo: itemInfo, productId: itemInfo.product_id, fromSearch: false)
//        productDetails(viewModel.categoryList.item_list[index].product_id)
//        print(totalAddItem)
//        let menuDetaiVC = MenuDetailsVC.instantiate(fromAppStoryboard: .Home)
//        menuDetaiVC.delegate = self
//        menuDetaiVC.selectedIndex = index
//        menuDetaiVC.numberOfItem = totalAddItem
    }
    
    func selectedCellIndex(_ index: Int, totalAddItem: Int) {
        let itemInfo = viewModel.categoryList.item_list[index]
        goToProductDetailsScreen(productInfo: itemInfo, productId: itemInfo.product_id, fromSearch: false)
    }
    
    func toAllItem() {
        let nextVc = MenuItemsListVC.instantiate(fromAppStoryboard: .Home)
        viewModel.categoryName = viewModel.dictSelectedData.category_name
        nextVc.viewModelCategory = viewModel
        self.navigationController?.pushViewController(nextVc, animated: true)
    }
}

// MARK: - sendBackQuantity
extension HomeVC : sendBackQuantity {
    func quantityOfItemDelegate(quantiy: Int, selectedId: Int) {
        let object = viewModel.categoryList.item_list[selectedId]
        print(quantiy)
        self.setupProductUI(object, qty: quantiy)
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
extension HomeVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.arrHomeCategory.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MenuitemsCell", for: indexPath) as! MenuitemsCell
        let dictData = viewModel.arrHomeCategory[indexPath.row]
        let selectedId = viewModel.dictSelectedData.category_id
        cell.configData(dictData, selectedId: selectedId)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        viewModel.dictSelectedData = viewModel.arrHomeCategory[indexPath.row]
        viewModel.categoryList.item_list = [ItemInfo]()
        viewModel.categoryList.pupularlist = [ItemInfo]()
        self.getCategoryItems(viewModel.dictSelectedData.category_id)
        collectionViewMenuItems.reloadData()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let fontAttributes = UIFont.init(name: Application.Font.PROXIMANOVA_THIN, size: 14)
        let dictData = viewModel.arrHomeCategory[indexPath.row]
        let myText = dictData.category_name
        let size = myText.size(withAttributes:[.font: fontAttributes!])
        print("Width : \(size.width)")
        print("Height : \(size.height)")
        return CGSize(width: size.width + size.height, height: 45)
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension HomeVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.arrOfSearchProduct.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: HomeSearchTableViewCell.identifier) as! HomeSearchTableViewCell
        cell.selectionStyle = .none
        let itemInfo = viewModel.arrOfSearchProduct[indexPath.row]
        cell.lblName.text = itemInfo.category_name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let searchInfo = viewModel.arrOfSearchProduct[indexPath.row]
        if searchInfo.is_category {
            fetchItemsForCategoryAndGoToListingScreen(searchInfo: searchInfo)
        } else {
       DLog("searchInfo = \(searchInfo.toDictionary())")
            if viewModel.categoryList.item_list.indices ~= indexPath.row {
            goToProductDetailsScreen(productInfo: viewModel.categoryList.item_list[indexPath.row], productId: searchInfo.category_id, fromSearch: true)
            }
            else{
                goToProductDetailsScreen(productInfo: ItemInfo(json: [:]), productId: searchInfo.category_id, fromSearch: true)
            }
        }
        viewModel.arrOfSearchProduct.removeAll()
        tblSearchItem.reloadData()
        viewContainerSearch.isHidden = true
        txtSearch.text = ""
        txtSearch.resignFirstResponder()
    }
}

// MARK: - Keyboard height events handling
extension HomeVC {
    private func registerKeyboardNotificationObservers() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }
    
    @objc func adjustForKeyboard(notification: Notification) {
        guard let keyboardValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else { return }
        
        let keyboardScreenEndFrame = keyboardValue.cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == UIResponder.keyboardWillHideNotification {
            tblSearchItem.contentInset = .zero
        } else {
            tblSearchItem.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height - view.safeAreaInsets.bottom, right: 0)
        }
        
        tblSearchItem.scrollIndicatorInsets = tblSearchItem.contentInset
    }
}
