//
//  DeliveryVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 07/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
import StoreKit

class DeliveryVC: BaseViewController {
    
    //MARK: - @IBOutlet
    @IBOutlet weak var lblOrderSent: UILabel!
    @IBOutlet weak var lblOrderRate: UILabel!
    @IBOutlet weak var lblWaiting: UILabel!
    @IBOutlet weak var viewHowItwork: UIView!
    @IBOutlet weak var viewInsideHowWorkView: UIView!
    @IBOutlet weak var lblHowItWork: UILabel!
    @IBOutlet weak var lblYourOrderDisplayed: UILabel!
    @IBOutlet weak var btnsendFeedback: UIButton!
    @IBOutlet weak var btnRateus: UIButton!
    @IBOutlet weak var scrollviewDelivery: UIScrollView!
    @IBOutlet weak var lblDeliveryStatus: UILabel!
    
    // MARK: - Properties
    var viewModel = DeliveryStatusViewModel()
    
    //MARK: - Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        deliveryStatusAtServer(order_id:  viewModel.order_id)
    }
    
    //MARK: - Functions
    func setUpUI() {
        viewInsideHowWorkView.addCornerRadius(15)
        viewHowItwork.addShadow(color: .black, opacity: 0.5, offset: CGSize(width: 0, height: 1), radius: 4)
        lblOrderSent.text = getLocalizedString(key: .OrderSent)
        lblWaiting.text = getLocalizedString(key: .Waiting)
        lblOrderRate.text = getLocalizedString(key: .OrderRate)
        lblHowItWork.text = getLocalizedString(key: .HowItWork)
        lblYourOrderDisplayed.text = getLocalizedString(key: .YourOrderDisplayed)
        btnsendFeedback.setTitle(getLocalizedString(key: .SendFeedback), for: .normal)
        btnRateus.setTitle(getLocalizedString(key: .Rate), for: .normal)
        lblDeliveryStatus.text = getLocalizedString(key: .DeliveryStatus )
        scrollviewDelivery.contentInset  = UIEdgeInsets(top: 0, left: 0, bottom: 60, right: 0)
        
    }
    
    //MARK: - IBAction
    @IBAction func BtntoBack(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    
    @IBAction func onBtnSendFeedback(_ sender: UIButton) {
        openFeedbackMailComposer()
    }
    
    @IBAction func onClickViewDeliveryCompleted(_ sender: UIControl) {
        let nextVc = DeliveryComformationVC.instantiate(fromAppStoryboard: .Delivery)
        navigationController?.pushViewController(nextVc, animated: false)
    }
    
    @IBAction func onBtnRate(_ sender: Any) {
        SKStoreReviewController.requestReview()
    }
    
    // MARK: - API calls
    private func deliveryStatusAtServer(order_id: String) {
        viewModel.order_id = order_id
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        
        LoaderManager.showLoader()
        viewModel.deliveryStatus(order_id: order_id) { (success, message) in
            LoaderManager.hideLoader()
            if success {
                // self.performSegue(withIdentifier: "segueSignupSuccess", sender: nil)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
}
