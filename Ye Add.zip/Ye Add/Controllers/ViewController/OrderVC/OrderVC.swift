//
//  OrderVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 04/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
import SDWebImage
import StoreKit

class OrderVC: BaseViewController {
    //MARK: - @IBOutlet
    @IBOutlet weak var tableviewOfItemList: UITableView!
    //LblOutlet
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblOrderTime: UILabel!
    @IBOutlet weak var lblYourOrder: UILabel!
    
    //BtnOutlet
    @IBOutlet weak var btnRepeat: UIButton!
    @IBOutlet weak var btntoSendfeedback: UIButton!
    @IBOutlet weak var btnrateusto: UIButton!
    
    // MARK: - Properties
    var viewModel = MyOrderViewModel()
    
    // MARK: - LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //        lblDate.text = "\(Date())"
        setUpUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchMyOrdersFromServer()
    }
    
    // MARK:- Functions
    func setUpUI() {
        setupTableViews()
        setupLocalizedData()
    }
    
    private func setupLocalizedData() {
        lblYourOrder.text = getLocalizedString(key: .YourOrder)
        //        lblOrderTime.text = getLocalizedString(key: .OrderTime)
        btntoSendfeedback.setTitle(getLocalizedString(key: .SendFeedback), for: .normal)
        btnrateusto.setTitle(getLocalizedString(key: .Rate), for: .normal)
    }
    
    private func setupTableViews() {
        tableviewOfItemList.register(Ordercell.nib, forCellReuseIdentifier: Ordercell.identifier)
        tableviewOfItemList.register(OrderSummaryFooterView.nib, forHeaderFooterViewReuseIdentifier: OrderSummaryFooterView.identifier)
        tableviewOfItemList.delegate = self
        tableviewOfItemList.dataSource = self
    }
    
    private func goToDeliveryStatusScreen(orderId: String) {
        let nextVc = DeliveryVC.instantiate(fromAppStoryboard: .Delivery)
        nextVc.viewModel.order_id = orderId
        navigationController?.pushViewController(nextVc, animated: true)
    }
    
    //MARK:- IBAction
    @IBAction func BtnBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onBtnSendFeedback(_ sender: UIButton) {
        openFeedbackMailComposer()
    }
    
    
    @IBAction func onBtnRate(_ sender: UIButton) {
        SKStoreReviewController.requestReview()
    }
    
    @objc private func onBtnRepeatOrder(_ sender: UIButton) {
        let orderInfo = viewModel.arrOrders[sender.tag]
        repeatOrderAtServer(orderId: orderInfo.order_id)
    }
    
    @objc private func onBtnOrderStatus(_ sender: UIButton) {
        if  viewModel.arrOrders[sender.tag].order_status == .Waiting {
            let nextVc = DeliveryVC.instantiate(fromAppStoryboard: .Delivery)
            navigationController?.pushViewController(nextVc, animated: true)
        }else{
            let nextVc = DeliveryComformationVC.instantiate(fromAppStoryboard: .Delivery)
            navigationController?.pushViewController(nextVc, animated: true)
        }
    }
    // MARK: - API calls
    private func fetchMyOrdersFromServer() {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        
        LoaderManager.showLoader()
        viewModel.myOrder(completion:  { (success, message) in
            LoaderManager.hideLoader()
            if success {
                self.tableviewOfItemList.reloadData()
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        })
    }
    
    private func repeatOrderAtServer(orderId: String) {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        
        LoaderManager.showLoader()
        viewModel.repeatOrder(orderId: orderId, completion:  { (success, message) in
            LoaderManager.hideLoader()
            if success {
//                self.goToDeliveryStatusScreen(orderId: orderId)
//                self.fetchMyOrdersFromServer()
                Utility.windowMain()?.showToastAtBottom(message: message)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        })
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension OrderVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.arrOrders.count
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 75
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: OrderSummaryFooterView.identifier) as! OrderSummaryFooterView
        
        footerView.btnRepeatOrder.tag = section
        footerView.btnOrderStatus.tag = section
        
        footerView.btnRepeatOrder.addTarget(self, action: #selector(onBtnRepeatOrder(_:)), for: .touchUpInside)
        footerView.btnOrderStatus.addTarget(self, action: #selector(onBtnOrderStatus(_:)), for: .touchUpInside)
        
        let orderInfo = viewModel.arrOrders[section]
        footerView.configure(info: orderInfo)
        return footerView
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.arrOrders[section].data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Ordercell.identifier, for: indexPath) as! Ordercell
        
        let orderInfo = viewModel.arrOrders[indexPath.section]
        let productInfo = orderInfo.data[indexPath.row]
        
        cell.viewOfItems.isHidden = true
        cell.viewOfPrice.isHidden = true
        if  indexPath.row == 0 {
            cell.viewOfItems.isHidden = false
            cell.viewOfPrice.isHidden = false
        }
        
        cell.configure(info: productInfo)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
        
    }
}
