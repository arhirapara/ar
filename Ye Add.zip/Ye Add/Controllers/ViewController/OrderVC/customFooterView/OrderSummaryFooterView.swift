//
//  OrderSummaryFooterView.swift
//  Yemeni
//
//  Created by Kartum Infotech on 21/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

protocol DeliveryStatusDelegate {
    func toDeliveryStatusVC(_ index: Int)
}

class OrderSummaryFooterView: UITableViewHeaderFooterView {
    
    // MARK: - Outlets
    @IBOutlet weak var lblOrderIdNumber: UILabel!
    @IBOutlet weak var lblTotalAmount: UILabel!
    @IBOutlet weak var lbltime: UILabel!
    @IBOutlet weak var btnRepeatOrder: UIButton!
    @IBOutlet weak var btnOrderStatus: UIButton!
    @IBOutlet weak var LblOrderOn: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var lblOrderid: UILabel!
    var deligate: DeliveryStatusDelegate?
    // MARK: - Functions
    
    override func awakeFromNib() {
           super.awakeFromNib()
           setUpUi()
       }
    
    func setUpUi() {
        lblTotal.text = getLocalizedString(key: .Total)
        lblOrderid.text = getLocalizedString(key: .OrderId)
        LblOrderOn.text = getLocalizedString(key: .OrderOn)
        btnRepeatOrder.setTitle(getLocalizedString(key: .Repeat), for: .normal)
    }
    func configure(info: OrderInfo) {
        lblOrderIdNumber.text = info.order_id
        lbltime.text = info.formattedDateTime()
        btnOrderStatus.setTitle(info.order_status.localizedName(), for: .normal)
        lblTotalAmount.text = info.formattedPrice()
        btnOrderStatus.titleLabel?.textColor = info.order_status.statusColor()
      }
    func deliveryStatus(){
    }
    @IBAction func btnOrderStatus(_ sender: UIButton) {
    }
}
