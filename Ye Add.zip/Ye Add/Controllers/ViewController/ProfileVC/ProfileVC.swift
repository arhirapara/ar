//
//  ProfileVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 03/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
import StoreKit

class ProfileVC: BaseViewController, UINavigationControllerDelegate {
    
    //MARK:- Properties
    var viewModel = LogOutViewModel()
    var viewModelOfUpdateProfile = UpdateProfileViewModel()
    
    // MARK:- IBOutlets
    
    @IBOutlet weak var scrollViewOfProfile: UIScrollView!
    
    //IMageViewOutlet
    @IBOutlet weak var imgFoodItem: UIImageView!
    @IBOutlet weak var imgProfilePhoto: UIImageView!
    @IBOutlet weak var imgLocationLogo: UIImageView!
    @IBOutlet weak var imagOrderLogo: UIImageView!
    
    //LBLOutlet
    @IBOutlet weak var lblPersonName: UILabel!
    @IBOutlet weak var lblCityName: UILabel!
    @IBOutlet weak var lblOrder: UILabel!
    
    //UIViewOutlet
    @IBOutlet weak var viewCityName: UIView!
    @IBOutlet weak var viewAddReview: UIView!
    @IBOutlet weak var viewImageView: UIView!
    @IBOutlet weak var ViewEditProfile: UIView!
    @IBOutlet weak var viewOrderLogo: UIView!
    @IBOutlet weak var viewInsideImageview: UIView!
    @IBOutlet weak var viewOfEdit: UIView!
    
    //BtnOutlet
    @IBOutlet weak var btnAddReview: UIButton!
    @IBOutlet weak var btnEditProfile: UIButton!
    @IBOutlet weak var btnSendFeedback: UIButton!
    @IBOutlet weak var btnRate: UIButton!
    @IBOutlet weak var btnLogOut: UIButton!
    @IBOutlet weak var btnEditImage: UIButton!
    @IBOutlet weak var btnSave: UIButton!
    
    //txtfldOutlet
    @IBOutlet weak var txtPersonName: UITextField!
    @IBOutlet weak var txtPersoneEmail: UITextField!
    @IBOutlet weak var txtMobileNUmber: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtZipCode: UITextField!
    @IBOutlet var txtCollection: [UITextField]!
    @IBOutlet weak var txtCity: UITextField!
    
    private var forProfileImage = false
    private var avatarImage = UIImage(named: "user_avatar")?.tintWithColor(UIColor(named: "foodNameLable_ce7c37")!)
    
    //MARK:-LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpUI()
        
        if #available(iOS 13.0, *) {
            scrollViewOfProfile.automaticallyAdjustsScrollIndicatorInsets = false
        } else {
        }
        scrollViewOfProfile.contentInsetAdjustmentBehavior = .never
        setProfileData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        for txt in txtCollection {
            txt.setUnderLine()
                      txt.isUserInteractionEnabled = false
        }
    }
    
    //MARK: - Functions
    func setUpUI() {
        lblOrder.text = getLocalizedString(key: .Order)
        btnSave.setTitle(getLocalizedString(key: .Save), for: .normal)
        btnAddReview.setTitle(getLocalizedString(key: .AddReview), for: .normal)
        btnEditProfile.setTitle(getLocalizedString(key: .EditProfile), for: .normal)
        btnLogOut.setTitle(getLocalizedString(key: .LogOut), for: .normal)
        btnEditImage.setTitle(getLocalizedString(key: .Edit), for: .normal)
        txtZipCode.placeholder = getLocalizedString(key: .ZipCode)
        txtPersoneEmail.placeholder = getLocalizedString(key: .PersoneEmail)
        txtMobileNUmber.placeholder = getLocalizedString(key: .MobileNUmber)
        txtCity.placeholder = getLocalizedString(key: .City)
        txtAddress.placeholder = getLocalizedString(key: .Address)
        txtPersonName.placeholder = getLocalizedString(key: .PersonName)
        btnSendFeedback.setTitle(getLocalizedString(key: .SendFeedback), for: .normal)
        btnRate.setTitle(getLocalizedString(key: .Rate), for: .normal)
         
        
        imgProfilePhoto.addCornerRadius(viewImageView.frame.size.height / 2)
        viewOfEdit.addCornerRadius(viewImageView.frame.size.height / 2)
        btnSave.addCornerRadius(btnSave.frame.size.height / 2)
        imgProfilePhoto.applyBorder(3, borderColor: Application.Color.Facebook_d19314)
        viewImageView.backgroundColor = .clear
        viewImageView.addShadow(color: .black, opacity: 0.5, offset: CGSize(width: 0, height: 0), radius: 8)
        
        viewCityName.addCornerRadius(viewCityName.frame.size.height / 2)
        
        viewAddReview.addCornerRadius(viewAddReview.frame.size.height / 2)
        viewAddReview.applyBorder(1, borderColor: Application.Color.TAB_UnSelect_Color_C6C6C6)
        
        ViewEditProfile.addCornerRadius(ViewEditProfile.frame.size.height / 2)
        ViewEditProfile.applyBorder(1, borderColor: Application.Color.TAB_UnSelect_Color_C6C6C6)
        
        viewOrderLogo.addCornerRadius(viewOrderLogo.frame.size.height / 2)
        imgLocationLogo.tintColor = UIColor.darkGray
        imagOrderLogo.tintColor = UIColor.white
        scrollViewOfProfile.contentInset  = UIEdgeInsets(top: 0, left: 0, bottom: 50, right: 0)
    }
    
    private func setProfileData() {
        let profileInfo = AppPrefsManager.shared.getLoggedInUserInfo()
        txtPersonName.text = profileInfo.fullName()
        txtMobileNUmber.text = profileInfo.mobile
        txtPersoneEmail.text = profileInfo.email
        lblPersonName.text = profileInfo.fullName()
        lblCityName.text = profileInfo.city
        txtAddress.text = profileInfo.address
        txtZipCode.text = profileInfo.pincode
        txtCity.text = profileInfo.city
        
        imgProfilePhoto.sd_setImage(with: URL(string: profileInfo.profile_image.encodedUrlQueryString()), placeholderImage: avatarImage)
        
    }
    
    //MARK: - IBAction
    @IBAction func onClickBtnBack(_ sender: Any) {
    }
    
    @IBAction func onBtnAddReview(_ sender: UIButton) {
    }
    
    @IBAction func onBtnSendFeedback(_ sender: UIButton) {
        openFeedbackMailComposer()
    }
    
    @IBAction func onBtnRate(_ sender: UIButton) {
        SKStoreReviewController.requestReview()
    }
    
    @IBAction func OnBtnEditProfile(_ sender: Any) {
        forProfileImage = true
        showAlert()
    }
    @IBAction func btnToChangeCoverImage(_ sender: UIButton) {
        forProfileImage = false
        showAlert()
    }
    
    @IBAction func onBtnEditUserProfile(_ sender: UIButton) {
        
        for txt in txtCollection{
                  txt.isUserInteractionEnabled = true
            
        }
        txtPersoneEmail.isUserInteractionEnabled = false
        txtMobileNUmber.isUserInteractionEnabled = false
        txtPersonName.becomeFirstResponder()
//        view.endEditing(true)
//        viewModelOfUpdateProfile.first_name = txtPersonName.text!
//      viewModelOfUpdateProfile.email = txtPersoneEmail.text!
//        viewModelOfUpdateProfile.phone = txtMobileNUmber.text!
//        viewModelOfUpdateProfile.address  = txtAddress.text!
//        viewModelOfUpdateProfile.city = txtCity.text!
//        viewModelOfUpdateProfile.pincode = txtZipCode.text!
//        viewModelOfUpdateProfile.profile_image = String(describing: imgProfilePhoto.image ?? nil)
//
//        updateProfileAtServer()

//        let validation = viewModelOfUpdateProfile.validateForm()
//        if validation.isValid {
//            updateProfileAtServer()
//        } else {
//            Utility.windowMain()?.showToastAtBottom(message: validation.message)
//            
//        }
    }
    
    @IBAction func onBtnLogOut(_ sender: UIButton) {
        let dialogMessage = UIAlertController(title: getLocalizedString(key: .Confirm), message: getLocalizedString(key: .Message), preferredStyle: .alert)
        let ok = UIAlertAction(title: getLocalizedString(key: .OK), style: .default, handler: { (action) -> Void in
            self.logOutAtServer()
        })
        let cancel = UIAlertAction(title: getLocalizedString(key: .Cancel), style: .cancel) { (action) -> Void in
        }
        dialogMessage.addAction(ok)
        dialogMessage.addAction(cancel)
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
    @IBAction func btnSave(_ sender: UIButton) {
        view.endEditing(true)
               viewModelOfUpdateProfile.first_name = txtPersonName.text!
             viewModelOfUpdateProfile.email = txtPersoneEmail.text!
               viewModelOfUpdateProfile.phone = txtMobileNUmber.text!
               viewModelOfUpdateProfile.address  = txtAddress.text!
               viewModelOfUpdateProfile.city = txtCity.text!
               viewModelOfUpdateProfile.pincode = txtZipCode.text!
               viewModelOfUpdateProfile.profile_image = String(describing: imgProfilePhoto.image ?? nil)
               
               updateProfileAtServer()
    }
    
    func logOutAtServer() {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        LoaderManager.showLoader()
        viewModel.device_id = "ios"
        viewModel.logOut { (success, message) in
            LoaderManager.hideLoader()
            if success {
                Utility.appDelegate().logoutFromApplication()
                self.tabBarController?.navigationController?.popToRootViewController(animated: true)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
    
    private func updateProfileAtServer() {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        LoaderManager.showLoader()
        viewModelOfUpdateProfile.UpdateProfileUser { (success, message) in
            LoaderManager.hideLoader()
            for txt in self.txtCollection{
                             txt.isUserInteractionEnabled = false
                       
                   }
            if success {
                DLog(AppPrefsManager.shared.getLoggedInUserInfo())
                self.setProfileData()
                //                   Utility.windowMain()?.showToastAtBottom(message: message)
                self.navigationController?.popViewController(animated: true)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
}

// MARK: - UIImagePickerControllerDelegate
extension ProfileVC : UIImagePickerControllerDelegate {
    
    func showAlert() {
        let alert = UIAlertController(title: getLocalizedString(key: .SelectPhoto), message: getLocalizedString(key: .MessageForProfilePhoto), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: getLocalizedString(key: .Camera), style: .default, handler: {(action: UIAlertAction) in
            self.getImage(fromSourceType: .camera)
        }))
        alert.addAction(UIAlertAction(title: getLocalizedString(key: .PhotoLibrary), style: .default, handler: {(action: UIAlertAction) in
            self.getImage(fromSourceType: .photoLibrary)
        }))
        alert.addAction(UIAlertAction(title: getLocalizedString(key: .Cancel), style: .destructive, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
        
    func getImage(fromSourceType sourceType: UIImagePickerController.SourceType) {
        
        //Check is source type available
        if UIImagePickerController.isSourceTypeAvailable(sourceType) {
            
            let imagePickerController = UIImagePickerController()
            imagePickerController.delegate = self
            imagePickerController.sourceType = sourceType
            self.present(imagePickerController, animated: true, completion: nil)
        }
    }
    //MARK: - UIImagePickerViewDelegate.
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        self.dismiss(animated: true) { [weak self] in
            guard let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else { return }
            //Setting image to your image view
                self?.imgProfilePhoto.image = image
            self?.viewModelOfUpdateProfile.profileImage = image
        }
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
