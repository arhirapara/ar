//
//  MenuItemsListVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 28/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
import PassKit

class MenuItemsListVC: BaseViewController {
    
    //MARK: Constant
    let HARIZONTAL_SPCE_IMAGE: CGFloat          = 10
    let VERTICAL_SPCE_IMAGE: CGFloat            = 8
    let COLUMN_IMAGE: CGFloat                   = 2
    
    // MARK:- IBOutlets
    @IBOutlet var collectionViewMenuCategoryList: UICollectionView!
    @IBOutlet var viewMainCollection: UIView!
    @IBOutlet var collectionViewCartGrid: UICollectionView!
    @IBOutlet weak var bottomCartLable: UIView!
    @IBOutlet weak var itemListView: UIView!
    @IBOutlet weak var collectionItemListView: UIView!
    @IBOutlet weak var viewOfCart: UIView!
    @IBOutlet weak var itemListTableView: UITableView!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var lblTotalAmount: UILabel!
    @IBOutlet weak var lblNumberOfquantiy: UILabel!
    @IBOutlet weak var lblCategoryNameTitle: UILabel!
    @IBOutlet weak var lblCart: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var lblCartOfTblView: UILabel!
    
    //MARK: - Properties
    var numberOfItem:Int = 0
    var viewModel = MyCartViewModel()
    var viewModelCategory = GetCategoriesViewModel()
    var arrayItems = [ItemInfo]()
    var paymentStatus = PKPaymentAuthorizationStatus.failure
    
    ///Apple Pay
    var paymentController: PKPaymentAuthorizationController?
    
    
    //MARK: - LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        viewMainCollection.addBottomCorner(view: viewMainCollection, radius: 50)
        fetchMyCartFromServer()
        addProductAddedToCartNotificationObservers()
        addProductRemovedfromCartNotificationObservers()
        addOrderPlacedNotificationObservers()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        hideTabBar()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        showTabBar()
    }
    
    //MARK: - Functions
    func setUpUI()  {
        
        lblCart.text = getLocalizedString(key: .Cart)
        lblTotal.text = getLocalizedString(key: .Total)
        lblCartOfTblView.text = getLocalizedString(key: .Cart)
        btnNext.setTitle(getLocalizedString(key: .Next), for: .normal)
        lblCategoryNameTitle.text = viewModelCategory.categoryName
        itemListTableView.delegate = self
        itemListTableView.dataSource = self
        itemListTableView.reloadData()
        self.collectionViewRegister()
        itemListView.isHidden = true
        collectionItemListView.isHidden = false
        bottomCartLable.addCornerRadius(bottomCartLable.frame.size.height / 2)
        btnNext.addCornerRadius(btnNext.frame.size.height / 2)
        btnNext.addShadow(color: Application.Color.Facebook_d19314, opacity: 0.5, offset: CGSize(width: 0, height: 0), radius: 8)
    }
    
    func collectionViewRegister()  {
        collectionViewMenuCategoryList.delegate = self
        collectionViewMenuCategoryList.dataSource = self
        
        collectionViewCartGrid.delegate = self
        collectionViewCartGrid.dataSource = self
        
        collectionViewMenuCategoryList.register(UINib(nibName: "MenuCell", bundle: nil), forCellWithReuseIdentifier: "MenuCell")
        collectionViewCartGrid.register(UINib(nibName: "CartGrideCell", bundle: nil), forCellWithReuseIdentifier: "CartGrideCell")
        itemListTableView.register(itemListViewCell.nib, forCellReuseIdentifier: itemListViewCell.identifier)
        collectionViewMenuCategoryList.reloadData()
    }
    
    private func goToDeliveryStatusScreen()  {
        let nextVc = DeliveryVC.instantiate(fromAppStoryboard: .Delivery)
        nextVc.viewModel.order_id = viewModel.arrMyCart.first?.order_id ?? ""//viewModel
        navigationController?.pushViewController(nextVc, animated: true)
    }
    
    private func postProductAddedToCartNotification(info: ItemInfo) {
        NotificationCenter.default.post(name: .productAddedToCart, object: info)
    }
    
    private func postProductRemovedFromCartNotification(info: ProductItemInfo) {
        NotificationCenter.default.post(name: .productRemovedFromCart, object: info)
    }
    
    private func postOrderPlacedNotification(arrInfo: [ProductItemInfo]) {
        NotificationCenter.default.post(name: .orderPlacedNotification, object: arrInfo)
    }
    
    // MARK: - Events
    override func onProductAddedToCartNotification(_ notification: Notification) {
        if let info = notification.object as? ItemInfo {
            for currentInfo in viewModelCategory.categoryList.item_list {
                if currentInfo.product_id == info.product_id {
                    currentInfo.quantity = info.quantity
                    break
                }
            }
            collectionViewMenuCategoryList.reloadData()
        }
    }
    
    override func onProductRemovedFromCartNotification(_ notification: Notification) {
        if let info = notification.object as? ProductItemInfo {
            for currentInfo in viewModelCategory.categoryList.item_list {
                if currentInfo.product_id == info.product_id {
                    currentInfo.quantity = "0"
                    break
                }
            }
            collectionViewMenuCategoryList.reloadData()
        }
    }
    
    override func onOrderPlacedNotification(_ notification: Notification) {
        if var arrInfo = notification.object as? [ProductItemInfo] {
            for currentInfo in viewModelCategory.categoryList.item_list {
                for (index, palcedInfo) in arrInfo.enumerated() {
                    if currentInfo.product_id == palcedInfo.product_id {
                        currentInfo.quantity = "0"
                        arrInfo.remove(at: index)
                        break
                    }
                }
            }
            collectionViewMenuCategoryList.reloadData()
        }
    }
    private func goToProductDetailsScreen(productInfo: ItemInfo, productId: String) {
        let nextVc = MenuDetailsVC.instantiate(fromAppStoryboard: .Home)
        nextVc.viewModel.productInfo = productInfo
        nextVc.viewModel.productId = productId
//        nextVc.fromSearch = fromSearch
        navigationController?.pushViewController(nextVc, animated: true)
    }
    @objc func onBtnMarkerNext(_ sender : UIButton) {
        let itemInfo = viewModelCategory.categoryList.item_list[sender.tag]
         goToProductDetailsScreen(productInfo: itemInfo, productId: itemInfo.product_id)
      }

    // MARK: - IBActions
    @IBAction func onbtnBack(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onBtnHideMenuListView(_ sender: UIControl) {
        self.itemListView.isHidden = true
        UIView.animate(withDuration: 0.3) {
            self.collectionItemListView.isHidden = false
        }
    }
    
    @IBAction func onViewShowMenuList(_ sender: UIControl) {
        UIView.animate(withDuration: 0.3) {
            self.itemListView.isHidden = false
            self.collectionItemListView.isHidden = true
        }
    }
    
    @IBAction func btnToNext(_ sender: UIButton) {
//        placeOrderAtServer()
        openApplePay()
    }
    
    @IBAction func btnSearch(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
        NotificationCenter.default.post(name: .becomeFirstResponderHomeSearch, object: nil)
    }
    
    // MARK: - API calls
    private func removeCartAtServer(cartId: String, indexPath: IndexPath) {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        
        LoaderManager.showLoader()
        viewModel.removeCart(cartId: cartId) { (success, message) in
            LoaderManager.hideLoader()
            if success {
                let info = self.viewModel.arrMyCart[indexPath.row]
                self.postProductRemovedFromCartNotification(info: info)
                self.viewModel.arrMyCart.remove(at: indexPath.row)
                self.lblTotalAmount.text = self.viewModel.objectCartTotal + " SAR"
                self.lblNumberOfquantiy.text = "\(self.viewModel.arrMyCart.count)"
                self.itemListTableView.reloadData()
                self.collectionViewCartGrid.reloadData()
                self.fetchMyCartFromServer(showLoader: false, checkForHide: false)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
    
    private func fetchMyCartFromServer(showLoader: Bool = true, checkForHide: Bool = true) {
        if showLoader {
            LoaderManager.showLoader()
        }
        viewModel.myCart { (success, message) in
            if showLoader {
                LoaderManager.hideLoader()
            }
            if success {
                self.lblTotalAmount.text = self.viewModel.objectCartTotal + " SAR"
                self.lblNumberOfquantiy.text = "\(self.viewModel.arrMyCart.count)"
                if checkForHide {
                    if !self.viewModel.arrMyCart.isEmpty {
                        self.itemListView.isHidden = true
                        self.collectionItemListView.isHidden = false
                    } else {
                        self.itemListView.isHidden = true
                        self.collectionItemListView.isHidden = true
                    }
                }
                // self.performSegue(withIdentifier: "segueSignupSuccess", sender: nil)
            } else {
                if !message.isEmpty {
                    Utility.windowMain()?.showToastAtBottom(message: message)
                }
                self.itemListView.isHidden = true
                self.collectionItemListView.isHidden = true
            }
            self.itemListTableView.reloadData()
            self.collectionViewCartGrid.reloadData()
        }
    }
    
    private func placeOrderAtServer() {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        
        LoaderManager.showLoader()
        viewModel.placeOrder{ (success, message) in
            LoaderManager.hideLoader()
            if success {
                self.postOrderPlacedNotification(arrInfo: self.viewModel.arrMyCart)
                self.goToDeliveryStatusScreen()
                // self.performSegue(withIdentifier: "segueSignupSuccess", sender: nil)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
    
    func addToCart(quantity: String, productId: String, increased: Bool, indexPath: IndexPath) {
        LoaderManager.showLoader()
        viewModel.addToCart(qty: quantity, productId: productId) { (success, message) in
            if success {
                LoaderManager.hideLoader()
                let dataObject = self.viewModelCategory.categoryList.item_list[indexPath.row]
                self.postProductAddedToCartNotification(info: dataObject)
                self.fetchMyCartFromServer(showLoader: false)
            } else {
                if !message.isEmpty {
                    Utility.windowMain()?.showToastAtBottom(message: message)
                }
                if let cell = self.collectionViewMenuCategoryList.cellForItem(at: indexPath) as? MenuCell {
                    let dataObject = self.viewModelCategory.categoryList.item_list[indexPath.row]
                    if increased {
                        dataObject.decreaseQuantity()
                    } else {
                        if dataObject.quantityInt() == 0 {
                            cell.viewCartAdd.isHidden = false
                        }
                        dataObject.increaseQuantity()
                    }
                    cell.lblTotalItemCount.text = dataObject.quantity
                }
            }
        }
    }
  
   
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
extension MenuItemsListVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        if collectionView == collectionViewMenuCategoryList{
            return 1
        }
        else {
            return 1
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == collectionViewMenuCategoryList{
            return viewModelCategory.categoryList.item_list.count
        }
        else {
            return viewModel.arrMyCart.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == collectionViewMenuCategoryList{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MenuCell", for: indexPath) as! MenuCell
            cell.btnAddItem.tag = indexPath.row
            cell.btnAddToItem.tag = indexPath.row
            cell.btnMinusItem.tag = indexPath.row
            let objData = viewModelCategory.categoryList.item_list[indexPath.row]
            cell.configItems(indexPath, data: objData)
            cell.delegate = self
            cell.btnNextFood.addTarget(self, action: #selector(onBtnMarkerNext), for: .touchUpInside)
            cell.addToCart = { [weak self] (index) in
                print(index)
                let indexPath = IndexPath.init(row: index, section: 0)
                let cell = self?.collectionViewMenuCategoryList.cellForItem(at: indexPath) as! MenuCell
                let dataObject = self?.viewModelCategory.categoryList.item_list[index]
                dataObject?.increaseQuantity()
                cell.lblTotalItemCount.text = dataObject?.quantity
                cell.viewCartAdd.isHidden = false
                self?.addToCart(quantity: dataObject!.quantity, productId: dataObject!.product_id, increased: true, indexPath: indexPath)
            }
            cell.addCornerRadius(22.5)
            cell.contentView.addCornerRadius(22.5)
            cell.addShadow(color: UIColor.gray, opacity: 0.5, offset: CGSize(width: 0, height: 1), radius: 4)
            return cell
        }
        else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CartGrideCell", for: indexPath) as! CartGrideCell
            let productInfo = viewModel.arrMyCart[indexPath.item]
            cell.configure(info: productInfo)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == collectionViewMenuCategoryList {
            let itemInfo = viewModelCategory.categoryList.item_list[indexPath.row]
            goToProductDetailsScreen(productInfo: itemInfo, productId: itemInfo.product_id)
            //            UIView.animate(withDuration: 0.3) {
            //                 self.itemListView.isHidden = false
            //                self.collectionItemListView.isHidden = true
            //            }
        }
    }
    
    //    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
    //        if collectionView == collectionViewMenuCategoryList{
    //            return HARIZONTAL_SPCE_IMAGE
    //        }
    //        else {
    //            return 0
    //        }
    //    }
    //
    //    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
    //        if collectionView == collectionViewMenuCategoryList{
    //            return VERTICAL_SPCE_IMAGE
    //        }
    //        else {
    //            return 0
    //        }
    //    }
    //
    //
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 6
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == collectionViewCartGrid{
            return CGSize(width: 40, height: 40)
        }
        
        //        if collectionView == collectionViewMenuCategoryList{
        //            let width: CGFloat = (collectionView.frame.width - ((COLUMN_IMAGE - 1) * HARIZONTAL_SPCE_IMAGE)) / COLUMN_IMAGE
        //            return CGSize(width: width, height: 257)
        //        }
        return CGSize(width: 0, height: 0)
    }
}

//MARK: - UITableviewDelegate,UITableViewDataSource

extension MenuItemsListVC: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.arrMyCart.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: itemListViewCell.identifier, for: indexPath) as! itemListViewCell
        let objData = viewModel.arrMyCart[indexPath.row]
        cell.configItems(indexPath, data: objData)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let objData = viewModel.arrMyCart[indexPath.row]
        let dialogMessage = UIAlertController(title: getLocalizedString(key: .Confirm), message: getLocalizedString(key: .MessageForRemoveCart), preferredStyle: .alert)
        let ok = UIAlertAction(title: getLocalizedString(key: .YES), style: .default, handler: { (action) -> Void in
            self.removeCartAtServer(cartId: objData.cart_id, indexPath: indexPath)
        
        })
        let cancel = UIAlertAction(title: getLocalizedString(key: .NO), style: .cancel) { (action) -> Void in
        }
        dialogMessage.addAction(ok)
        dialogMessage.addAction(cancel)
        self.present(dialogMessage, animated: true, completion: nil)
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
}
//MARK: - increaseItemDelegate

extension MenuItemsListVC: icreaseItemDelegate {
    
    func increseItem(_ index: Int) {
        
        let indexPath = IndexPath.init(row: index, section: 0)
        let cell = collectionViewMenuCategoryList.cellForItem(at: indexPath) as! MenuCell
        cell.viewCartAdd.isHidden = false
        let objData = viewModelCategory.categoryList.item_list[index]
       objData.increaseQuantity()
        cell.lblTotalItemCount.text = objData.quantity
        addToCart(quantity: objData.quantity, productId: objData.product_id, increased: true, indexPath: indexPath)
    }
    
    func decreseItem(_ index: Int) {
        let indexPath = IndexPath.init(row: index, section: 0)
        let cell = collectionViewMenuCategoryList.cellForItem(at: indexPath) as! MenuCell
        cell.viewCartAdd.isHidden = false
        let objData = viewModelCategory.categoryList.item_list[index]
        objData.decreaseQuantity()
        addToCart(quantity: objData.quantity, productId: objData.product_id, increased: true, indexPath: indexPath)
        
        if objData.quantityInt() == 0 {
            cell.viewCartAdd.isHidden = true
        }
    }
    
    func drawDottedImage(width: CGFloat, height: CGFloat, color: UIColor) -> UIImage {
        let path = UIBezierPath()
        path.move(to: CGPoint(x:10,y:10))
        path.addLine(to: CGPoint(x:290,y:10))
        path.lineWidth = 8
        let dashes: [CGFloat] = [0.001, path.lineWidth * 2]
        path.setLineDash(dashes, count: dashes.count, phase: 0)
        path.lineCapStyle = CGLineCap.round
        UIGraphicsBeginImageContextWithOptions(CGSize(width:width, height:20), false, 2)
        UIColor.clear.setFill()
        UIGraphicsGetCurrentContext()!.fill(.infinite)
        color.setStroke()
        path.stroke()
        let image = UIGraphicsGetImageFromCurrentImageContext()
        return image!
    }
}

// MARK: - Apple Pay
extension MenuItemsListVC {
    private func openApplePay() {
        guard !viewModel.objectCartTotal.isEmpty, viewModel.objectCartTotal != "0", let _ = Double(viewModel.objectCartTotal) else {
            DLog("amount is not valid")
            return
        }
        
        let userInfo = AppPrefsManager.shared.getLoggedInUserInfo()
        var nameComponents = userInfo.fullName().components(separatedBy: " ")
        
        let contact = PKContact()
        
        var name = PersonNameComponents()
        name.givenName = nameComponents.first
        nameComponents.removeFirst()
        name.familyName = nameComponents.joined(separator: " ")
        
        contact.name = name
        
        let address = CNMutablePostalAddress()
        address.street = userInfo.address
        address.city = userInfo.city
//        address.state = "GA";
        address.postalCode = userInfo.pincode
        
        contact.postalAddress = address
        
        contact.emailAddress = userInfo.email
        
        let fare = PKPaymentSummaryItem(label: "Total", amount: NSDecimalNumber(string: viewModel.objectCartTotal), type: .final)
        
        let paymentRequest = PKPaymentRequest()
        paymentRequest.merchantIdentifier = "merchant.Yemeni.test.kartum.com"
        paymentRequest.supportedNetworks = [PKPaymentNetwork.visa, PKPaymentNetwork.masterCard, PKPaymentNetwork.amex]
        paymentRequest.merchantCapabilities = PKMerchantCapability.capability3DS
        paymentRequest.countryCode = "SA"
        paymentRequest.currencyCode = "SAR"
//        paymentRequest.shippingContact = contact
//        paymentRequest.requiredBillingContactFields = [.emailAddress, .postalAddress]
        paymentRequest.paymentSummaryItems = [fare]
        
//        request.paymentSummaryItems = [
//            PKPaymentSummaryItem(label: "Some Product", amount: amount)
//        ]
        
        // Display our payment request
        paymentController = PKPaymentAuthorizationController(paymentRequest: paymentRequest)
        paymentController?.delegate = self
        paymentController?.present(completion: { (presented: Bool) in
            if presented {
                debugPrint("Presented payment controller")
            } else {
                debugPrint("Failed to present payment controller")
//                self.completionHandler(false)
            }
        })
    }
}

// MARK: PKPaymentAuthorizationControllerDelegate
extension MenuItemsListVC: PKPaymentAuthorizationControllerDelegate {

    func paymentAuthorizationController(_ controller: PKPaymentAuthorizationController, didAuthorizePayment payment: PKPayment, handler completion: @escaping (PKPaymentAuthorizationResult) -> Void) {
        
        // Perform some very basic validation on the provided contact information
        var errors = [Error]()
        var status = PKPaymentAuthorizationStatus.success
//        if payment.shippingContact?.postalAddress?.isoCountryCode != "US" {
//            let pickupError = PKPaymentRequest.paymentShippingAddressUnserviceableError(withLocalizedDescription: "Sample App only picks up in the United States")
//            let countryError = PKPaymentRequest.paymentShippingAddressInvalidError(withKey: CNPostalAddressCountryKey, localizedDescription: "Invalid country")
//            errors.append(pickupError)
//            errors.append(countryError)
//            status = .failure
//        } else {
//            // Here you would send the payment token to your server or payment provider to process
//            // Once processed, return an appropriate status in the completion handler (success, failure, etc)
//        }
        
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        
        LoaderManager.showLoader()
        viewModel.placeOrder{ (success, message) in
            LoaderManager.hideLoader()
            if success {
                status = .success
                self.paymentStatus = status
                completion(PKPaymentAuthorizationResult(status: status, errors: errors))
                // self.performSegue(withIdentifier: "segueSignupSuccess", sender: nil)
            } else {
                status = .failure
                self.paymentStatus = status
                completion(PKPaymentAuthorizationResult(status: status, errors: errors))
                if !message.isEmpty {
                    Utility.windowMain()?.showToastAtBottom(message: message)
                }
            }
        }
    }
    
    func paymentAuthorizationControllerDidFinish(_ controller: PKPaymentAuthorizationController) {
        controller.dismiss {
            // We are responsible for dismissing the payment sheet once it has finished
            DispatchQueue.main.async {
                if self.paymentStatus == .success {
                    self.postOrderPlacedNotification(arrInfo: self.viewModel.arrMyCart)
                    self.goToDeliveryStatusScreen()
//                    self.completionHandler!(true)
                } else {
//                    self.completionHandler!(false)
                }
            }
        }
    }
}
