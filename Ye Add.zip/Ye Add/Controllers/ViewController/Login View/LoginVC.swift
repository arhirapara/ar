//
//  LoginVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 26/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class LoginVC: BaseViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var lblWelcomeBack: UILabel!
    @IBOutlet weak var lblFoodServrdDescreption: UILabel!
    @IBOutlet weak var txtEmailId: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnRememberMe: UIButton!
    @IBOutlet weak var btnForgotPassword: UIButton!
    @IBOutlet weak var btnLogIn: UIButton!
    @IBOutlet weak var btnOfSignup: UIButton!
    @IBOutlet weak var lblDoNotAccount: UILabel!
    
    //MARK:-Properties
    var btnShowPassword: UIButton = UIButton()
    private let viewModel = LogInViewModel()
    
    //MARK:-LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUi()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        if AppPrefsManager.shared.isRememberMe() {
            btnRememberMe.isSelected = true
            txtPassword.text = AppPrefsManager.shared.getPass()
            txtEmailId.text = AppPrefsManager.shared.getEmail()
        } else {
            btnRememberMe.isSelected = false
        }
    } 
    
    //MARK:-Functions
    func setupUi()  {
        
        let attrs = [
            NSAttributedString.Key.font : UIFont.init(name: Application.Font.PROXIMANOVA_BOLD, size: 12)!,
            NSAttributedString.Key.foregroundColor : Application.Color.Next_4d2612,
            NSAttributedString.Key.underlineStyle : 1] as [NSAttributedString.Key : Any]
        let attributedString = NSMutableAttributedString(string:"")
        let buttonTitleStr = NSMutableAttributedString(string:getLocalizedString(key: .Signup), attributes:attrs)
        attributedString.append(buttonTitleStr)
        btnOfSignup.setAttributedTitle(attributedString, for: .normal)
        
        lblDoNotAccount.text = getLocalizedString(key: .DontHaveAnAccount)
        lblWelcomeBack.text = getLocalizedString(key: .WelcomeBack)
        lblFoodServrdDescreption.text = getLocalizedString(key: .FoodServrdDescreption)
        txtEmailId.placeholder = getLocalizedString(key: .EmailId)
        txtPassword.placeholder = getLocalizedString(key: .Password)
        
        btnRememberMe.setTitle(getLocalizedString(key: .RememberMe), for: .normal)
        btnForgotPassword.setTitle(getLocalizedString(key: .ForgotPassword), for: .normal)
        
        btnLogIn.setTitle(getLocalizedString(key: .Login), for: .normal)
        
        txtEmailId.addCornerRadius(txtEmailId.frame.height/2.0)
        txtPassword.addCornerRadius(txtPassword.frame.height/2.0)
        btnLogIn.addCornerRadius(btnLogIn.frame.height/2.0)
        
        txtEmailId.addLeftPadding(padding: 20)
        txtPassword.addLeftPadding(padding: 20)
        txtEmailId.addRightPadding(padding: 20)
        txtPassword.addRightPadding(padding: 20)
        txtPassword.addSubview(btnShowPassword)
        AppTheme.setupTextField(textField: txtPassword, rightButton: btnShowPassword, icon: UIImage(named: "passwordEye")!)
        
        btnShowPassword.addTarget(self, action: #selector(onBtnShowPassword), for: .touchUpInside)
        btnShowPassword.setImage(UIImage(named: "passwordEye")!, for: .normal)
        btnShowPassword.setImage(UIImage(named: "ic_password_show")!, for: .selected)
        
        txtPassword.delegate = self
        txtEmailId.delegate = self
        
        txtPassword.applyBorder(0.5, borderColor: Application.Color.Facebook_d19314)
        txtEmailId.applyBorder(0.5, borderColor: Application.Color.Facebook_d19314)
    }
    
    func hideKeybord()  {
        txtPassword.resignFirstResponder()
        txtEmailId.resignFirstResponder()
    }
    func rememberTapped() {
        if btnRememberMe.isSelected {
            AppPrefsManager.shared.setRememberMe(remember: true)
            AppPrefsManager.shared.saveIdPass(email: txtEmailId.text!, password: txtPassword.text!)
        }
    }
    
    private func redirectToHomeOrProfile() {
        let tabBarVc = TabBarVC()
        self.navigationController?.pushViewController(tabBarVc, animated: true)
    }
    
    //MARK:- IBAction
    @objc func onBtnShowPassword(_ sender: UIButton)  {
        self.hideKeybord()
        btnShowPassword.isSelected = !btnShowPassword.isSelected
        if btnShowPassword.isSelected{
            txtPassword.isSecureTextEntry = false
        }
        else {
            txtPassword.isSecureTextEntry = true
        }
    }
    
    @IBAction func btnRememberMeTapped(_ sender: Any) {
        self.hideKeybord()
        btnRememberMe.isSelected = !btnRememberMe.isSelected
        if btnRememberMe.isSelected{
            rememberTapped()
        }
        
    }
    @IBAction func btnForgotPasswordTapped(_ sender: Any) {
        self.hideKeybord()
        let nextVC = ForgotPasswordVC.instantiate(fromAppStoryboard: .Main)
        navigationController?.pushViewController(nextVC, animated: true)
    }
    @IBAction func btnLogInTapped(_ sender: Any) {
        self.hideKeybord()
        viewModel.email = txtEmailId.text!
        viewModel.password = txtPassword.text!
        viewModel.device_id = "ios"
        let validation = viewModel.validateForm()
        if validation.isValid {
            loginUserAtServer()
        } else {
            //Utility.showMessageAlert(title: validation.title, andMessage: validation.message, withOkButtonTitle: "OK")
            Utility.windowMain()?.showToastAtBottom(message: validation.message)
        }
    }
    //        let tabBarVc = TabBarVC()
    //        navigationController?.pushViewController(tabBarVc, animated: true)
    
    @IBAction func onbtnBack(_ sender: UIButton) {
        self.hideKeybord()
        navigationController?.popViewController(animated: true)
    }
    @IBAction func onBtnSignUp(_ sender: UIButton) {
        let nextVC = SignUpVC.instantiate(fromAppStoryboard: .Main)
        navigationController?.pushViewController(nextVC, animated: true)
    }
    
    //MARK:- API CALL
    
    private func loginUserAtServer() {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        LoaderManager.showLoader()
        viewModel.loginUser { (success, message) in
            LoaderManager.hideLoader()
            if success {
                AppPrefsManager.shared.setIsUserLogin(isUserLogin: true)
                let tabBarVc = TabBarVC()
                self.navigationController?.pushViewController(tabBarVc, animated: true)
                DLog(AppPrefsManager.shared.getLoggedInUserInfo())
                self.rememberTapped()
                // self.performSegue(withIdentifier: "segueSignupSuccess", sender: nil)
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
                
            }
        }
    }
}


extension LoginVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == txtEmailId {
            txtPassword.becomeFirstResponder()
        }
        else if textField == txtPassword {
            txtPassword.resignFirstResponder()
        }
        return true
    }
}

