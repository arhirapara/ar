//
//  LoginVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 26/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class LoginVC: BaseViewController {
    
    @IBOutlet weak var lblWelcomeBack: UILabel!
    @IBOutlet weak var lblFoodServrdDescreption: UILabel!
    @IBOutlet weak var txtEmailId: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnRememberMe: UIButton!
    @IBOutlet weak var btnForgotPassword: UIButton!
    
    @IBOutlet weak var btnLogIn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUi()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    func setupUi()  {
        
        lblWelcomeBack.text = getLocalizedString(key: .WelcomeBack)
        lblFoodServrdDescreption.text = getLocalizedString(key: .FoodServrdDescreption)
        txtEmailId.placeholder = getLocalizedString(key: .EmailId)
        txtPassword.placeholder = getLocalizedString(key: .Password)
        
        btnRememberMe.setTitle(getLocalizedString(key: .RememberMe), for: .normal)
        btnForgotPassword.setTitle(getLocalizedString(key: .ForgotPassword), for: .normal)
        
        btnLogIn.setTitle(getLocalizedString(key: .Login), for: .normal)
        
        txtEmailId.addCornerRadius(txtEmailId.frame.height/2.0)
        txtPassword.addCornerRadius(txtPassword.frame.height/2.0)
        btnLogIn.addCornerRadius(btnLogIn.frame.height/2.0)
    }
    
    //MARK:- IBAction
    
    
    @IBAction func btnRememberMeTapped(_ sender: Any) {
    }
    @IBAction func btnForgotPasswordTapped(_ sender: Any) {
    }
    @IBAction func btnLogInTapped(_ sender: Any) {
    }
    
}
