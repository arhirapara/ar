//
//  ForgotPasswordVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 12/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class ForgotPasswordVC: BaseViewController {

    //MARK:- IBOUTLET
    @IBOutlet weak var btnForgotPassword: UIButton!
    @IBOutlet weak var txtEmailId: UITextField!
    
    //MARK:- Properties
    var viewModelOfForgotPassword = ForgotPasswordViewModel()

    
    //MARK:-LIFECYCLES
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
  }
    //MARK:- Functions
    func setUpUI(){
        txtEmailId.addCornerRadius(txtEmailId.frame.size.height / 2)
        txtEmailId.applyBorder(0.3, borderColor: Application.Color.Facebook_d19314)
        txtEmailId.addLeftPadding(padding: 20)
        btnForgotPassword.addCornerRadius(btnForgotPassword.frame.size.height / 2)
    }
    //MARK:-IBACTIONS
    @IBAction func onBtnForgotPassword(_ sender: Any) {
        viewModelOfForgotPassword.email = txtEmailId.text!
          
           let validation = viewModelOfForgotPassword.validateForm()
                  if validation.isValid {
                     forgotPasswordAtServer()
                  } else {
                    Utility.windowMain()?.showToastAtBottom(message: validation.message)
                  }
            
        }
 
    @IBAction func onBtntoBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
   private func forgotPasswordAtServer() {
             guard NetworkStatus.shared.isConnected else {
                 showNoNetworkAlert()
                 return
             }
             LoaderManager.showLoader()
             viewModelOfForgotPassword.forgotPasswordUser { (success, message) in
                LoaderManager.hideLoader()
                 if success {
                     DLog(AppPrefsManager.shared.getLoggedInUserInfo())
                     // self.performSegue(withIdentifier: "segueSignupSuccess", sender: nil)
                 } else if !message.isEmpty {
                                     Utility.windowMain()?.showToastAtBottom(message: message)

                 }
             }
         }
}
