//
//  ChooseLanguageVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 25/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class ChooseLanguageVC: BaseViewController {
    
    
    // MARK:- IBOutlets
    @IBOutlet weak var lblChooseLanguage: UILabel!
    @IBOutlet weak var imgChooseLanguage: UIImageView!
    @IBOutlet weak var btnArabicLanguage: UIButton!
    @IBOutlet weak var btnEnglishLanguage: UIButton!
    @IBOutlet weak var btnNext: UIButton!
    
    //MARK:- Properies
    private let viewModel = LanguageViewModel()
    
    //MARK:-LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        if AppPrefsManager.shared.isUserLogin(){
            let tabBarVc = TabBarVC()
            self.navigationController?.pushViewController(tabBarVc, animated: false)
            return 
        }
        setupUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        if AppPrefsManager.shared.getLanguageCode() == "ar" {
            btnArabicLanguageTapped(btnArabicLanguage)
        } else {
            btnEnglishLanguageTapped(btnEnglishLanguage)
        }
    }
    override func viewDidLayoutSubviews() {
        btnNext.addCornerRadius(btnNext.frame.height/2.0)
    }
    //MARK: - Functions
    func setupUI() {
        
        lblChooseLanguage.text = getLocalizedString(key: .ChooseLanguage)
        btnArabicLanguage.setTitle(getLocalizedString(key: .Arabic), for: .normal)
        btnEnglishLanguage.setTitle(getLocalizedString(key: .English), for: .normal)
        btnNext.setTitle(getLocalizedString(key: .Next), for: .normal)
        
        for i in 0..<viewModel.arrLanguages.count{
            let langCode = viewModel.arrLanguages[i]
            if AppPrefsManager.shared.getLanguageCode() == langCode.rawValue {
                btnArabicLanguage.titleLabel?.font = UIFont(name: Application.Font.PROXIMANOVA_BOLD, size: 20.0)
                btnEnglishLanguage.titleLabel?.font = UIFont(name: Application.Font.PROXIMANOVA_REGULAR, size: 17.0)
                break
            }
            else {
                btnArabicLanguage.titleLabel?.font = UIFont(name: Application.Font.PROXIMANOVA_REGULAR, size: 17.0)
                btnEnglishLanguage.titleLabel?.font = UIFont(name: Application.Font.PROXIMANOVA_BOLD, size: 20.0)
                break
            }
        }
    }
    
    //MARK:- Action
    @IBAction func btnArabicLanguageTapped(_ sender: UIButton) {
        btnArabicLanguage.titleLabel?.font = UIFont(name: Application.Font.PROXIMANOVA_BOLD, size: 20.0)
        btnEnglishLanguage.titleLabel?.font = UIFont(name: Application.Font.PROXIMANOVA_REGULAR, size: 17.0)
        let languageCode = viewModel.arrLanguages[0]
        AppPrefsManager.shared.saveLanguageCode(languageCode: languageCode.rawValue)
        setupUI()
    }
    
    @IBAction func btnEnglishLanguageTapped(_ sender: UIButton) {
        btnArabicLanguage.titleLabel?.font = UIFont(name: Application.Font.PROXIMANOVA_REGULAR, size: 17.0)
        btnEnglishLanguage.titleLabel?.font = UIFont(name: Application.Font.PROXIMANOVA_BOLD, size: 20.0)
        let languageCode = viewModel.arrLanguages[1]
        AppPrefsManager.shared.saveLanguageCode(languageCode: languageCode.rawValue)
        setupUI()
        
    }
    
    @IBAction func onBtnNext(_ sender: UIButton) {
        let nextVc = LoginVC.instantiate(fromAppStoryboard: .Main)
        navigationController?.pushViewController(nextVc, animated: true)
    }
}

