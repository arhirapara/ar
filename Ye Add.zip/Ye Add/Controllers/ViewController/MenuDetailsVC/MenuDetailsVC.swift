//
//  MenuDetailsVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 27/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
import CocoaLumberjack

protocol sendBackQuantity {
    func quantityOfItemDelegate(quantiy: Int, selectedId: Int)
}

class MenuDetailsVC: BaseViewController {
    
    //MARK:- @IBOUTLETS
    
    @IBOutlet var scrollViewMenuDetails: UIScrollView!
    //IMAGE
    @IBOutlet weak var imgFoodItem: UIImageView!
    //LABLE
    @IBOutlet weak var lblFoodName: UILabel!
    @IBOutlet weak var lblFoodPrice: UILabel!
    @IBOutlet weak var lblQuntityOfFood: UILabel!
    @IBOutlet weak var lblPlus: UIButton!
    @IBOutlet weak var lblAboutTheDish: UILabel!
    @IBOutlet weak var lblDescreptionOfTheDish: UILabel!
    //BUTTON
    @IBOutlet weak var btnLike: UIButton!
    @IBOutlet weak var btnAddToCart: UIButton!
    @IBOutlet weak var btnMinus: UIButton!
    //VIEW
    @IBOutlet weak var add_subView: UIView!
    
    //MARK: - Properties
    var fromSearch = false
    var viewModel = ProductDetailsViewModel()
    var cartViewModel = MyCartViewModel()
    
    var delegate:sendBackQuantity?
    var menuItemView = MenuItemsView()
    var selectedIndex : Int = -1
    
    // MARK:- LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        scrollViewMenuDetails.isHidden = true
        btnAddToCart.isEnabled = false
        if fromSearch {
            DDLogInfo("fromSearch")
            getProductDetailsFromServer()
        } else {
            DDLogInfo("product info = \(viewModel.productInfo.toDictionary())")
            setProductDetailsInfo()
        }
        addProductAddedToCartNotificationObservers()
        addProductRemovedfromCartNotificationObservers()
        addOrderPlacedNotificationObservers()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        hideTabBar()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        showTabBar()
    }
    
    override func viewWillLayoutSubviews() {
        imgFoodItem.addBottomCorner(view: imgFoodItem, radius: 50)
    }
    
    // MAARK: - Functions
    func setUpUI() {
        lblAboutTheDish.text = getLocalizedString(key: .AboutTheDish)
        //        imgFoodItem.addCornerRadius(imgFoodItem.frame.size.height / 8.8)
        btnAddToCart.addCornerRadius(btnAddToCart.frame.size.height / 2)
        btnAddToCart.addShadow(color: Application.Color.Facebook_d19314, opacity: 0.5, offset: CGSize(width: 0, height: 0), radius: 8)
        add_subView.addCornerRadius(add_subView.frame.size.height / 2)
        add_subView.applyBorder(0.5, borderColor: Application.Color.Next_4d2612)
        
        
        if #available(iOS 13.0, *) {
            scrollViewMenuDetails.automaticallyAdjustsScrollIndicatorInsets = false
        } else {
            
        }
        scrollViewMenuDetails.contentInsetAdjustmentBehavior = .never
    }
    
    private func setProductDetailsInfo() {
        lblFoodName.text = viewModel.productInfo.product_name
        lblFoodPrice.text = viewModel.productInfo.price
        lblDescreptionOfTheDish.text  = viewModel.productInfo.product_details
        lblQuntityOfFood.text = viewModel.productInfo.quantity
        lblFoodPrice.text = viewModel.productInfo.formattedPrice()
        imgFoodItem.sd_setImage(with: URL(string: viewModel.productInfo.product_image.encodedUrlQueryString()), completed: nil)
        scrollViewMenuDetails.isHidden = false
        btnAddToCart.isEnabled = true
    }
    
    private func postProductAddedToCartNotification(info: ItemInfo) {
        NotificationCenter.default.post(name: .productAddedToCart, object: info)
    }
    
    // MARK: - Events
    override func onProductAddedToCartNotification(_ notification: Notification) {
        if let info = notification.object as? ItemInfo {
            if viewModel.productInfo.product_id == info.product_id {
                viewModel.productInfo.quantity = info.quantity
                lblQuntityOfFood.text = viewModel.productInfo.quantity
            }
        }
    }
    
    override func onProductRemovedFromCartNotification(_ notification: Notification) {
        if let info = notification.object as? ProductItemInfo {
            if viewModel.productInfo.product_id == info.product_id {
                viewModel.productInfo.quantity = "0"
                lblQuntityOfFood.text = viewModel.productInfo.quantity
            }
        }
    }
    
    override func onOrderPlacedNotification(_ notification: Notification) {
        if let arrInfo = notification.object as? [ProductItemInfo] {
            for palcedInfo in arrInfo {
                if viewModel.productInfo.product_id == palcedInfo.product_id {
                    viewModel.productInfo.quantity = "0"
                    lblQuntityOfFood.text = viewModel.productInfo.quantity
                    break
                }
            }
        }
    }
    
    //MARK:- @IBACTION
    @IBAction func btnMinusTapped(_ sender: UIButton) {
        if viewModel.productInfo.quantityInt() != 0 {
            viewModel.productInfo.decreaseQuantity()
            lblQuntityOfFood.text = viewModel.productInfo.quantity
            addToCart(quantity: viewModel.productInfo.quantity, productId: viewModel.productInfo.product_id, increased: false)
        }
    }
    
    @IBAction func btnPlusTapped(_ sender: UIButton) {
    
        viewModel.productInfo.increaseQuantity()
        lblQuntityOfFood.text = viewModel.productInfo.quantity
        addToCart(quantity: viewModel.productInfo.quantity, productId: viewModel.productInfo.product_id, increased: true)
 
    }
    
    @IBAction func btnAddToCartTapped(_ sender: UIButton) {
        fetchItemsForCategoryAndGoToListingScreen()
    }
    
    @IBAction func btnLikeTapped(_ sender: UIButton) {
    }
    
    @IBAction func btnBabkTapped(_ sender: Any) {
        let iteNumber = Int(lblQuntityOfFood.text ?? "") ?? 0
        delegate?.quantityOfItemDelegate(quantiy: iteNumber, selectedId: selectedIndex)
        navigationController?.popViewController(animated: true)
    }
    
    // MARK: - API calls
    private func getProductDetailsFromServer() {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        LoaderManager.showLoader()
        viewModel.getProductDetails(completion: { (success, message) in
            LoaderManager.hideLoader()
            if success {
                self.setProductDetailsInfo()
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        })
    }
    
    private func addToCart(quantity: String, productId: String, increased: Bool) {
        LoaderManager.showLoader()
        cartViewModel.addToCart(qty: quantity, productId: productId) { (success, message) in
            LoaderManager.hideLoader()
            if success {
                self.postProductAddedToCartNotification(info: self.viewModel.productInfo)
            } else {
                if !message.isEmpty {
                    Utility.windowMain()?.showToastAtBottom(message: message)
                }
                
                if increased {
                    self.viewModel.productInfo.decreaseQuantity()
                } else {
                    self.viewModel.productInfo.increaseQuantity()
                }
                self.lblQuntityOfFood.text = self.viewModel.productInfo.quantity
                
            }
        }
       
        view.isUserInteractionEnabled = true
    }
    
    private func fetchItemsForCategoryAndGoToListingScreen() {
        guard NetworkStatus.shared.isConnected else {
            showNoNetworkAlert()
            return
        }
        let categoryViewModel = GetCategoriesViewModel()
        categoryViewModel.category_id = viewModel.productInfo.category_id
        categoryViewModel.categoryName = viewModel.productInfo.category_name
        LoaderManager.showLoader()
        categoryViewModel.getItems { (success, message) in
            LoaderManager.hideLoader()
            if success {
                if self.viewModel.productInfo.quantity != "0"{
                let nextVc = MenuItemsListVC.instantiate(fromAppStoryboard: .Home)
                nextVc.viewModelCategory = categoryViewModel
                self.navigationController?.pushViewController(nextVc, animated: true)
                }else
                {
                    Utility.windowMain()?.showToastAtBottom(message: "Please add item quantity")
                }
            } else if !message.isEmpty {
                Utility.windowMain()?.showToastAtBottom(message: message)
            }
        }
    }
}
