//
//  SignUpOptionsVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 26/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class SignUpOptionsVC: BaseViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var imgIconLogo: UIImageView!
    @IBOutlet weak var btnSighnUp: UIButton!
    @IBOutlet weak var lblSighnUpDescreption: UILabel!
    @IBOutlet weak var btnLogInWithFacebook: UIButton!
    @IBOutlet weak var btnEmailORMobileNumber: UIButton!
    @IBOutlet weak var lblAlreadyAcountDescreption: UILabel!
    @IBOutlet var btnLogin: UIButton!
    
    //MARK:-LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
      //MARK:-Functions
    func setupUI()  {
        let strSignup = getLocalizedString(key: .AlreadyHaveAnAccount)
        let attrs = [
            NSAttributedString.Key.font : UIFont.init(name: Application.Font.PROXIMANOVA_BOLD, size: 12)!,
            NSAttributedString.Key.foregroundColor : Application.Color.Next_4d2612,
            NSAttributedString.Key.underlineStyle : 1] as [NSAttributedString.Key : Any]
        let attributedString = NSMutableAttributedString(string:"")
        let buttonTitleStr = NSMutableAttributedString(string:getLocalizedString(key: .Login), attributes:attrs)
        attributedString.append(buttonTitleStr)
        
        btnLogin.setAttributedTitle(attributedString, for: .normal)
        
        lblAlreadyAcountDescreption.text = strSignup
        lblSighnUpDescreption.text = getLocalizedString(key: .SighnUpDescreption)
        btnSighnUp.setTitle(getLocalizedString(key: .Signup), for: .normal)
        btnLogInWithFacebook.setTitle(getLocalizedString(key: .LoginWithFacebook), for: .normal)
        btnEmailORMobileNumber.setTitle(getLocalizedString(key: .EmailORMobileNumber), for: .normal)
        
        btnLogInWithFacebook.addCornerRadius(btnLogInWithFacebook.frame.height/2.0)
        btnEmailORMobileNumber.addCornerRadius(btnEmailORMobileNumber.frame.height/2.0)
        
        btnEmailORMobileNumber.applyBorder(1, borderColor: Application.Color.Facebook_d19314)
    }
    
    //MARK:- Action
    @IBAction func onbtnBack(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onBtnLoginAction(_ sender: UIButton) {
        let nextVc = LoginVC.instantiate(fromAppStoryboard: .Main)
        navigationController?.pushViewController(nextVc, animated: true)
    }
}
