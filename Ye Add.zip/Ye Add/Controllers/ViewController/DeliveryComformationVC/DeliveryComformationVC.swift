//
//  DeliveryComformationVC.swift
//  Yemeni
//
//  Created by Kartum Infotech on 07/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class DeliveryComformationVC: BaseViewController {

    //MARK:-@IBOutlet
    @IBOutlet weak var lblOrderPlaced: UILabel!
    @IBOutlet weak var btnsendfeedback: UIButton!
    @IBOutlet weak var btnRate: UIButton!
    @IBOutlet weak var lblDeliveryStatus: UILabel!
    
    //MARK:- LIfecycles
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    //MARK:- Functions
    
    func setupUI(){
        lblOrderPlaced.text = getLocalizedString(key: .OrderPlaced)
        lblDeliveryStatus.text = getLocalizedString(key: .DeliveryStatus)
        btnsendfeedback.setTitle(getLocalizedString(key: .SendFeedback), for: .normal)
        btnRate.setTitle(getLocalizedString(key: .Rate), for: .normal)
    }
    
    //MARK:- IBAction
    
    @IBAction func ontoBtnBack(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func OnbtnToSendfeedback(_ sender: Any) {
        
    }
    @IBAction func onbtnToRate(_ sender: Any) {
        
    }
    
}
