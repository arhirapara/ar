//
//  itemListViewCell.swift
//  Yemeni
//
//  Created by Kartum Infotech on 29/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class itemListViewCell: UITableViewCell {

    @IBOutlet weak var imgItem: UIImageView!
    @IBOutlet weak var lblQuantity: UILabel!
    @IBOutlet weak var lblmultiply: UILabel!
    @IBOutlet weak var lblItemName: UILabel!
    @IBOutlet weak var lblitemPrice: UILabel!
    
    @IBOutlet weak var lblView: UIView!
    @IBOutlet weak var lblMinus: UILabel!
    @IBOutlet var imageViewDotted: UIImageView!
    
 
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        imgItem.addCornerRadius(CGFloat(imgItem.frame.size.width / 2 ))
        imgItem.applyBorder(3, borderColor: Application.Color.Facebook_d19314)
        lblView.addCornerRadius(CGFloat(lblView.frame.size.width / 2))
        
    }

    
    func configItems(_ index : IndexPath, data: ProductItemInfo){
        let productImage: String = data.product_image
        imgItem.sd_setImage(with: URL(string: productImage.encodedUrlQueryString()), completed: nil)
        lblItemName.text = data.product_name
        lblitemPrice.text = data.formattedSubTotalOfCart()
        lblQuantity.text = data.qty
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
