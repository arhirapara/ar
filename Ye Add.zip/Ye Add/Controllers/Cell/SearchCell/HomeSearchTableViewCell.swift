//
//  HomeSearchTableViewCell.swift
//  Yemeni
//
//  Created by Sunil Zalavadiya on 23/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class HomeSearchTableViewCell: UITableViewCell {

    // MARK: - Outlets
    @IBOutlet weak var lblName: UILabel!
    
    // MARK: - Lifecycles
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
