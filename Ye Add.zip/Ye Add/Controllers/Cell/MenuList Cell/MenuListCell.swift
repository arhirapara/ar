//
//  MenuListCell.swift
//  Yemeni
//
//  Created by Kartum Infotech on 27/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
protocol icreaseDecreaseItemDelegate {
    func increseItem(_ index:Int)
    func decreseItem(_ index:Int)
    
}


class MenuListCell: UITableViewCell {
    
    var viewModel = MyCartViewModel()
    var delegate: icreaseDecreaseItemDelegate?
    
    @IBOutlet var viewimageView: UIView!
    @IBOutlet var viewMain: UIView!
    @IBOutlet weak var imgFoodItem: UIImageView!
    @IBOutlet weak var imgKingcrown: UIImageView!
    @IBOutlet weak var lblFoodName: UILabel!
    @IBOutlet weak var lblFoodPrice: UILabel!
    @IBOutlet weak var lblTopOfTheWeek: UILabel!
    @IBOutlet weak var btnLike: UIButton!
    @IBOutlet weak var btnAddItem: UIButton!
    @IBOutlet weak var lblNumberOfItem: UILabel!
    @IBOutlet weak var viewCart: UIView!
    @IBOutlet weak var btnDecrease: UIButton!
    @IBOutlet weak var btnIncrease: UIButton!
    
    var addToCart:((Int) -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        setupUI()
    }
    
    override func draw(_ rect: CGRect) {
        viewMain.addCornerRadius(22.5)
        //  viewimageView.addCornerRadius(22.5)
        imgFoodItem.addCornerRadius(22.5)
        viewCart.addCornerRadius(22.5)
    }
    
    func setupUI()  {
        if isRTLLanguage() {
            let addImage = UIImage(named: "ic_add")?.imageFlippedForRightToLeftLayoutDirection()
            btnAddItem.setBackgroundImage(addImage, for: .normal)
        }
        lblTopOfTheWeek.text = getLocalizedString(key: .TopOfTheWeek)
        btnLikeSelected()
        
    }
    
    func configItems(_ index : IndexPath, data: ItemInfo){
        btnAddItem.tag = index.row
        btnIncrease.tag = index.row
        btnDecrease.tag = index.row
        lblFoodName.text = data.product_name
        let productImage: String = data.product_image
        imgFoodItem.sd_setImage(with: URL(string: productImage.encodedUrlQueryString()), completed: nil)
        lblFoodPrice.text = data.formattedPrice()
        
        if let qty = Int(data.quantity), qty > 0 {
            showAddToCartOption(show: true, defaultQty: qty)
        } else {
            showAddToCartOption(show: false, defaultQty: 0)
        }
    }
    
    func showAddToCartOption(show: Bool, defaultQty: Int) {
        viewCart.isHidden = !show
        lblNumberOfItem.text = "\(defaultQty)"
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    func btnLikeSelected(){
        let imageFilled = UIImage(named: "ic_likeClicked")
        btnLike.setImage(imageFilled, for: .selected)
    }
    
    @IBAction func btnLikeTapped(_ sender: UIButton) {
        
        btnLike.isSelected.toggle()
    }
    @IBAction func btnAddItemTapped(_ sender: UIButton) {
        guard let addCartItem = self.addToCart else { return }
               addCartItem(sender.tag)
        
    }
    
    @IBAction func btnDecreaseTapped(_ sender: UIButton) {
        delegate?.decreseItem(sender.tag)
        
    }
    @IBAction func btnIncreaseTapped(_ sender: UIButton) {
        delegate?.increseItem(sender.tag)
    }
}
