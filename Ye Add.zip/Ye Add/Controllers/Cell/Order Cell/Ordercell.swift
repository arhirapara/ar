//
//  Ordercell.swift
//  Yemeni
//
//  Created by Kartum Infotech on 04/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class Ordercell: UITableViewCell {
    
    //MARK:- IBOutlet
    @IBOutlet weak var viewOfItems: UIView!
    @IBOutlet weak var viewOfPrice: UIView!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblProductQty: UILabel!
    @IBOutlet weak var lblSubTotal: UILabel!
    @IBOutlet weak var lblItems: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var imgProduct: UIImageView!
    
    //MARK:- LifeCycle
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        setUpUi()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    //MARK:- Functions
    
    
    func setUpUi(){
        
        lblItems.text = getLocalizedString(key: .Items)
        lblPrice.text = getLocalizedString(key: .Price)
        imgProduct.addCornerRadius(imgProduct.frame.size.height / 2)
        imgProduct.applyBorder(3, borderColor: Application.Color.Facebook_d19314)
        viewOfItems.addCornerRadius(viewOfItems.frame.size.height / 2)
        viewOfPrice.addCornerRadius(viewOfItems.frame.size.height / 2)
    }
    
    func configure(info: ProductItemInfo) {
        lblProductName.text = info.product_name
        lblSubTotal.text = info.formattedSubTotal()
        lblProductQty.text = info.qty
        imgProduct.sd_setImage(with: URL(string: info.product_image.encodedUrlQueryString()), completed: nil)
    }
    
    
}
