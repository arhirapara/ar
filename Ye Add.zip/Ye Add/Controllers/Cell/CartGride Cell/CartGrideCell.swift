//
//  CartGrideCell.swift
//  Yemeni
//
//  Created by Kartum Infotech on 28/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class CartGrideCell: UICollectionViewCell {

    // MARK: - Outlets
    @IBOutlet weak var imageViewMenu: UIImageView!
    @IBOutlet weak var minusbtnView: UIView!
    
    // MARK: - Lifecycles
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func draw(_ rect: CGRect) {
        super.draw(rect)
        imageViewMenu.addCornerRadius(imageViewMenu.frame.size.height / 2)
        minusbtnView.addCornerRadius(minusbtnView.frame.size.height / 2)
        imageViewMenu.applyBorder(3, borderColor: Application.Color.Facebook_d19314)
    }
    
    // MARK: Functions
    func configure(info: ProductItemInfo) {
        imageViewMenu.sd_setImage(with: URL(string: info.product_image.encodedUrlQueryString()), completed: nil)
    }
}
