//
//  MenuCell.swift
//  Yemeni
//
//  Created by Kartum Infotech on 27/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
import SDWebImage

protocol icreaseItemDelegate {
    func increseItem(_ index:Int)
    func decreseItem(_ index:Int)
}


class MenuCell: UICollectionViewCell {
    // MARK: - Outlets
    @IBOutlet var viewCartAdd: UIView!
    @IBOutlet var viewMain: UIView!
    @IBOutlet weak var imgFoodPicture: UIImageView!
    @IBOutlet weak var btnAddItem: UIButton!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var btnNextFood: UIButton!
    @IBOutlet weak var lblFoodName: UILabel!
    @IBOutlet var btnMinusItem: UIButton!
    @IBOutlet var lblTotalItemCount: UILabel!
    @IBOutlet var btnAddToItem: UIButton!
    
    // MARK: - Properties
    var delegate: icreaseItemDelegate?
    var addToCart:((Int) -> Void)?

    // MARK: - Lifecycles
    override func awakeFromNib() {
        super.awakeFromNib()
        if isRTLLanguage() {
            let addImage = UIImage(named: "ic_cornerImage_RTL")
            btnAddItem.setBackgroundImage(addImage, for: .normal)
        } else {
            let addImage = UIImage(named: "ic_cornerImage")
            btnAddItem.setBackgroundImage(addImage, for: .normal)
        }
    }

    override func draw(_ rect: CGRect) {
        super.draw(rect)
        imgFoodPicture.addCornerRadius(22.5)
        viewMain.addCornerRadius(22.5)
        viewCartAdd.addCornerRadius(22.5)
    }
    // MARK: - Functions
    func configItems(_ index : IndexPath, data: ItemInfo) {
        btnAddItem.tag = index.row
        btnMinusItem.tag = index.row
        btnAddToItem.tag = index.row
        btnNextFood.tag = index.row
        let productImage: String = data.product_image
        imgFoodPicture.sd_setImage(with: URL(string: productImage.encodedUrlQueryString()), completed: nil)
        lblFoodName.text = data.product_name
        lblPrice.text = data.formattedPrice()
        
        if let qty = Int(data.quantity), qty > 0 {
            showAddToCartOption(show: true, defaultQty: qty)
        } else {
            showAddToCartOption(show: false, defaultQty: 0)
        }
    }
    

    func showAddToCartOption(show: Bool, defaultQty: Int) {
        viewCartAdd.isHidden = !show
        lblTotalItemCount.text = "\(defaultQty)"
    }
    
    // MARK: - Actions
    @IBAction func btnAddItemTapped(_ sender: UIButton) {
        guard let addCartItem = self.addToCart else { return }
        addCartItem(sender.tag)
    }
    
    @IBAction func btnNextFoodTapped(_ sender: UIButton) {
    }
    
    @IBAction func onButtonDecreaseItem(_ sender: UIButton) {
        delegate?.decreseItem(sender.tag)
    }
        
    @IBAction func onBtnIncreaseItem(_ sender: UIButton) {
        delegate?.increseItem(sender.tag)
    }
}
