//
//  MenuitemsCell.swift
//  Yemeni
//
//  Created by Kartum Infotech on 27/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class MenuitemsCell: UICollectionViewCell {

    @IBOutlet var viewLine: UIView!
    @IBOutlet var viewRound: UIView!
    @IBOutlet var lblMenuName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func draw(_ rect: CGRect) {
        viewRound.addCornerRadius(viewRound.frame.height/2)
        //lblMenuName.font = UIFont.init(name: Application.Font.PROXIMANOVA_THIN, size: 14)
    }
    
    func configData(_ data: HomeModelInfo, selectedId: String = "")  {
        lblMenuName.text = data.category_name
        
        let id = data.category_id
        if id == selectedId {
            viewLine.isHidden = false
            lblMenuName.textColor = Application.Color.Next_4d2612
            lblMenuName.font = UIFont.init(name: Application.Font.PROXIMANOVA_BOLD, size: 14)
        }
        else {
            viewLine.isHidden = true
            lblMenuName.textColor = Application.Color.Description_B8AFA7
            lblMenuName.font = UIFont.init(name: Application.Font.PROXIMANOVA_THIN, size: 14)
        }
    }
}
