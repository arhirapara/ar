//
//  SplashViewController.swift
//  MovieApp
//
//  Created by Kartum on 24/02/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit

class SplashViewController: UIViewController {
    
    // MARK: IBOutlets
//    @IBOutlet weak var imgBG: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let screen = UIScreen.main.bounds
        
//        imgBG.frame = CGRect(x: 0, y: 0, width: screen.width, height: screen.height)
//        imgBG.applyViewGradient(colors: [Application.Color.START_COLOR, Application.Color.END_COLOR])
    }

}
