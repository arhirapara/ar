//
//  BaseViewController.swift
//  Drivo
//
//  Created by Kartum on 03/03/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
import MessageUI

class BaseViewController: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func addBackgroundNotificationObserver() {
        NotificationCenter.default.addObserver(self, selector: #selector(onApplicationDidEnterBackgroundNotification), name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onApplicationDidEnterBackgroundNotification), name: UIApplication.willResignActiveNotification, object: nil)
    }
    
    func removeBackgroundNotificationObserver() {
        NotificationCenter.default.removeObserver(self, name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIApplication.willResignActiveNotification, object: nil)
    }
    
    func addForegorundNotificationObserver() {
        NotificationCenter.default.addObserver(self, selector: #selector(onApplicationWillEnterForegroundNotification), name: UIApplication.willEnterForegroundNotification, object: nil)
    }
    
    func removeForegroundNotificationObserver() {
        NotificationCenter.default.removeObserver(self, name: UIApplication.willEnterForegroundNotification, object: nil)
    }
    
    func addProductAddedToCartNotificationObservers() {
        NotificationCenter.default.addObserver(self, selector: #selector(onProductAddedToCartNotification(_:)), name: .productAddedToCart, object: nil)
    }
    
    func removeProductAddedToCartNotificationObservers() {
        NotificationCenter.default.removeObserver(self, name: .productAddedToCart, object: nil)
    }
    
    func addProductRemovedfromCartNotificationObservers() {
        NotificationCenter.default.addObserver(self, selector: #selector(onProductRemovedFromCartNotification(_:)), name: .productRemovedFromCart, object: nil)
    }
    
    func removeProductRemovedFromCartNotificationObservers() {
        NotificationCenter.default.removeObserver(self, name: .productRemovedFromCart, object: nil)
    }
    
    func addOrderPlacedNotificationObservers() {
        NotificationCenter.default.addObserver(self, selector: #selector(onOrderPlacedNotification(_:)), name: .orderPlacedNotification, object: nil)
    }
    
    func removeOrderPlacedNotificationObservers() {
        NotificationCenter.default.removeObserver(self, name: .orderPlacedNotification, object: nil)
    }
    
    //    func showTabBar() {
    //        if let tabBarVC = navigationController?.tabBarController as? CustomTabBarController {
    //            tabBarVC.setTabBarHidden(tabBarHidden: false, vc: self)
    //        }
    //    }
    //
    //    func hideTabBar() {
    //        if let tabBarVC = navigationController?.tabBarController as? CustomTabBarController {
    //            tabBarVC.setTabBarHidden(tabBarHidden: true, vc: self)
    //        }
    //    }
    
    //    func setMenuItem() {
    //        let menuItem = UIBarButtonItem(image: UIImage(named: "ic_menu"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(onBtnMenu(_:)))
    //        let menu  = UIBarButtonItem(title: nil, style: UIBarButtonItem.Style.plain, target: self, action: nil)
    //         navigationItem.leftBarButtonItems = [menu,menuItem]
    //    }
    
    func frame(for image: UIImage?, inImageViewAspectFit imageView: UIImageView?) -> CGRect {
        let imageRatio = Float((image?.size.width ?? 0.0) / (image?.size.height ?? 0.0))
        let viewRatio = Float((imageView?.frame.size.width ?? 0.0) / (imageView?.frame.size.height ?? 0.0))
        if imageRatio < viewRatio {
            let scale = Float((imageView?.frame.size.height ?? 0.0) / (image?.size.height ?? 0.0))
            let width = Float(CGFloat(scale) * (image?.size.width ?? 0.0))
            let topLeftX = Float(((imageView?.frame.size.width ?? 0.0) - CGFloat(width)) * 0.5)
            return CGRect(x: CGFloat(topLeftX), y: 0, width: CGFloat(width), height: imageView?.frame.size.height ?? 0.0)
        } else {
            let scale = Float((imageView?.frame.size.width ?? 0.0) / (image?.size.width ?? 0.0))
            let height = Float(CGFloat(scale) * (image?.size.height ?? 0.0))
            let topLeftY = Float(((imageView?.frame.size.height ?? 0.0) - CGFloat(height)) * 0.5)
            
            return CGRect(x: 0, y: CGFloat(topLeftY), width: imageView?.frame.size.width ?? 0.0, height: CGFloat(height))
        }
    }
    
    func showTabBar() {
        if let tabBarVC = navigationController?.tabBarController as? TabBarVC {
            tabBarVC.setTabBarHidden(tabBarHidden: false, vc: self)
        }
    }
    
    func hideTabBar() {
        if let tabBarVC = navigationController?.tabBarController as? TabBarVC {
            tabBarVC.setTabBarHidden(tabBarHidden: true, vc: self)
        }
    }
    
    func setBackItem() {
        let backItem = UIBarButtonItem(image: UIImage(named: "ic_arrow_back"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(onBtnBack))
        navigationItem.leftBarButtonItem = backItem
    }
    
    func showNoNetworkAlert() {
        Utility.showMessageAlert(title: getLocalizedString(key: .noNetworkConnection), andMessage: getLocalizedString(key: .checkConnectionMsg))
    }
    
    func canConnectChannel() -> Bool {
//        if let status = UserProfileStatus(rawValue: AppPrefsManager.shared.getLoggedInUserInfo().profile_status) {
//            return status == .available
//        }
        return false
    }
    
    func postProfileStatusChangedNotification() {
        NotificationCenter.default.post(name: .USER_PROFILE_STATUS_CHANGED, object: nil)
    }
    
    
    func openFeedbackMailComposer() {
//        let recipientEmail = "feedback@yemini.com"
//        
//        if MFMailComposeViewController.canSendMail() {
//            let mail = MFMailComposeViewController()
//            mail.mailComposeDelegate = self
//            mail.setToRecipients([recipientEmail])
//            present(mail, animated: true)
//            
//        } else if let emailUrl = createEmailUrl(to: recipientEmail, subject: "", body: "") {
//            UIApplication.shared.open(emailUrl)
//        } else {
//            Utility.showMessageAlert(title: "Error", andMessage: "Email not configured on your device.", withOkButtonTitle: "OK")
//        }
    }
    
    private func createEmailUrl(to: String, subject: String, body: String) -> URL? {
        let subjectEncoded = subject.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
        let bodyEncoded = body.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
        
        let gmailUrl = URL(string: "googlegmail://co?to=\(to)&subject=\(subjectEncoded)&body=\(bodyEncoded)")
        let outlookUrl = URL(string: "ms-outlook://compose?to=\(to)&subject=\(subjectEncoded)")
        let yahooMail = URL(string: "ymail://mail/compose?to=\(to)&subject=\(subjectEncoded)&body=\(bodyEncoded)")
        let sparkUrl = URL(string: "readdle-spark://compose?recipient=\(to)&subject=\(subjectEncoded)&body=\(bodyEncoded)")
        let defaultUrl = URL(string: "mailto:\(to)?subject=\(subjectEncoded)&body=\(bodyEncoded)")
        
        if let gmailUrl = gmailUrl, UIApplication.shared.canOpenURL(gmailUrl) {
            return gmailUrl
        } else if let outlookUrl = outlookUrl, UIApplication.shared.canOpenURL(outlookUrl) {
            return outlookUrl
        } else if let yahooMail = yahooMail, UIApplication.shared.canOpenURL(yahooMail) {
            return yahooMail
        } else if let sparkUrl = sparkUrl, UIApplication.shared.canOpenURL(sparkUrl) {
            return sparkUrl
        }
        
        return defaultUrl
    }
    
    
    // MARK: - NotificationCenter events
    @objc func onApplicationDidEnterBackgroundNotification() {
        
    }
    
    @objc func onApplicationWillEnterForegroundNotification() {
        
    }
    
    @objc func onProductAddedToCartNotification(_ notification: Notification) {
        
    }
    
    @objc func onProductRemovedFromCartNotification(_ notification: Notification) {
        
    }
    
    @objc func onOrderPlacedNotification(_ notification: Notification) {
    }
    
    // MARK: - Actions
    @objc func onBtnBack(_ sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
    
    //    @objc func onBtnMenu(_ sender: UIBarButtonItem) {
    //       // present(SideMenuManager.default.leftMenuNavigationController!, animated: true, completion: nil)
    //         self.sideMenuController?.revealMenu()
    //    }
    
    deinit {
        removeBackgroundNotificationObserver()
        removeForegroundNotificationObserver()
        removeProductAddedToCartNotificationObservers()
        removeProductRemovedFromCartNotificationObservers()
        removeOrderPlacedNotificationObservers()
    }
}

// MARK: - MFMailComposeViewControllerDelegate
extension BaseViewController: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        dismiss(animated: true, completion: nil)
    }
}
