//
//  SecondViewController.swift
//  test
//
//  Created by AR on 25/06/20.
//  Copyright © 2020 asfasf. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("Heelp")
    }


}

