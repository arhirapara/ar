//
//  ViewController.swift
//  test
//
//  Created by AR on 25/06/20.
//  Copyright © 2020 asfasf. All rights reserved.
//

typealias typeAliasDictionary               = [String: AnyObject]
typealias typeAliasStringDictionary         = [String: String]

let PARAMETER_KEY                               = "PARAMETER_KEY"
let PARAMETER_VALUE                             = "PARAMETER_VALUE"

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var btnPriview: UIButton!
    @IBOutlet weak var btnNewScreen: UIButton!
    @IBOutlet weak var collectionViewSplace: UICollectionView!
    @IBOutlet weak var pageControlView: UIView!
    
    let pageControl = SCPageControlView()
    var currentPage = 0
    var arrimage = [typeAliasStringDictionary]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        arrimage = self.getTitle()!
        btnPriview.alpha = 0
        btnNewScreen.alpha = 1
        btnNewScreen.alpha = 0
        collectionViewSplace.delegate = self
        collectionViewSplace.dataSource = self
        pageControl.frame = CGRect(x: 0, y: 0, width: pageControlView.frame.width, height: pageControlView.frame.height)
        pageControl.scp_style = .SCNormal
        pageControl.set_view(arrimage.count, current: 0, current_color: UIColor.red)
        //collectionViewSplace.isPagingEnabled = true
        pageControlView.addSubview(pageControl)
        collectionViewSplace.register(UINib(nibName: "CollectionViewSplaceCell", bundle: nil), forCellWithReuseIdentifier: "CollectionViewSplaceCell")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        collectionViewSplace.reloadData()
    }
    
    func getTitle() -> [typeAliasStringDictionary]? {
        
        let dict = [
            "Title" : "sdgfhjkljhgfdsghjkl;jhgfdsghjkl;jhgfdsgh",
            "link" : "2"
        ]
        let dict1 = [
            "Title" : "Environment Earth Day In the hands of trees growing seedlings. Bokeh green Background Female hand holding tree on nature field gra.",
            "link" : "1"
        ]
        let dict2 = [
            "Title" : "ARRARARARAAR",
            "link" : "3"
        ]
        let arrTitle = [dict, dict1, dict2]
        return arrTitle
    }
    
    func showButton()  {
        if arrimage.count - 1 == currentPage {
            btnNewScreen.alpha = 1;
        }
        else {
            btnNewScreen.alpha = 0;
        }
    }
    
    //MARK: Scrollview Delegate
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let pageWidth = screenWidth
        currentPage = Int(floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1)
        pageControl.currentOfPage = currentPage
        pageControl.scroll_did(scrollView)
        if currentPage == 0 {
            btnPriview.alpha = 0
            btnNewScreen.alpha = 1
        } else {
            btnPriview.alpha = 1
            btnNewScreen.alpha = 1
        }
       // self.showButton()
    }
    
//    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
//        let pageWidth = screenWidth
//        currentPage = Int(floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1)
//        pageControl.currentOfPage = currentPage
//        pageControl.scroll_did(scrollView)
//    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrimage.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewSplaceCell", for: indexPath) as! CollectionViewSplaceCell
        let dictData: typeAliasStringDictionary = arrimage[indexPath.row]
        cell.lblTitle.text = dictData["Title"]
        cell.imageViewLogo.contentMode = .scaleToFill
        cell.imageViewLogo.image = UIImage(named: dictData["link"]!)
        cell.lblTitle.numberOfLines = 0
        return cell
    }
    
    //MARK: CollectionView FlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var bannerWidth: CGFloat = 0.0
        var bannerHeight: CGFloat = 0.0
        var heightImageView: CGFloat = 0.00
        
//        if !arrImg.isEmpty{
//            var imageData: Data? = nil
//            if let url = URL(string: arrImg[indexPath.row].valuForKeyString("mb_banners")) {
//                do {
//                    imageData = try Data(contentsOf: url)
//                }
//                catch {
//                    print(error)
//                }
//            }
//            var image: UIImage? = nil
//            if let imageData = imageData {
//                image = UIImage(data: imageData)
//            }
//
//            bannerWidth = image!.size.width
//            bannerHeight = image!.size.height
//
//            heightImageView = (screenWidth * CGFloat(bannerHeight)) / CGFloat(bannerWidth)
//            heightImageView = ceil(heightImageView)
//            constrintHeightForCollectionView.constant = heightImageView
//            self.layoutIfNeeded()
//            return CGSize(width: screenWidth, height: heightImageView)
//        }
//        constrintHeightForCollectionView.constant = 200
//        self.layoutIfNeeded()
        
        var uiImage: UIImage? = nil
        let dictData: typeAliasStringDictionary = arrimage[indexPath.row]
        uiImage = UIImage(named: dictData["link"]!)
        bannerWidth = uiImage!.size.width
        bannerHeight = uiImage!.size.height
        heightImageView = (screenWidth * CGFloat(bannerHeight)) / CGFloat(bannerWidth)
        heightImageView = ceil(heightImageView)
        return CGSize(width: screenWidth, height: collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    @IBAction func btnShowNewScreen(_ sender: UIButton) {
        if (sender == btnNewScreen) {
            if (currentPage == arrimage.count - 1) {
                //  @IBAction func btnShowNewScreen() {
                //        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                //        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
                //        self.navigationController?.pushViewController(nextViewController, animated: true)
                
                //Jump second StoryBord
                let next = UIStoryboard(name: "second", bundle: nil)
                let ne = next.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
                self.navigationController?.pushViewController(ne, animated: true)
            }
            else {
                currentPage += 1;
                collectionViewSplace.scrollToItem(at: IndexPath(item: currentPage, section: 0), at: .centeredHorizontally, animated: true)
            }
        }
        else {
            currentPage -= 1;
            collectionViewSplace.scrollToItem(at: IndexPath(item: currentPage, section: 0), at: .centeredHorizontally, animated: true)
        }
    }
    
}

// Screen width.
public var screenWidth: CGFloat {
    return UIScreen.main.bounds.width
}

// Screen height.
public var screenHeight: CGFloat {
    return UIScreen.main.bounds.height
}
