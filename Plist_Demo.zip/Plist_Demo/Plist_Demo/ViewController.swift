//
//  ViewController.swift
//  Plist_Demo
//
//  Copyright © 2019 . All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txt4: UITextField!
    @IBOutlet var txt3: UITextField!
    @IBOutlet var txt2: UITextField!
    @IBOutlet var txt1: UITextField!
    
    override func viewDidLoad() { super.viewDidLoad() }

    override func didReceiveMemoryWarning() { super.didReceiveMemoryWarning() }

    
    //Actiobn
    @IBAction func btnClickAction() {
        //Write Data Using Plist
        //CUSTOME PLIST CREATE
        
        let string = "ni123n456iniASijasod!jhadgfhjagdfjhg4kg46gjg6j4678a9-kasd aosd0"
        
        let numbersString = string.filter { Int(String($0)) != nil }
        
        print("Numbar String : \(numbersString)")

        let fileManager = FileManager.default
        
        let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        let path = documentDirectory.appending("/Demo.plist")
        
        do {
            if FileManager.default.fileExists(atPath: path) {
                try FileManager.default.removeItem(atPath: path)
            }
        } catch {
            print(error)
        }
        
        if(!fileManager.fileExists(atPath: path)){
            print(path)
            
            let data : [String: String] = [
                "Company": txt1.text!,
                "FullName": txt2.text!,
                "FirstName": txt3.text!,
                "LastName": txt4.text!,
                // any other key values
            ]
            
            let someData = NSDictionary(dictionary: data)
            let isWritten = someData.write(toFile: path, atomically: true)
            print("is the file created: \(isWritten)")
            
        } else{
            print("file exists")
        }
       
    }
    
    @IBAction func btnDemoproAction() {
        let data : [String: String] = [
                        "Company": txt1.text!,
                        "FullName": txt2.text!,
                        "FirstName": txt3.text!,
                        "LastName": txt4.text!,
                        // any other key values
                    ]
        
        self.plistData("DemoPro", dictData: data)
    }
    
    
    @IBAction func btnDemoProReadDataAction() {
        var nsDictionary: NSDictionary?
        if let path = Bundle.main.path(forResource: "DemoPro", ofType: "plist") {
            nsDictionary = NSDictionary(contentsOfFile: path)
        }
        print("Data Path : \(nsDictionary!)")
    }
    
    
    @IBAction func btnReadAction() {
        self.readPropertyList()
    }
    
    func readPropertyList() {
        let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        let path = documentDirectory.appending("/Demo.plist")
        
        var nsDictionary: NSDictionary?
            nsDictionary = NSDictionary(contentsOfFile: path)
        print("Plist Data : ", nsDictionary!)
    }
    
    
    
    
    func plistData(_ stPlistName: String, dictData:[String: String])  {
        let fileManager = FileManager.default
        let path = Bundle.main.path(forResource: stPlistName, ofType: "plist")
        
        do {
            if FileManager.default.fileExists(atPath: path!) {
                try FileManager.default.removeItem(atPath: path!)
            }
        } catch {
            print(error)
        }
        
        if(!fileManager.fileExists(atPath: path!)){
            print(path!)
            let someData = NSDictionary(dictionary: dictData)
            let isWritten = someData.write(toFile: path!, atomically: true)
            print("is the file created: \(isWritten)")
            
        } else{
            print("file exists")
        }
    }
}
