//
//  AppDelegate.swift
//  Yemeni
//
//  Created by Kartum Infotech on 25/08/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import CocoaLumberjack

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        // Logger
        
        if isRTLLanguage() {
            UIView.appearance().semanticContentAttribute = .forceRightToLeft
        } else {
            UIView.appearance().semanticContentAttribute = .forceLeftToRight
        }
        
        if Application.debug {
            DDLog.add(DDTTYLogger.sharedInstance!) // TTY = Xcode console
        }
        
        //        registerDeviceForRemoteNotifictaion()
        
        NetworkStatus.shared.startNetworkReachabilityObserver()
        setupApplicationUIAppearance()
        
        return true
    }
    
    // MARK: - Functions
    private func setupApplicationUIAppearance() {
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.enableAutoToolbar = true
        setupNavigationBarApperance(navigationBar: UINavigationBar.appearance())
    }
    
    func setupNavigationBarApperance(navigationBar: UINavigationBar, color: UIColor = Application.Color.CHARADE_252932) {
        navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), NSAttributedString.Key.font : UIFont(name: Application.Font.MONTSERRAT_REGULAR, size: 19.0)!]
        navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        navigationBar.shadowImage = UIImage()
        navigationBar.tintColor = UIColor.white
        navigationBar.backgroundColor = color
        navigationBar.barTintColor = color
        navigationBar.isTranslucent = false
    }
    
    func logoutFromApplication() {
        ///Perform logout action like clear data
        AppPrefsManager.shared.removeLoggedInUserInfo()
        AppPrefsManager.shared.removeToken()
        AppPrefsManager.shared.setIsUserLogin(isUserLogin: false)
        if let rootNavVc = window?.rootViewController as? UINavigationController {
            rootNavVc.popToRootViewController(animated: false)
        }
    }
    
    // MARK: - Push Notification Methods
    func registerDeviceForRemoteNotifictaion() {
        let center  = UNUserNotificationCenter.current()
        center.delegate = self
        center.requestAuthorization(options: [.sound, .alert, .badge]) { (granted, error) in
            guard granted else { return }
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
            }
        }
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        DDLogVerbose("didRegisterForRemoteNotificationsWithDeviceToken")
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        DDLogError("didFailToRegisterForRemoteNotificationsWithError = \(error)")
    }
}

// MARK: - UNUserNotificationCenterDelegate
extension AppDelegate: UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        DDLogVerbose("userNotificationCenter willPresent: \(notification.request.content)")
        handleScreenRedirection(pushInfo: notification.request.content.userInfo)
        completionHandler([.alert, .badge, .sound])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        DDLogVerbose("userNotificationCenter didReceive: \(response.notification.request.content)")
        handleScreenRedirection(pushInfo: response.notification.request.content.userInfo)
        completionHandler()
    }
}

extension AppDelegate {
    private func handleScreenRedirection(pushInfo: [AnyHashable: Any]) {
        
    }
}
