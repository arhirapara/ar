//
//  HeaderParameterRequest.swift
//  Drivo
//
//  Created by Sunil Zalavadiya on 07/05/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation
import Alamofire

class HeaderParameterRequest {
    // MARK: - Properties
    var params = HTTPHeaders()
    
    // MARK: - Init
    init() {
        let languageCode = AppPrefsManager.shared.getLanguageCode()
        var langCode = ""
        if languageCode == LanguageCode.english.rawValue {
            langCode = LanguageCode.english.codeForApi()
        } else if languageCode == LanguageCode.arabic.rawValue {
            langCode = LanguageCode.arabic.codeForApi()
        }
        addParameter(paramName: .YeminiApiKey, value: Application.YeminiApiKEY)
        addParameter(paramName: .Lang, value: langCode)
        if AppPrefsManager.shared.isUserLogin() {
            let userData = AppPrefsManager.shared.getLoggedInUserInfo()
            addParameter(paramName: .Yemini_Login_Token, value: userData.login_token)
            addParameter(paramName: .User_ID, value: userData.user_id)
        }
    }
    
    // MARK: - Functions
    func addParameter(paramName: ApiParamNameHeader, value: Any?) {
        if let value = value as? String {
            params[paramName.rawValue] = value
        }
    }
}
