//
//  API.swift
//  Sunil Zalavadiya
//
//  Created by Sunil Zalavadiya on 24/06/20.
//  Copyright © 2020 Sunil Zalavadiya. All rights reserved.
//

import Foundation

struct API {
    
    static var BASE_URL                 = "https://wepixel.in"
    
    static var DATA_PRIVACY             =   BASE_URL + "/data_privacy"
    static var AGB                      =   BASE_URL + "/agb"
    static var IMPRINT                  =   BASE_URL + "/imprint"
    
    static var BASE_API_URL             =   BASE_URL + "/yemini/api/v1/auth/"
    
    static var COUNTRY_LIST             =   BASE_API_URL + "getCountyList"
    static var LOGIN_OTP                =   BASE_API_URL + "login_otp"
    static var SIGNUP                   =   BASE_API_URL + "signup"
    static var UPDATE_FCM_TOKEN         =   BASE_API_URL + "update_fcm_token"
    
    static var REGISTER                 =   BASE_API_URL + "register"
    static var UPDATE_PROFILE           =   BASE_API_URL + "update_profile"
    static var LOGIN                    =   BASE_API_URL + "login"
    static var FORGOT_PASSWORD          =   BASE_API_URL + "forgot_password"
    static var ITEMS                    =   BASE_API_URL + "items"
    static var SEARCH_PRODUCT           =   BASE_API_URL + "search_product"
    static var CATEGORY                 =   BASE_API_URL + "category"
    static var ADD_TO_CART              =   BASE_API_URL + "add_to_cart"
    static var REMOVE_ITEM_CART         =   BASE_API_URL + "remove_item_cart"
    static var MY_CART                  =   BASE_API_URL + "my_cart"
    static var MY_ORDER                 =   BASE_API_URL + "my_order"
    static var PLACE_ORDER              =   BASE_API_URL + "place_order"
    static var LOGOUT                   =   BASE_API_URL + "logout"
    static var DELIVERY_STATUS          =   BASE_API_URL + "delivery_status"
    static var REPEAT_ORDER             =   BASE_API_URL + "repeat_order"
    static var PRODUCT_DETAIL            =   BASE_API_URL + "product_detail"

    
}
