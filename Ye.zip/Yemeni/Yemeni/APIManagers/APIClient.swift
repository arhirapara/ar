//
//  ApiClient.swift
//  Sunil Zalavadiya
//
//  Created by Sunil Zalavadiya on 24/06/20.
//  Copyright © 2020 Sunil Zalavadiya. All rights reserved.
//

import Foundation
import Alamofire
import CocoaLumberjack

class APIClient {
    private var networkService = NetworkService()
    
    //This should call if you need response, error
    private func callAPI(url: String, method: Alamofire.HTTPMethod, parameters: Parameters? = nil, headers: HTTPHeaders? = nil, parameterEncoding: ParameterEncoding = JSONEncoding.default, showHttpErrorAutomatic: Bool = false, checkForAuthorization: Bool = true, completion completionBlock: @escaping (Any?, Error?) -> Void) -> DataRequest {
        
        return networkService.callApi(url: url, method: method, parameters: parameters, headers: headers, parameterEncoding: parameterEncoding,
                                      success: { response, _ in
                                        DispatchQueue.main.async {
                                            if checkForAuthorization {
                                                self.checkForAuthorization(response: response)
                                            }
                                            completionBlock(response, nil)
                                        }
        },
                                      failure: { (error, status) -> Bool in
                                        DispatchQueue.main.async {
                                            completionBlock(nil, error)
                                        }
                                        return showHttpErrorAutomatic
        })
    }
    
    //This should call if you need response, error, status code
    private func callAPI(url: String, method: Alamofire.HTTPMethod, parameters: Parameters? = nil, headers: HTTPHeaders? = nil, parameterEncoding: ParameterEncoding = JSONEncoding.default, showHttpErrorAutomatic: Bool = false, checkForAuthorization: Bool = true, completion completionBlock: @escaping (Any?, Error?, Int?) -> Void) -> DataRequest {
        
        return networkService.callApi(url: url, method: method, parameters: parameters, headers: headers, parameterEncoding: parameterEncoding,
                                      success: { response, statucCode in
                                        DispatchQueue.main.async {
                                            if checkForAuthorization {
                                                self.checkForAuthorization(response: response)
                                            }
                                            completionBlock(response, nil, statucCode)
                                        }
        },
                                      failure: { (error, statucCode) -> Bool in
                                        DispatchQueue.main.async {
                                            completionBlock(nil, error, statucCode)
                                        }
                                        return showHttpErrorAutomatic
        })
    }
    
    //This should call if you need response, header, error, status code
    private func callAPI(url: String, method: Alamofire.HTTPMethod, parameters: Parameters? = nil, headers: HTTPHeaders? = nil, parameterEncoding: ParameterEncoding = JSONEncoding.default, showHttpErrorAutomatic: Bool = false, checkForAuthorization: Bool = true, completion completionBlock: @escaping (Any?, Any?, Error?, Int?) -> Void) -> DataRequest {
        
        return networkService.callApi(url: url, method: method, parameters: parameters, headers: headers, parameterEncoding: parameterEncoding,
                                      success: { response, responseHeader, statucCode in
                                        DispatchQueue.main.async {
                                            if checkForAuthorization {
                                                self.checkForAuthorization(response: response)
                                            }
                                            completionBlock(response, responseHeader, nil, statucCode)
                                        }
        },
                                      failure: { (error, statucCode) -> Bool in
                                        DispatchQueue.main.async {
                                            completionBlock(nil, nil, error, statucCode)
                                        }
                                        return showHttpErrorAutomatic
        })
    }
    
    //This should call for upload if you need response, error
    private func callUploadAPI(url: String, parameters: MultipartFormData, headers: HTTPHeaders? = nil, parameterEncoding: ParameterEncoding = JSONEncoding.default, showHttpErrorAutomatic: Bool = false, checkForAuthorization: Bool = false, completion completionBlock: @escaping (Any?, Error?) -> Void) -> UploadRequest {
        
        return networkService.callApiWithUpload(url: url, method: .post, headers: headers, multipartFormData: parameters, success: { response, _ in
            DispatchQueue.main.async {
                if checkForAuthorization {
                    self.checkForAuthorization(response: response)
                }
                completionBlock(response, nil)
            }
        }) { (error, status) -> Bool in
            DispatchQueue.main.async {
                completionBlock(nil, error)
            }
            return showHttpErrorAutomatic
        }
    }
    
    private func checkForAuthorization(response: Any?) {
        guard let responseObj = response as? [String: Any] else {
            return
        }
        let responseData = ResponseData(json: responseObj)
        if responseData.status == 401 {
            Utility.appDelegate().logoutFromApplication()
        }
    }
    
    func fetchCountries(completion: @escaping (Any?, Error?, Int?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callAPI(url: API.COUNTRY_LIST, method: .get, parameters: nil, headers: headers.params, checkForAuthorization: false, completion: completion)
    }
    
    //    func loginOtp(params: ParameterRequest, completion: @escaping (Any?, Error?, Int?) -> Void) -> DataRequest {
    //        let headers = HeaderParameterRequest()
    //        return callAPI(url: API.LOGIN_OTP, method: .post, parameters: params.params, headers: headers.params, checkForAuthorization: false, completion: completion)
    //    }
    
    func signUp(params: ParameterRequest, completion: @escaping (Any?, Error?, Int?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callAPI(url: API.SIGNUP, method: .post, parameters: params.params, headers: headers.params, checkForAuthorization: false, completion: completion)
    }
    
    func updateFcmToken(params: ParameterRequest, completion: @escaping (Any?, Error?, Int?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callAPI(url: API.UPDATE_FCM_TOKEN, method: .post, parameters: params.params, headers: headers.params, completion: completion)
    }
    
    //YEMINI
    
    func register(params: MultipartFormData, completion: @escaping (Any?, Error?) -> Void) -> UploadRequest {
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.REGISTER, parameters: params, headers: headers.params, completion: completion)
    }
    
    func updateProfile(params: MultipartFormData, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.UPDATE_PROFILE, parameters: params, headers: headers.params, completion: completion)
    }
    
    func logIn(params: MultipartFormData, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.LOGIN, parameters: params, headers: headers.params, completion: completion)
    }
    func forgotPassword(params: MultipartFormData, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.FORGOT_PASSWORD, parameters: params, headers: headers.params, completion: completion)
    }
    func items(params: MultipartFormData, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.ITEMS, parameters: params, headers: headers.params, completion: completion)
        
    }
    func searchProduct(params: MultipartFormData, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.SEARCH_PRODUCT,parameters: params, headers: headers.params, completion: completion)
    }
    func category(completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callAPI(url: API.CATEGORY , method: .get, headers: headers.params, completion: completion)
        
    }
    func addToCart(params: MultipartFormData, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.ADD_TO_CART, parameters: params, headers: headers.params, completion: completion)
       // return callAPI(url: API.ADD_TO_CART , method: .post, parameters: params.params, headers: headers.params, completion: completion)
    }
    func removeItemCart(params: MultipartFormData, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
         return callUploadAPI(url: API.REMOVE_ITEM_CART, parameters: params, headers: headers.params, completion: completion)
//        return callAPI(url: API.REMOVE_ITEM_CART , method: .post, parameters: params.params, headers: headers.params, completion: completion)
    }
    func myCart( completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
     return callAPI(url: API.MY_CART , method: .get, headers: headers.params, completion: completion)
    }
    func myOrder(completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callAPI(url: API.MY_ORDER , method: .get, headers: headers.params, completion: completion)
    }
    func placeOrder(completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callAPI(url: API.PLACE_ORDER , method: .get, headers: headers.params, completion: completion)
    }
    func logOut(params: MultipartFormData, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.LOGOUT,parameters: params, headers: headers.params, completion: completion)
    }
    func deliveryStatus(params: MultipartFormData, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.DELIVERY_STATUS, parameters: params, headers: headers.params, completion: completion)
        
    }
    
    func repeatOrder(params: MultipartParameterRequest, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        DDLogVerbose("repeatOrder params = \(params.tempParamsRequest.params)")
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.REPEAT_ORDER, parameters: params.multipartFormData, headers: headers.params, completion: completion)
        
    }
    func productDetail(params: MultipartParameterRequest, completion: @escaping (Any?, Error?) -> Void) -> DataRequest {
        DDLogVerbose("productDetail params = \(params.tempParamsRequest.params)")
        let headers = HeaderParameterRequest()
        return callUploadAPI(url: API.PRODUCT_DETAIL, parameters: params.multipartFormData, headers: headers.params, completion: completion)
        
    }
}
