//
//  ApiParameterConstants.swift
//  Sunil Zalavadiya
//
//  Created by Sunil Zalavadiya on 24/06/20.
//  Copyright © 2020 Sunil Zalavadiya. All rights reserved.
//

import Foundation

///
enum ApiParamName: String {
    case device_type            = "device_type"
    case device_token           = "device_token"
    case device_id              = "device_id"
    case certification_type     = "certification_type"
    
    case user_id                = "user_id"
    case firebase_token         = "firebase_token"
    
    
    //Register
    case firstname              = "firstname"
    case lastname               = "lastname"
    case email                  = "email"
    case password               = "password"
    case confirm_password       = "confirm_password"
    case phone                  = "phone"
    
    //Get Items
    case category_id            = "category_id"
    
    //Add To Cart
    
    case product_id             = "product_id"
    case quantity               = "quantity"
    
    // Remove To Cart
    case cart_id                = "cart_id"
    
    //Delivery Status
    case order_id               =  "order_id"
    
    //EditProfile
    
    case first_name             =   "first_name"
    case last_name              =   "last_name"
    case address                =   "address"
    case city                   =   "city"
    case pincode                =   "pincode"
    case profile_image          =   "profile_image"
    
    //SearchProduct
    case product_name           =  "product_name"
}


//Header parameters
enum ApiParamNameHeader: String {
    case device             =   "device"
    case apiToken           =   "apiToken"
    case Authorization      =  "Authorization"
    case AcceptLanguage     =   "Accept-Language"
    
    case YeminiApiKey       = "YEMINI-API-KEY"
    case User_ID            = "USER-ID"
    case Yemini_Login_Token = "YEMINI-LOGIN-TOKEN"
    case Lang               = "Lang"

}
