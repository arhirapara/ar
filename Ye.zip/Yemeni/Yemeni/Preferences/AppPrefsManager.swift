//
//  AppPrefsManager.swift
//  TwoDoors
//
//  Created by Hoai on 02/05/18.
//  Copyright © 2018 Hoai. All rights reserved.
//

import UIKit
import CoreLocation


class AppPrefsManager: NSObject {

    static let shared = AppPrefsManager()
    
    private let LANGUAGE_CODE           = "LANGUAGE_CODE"
    private let SEARCH_CONTACT          = "SEARCH_CONTACT"
    private let IS_FIRST_TIME_APP_RUN   = "IS_FIRST_TIME_APP_RUN"
    private let DEVICE_ID               = "DEVICE_ID"
    private let DEVICE_AUTH             = "DEVICE_AUTH"
    private let DEVICE_TOKEN            = "DEVICE_TOKEN"
    private let USER_ID                 = "USER_ID"
    private let USER_DATA               = "USER_DATA"
    private let USER_LOGIN              = "USER_LOGIN"
    private let USER_TOKEN              = "USER_TOKEN"
    private let LOGGED_IN_USER          = "LOGGED_IN_USER"
    private let FCM_TOKEN               = "FCM_TOKEN"
    private let MAX_SPEAKING_TIME       = "MAX_SPEAKING_TIME"
    private let IS_SILENT_ENABLE        = "IS_SILENT_ENABLE"
    private let USER_EMAIL              = "USER_EMAIL"
    private let USER_PASSWORD           = "USER_PASSWORD"
    private let REMEMBER_ME             = "REMEMBER_ME"
    
    func setDataToPreference(data: Any, forKey key: String) {
        let archivedData = NSKeyedArchiver.archivedData(withRootObject: data)
        UserDefaults.standard.set(archivedData, forKey: key)
        UserDefaults.standard.synchronize()
    }
    
    func getDataFromPreference(key: String) -> Any? {
        let archivedData = UserDefaults.standard.object(forKey: key)
        
        if(archivedData != nil) {
            return NSKeyedUnarchiver.unarchiveObject(with: archivedData! as! Data) as AnyObject?
        }
        return nil
    }
    
    func setSelectedContact(data: Any, forKey key: String) {
        let archivedData = NSKeyedArchiver.archivedData(withRootObject: data)
        UserDefaults.standard.set(archivedData, forKey: key)
        UserDefaults.standard.synchronize()
    }
    
    func getSelectedContact(key: String) -> Any?  {
        let archivedData = UserDefaults.standard.object(forKey: key)
        if(archivedData != nil) {
            return NSKeyedUnarchiver.unarchiveObject(with: archivedData! as! Data) as AnyObject?
        }
        return nil
    }
    
    func removeDataFromPreference(key: String) {
        UserDefaults.standard.removeObject(forKey: key)
        UserDefaults.standard.synchronize()
    }
    
    func isKeyExistInPreference(key: String) -> Bool {
        if(UserDefaults.standard.object(forKey: key) == nil) {
            return false
        }
        return true
    }
    
    private func setData<T: Codable>(data: T, forKey key: String) {
        do {
            let jsonData = try JSONEncoder().encode(data)
            UserDefaults.standard.set(jsonData, forKey: key)
            UserDefaults.standard.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    private func getData<T: Codable>(objectType: T.Type, forKey key: String) -> T? {
        guard let result = UserDefaults.standard.data(forKey: key) else {
            return nil
        }
        do {
            return try JSONDecoder().decode(objectType, from: result)
        } catch let error {
            print(error)
            return nil
        }
    }
    
    // MARK: - Language Name
    func saveLanguageCode(languageCode: String) {
        setDataToPreference(data: languageCode as AnyObject, forKey: LANGUAGE_CODE)
        if isRTLLanguage() {
            UIView.appearance().semanticContentAttribute = .forceRightToLeft
        } else {
            UIView.appearance().semanticContentAttribute = .forceLeftToRight
        }
    }
    func getLanguageCode() -> String {
        return getDataFromPreference(key: LANGUAGE_CODE) as? String ?? LanguageCode.arabic.rawValue//Locale.current.languageCode!
    }
    
    // MARK: - Is Login
    func setIsUserLogin(isUserLogin: Bool) {
        setDataToPreference(data: isUserLogin, forKey: USER_LOGIN)
    }
    
    func isUserLogin() -> Bool {
        let isUserLogin = getDataFromPreference(key: USER_LOGIN)
        return isUserLogin == nil ? false: (isUserLogin as! Bool)
    }
    
    func removeUserLogin() {
        removeDataFromPreference(key: USER_LOGIN)
    }
    
    func setIsFirstTimeAppRun(run: Bool) {
        setDataToPreference(data: run, forKey: IS_FIRST_TIME_APP_RUN)
    }
    
    func isFirstTimeAppRun() -> Bool {
        return getDataFromPreference(key: IS_FIRST_TIME_APP_RUN) as? Bool ?? true
    }
    
    // MARK: - Fcm token
    func saveFcmToken(token : String) {
        setDataToPreference(data: token, forKey: FCM_TOKEN)
    }
    
    func getFcmToken() -> String {
        return getDataFromPreference(key: FCM_TOKEN) as? String ?? ""
    }
    
    // MARK: - Token
    func getToken() -> String {
        
        return getDataFromPreference(key: USER_TOKEN) as? String ?? ""
    }
    
    func saveToken(token: String) {
        setDataToPreference(data: token, forKey: USER_TOKEN)
    }
    
    func removeToken(){
        removeDataFromPreference(key: USER_TOKEN)
    }

    //MARK: - Logged in user info
    func saveLoggedInUserInfo(userInfo: [String: Any]) {
        setDataToPreference(data: userInfo, forKey: LOGGED_IN_USER)
    }
    
    func getLoggedInUserInfo() -> UserInfo {
        let userDict = getDataFromPreference(key: LOGGED_IN_USER) as? [String: Any] ?? [:]
        return UserInfo(json: userDict)
    }
    
    func removeLoggedInUserInfo() {
        removeDataFromPreference(key: LOGGED_IN_USER)
    }
    
    
    // MARK: - Remember me
    func setRememberMe(remember: Bool) {
        setDataToPreference(data: remember, forKey: REMEMBER_ME)
    }
    
    func isRememberMe() -> Bool {
        let remember = getDataFromPreference(key: REMEMBER_ME)
        return remember as? Bool ?? false
    }
    
    func removeRememberMe() {
        removeDataFromPreference(key: REMEMBER_ME)
    }
    
    // MARK: - Email/password
    func saveIdPass(email: String, password: String) {
        setDataToPreference(data: email, forKey: USER_EMAIL)
        setDataToPreference(data: password, forKey: USER_PASSWORD)
    }
    
    func getEmail() -> String {
           return getDataFromPreference(key: USER_EMAIL) as? String ?? ""
       }
    
    func getPass() -> String {
           return getDataFromPreference(key: USER_PASSWORD) as? String ?? ""
       }
    
    func removeEmailAndPass(){
        removeDataFromPreference(key: USER_EMAIL)
        removeDataFromPreference(key: USER_PASSWORD)
    }
}
