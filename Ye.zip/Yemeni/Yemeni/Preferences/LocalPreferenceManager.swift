//
//  LocalPreferenceManager.swift
//  Sunil Zalavadiya
//
//  Created by Sunil Zalavadiya on 08/07/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import Foundation

class LocalPreferenceManager: NSObject {}
//{
//    static let shared = LocalPreferenceManager()
//
//    lazy var arrFriend = [UserInfo]()
//
//
//    lazy var bundlePathForCountries = Bundle.main.path(forResource: "countries", ofType: "plist")!
//    lazy var bundlePathForFriend = Bundle.main.path(forResource: "friend", ofType: "plist")!
//
//    override init() {
//        super.init()
//        preparePlistForUse()
//    }
//
//    var countriesPlistPath: URL {
//        return FileHelper.documentDirectoryPath().appendingPathComponent("states.plist")
//    }
//
//    var friendPlistPath: URL {
//        return FileHelper.documentDirectoryPath().appendingPathComponent("friend.plist")
//    }
//
//    func preparePlistForUse() {
//        if !FileHelper.isFileExistsAtPath(fileURL: countriesPlistPath) {
//            do {
//                try FileManager.default.copyItem(atPath: bundlePathForCountries, toPath: countriesPlistPath.path)
//            } catch {
//                print("Error occurred while copying file to document \(error)")
//            }
//        }
//
//        if !FileHelper.isFileExistsAtPath(fileURL: friendPlistPath) {
//            do {
//                try FileManager.default.copyItem(atPath: bundlePathForFriend, toPath: friendPlistPath.path)
//            } catch {
//                print("Error occurred while copying file to document \(error)")
//            }
//        }
//    }
//
//    func loadFriendVC() {
//        if let data = FileManager.default.contents(atPath: friendPlistPath.path) {
//            do {
//                if let dataAr = try PropertyListSerialization.propertyList(from: data, options: PropertyListSerialization.ReadOptions.mutableContainersAndLeaves, format: nil) as? [[String: Any]] {
//                    arrFriend.removeAll()
//                    arrFriend.append(contentsOf: UserInfo.toArray(arrJson: dataAr))
//                }
//            } catch {
//                print("Error occurred while copying file to document \(error)")
//            }
//        }
//    }
//
//    func saveFriendList(arrJson: [UserInfo]) {
//        arrFriend.removeAll()
//        arrFriend.append(contentsOf: arrJson)
//        if let data = try? PropertyListSerialization.data(fromPropertyList: arrJson, format: PropertyListSerialization.PropertyListFormat.binary, options: 0) {
//            do {
//                try data.write(to: friendPlistPath, options: .atomic)
//                print("Successfully write")
//            }catch (let err){
//                print(err.localizedDescription)
//            }
//        }
//    }
//}
