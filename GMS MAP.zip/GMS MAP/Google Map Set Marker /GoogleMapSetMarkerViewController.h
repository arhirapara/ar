//
//  GoogleMapSetMarkerViewController.h
//  WibrateMe
//
//  Created by MacBook on 02/04/19.
//  Copyright © 2019 DNKTechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>
#import <CoreLocation/CoreLocation.h>
#import <GooglePlaces/GooglePlaces.h>
#import "GoogleMapOfferCelll.h"
#import "MarkerDetailsView.h"
#import "HomeLocationViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GoogleMapSetMarkerViewController : UIViewController <AppNavigationControllerDelegate, VKAlertActionViewDelegate, CLLocationManagerDelegate, GMSMapViewDelegate, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITextFieldDelegate, HomeLocationVCDelegate, UIScrollViewDelegate>{
    
    SharedModel *obj_SharedModel;
    DesignModel  *obj_DesignModel;
    AppNavigationController *navigationController;
    AppDelegate *obj_AppDelegate;
    NSString *stLoginUserName, *stLoginPassword;

    IBOutlet UIView *viewGoogleMap;
    IBOutlet UICollectionView *collectionViewShowMapOffer;

    IBOutlet UITextField *txtSearchOfferShop;
    
    VKAlertActionView *_VKAlertActionView;
    NSInteger indexSelectedLoctionCollectionView;
    //Google Map
    CLLocationManager *locationManager;
    CLLocation *userLocation;
    GMSMarker *marker;
    GMSMapView *mapView;
    
    IBOutlet UIView *viewDetectLocation;
    BOOL isCuurentLocationExist;
    
    NSMutableArray *arrMarker;
    NSArray *arrLocation;
    MAP_GOOGLE _MAP_GOOGLE;
}
- (IBAction)btnSelectLocationAction;
- (IBAction)btnDetectLocationAction;

@end

NS_ASSUME_NONNULL_END
