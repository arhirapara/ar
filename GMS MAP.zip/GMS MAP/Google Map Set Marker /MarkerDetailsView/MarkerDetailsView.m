//
//  MarkerDetailsView.m
//  WibrateMe
//
//  Created by MacBook on 29/03/19.
//  Copyright © 2019 DNKTechnologies. All rights reserved.
//

#import "MarkerDetailsView.h"

@implementation MarkerDetailsView

- (void)awakeFromNib {
    [super awakeFromNib];
    
    UIImage * backgroundImg = [UIImage imageNamed:IMAGE_SHADOW_BG];
    backgroundImg = [backgroundImg resizableImageWithCapInsets:UIEdgeInsetsMake(25, 25, 25, 25)];
    imageViewLoctionShadow.image = backgroundImg;
}

@end
