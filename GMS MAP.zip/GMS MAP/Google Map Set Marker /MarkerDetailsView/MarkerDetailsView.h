//
//  MarkerDetailsView.h
//  WibrateMe
//
//  Created by MacBook on 29/03/19.
//  Copyright © 2019 DNKTechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MarkerDetailsView : UIView {
    
    AppDelegate *obj_AppDelegate;
    NSString *stMarkerMesaage;
    
    
    IBOutlet UIImageView *imageViewLoctionShadow;
    
    
}
@property (strong, nonatomic) IBOutlet UILabel *lblMarkerDetails;


//+ (MarkerDetailsView *)showMarkerMessage:(NSString *)markerMessage frameMarker:(CGRect)frameMarker;
@end
