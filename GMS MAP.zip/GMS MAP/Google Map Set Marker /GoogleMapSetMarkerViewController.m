//
//  GoogleMapSetMarkerViewController.m
//  WibrateMe
//
//  Created by MacBook on 02/04/19.
//  Copyright © 2019 DNKTechnologies. All rights reserved.
//

#import "GoogleMapSetMarkerViewController.h"

#define GOOGLE_MAP_ANIMATION_TIME                       1
//GOOGLE

@interface GoogleMapSetMarkerViewController ()

@end

@implementation GoogleMapSetMarkerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    obj_SharedModel = [[SharedModel alloc] init];
    obj_DesignModel = [[DesignModel alloc] init];
    _VKAlertActionView = [[VKAlertActionView alloc] init];
    stLoginUserName = [obj_SharedModel getUserMobileNo];
    stLoginPassword = [obj_SharedModel getPassword];
    //isCuurentLocationExist = NO;
    viewDetectLocation.alpha = 1;
    collectionViewShowMapOffer.alpha = 0;
    indexSelectedLoctionCollectionView = -1;
    _VKAlertActionView.delegate = self;
    obj_AppDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    _MAP_GOOGLE = GOOGLE_MAP_DUMMY;
    [self allocGoogleMap];
}

- (void)viewWillAppear:(BOOL)animated { [super viewWillAppear:animated];
    //[self setNavigationBar];
    [self setLocationAccessPermission]; }

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self setLocationManager];
    
}

#pragma mark - AppNavigationController
- (void)setNavigationBar {
    navigationController = (AppNavigationController *)self.navigationController;
    [navigationController setNavigationBarHidden:NO animated:YES];
    [navigationController setNavigationBarLineHidden:YES];
    navigationController.navigationDelegate = self;
    [navigationController setLeftImageButton:self imageName:@"ic_back_white"];
    self.title = @"SELECT LOCATION";
}

- (void)appNavigationController_LeftButtonAction {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Custome Method
- (void)setLocationAccessPermission {
    if ([CLLocationManager locationServicesEnabled]) {
        if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied) {
            [_VKAlertActionView showYesNoAlertView:MSG_ERR_OFFLINE_LOCATION alertType:ALERT_DUMMY object:nil];
        }
        else if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways || [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedWhenInUse) {
            [self setLocationManager];
        }
    }
    else {
        [_VKAlertActionView showYesNoAlertView:MSG_ERR_OFFLINE_LOCATION alertType:ALERT_DUMMY object:nil];
    }
}

- (void)setLocationManager {
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    [locationManager requestWhenInUseAuthorization];
    [locationManager startUpdatingLocation];
}

- (void)allocGoogleMap {
    marker = [[GMSMarker alloc] init];
    mapView = [[GMSMapView alloc] init];
    userLocation = [[CLLocation alloc] init];
    locationManager = [[CLLocationManager alloc] init];
    arrLocation = [[NSArray alloc] init];
    
    [collectionViewShowMapOffer registerNib:[UINib nibWithNibName:CELL_IDENTIFIER_GOOGLE_MAP_OFFER_CELLL bundle:nil] forCellWithReuseIdentifier:CELL_IDENTIFIER_GOOGLE_MAP_OFFER_CELLL];
    //33106447547
    arrLocation = @[@{@"name": @"Mota Varachha", @"long": @"72.876268", @"lat": @"21.236405", @"Id":@"0"},
                    @{@"name": @"Mahalaxmi soc Surat", @"long": @"72.883359", @"lat": @"21.212433", @"Id":@"11"},
                    @{@"name": @"Uttran", @"long": @"72.871161", @"lat": @"21.232124", @"Id":@"2"},
                    @{@"name": @"Vaholi", @"long": @"73.244996", @"lat": @"19.246536", @"Id":@"3"},
                    @{@"name": @"Bhakti Nandan Sector", @"long": @"72.876525", @"lat": @"21.242445", @"Id":@"4"},
                    @{@"name": @"Motavarachha, Chourasia", @"long": @"72.890469", @"lat": @"21.240045", @"Id":@"5"},
                    @{@"name": @"Andheri West", @"long": @"72.827694", @"lat": @"19.116815", @"Id":@"6"},
                    @{@"name": @"Vikhroli West", @"long": @"72.918350", @"lat": @"19.116815", @"Id":@"7"},
                    @{@"name": @"Patil Pada", @"long": @"73.237148", @"lat": @"19.162298", @"Id":@"8"},
                    @{@"name": @"Jambhilghar", @"long": @"73.281270", @"lat": @"19.160988", @"Id":@"9"},
                    @{@"name": @"Hart Northern Territory", @"long": @"134.559573", @"lat": @"-23.328175", @"Id":@"10"},
                    @{@"name": @"South Island", @"long": @"170.180220", @"lat": @"-44.468501", @"Id":@"1"}];
}

- (void)setGoogleMap {
    arrMarker = [[NSMutableArray alloc] init];
    if (_MAP_GOOGLE != GOOGLE_MAP_CLICK_COLLECTION_VIEW && _MAP_GOOGLE != GOOGLE_MAP_CLICK_MARKER) {
        GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:userLocation.coordinate.latitude
                                                                longitude:userLocation.coordinate.longitude
                                                                     zoom:10];
        
        CGRect frame = CGRectMake(0, 0, viewGoogleMap.frame.size.width, viewGoogleMap.frame.size.height);
        mapView = [GMSMapView mapWithFrame:frame camera:camera];
        mapView.myLocationEnabled = YES;
        //        mapView.mapType = kGMSTypeSatellite;
        mapView.delegate = self;
    }
    
    if([arrLocation count]) {
        for (int i=0; i < [arrLocation count]; i++) {
            NSDictionary *dict = [arrLocation objectAtIndex:i];
            
            CLLocationCoordinate2D position = { [[dict valueForKey:@"lat"] doubleValue], [[dict valueForKey:@"long"]    doubleValue] };
            
            marker = [GMSMarker markerWithPosition:position];
//            marker.title = [dict valueForKey:@"name"];
            marker.appearAnimation = YES;
            marker.flat = YES;
            marker.snippet = @"";
            if (_MAP_GOOGLE == GOOGLE_MAP_CLICK_COLLECTION_VIEW || _MAP_GOOGLE == GOOGLE_MAP_CLICK_MARKER) {
                NSInteger indexPath = [[NSString stringWithFormat:@"%@",[dict valueForKey:@"Id"]] integerValue];
                if (indexPath == indexSelectedLoctionCollectionView) {
                    marker.icon = [UIImage imageNamed:@"ic_google_map_select_pin"];
                }
                else {
                    marker.icon = [UIImage imageNamed:@"ic_google_map_unselect_pin"];
                }
            }
            else {
                marker.icon = [UIImage imageNamed:@"ic_google_map_unselect_pin"];
            }
            
            //marker.snippet = @"";
            marker.accessibilityLabel = [@(i) stringValue];
            [arrMarker addObject:marker];
            
            marker.map = mapView;
        }
    }
    
    if (_MAP_GOOGLE != GOOGLE_MAP_CLICK_COLLECTION_VIEW && _MAP_GOOGLE != GOOGLE_MAP_CLICK_MARKER) {
        [viewGoogleMap addSubview:mapView];
        [viewGoogleMap layoutIfNeeded];
        [collectionViewShowMapOffer reloadData];
    }
}

#pragma mark - Collection View Datasource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView { return 1; }

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return arrLocation.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    GoogleMapOfferCelll *cell = [collectionView dequeueReusableCellWithReuseIdentifier: CELL_IDENTIFIER_GOOGLE_MAP_OFFER_CELLL forIndexPath:indexPath];
    
    NSMutableDictionary *dictLocation = [arrLocation objectAtIndex:indexPath.row];
    cell.lblOfferName.text = [dictLocation valueForKey:@"name"];
    
    
    return cell;
}
#pragma mark - UICollectionViewDelegate Method
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSMutableDictionary *dictLocation = [arrLocation objectAtIndex:indexPath.row];
    _MAP_GOOGLE = GOOGLE_MAP_CLICK_COLLECTION_VIEW;
    NSString *stSelectedId = [dictLocation valueForKey:@"Id"];
    
    indexSelectedLoctionCollectionView = [[NSString stringWithFormat:@"%@",stSelectedId] integerValue];
    //    indexSelectedLoctionCollectionView = [arrLocation indexOfObjectPassingTest:
    //                                          ^BOOL(NSDictionary *dict, NSUInteger idx, BOOL *stop)
    //                                          {
    //                                              return [[dict objectForKey:@"Id"] isEqual:stSelectedId];
    //                                          }
    //                                          ];
    [mapView clear];
    [self setGoogleMap];
    [self mapView:mapView didTapMarker:marker];
}

#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CGFloat width = [[UIScreen mainScreen] bounds].size.width * 0.94;
    return CGSizeMake(width, 153);
    //    return CGSizeMake(326, 88);
    
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section { return 2; }

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section { return 0; }

#pragma mark - CLLocationManager Delegate
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    userLocation = [locations lastObject];
//  isCuurentLocationExist = YES;
    viewDetectLocation.alpha = 0;
    collectionViewShowMapOffer.alpha = 1;
    [self setGoogleMap];
    
    [locationManager stopUpdatingLocation];
}

#pragma mark - GMS Delegate
- (BOOL)mapView:(GMSMapView *)mapView didTapMarker:(GMSMarker *)marker {
    if(_MAP_GOOGLE == GOOGLE_MAP_CLICK_COLLECTION_VIEW) {
        for (int i=0; i < [arrLocation count]; i++) {
            NSDictionary *dict = [arrLocation objectAtIndex:i];
            NSInteger indexPath = [[NSString stringWithFormat:@"%@",[dict valueForKey:@"Id"]] integerValue];
            if (indexPath == indexSelectedLoctionCollectionView) {
                
                double lati = [[dict valueForKey:@"lat"] doubleValue];
                double longv = [[dict valueForKey:@"long"] doubleValue];
                
                [CATransaction begin];
                [CATransaction setValue:[NSNumber numberWithFloat:GOOGLE_MAP_ANIMATION_TIME] forKey:kCATransactionAnimationDuration];
                GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude: lati
                                                                        longitude: longv zoom: 10.0];
                [mapView animateToCameraPosition:camera];
                [CATransaction commit];
                
                [collectionViewShowMapOffer scrollToItemAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0] atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
            }
        }
    }
    else { _MAP_GOOGLE = GOOGLE_MAP_CLICK_MARKER; }
    
    if(_MAP_GOOGLE == GOOGLE_MAP_CLICK_MARKER) {
        
        NSUInteger index = [arrMarker indexOfObject:marker];
        NSDictionary *dictSelectedLocation = arrLocation[index];
        NSLog(@"%@", dictSelectedLocation);

        NSString *stSelectedId = [dictSelectedLocation valueForKey:@"Id"];

        indexSelectedLoctionCollectionView = [[NSString stringWithFormat:@"%@",stSelectedId] integerValue];
        [mapView clear];
        [self setGoogleMap];
        
        double latitude = [[dictSelectedLocation valueForKey:@"lat"] doubleValue];
        double longitude = [[dictSelectedLocation valueForKey:@"long"] doubleValue];

        [CATransaction begin];
        [CATransaction setValue:[NSNumber numberWithFloat:GOOGLE_MAP_ANIMATION_TIME] forKey:kCATransactionAnimationDuration];
        GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude: latitude
                                                                longitude: longitude zoom: 10.0];
        [mapView animateToCameraPosition:camera];
        [CATransaction commit];
        
        [collectionViewShowMapOffer scrollToItemAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
    }
    _MAP_GOOGLE = GOOGLE_MAP_DUMMY;
    return NO;
}


- (void)mapView:(GMSMapView *)mapView didTapInfoWindowOfMarker:(GMSMarker *)marker {
    
}

//- (UIView *)mapView:(GMSMapView *)mapView markerInfoWindow:(GMSMarker *)marker {
//    MarkerDetailsView *_MarkerDetailsView;
//
//    NSInteger index = [marker.accessibilityLabel intValue];
//    NSDictionary *dictLocationMarker = arrLocation[index];
//    NSLog(@"get ViewMarker Location : %@ Index Is : %ld ", dictLocationMarker, (long)index);
//
//    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MarkerDetailsView" owner:self options:nil];
//    _MarkerDetailsView = [nib objectAtIndex:0];
//    _MarkerDetailsView.lblMarkerDetails.text = [dictLocationMarker valueForKey:@"name"];
//    return _MarkerDetailsView;
//}

#pragma mark - VKAlertActionView Delegate
- (void)vkAlertViewAction:(ALERT_TYPE)alertType buttonIndex:(int)buttonIndex buttonTitle:(NSString *)buttonTitle object:(id)object {
    if (buttonIndex == 0) {
        if (![CLLocationManager locationServicesEnabled]) {
            // [[UIApplication sharedApplication] openURL:[NSURL URLWithString:SCHEMES_APP_LOCATION]];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
        }
        else { [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]]; }
    }
    else if (buttonIndex == 1) {
        //[self setGoogleMap];
        return;
    }
    
}
#pragma mark - UI TextField DELEGATE METHODS
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [txtSearchOfferShop resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    txtSearchOfferShop.text = @"";
//    arrFilteredLocation = [[NSMutableArray alloc] initWithArray:arrSearchCityLocation];
//    [tableViewHomeLocation reloadData];
    return YES;
}

- (IBAction)btnSelectLocationAction {
    HomeLocationViewController *homeLocationVC = [[HomeLocationViewController alloc] initWithNibName:@"HomeLocationViewController" bundle:nil];
    homeLocationVC.delegate = self;
    [self.navigationController pushViewController:homeLocationVC animated:YES];
}

#pragma: Action
- (IBAction)btnDetectLocationAction {
     [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
}


- (void)onLocationVC_SelectionAction:(NSDictionary *)dictLocationInfo {
    
}

//- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
//    NSIndexPath *secondVisibleIndexPath = [[collectionViewShowMapOffer indexPathsForVisibleItems] objectAtIndex:1];
//    NSLog(@"firstVisibleIndexPath : %@",secondVisibleIndexPath);
//
//    NSDictionary *dictLocation = arrLocation[secondVisibleIndexPath.row];
//
//    _MAP_GOOGLE = GOOGLE_MAP_CLICK_COLLECTION_VIEW;
//    NSString *stSelectedId = [dictLocation valueForKey:@"Id"];
//    indexSelectedLoctionCollectionView = [[NSString stringWithFormat:@"%@",stSelectedId] integerValue];
//
//    [mapView clear];
//    [self setGoogleMap];
//    [self mapView:mapView didTapMarker:marker];
//}




@end
