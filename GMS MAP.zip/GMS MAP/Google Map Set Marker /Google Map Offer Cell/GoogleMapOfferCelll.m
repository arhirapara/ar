//
//  GoogleMapOfferCelll.m
//  WibrateMe
//
//  Created by MacBook on 29/03/19.
//  Copyright © 2019 DNKTechnologies. All rights reserved.
//

#import "GoogleMapOfferCelll.h"

@implementation GoogleMapOfferCelll

- (void)awakeFromNib {
    [super awakeFromNib];
    obj_DataModel = [[DataModel alloc] init];
    obj_DesignModel = [[DesignModel alloc] init];
}

- (void)drawRect:(CGRect)rect {
    UIImage * backgroundImg = [UIImage imageNamed:IMAGE_MAP_SHADOW_BG];
    backgroundImg = [backgroundImg resizableImageWithCapInsets:UIEdgeInsetsMake(25, 25, 25, 25)];
    self.imageViewSearchShadow.image = backgroundImg;
}

@end
