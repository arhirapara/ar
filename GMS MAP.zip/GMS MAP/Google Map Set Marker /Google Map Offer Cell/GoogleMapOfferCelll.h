//
//  GoogleMapOfferCelll.h
//  WibrateMe
//
//  Created by MacBook on 29/03/19.
//  Copyright © 2019 DNKTechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoogleMapOfferCelll : UICollectionViewCell {
    DataModel *obj_DataModel;
    DesignModel *obj_DesignModel;
}
@property (strong, nonatomic) IBOutlet UIImageView *imageViewOffer;
@property (strong, nonatomic) IBOutlet UILabel *lblOfferName;
@property (strong, nonatomic) IBOutlet UILabel *lblofferDescription;
@property (strong, nonatomic) IBOutlet UIView *viewShadow;
@property (strong, nonatomic) IBOutlet UIImageView *imageViewSearchShadow;

@end
