//
//  ViewController.swift
//  gmap Swift
//
//  Created by MacBook on 27/03/19.
//  Copyright © 2019 dnk. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
import CoreLocation

struct State {
    let name: String
    let long: CLLocationDegrees
    let lat: CLLocationDegrees
    let id: Int
}

class ViewController: UIViewController, CLLocationManagerDelegate, GMSMapViewDelegate, UITextFieldDelegate {
    
    @IBOutlet var viewMap: UIView!
    let states = [
        State(name: "Mota Varachha", long: 72.876268, lat: 21.236405, id: 0),
        State(name: "Uttran", long: 72.871161, lat: 21.232124, id: 1),
        State(name: "Bhakti Nandan Sector", long: 72.876525, lat: 21.242445, id: 2),
        State(name: "Unnamed Road", long: 72.890469, lat: 21.240045, id: 3),
        State(name: "Kandivali West", long: 72.830521, lat: 19.201314, id: 4),
        State(name: "Andheri West", long: 72.827694, lat: 19.149394, id: 5),
        State(name: "Vikhroli West", long: 72.918350, lat: 19.116815, id: 6),
        State(name: "Vikhroli West", long: 72.918350, lat: 19.116815, id: 7),
        State(name: "Patil Pada", long: 73.237148, lat: 19.162298, id: 8),
        State(name: "Jambhilghar", long: 73.281270, lat: 19.160988, id: 9),
        State(name: "Vaholi", long: 73.244996, lat: 19.246536, id: 10),
        
        // the other 51 states here...
    ]
   // var mapView = GMSMapView()
    var mapView: GMSMapView!
    var location: CLLocation?
   var marker: GMSMarker?
    var markersAR = [GMSMarker]()
     var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        locationManager.startMonitoringSignificantLocationChanges()
        
       // UITextField.appearance().tintColor = .red
    }
    //
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        self.currentAddres(position.target)
    }
    
    func currentAddres(_ coordinate:CLLocationCoordinate2D) -> Void {
        
    }
    
    func setLocation()  {
        let camera = GMSCameraPosition.camera(withLatitude: (location?.coordinate.latitude)!, longitude: (location?.coordinate.longitude)!, zoom: 8.0)
        mapView = GMSMapView.map(withFrame: viewMap.frame , camera: camera)
        viewMap.addSubview(mapView)
        mapView.delegate = self
        
        for state in states {
            let marker = GMSMarker()
            marker.position = CLLocationCoordinate2D(latitude: state.lat, longitude: state.long)
            marker.title = state.name
            marker.icon = #imageLiteral(resourceName: "placeholder-filled-point.png")
            
            marker.snippet = "Hey, this is \(state.name)"
            marker.map = mapView
        }
    }

    // MARK: CLLocation Manager Delegate
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error while getting location \(error)")
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        location = locations.last
        self.setLocation()
        self.locationManager.stopUpdatingLocation()
    }
    
    // MARK: GOOGLE MAP DELEGATE
    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
//        if let index = marker.index(ofAccessibilityElement: markersAR) {
//            let tappedState = states[index]
//        }
//        let index = marker.index(ofAccessibilityElement: marker)
//        let tappedState = states[index]
        
        return true
    }

    func mapView(_ mapView: GMSMapView, didTapInfoWindowOf marker: GMSMarker) {
//            print("Called didTap")
//            let googleMarker = mapView.selectedMarker
//        
//            let markerValue: CLLocationCoordinate2D = googleMarker.position
//            let markerLat = markerValue.latitude
//        
//            let markerLong = markerValue.longitude
//            print("markerLat: \(markerLat)")
//            print("markerLong: \(markerLong)")
//            mapView.selectedMarker = nil
//            mapView.delegate = self
    }

    func mapView(_ mapView: GMSMapView, didCloseInfoWindowOf marker: GMSMarker) {

    }
    
}

