//
//  SideMenu.h
//  SideMenu
//
//  Created by kukushi on 03/02/2018.
//  Copyright © 2018 kukushi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SideMenu.
FOUNDATION_EXPORT double SideMenuVersionNumber;

//! Project version string for SideMenu.
FOUNDATION_EXPORT const unsigned char SideMenuVersionString[];

