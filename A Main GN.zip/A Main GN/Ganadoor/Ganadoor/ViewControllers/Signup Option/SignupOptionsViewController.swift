//
//  SignupOptionsViewController.swift
//  Ganadoor
//
//  Created by AR on 02/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit
import FBSDKLoginKit

class SignupOptionsViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnCreateAccount: UIButton!
    @IBOutlet weak var btnConnectFB: UIButton!
    
    let subText = ["Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs.", "The passage is attributed to an unknown typesetter in the 15th century", "who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book."]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnCreateAccount.style(style: TextStyle.createNewAccount)
        btnConnectFB.style(style: TextStyle.LoginText)
        btnLogin.style(style: TextStyle.themeLabelSize18)
//        for i in  0...2 {
//            let view:LimeLightView = UIView.fromNib()
//            view.frame = CGRect(x: CGFloat(i) * screenWidth, y: contentView.frame.minY, width: screenWidth, height: contentView.frame.height)
//            view.lblHeader.text = "THE STANDARD LOREM IPSUM"
//            view.lblSubText.text = subText[i]
//            view.lblHeader.style(style: TextStyle.themeLabelSize20)
//            view.lblSubText.style(style: TextStyle.semiBold15)
//            view.lblHeader.textAlignment = .center
//            view.lblSubText.textAlignment = .center
//            contentView.addSubview(view)
//        }
        
        let loginButton = FBLoginButton()
        loginButton.center = view.center
        loginButton.frame = btnConnectFB.bounds
        btnConnectFB.addSubview(loginButton)
        loginButton.permissions = ["public_profile", "email"]
        if let token = AccessToken.current,
            !token.isExpired {
            // User is logged in, do work such as go to next view controller.
            
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        for i in  0...2 {
            let view:LimeLightView = UIView.fromNib()
            view.frame = CGRect(x: CGFloat(i) * screenWidth, y: contentView.frame.minY, width: screenWidth, height: contentView.frame.height)
            view.lblHeader.text = "THE STANDARD LOREM IPSUM"
            view.lblSubText.text = subText[i]
            view.lblHeader.style(style: TextStyle.themeLabelSize20)
            view.lblSubText.style(style: TextStyle.semiBold15)
            view.lblHeader.textAlignment = .center
            view.lblSubText.textAlignment = .center
            contentView.addSubview(view)
        }
        contentView.layoutIfNeeded()
        self.view.layoutIfNeeded()
    }
    
    @IBAction func btnLoginAction(_ sender: UIButton) {
       let loginVC = LoginViewController(nibName: "LoginViewController", bundle: nil)
        loginVC.isBackButton = true
        navigationController?.pushViewController(loginVC, animated: true)
    }
    
    @IBAction func btnCreateNewAccount(_ sender: UIButton) {
        let signUPVC = SignUpViewController(nibName: "SignUpViewController", bundle: nil)
        signUPVC.isBackButton = true
        navigationController?.pushViewController(signUPVC, animated: true)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageIndex = round(scrollView.contentOffset.x / screenWidth)
        pageControl.currentPage = Int(pageIndex)
    }
}
