//
//  LimeLightView.swift
//  Ganadoor
//
//  Created by AR on 02/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class LimeLightView: UIView {

    @IBOutlet weak var lblHeader: UILabel!
    
    @IBOutlet weak var lblSubText: UILabel!
    
}
