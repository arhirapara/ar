//
//  AdvertView.swift
//  vincitore
//
//  Created by AR on 05/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class AdvertView: UIView, UIScrollViewDelegate {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var pageControlView: UIView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var lblTagLine: UILabel!
    
    var flowHeightConstraint: NSLayoutConstraint?
    var currentPage = 0
    var arrImg:[typeAliasDictionary] = [typeAliasDictionary]()
    let pageControl = SCPageControlView()
    var timerBanner = Timer()
    
    @IBOutlet weak var widthContentView: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        lblTagLine.style(style: TextStyle.HederBold)
        pageControl.frame = CGRect(x: 0, y: 0, width: pageControlView.frame.width, height: pageControlView.frame.height)
        scrollView.delegate = self
        self.viewWithTag(100)?.isHidden = true
        flowHeightConstraint =  self.heightAnchor.constraint(equalToConstant: 250)
        flowHeightConstraint?.isActive = true
    }
    
    @IBAction func btnClose(_ sender: UIButton) {
        self.viewWithTag(100)?.isHidden = true
    }
    
    func addBannerTimer() {
        let timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(nextBannerPage), userInfo: nil, repeats: true)
        RunLoop.main.add(timer, forMode: .common)
        timerBanner = timer
    }
    
    @objc func nextBannerPage() {
        let pageWidth: CGFloat = screenWidth
        let maxWidth: CGFloat = (screenWidth) * CGFloat(arrImg.count)
        let contentOffset = scrollView.contentOffset.x
        var slideToX = contentOffset + pageWidth
        if contentOffset + pageWidth == maxWidth {
            slideToX = 0
        }
        scrollView.setContentOffset(CGPoint(x: slideToX, y: 0), animated: true)
    }
    
    func setupPageControl() {
        widthContentView.constant =  CGFloat(arrImg.count-1) * screenWidth
        for i in 0..<arrImg.count {
            let ivImage = UIImageView(frame: CGRect(x: screenWidth*CGFloat(i), y: 0, width: screenWidth, height: contentView.frame.height))
            
            let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
            ivImage.addGestureRecognizer(tap)
            ivImage.isUserInteractionEnabled = true
            
            ivImage.setImageWith(URL(string: arrImg[i].valuForKeyString("mb_banners")), completed: { (image, error, cache, url) in
                let bannerWidth = image!.size.width
                let bannerHeight = image!.size.height
                
                if bannerWidth == 0 || bannerHeight == 0 {
                    self.setHeight(0)
                    
                } else {
                    var heightImageView = (screenWidth * CGFloat(bannerHeight)) / CGFloat(bannerWidth)
                    heightImageView = ceil(heightImageView)
                    self.setHeight(heightImageView)
                    ivImage.setHeight(height: heightImageView)
                    ivImage.layoutIfNeeded()
                }
                self.layoutIfNeeded()
            }, usingActivityIndicatorStyle: .gray)
            ivImage.contentMode = .scaleAspectFit
            ivImage.clipsToBounds = true
            contentView.addSubview(ivImage)
        }
        contentView.layoutIfNeeded()
        pageControl.scp_style = .SCNormal
        pageControl.set_view(Int(contentView.frame.width/screenWidth), current: 0, current_color: UIColor(hexString:"#DC6666"))
        pageControlView.addSubview(pageControl)
        if arrImg.count <= 1 {
            pageControl.isHidden = true
        }
        //pageControl.numberOfPage = arrImg.count
        //timerBanner.invalidate()
        //self.addBannerTimer()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let pageWidth = screenWidth
        currentPage = Int(floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1)
        pageControl.currentOfPage = currentPage
        pageControl.scroll_did(scrollView)
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        let index = pageControl.currentOfPage
        let dictData = arrImg[index]
        var _HOME_SCREEN_NAVIGATION = HOME_SCREEN_NAVIGATION.HOME_SCREEN_DUMMY
        if !dictData.isEmpty{
            print(dictData)
            
            _HOME_SCREEN_NAVIGATION = HOME_SCREEN_NAVIGATION(rawValue: dictData.valuForKeyInt("mb_screen_id"))!
            print(_HOME_SCREEN_NAVIGATION)
            if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_HOME{
                
            }
            else if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_CATEGOTY{
                let categoryVC = CategoryViewController(nibName: "CategoryViewController", bundle: nil)
                categoryVC.isBackButton = true
                categoryVC.isBackButtonBanner = true
                categoryVC.dictCategoryData = dictData
                appDelegateObject().navigationController!.setNavigationBarHidden(false, animated: false)
                appDelegateObject().navigationController?.pushViewController(categoryVC, animated: true)
            }
            else if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_PRODUCT{
                let productListVC = ProductListViewController(nibName: "ProductListViewController", bundle: nil)
                productListVC.dictProductData = dictData as! typeAliasStringDictionary
                productListVC.isBackButton = true
                productListVC.isClickHomePage = true
                appDelegateObject().navigationController!.setNavigationBarHidden(false, animated: false)
                appDelegateObject().navigationController?.pushViewController(productListVC, animated: true)
            }
        }
        
    }
}
