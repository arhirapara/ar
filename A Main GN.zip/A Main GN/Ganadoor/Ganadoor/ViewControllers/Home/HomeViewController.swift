//
//  HomeViewController.swift
//  vincitore
//
//  Created by AR on 04/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var activityIndicatorHome: UIActivityIndicatorView!
    @IBOutlet weak var scrollableStackView: ScrollableStackView!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var lblTotalItems: UILabel!
    @IBOutlet weak var lblTotalPrice: UILabel!
    @IBOutlet weak var constraintViewCartBottom: NSLayoutConstraint!
    
    let stcurrency = SharedModel.getUpdateFlagInfo().valuForKeyString("currency")
    var arrHomeData = [typeAliasDictionary]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hidesBottomBarWhenPushed = false
        sideBarBackButton { (str) in }
        sideBarLeftButton(imageName: "icn_notification") {[weak self] (str) in
            let notificationListVC = NotificationListViewController(nibName: "NotificationListViewController", bundle: nil)
            notificationListVC.isBackButton = true
            self?.navigationController?.pushViewController(notificationListVC, animated: true)
        }
        constraintViewCartBottom.constant = -100//-150
        self.view.LableWithTag(200).style(style: TextStyle.mediumWhite15)
        lblTotalItems.style(style: TextStyle.productLabel)
        lblTotalPrice.style(style: TextStyle.themeSemiBoldLabelSize18)
        txtSearch.setLeftImageView(25, image: UIImage(named: "icn_search")!)
        setTitle("HOME:Tembo")
        self.view.LableWithTag(100).style(style: TextStyle.HeaderLabel)
        txtSearch.style(style: TextStyle.placeHolder)
        NotificationCenter.default.addObserver(self, selector: #selector(self.cartValueUpdate), name: NSNotification.Name(rawValue: NOTIFICATION_GET_CART_VALUE), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.removeAllCart), name: NSNotification.Name(rawValue: NOTIFICATION_CLEAR_CART), object: nil)
        self.dataDummy()
        callSuperHome()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//        self.hidesBottomBarWhenPushed = false
        //self.tabBarController?.tabBar.isHidden = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        txtSearch.resignFirstResponder()
    }
    
    @IBAction func btnViewCartAction(_ sender: UIControl) {
//        isClickHomePage = false
//        let cartVC = BasketViewController(nibName: "BasketViewController", bundle: nil)
//        cartVC.isBackButton = true
//        self.navigationController?.pushViewController(cartVC, animated: true)
        appDelegate().contentViewController.selectedIndex = 3
    }
    
    @objc func removeAllCart() {
        for i in 0..<arrHomeData.count {
            var dict: typeAliasDictionary = arrHomeData[i]
            if dict.valuForKeyString("Type") == "product" {
                var arrMenu = dict.valuForKeyArray("ItemList") as! [typeAliasDictionary]
                for j in 0..<arrMenu.count {
                    var dictMenu: typeAliasDictionary = arrMenu[j]
                        dictMenu["Cart_Qty"] = "0" as AnyObject
                        arrMenu[j] = dictMenu
                        dict["ItemList"] = arrMenu as AnyObject
                        arrHomeData[i] = dict
                        self.setupProductUI(dictMenu)
                }
            }
        }
        self.constraintViewCartBottom.constant = -100
    }
    
    @objc func cartValueUpdate(notification: Notification) {
        let dictSelected: typeAliasDictionary = notification.object! as! typeAliasDictionary
        self.replaceMenuQty(dictSelected)
    }
    
    func replaceMenuQty(_ dictMenuData: typeAliasDictionary){
        let dictSelected: typeAliasDictionary = dictMenuData
        for i in 0..<arrHomeData.count {
            var dict: typeAliasDictionary = arrHomeData[i]
            if dict.valuForKeyString("Type") == "product" {
                var arrMenu = dict.valuForKeyArray("ItemList") as! [typeAliasDictionary]
                for j in 0..<arrMenu.count {
                    var dictMenu: typeAliasDictionary = arrMenu[j]
                    let menuId = dictMenu.valuForKeyString("Menu_Id")
                    let menuUpdateDictId = dictSelected.valuForKeyString("Menu_Id")
                    if menuId == menuUpdateDictId{
                        dictMenu["Cart_Qty"] = dictSelected.valuForKeyString("Cart_Qty") as AnyObject
                        self.cartCountUpdate(dictSelected)
                        arrMenu[j] = dictMenu
                        dict["ItemList"] = arrMenu as AnyObject
                        arrHomeData[i] = dict
                        break;
                    }
                    else {
                        self.cartCountUpdate(dictSelected)
                    }
                }
            }
        }
        self.setupProductUI(dictMenuData)
    }
    
    func setupProductUI(_ productObject : typeAliasDictionary) {
         if let prodyctcell = view.view(withId: productObject.valuForKeyString("Menu_Id")) as? ProductCollectionViewCell{
            
            if productObject.valuForKeyInt("Cart_Qty") == 0 {
                prodyctcell.viewStapper.alpha = 0;
                prodyctcell.viewAddProduct.alpha = 1;
            } else {
                prodyctcell.viewStapper.value = productObject.valuForKeyDouble("Cart_Qty")
                prodyctcell.viewStapper.alpha = 1;
                prodyctcell.viewAddProduct.alpha = 0;
            }
        }
    }
    
    func cartCountUpdate(_ dictCountUpdate: typeAliasDictionary){
        if dictCountUpdate.valuForKeyString("cart_count") == "0" || dictCountUpdate.valuForKeyString("cart_count") == "" {
            self.constraintViewCartBottom.constant = -100//-150
        }
        else {
            self.constraintViewCartBottom.constant = 0
            self.lblTotalItems.text = dictCountUpdate.valuForKeyString("cart_count") + " ITEMS".localized
            self.lblTotalPrice.text = "\(stcurrency) " + dictCountUpdate.valuForKeyString("cart_total")
        }
    }
    
    func dataDummy()  {
        for i in 0..<4 {
            if i == 0{
                let adView:AdvertView = UIView.fromNib()
                scrollableStackView.stackView.addArrangedSubview(adView)
                adView.reloadSkeleton()
            } else if i == 1{
                let categoryView:CommonFilterView = UIView.fromNib()
                categoryView.viewType = .CATEGORY
                scrollableStackView.stackView.addArrangedSubview(categoryView)
                categoryView.reloadSkeleton()
            } else if i == 3{
                let offerForUView:CommonFilterView = UIView.fromNib()
                offerForUView.viewType = .CATEGORY
                scrollableStackView.stackView.addArrangedSubview(offerForUView)
                offerForUView.reloadSkeleton()
            }
            else if i == 2{
                let adView:AdvertView = UIView.fromNib()
                scrollableStackView.stackView.addArrangedSubview(adView)
                adView.reloadSkeleton()
            }
            
        }
    }
    
    func setupUI() {
        let _ = scrollableStackView.stackView.subviews.map {$0.removeFromSuperview()}
        for i in 0..<arrHomeData.count {
            let dict = arrHomeData[i]
            if dict.valuForKeyString("Type") == "multi_banner" {
                let adView:AdvertView = UIView.fromNib()
                scrollableStackView.stackView.addArrangedSubview(adView)
                adView.arrImg = dict.valuForKeyArray("ItemList") as! [typeAliasDictionary]
                adView.setupPageControl()
            } else if dict.valuForKeyString("Type") == "category" {
                let categoryView:CommonFilterView = UIView.fromNib()
                if dict.valuForKeyString("Is_See_More") == "1" {
                    categoryView.btnViewAll.isHidden = false
                }
                categoryView.tag = i
                categoryView.lblTitle.text = dict.valuForKeyString("Title")
                categoryView.viewType = .CATEGORY
                categoryView.dictMain = dict
                scrollableStackView.stackView.addArrangedSubview(categoryView)
                categoryView.collectionArray = dict.valuForKeyArray("ItemList") as! [typeAliasDictionary]
                categoryView.parameterKey = "Category_Image_Url"
                categoryView.reloadData()
            } else if dict.valuForKeyString("Type") == "product" {
                let offerForUView:CommonFilterView = UIView.fromNib()
                if dict.valuForKeyString("Is_See_More") == "1" {
                    offerForUView.btnViewAll.isHidden = false
                }
                offerForUView.lblTitle.text = dict.valuForKeyString("Title")
                offerForUView.dictMain = dict
                offerForUView.viewType = .OFFERS
                scrollableStackView.stackView.addArrangedSubview(offerForUView)
                offerForUView.collectionArray = dict.valuForKeyArray("ItemList") as! [typeAliasDictionary]
                offerForUView.parameterKey = "Menu_Image"
                offerForUView.reloadData()
                offerForUView.cartAdded = { [weak self] (dict, value) in
                    self?.callAddToCart(categoryID: dict.valuForKeyString("Category_Id"), menuID: dict.valuForKeyString("Menu_Id"), menuQty: value.description)
                }
                
            }
        }
    }
    
    //MARK: Custom Function
    func callSuperHome()  {
        activityIndicatorHome.isHidden = true
        activityIndicatorHome.stopAnimating()
        self.view.viewWithTag(8062020)?.alpha = 1
        
        var param = typeAliasDictionary()
        
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id")  as AnyObject
        
        callRestApi(API_Super_Home, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: false, onCompletion: { [weak self](response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                
                self?.arrHomeData = response.valuForKeyDic("superHomeData").valuForKeyArray("SuperHomeList") as! [typeAliasDictionary]
                if response.valuForKeyDic("CartData").valuForKeyString("cart_count") == "0" || response.valuForKeyDic("CartData").valuForKeyString("cart_count") == "" {
                    self?.constraintViewCartBottom.constant = -100//-150
                }
                else {
                    self?.constraintViewCartBottom.constant = 0
                    self?.lblTotalItems.text = response.valuForKeyDic("CartData").valuForKeyString("cart_count") + " ITEMS".localized
                    self?.lblTotalPrice.text = "\(self!.stcurrency) " + response.valuForKeyDic("CartData").valuForKeyString("cart_total")
                }
                self?.setupUI()
                self?.scrollableStackView.stackView.translatesAutoresizingMaskIntoConstraints = false
            }
            else if response.valuForKeyString("status") == "0" {
                
            }
            }, onFailure: { (error) in
                print(error)
        })
    }
    
    //MARK: AddToCart
    func callAddToCart(categoryID:String, menuID:String, menuQty:String) {
        lblTotalItems.text = ""
        lblTotalPrice.text = ""
        self.view.viewWithTag(8062020)?.alpha = 0
        activityIndicatorHome.isHidden = false
        activityIndicatorHome.startAnimating()
        
        self.view.isUserInteractionEnabled = false
        var param = typeAliasDictionary()
     
        param[REQ_USER_ID] = SharedModel.getUserInfo().valuForKeyString("User_Id") as AnyObject
        param[REQ_CATEGORY_ID] = categoryID as AnyObject
        param[REQ_MENU_ID] = menuID as AnyObject
        param[REQ_MENU_QTY] = menuQty as AnyObject
        
        callRestApi(API_Add_To_Cart_Remove_Cart, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: false, onCompletion: { [weak self] (response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                
                let dict = [
                    "cart_total" : response.valuForKeyString("cart_total"),
                    "cart_count" : response.valuForKeyString("cart_count"),
                    "menu_price" : response.valuForKeyString("menu_price"),
                    "Cart_Qty" : menuQty,
                    "Menu_Id" : menuID
                ]
                self!.replaceMenuQty(dict as typeAliasDictionary)
                
                if response.valuForKeyString("cart_count") == "0" || response.valuForKeyString("cart_count") == "" {
                    self?.constraintViewCartBottom.constant = -100//-150
                }
                else {
                    self?.constraintViewCartBottom.constant = 0
                    self?.lblTotalItems.text = response.valuForKeyString("cart_count") + " ITEMS".localized
                    self?.lblTotalPrice.text = "\(self!.stcurrency) " + response.valuForKeyString("cart_total")
                }
                UIView.animate(withDuration: 0.3) {
                    self?.view.layoutIfNeeded()
                    self?.view.isUserInteractionEnabled = true
                    self!.view.viewWithTag(8062020)?.alpha = 1
                    self?.activityIndicatorHome.isHidden = true
                    self?.activityIndicatorHome.stopAnimating()
                }
            }
            else if response.valuForKeyString("status") == "0" {
                self!.view.viewWithTag(8062020)?.alpha = 1
                self?.activityIndicatorHome.isHidden = true
                self?.activityIndicatorHome.stopAnimating()
                self?.view.isUserInteractionEnabled = true
            }
            }, onFailure: { [weak self] (error) in
                print(error)
                self!.view.viewWithTag(8062020)?.alpha = 1
                self?.activityIndicatorHome.isHidden = true
                self?.activityIndicatorHome.stopAnimating()
                self?.view.isUserInteractionEnabled = true
        })
    }
    
    //MARK:- TextField Delegate
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
        if textField == txtSearch {
            let categoryVC = CategoryViewController(nibName: "CategoryViewController", bundle: nil)
            categoryVC.isBackButton = true
            categoryVC.isBackButtonBanner = true
            appDelegateObject().navigationController!.setNavigationBarHidden(false, animated: false)
            appDelegateObject().navigationController?.pushViewController(categoryVC, animated: true)
        }
    }
}

//extension UIView {
//
//    var id: String? {
//        get {
//            return self.accessibilityIdentifier
//        }
//        set {
//            self.accessibilityIdentifier = newValue
//        }
//    }
//
//    func view(withId id: String) -> UIView? {
//        if self.id == id {
//            return self
//        }
//        for view in self.subviews {
//            if let view = view.view(withId: id) {
//                return view
//            }
//        }
//        return nil
//    }
//}
