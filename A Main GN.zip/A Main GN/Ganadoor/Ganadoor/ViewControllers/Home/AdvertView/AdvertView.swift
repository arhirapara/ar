//
//  AdvertView.swift
//  vincitore
//
//  Created by AR on 05/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

let CELL_IDENTIFIER_MULTI_BANNER_CELL                = "MultiBannerCell"

class AdvertView: UIView, UIScrollViewDelegate, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var constrintHeightForCollectionView: NSLayoutConstraint!
    @IBOutlet weak var collectionViewBanner: UICollectionView!
    @IBOutlet weak var pageControlView: UIView!
    @IBOutlet weak var lblTagLine: UILabel!
    
    var currentPage = 0
    var arrImg:[typeAliasDictionary] = [typeAliasDictionary]()
    let pageControl = SCPageControlView()
    var timerBanner = Timer()
    var isLoading = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionViewBanner.delegate = self
        collectionViewBanner.dataSource = self
        
        collectionViewBanner.register(UINib(nibName: CELL_IDENTIFIER_MULTI_BANNER_CELL, bundle: nil), forCellWithReuseIdentifier: CELL_IDENTIFIER_MULTI_BANNER_CELL)
        
        lblTagLine.style(style: TextStyle.HederBold)
        pageControl.frame = CGRect(x: 0, y: 0, width: pageControlView.frame.width, height: pageControlView.frame.height)
        self.viewWithTag(100)?.isHidden = true
    }
    
    //MARK: Action
    @IBAction func btnClose(_ sender: UIButton) {
        self.viewWithTag(100)?.isHidden = true
    }
    
    //MARK: Custom Method
    func addBannerTimer() {
        let timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(nextBannerPage), userInfo: nil, repeats: true)
        RunLoop.main.add(timer, forMode: .common)
        timerBanner = timer
    }
    
    @objc func nextBannerPage() {
        for cell in collectionViewBanner.visibleCells {
            let indexPath = collectionViewBanner.indexPath(for: cell)
            if (indexPath?.row ?? 0) < arrImg.count - 1 {
                let indexPath1 = IndexPath(row: (indexPath?.row ?? 0) + 1, section: 0)
                collectionViewBanner.scrollToItem(at: indexPath1, at: [], animated: true)
            } else {
                let indexPath1 = IndexPath(row: 0, section: 0)
                collectionViewBanner.scrollToItem(at: indexPath1, at: [], animated: true)
            }
        }
    }
    
    func reloadSkeleton() {
        isLoading = true
        collectionViewBanner.reloadData()
    }
    
    func setupPageControl() {
        isLoading = false
        collectionViewBanner.reloadData()
        pageControl.scp_style = .SCNormal
        pageControl.set_view(arrImg.count, current: 0, current_color: UIColor(hexString:"#DC6666"))
        pageControlView.addSubview(pageControl)
        
        if arrImg.count <= 1 {
            pageControl.isHidden = true
        }
        timerBanner.invalidate()
        self.addBannerTimer()
    }
    
    //MARK: Scrollview Delegate
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let pageWidth = screenWidth
        currentPage = Int(floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1)
        pageControl.currentOfPage = currentPage
        pageControl.scroll_did(scrollView)
    }
    
    //MARK: CollectionView Datasource
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if !arrImg.isEmpty {
            return arrImg.count
        } else {
            return 2
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CELL_IDENTIFIER_MULTI_BANNER_CELL, for: indexPath) as! MultiBannerCell
        if !arrImg.isEmpty{
            let dictData = arrImg[indexPath.row]
            cell.imageViewBanner.hideSkeleton()
            cell.imageViewBanner.contentMode = .scaleToFill
            cell.imageViewBanner.setImageWith(URL(string: dictData.valuForKeyString("mb_banners")), placeholderImage: nil, usingActivityIndicatorStyle: .gray)
        }
        else {
            cell.imageViewBanner.frame = CGRect(x: 0, y: 0, width: screenWidth, height: 200)
            //cell.imageViewBanner.image = UIImage(named: "no_image_available")
            cell.imageViewBanner.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        }
        return cell
    }
    
    //MARK: CollectionView Delegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if !arrImg.isEmpty{
            let dictData = arrImg[indexPath.row]
            var _HOME_SCREEN_NAVIGATION = HOME_SCREEN_NAVIGATION.HOME_SCREEN_DUMMY
            if !dictData.isEmpty{
                print(dictData)
                
                _HOME_SCREEN_NAVIGATION = HOME_SCREEN_NAVIGATION(rawValue: dictData.valuForKeyInt("mb_screen_id"))!
                print(_HOME_SCREEN_NAVIGATION)
                if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_HOME{
                    
                }
                else if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_CATEGOTY{
                    let categoryVC = CategoryViewController(nibName: "CategoryViewController", bundle: nil)
                    categoryVC.isBackButton = true
                    categoryVC.isBackButtonBanner = true
                    categoryVC.dictCategoryData = dictData
                    appDelegateObject().navigationController!.setNavigationBarHidden(false, animated: false)
                    appDelegateObject().navigationController?.pushViewController(categoryVC, animated: true)
                }
                else if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_PRODUCT{
                    let productListVC = ProductListViewController(nibName: "ProductListViewController", bundle: nil)
                    productListVC.dictProductData = dictData as! typeAliasStringDictionary
                    productListVC.isBackButton = true
                    productListVC.isClickHomePage = true
                    appDelegateObject().navigationController!.setNavigationBarHidden(false, animated: false)
                    appDelegateObject().navigationController?.pushViewController(productListVC, animated: true)
                }
            }
        }
    }
    
    //MARK: CollectionView FlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var bannerWidth: CGFloat = 0.0
        var bannerHeight: CGFloat = 0.0
        var heightImageView: CGFloat = 0.00
        
        if !arrImg.isEmpty{
            var imageData: Data? = nil
            if let url = URL(string: arrImg[indexPath.row].valuForKeyString("mb_banners")) {
                do {
                    imageData = try Data(contentsOf: url)
                }
                catch {
                    print(error)
                }
            }
            var image: UIImage? = nil
            if let imageData = imageData {
                image = UIImage(data: imageData)
            }
            
            bannerWidth = image!.size.width
            bannerHeight = image!.size.height
            
            heightImageView = (screenWidth * CGFloat(bannerHeight)) / CGFloat(bannerWidth)
            heightImageView = ceil(heightImageView)
            constrintHeightForCollectionView.constant = heightImageView
            self.layoutIfNeeded()
            return CGSize(width: screenWidth, height: heightImageView)
        }
        constrintHeightForCollectionView.constant = 200
        self.layoutIfNeeded()
        return CGSize(width: screenWidth, height: 200)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
