//
//  PromotionView.swift
//  vincitore
//
//  Created by AR on 06/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class PromotionView: UIView {

}
