//
//  CommonFilterCell.swift
//  vincitore
//
//  Created by AR on 05/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let animation = SkeletonAnimationBuilder().makeSlidingAnimation(withDirection: .leftRight)

import UIKit

class CommonFilterCell: UICollectionViewCell {

    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblProductPrice: UILabel!
    @IBOutlet weak var lblProductWeight: UILabel!
    @IBOutlet weak var productDescriptionView: UIView!
    @IBOutlet weak var lblOfferWeight: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.borderColor = UIColor.init(hexString: "DCDCDC").cgColor
        self.layer.borderWidth = 0.5
        lblProductName.style(style: TextStyle.productLabel)
        lblProductPrice.style(style: TextStyle.productPriceLabel)
        lblProductWeight.style(style: TextStyle.productOfferLabel)
        lblOfferWeight.style(style: TextStyle.offerLabel)
    }
    
    func showLoader(){
        lblProductPrice.numberOfLines = 1
        lblProductPrice.linesCornerRadius = 8
        productImageView.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
//       lblProductName.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblProductPrice.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
//        lblProductWeight.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        //productDescriptionView.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblOfferWeight.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
    }
    
    func hideLoder(){
        lblProductName.numberOfLines = 0
        productImageView.hideSkeleton()
        lblProductName.hideSkeleton()
        lblProductPrice.hideSkeleton()
        lblProductWeight.hideSkeleton()
        productDescriptionView.hideSkeleton()
        lblOfferWeight.hideSkeleton()
    }
    
}
