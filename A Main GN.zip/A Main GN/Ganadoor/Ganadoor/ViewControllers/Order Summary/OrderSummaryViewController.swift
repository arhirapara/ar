//
//  OrderSummaryViewController.swift
//  vincitore
//
//  Created by DNK040 on 28/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let CELL_IDENTIFIER_ORDER_SUMMARY_LIST_CELL         = "OrderSummaryListCell"


import UIKit

class OrderSummaryViewController: UIViewController {
    let stcurrency = SharedModel.getUpdateFlagInfo().valuForKeyString("currency")
    var orderSummary:ORDER_SUMMARY = ORDER_SUMMARY.ORDER_SUMMARY_MYORDER
    @IBOutlet weak var orderAmountLabel: UILabel!
    @IBOutlet weak var orderDateLabel: UILabel!
    @IBOutlet weak var orderNumberLabel: UILabel!
    @IBOutlet weak var constraintTableViewOrderItemsHeight: NSLayoutConstraint!
    var isJumpPayment: Bool = false
    @IBOutlet weak var imageViewSuccessFaield: UIImageView!
    
    @IBOutlet weak var tableViewOrderItems: UITableView! {
        didSet {
            tableViewOrderItems.dataSource = self
            tableViewOrderItems.delegate = self
            tableViewOrderItems.register(UINib.init(nibName: CELL_IDENTIFIER_ORDER_SUMMARY_LIST_CELL, bundle: nil), forCellReuseIdentifier: CELL_IDENTIFIER_ORDER_SUMMARY_LIST_CELL)
            tableViewOrderItems.rowHeight = HEIGHT_PRODUCT_LIST_CELL
            tableViewOrderItems.tableFooterView = UIView(frame: CGRect.zero)
        }
    }
    @IBOutlet weak var tableViewPayable: UITableView!{
        didSet {
            tableViewPayable.dataSource = self
            tableViewPayable.delegate = self
            tableViewPayable.register(UINib.init(nibName: "OrderSummaryCell", bundle: nil), forCellReuseIdentifier: "OrderSummaryCell")
            tableViewPayable.rowHeight = 40
            tableViewPayable.tableFooterView = UIView(frame: CGRect.zero)
        }
    }
    
    @IBOutlet weak var termsConditionLabel: UILabel!
    @IBOutlet weak var constraintTableViewPayableHeight: NSLayoutConstraint!
    @IBOutlet weak var subTotalLabel: UILabel!
    @IBOutlet weak var orderIdLabel: UILabel!
    @IBOutlet weak var orderStatusLabel: UILabel!
    var dictSummary = typeAliasDictionary()
    var dictOrder = typeAliasDictionary()
    var dictPayable = typeAliasDictionary()
    var arrOrderItems = [typeAliasDictionary]()
    var arrPayableAmount = [typeAliasDictionary]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideBarBackButton { (str) in
            if self.isJumpPayment{
                self.isJumpPayment = false
                appDelegateObject().showHome()
            }
        }
        setTitle("ORDERSUMMARY:Order Summary")
        if orderSummary == ORDER_SUMMARY.ORDER_SUMMARY_MYORDER {
            self.callSingleOrderDetail()
        }
        else if orderSummary == ORDER_SUMMARY.ORDER_SUMMARY_BASKET {
            print(dictSummary)
            if dictSummary.valuForKeyString("status") == "1" {
                if let dictResponse = dictSummary.valuForKeyDic("OrderData") as? typeAliasDictionary {
                    if let orderDict = dictResponse.valuForKeyDic("Order") as? typeAliasDictionary {
                        self.dictOrder = orderDict
                        self.setOrderSummaryData()
                    }
                    if let arrPayment = dictResponse["OrderSummary"] as? [typeAliasDictionary], arrPayment.count != 0 {
                        self.view.viewWithTag(136)?.isHidden = false
                        self.arrPayableAmount = arrPayment
                        self.constraintTableViewPayableHeight.constant = CGFloat(self.arrPayableAmount.count) * 30
                        self.tableViewPayable.reloadData()
                    }
                    else {
                        self.view.viewWithTag(136)?.isHidden = true
                        self.constraintTableViewPayableHeight.constant = 0
                    }
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
        self.hidesBottomBarWhenPushed = true
    }
    
    func callSingleOrderDetail() {
        var param = typeAliasDictionary()
        param[REQ_USER_ID] = SharedModel.getUserInfo().valuForKeyString("User_Id") as AnyObject
        param[REQ_ORDER_ID] = self.dictSummary.valuForKeyString("orderID") as AnyObject
        
        callRestApi(API_Single_Order_Detail, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: {[weak self] (response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                if let dictResponse = response.valuForKeyDic("OrderData") as? typeAliasDictionary {
                    if let orderDict = dictResponse.valuForKeyDic("Order") as? typeAliasDictionary {
                        self!.dictOrder = orderDict
                        self!.setOrderSummaryData()
                    }
                    if let arrPayment = dictResponse["OrderSummary"] as? [typeAliasDictionary], arrPayment.count != 0 {
                        self!.view.viewWithTag(136)?.isHidden = false
                        self!.arrPayableAmount = arrPayment
                        self!.constraintTableViewPayableHeight.constant = CGFloat(self!.arrPayableAmount.count) * 30
                        self!.tableViewPayable.reloadData()
                    }
                    else {
                        self!.view.viewWithTag(136)?.isHidden = true
                        self!.constraintTableViewPayableHeight.constant = 0
                    }
                }
            }
            else if response.valuForKeyString("status") == "0" {
                appDelegateObject()
            }
            }, onFailure: { (error) in
                print(error)
        })
    }
    
    
    func setOrderSummaryData() {
        let text = "ORDERSUMMARY:Order id".localized
        orderIdLabel.text = String.init(format: "%@ : %@", text, self.dictOrder.valuForKeyString("OrderId"))
        orderStatusLabel.text = self.dictOrder.valuForKeyString("OrderStatusMessage")
        orderNumberLabel.text = self.dictOrder.valuForKeyString("OrderNumber")
        orderDateLabel.text = self.dictOrder.valuForKeyString("OrderDate")
        orderAmountLabel.text = String.init(format: "%@ %@", stcurrency,self.dictOrder.valuForKeyString("OrderAmount"))
        orderStatusLabel.textColor = UIColor(hexString: self.dictOrder.valuForKeyString("OrderColor"))
        var orderStatus = self.dictOrder.valuForKeyString("OrderStatus")
        orderStatus = orderStatus.uppercased()
        if orderStatus == "SUCCESS"{
            imageViewSuccessFaield.image = UIImage(named: "icn_success")
        }
        else {
            imageViewSuccessFaield.image = UIImage(named: "ic_close_order")
        }
        if let arrItems = self.dictOrder["MenuList"] as? [typeAliasDictionary], arrItems.count != 0 {
            self.view.viewWithTag(135)?.isHidden = false
            self.arrOrderItems = arrItems
            constraintTableViewOrderItemsHeight.constant = CGFloat(arrOrderItems.count) * HEIGHT_PRODUCT_LIST_CELL
            tableViewOrderItems.reloadData()
        }
        else {
            self.view.viewWithTag(135)?.isHidden = true
            constraintTableViewOrderItemsHeight.constant = 0
        }
        
        subTotalLabel.text = String.init(format: "%@ %@", stcurrency,self.dictOrder.valuForKeyString("SubTotal"))
        termsConditionLabel.attributedText = self.dictOrder.valuForKeyString("TermsCondition").htmlToAttributedString
        
        
    }
}

extension OrderSummaryViewController:UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tableViewOrderItems {
            return arrOrderItems.count
        }
        else {
            return arrPayableAmount.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tableViewOrderItems {
            let cell : OrderSummaryListCell = tableView.dequeueReusableCell(withIdentifier: CELL_IDENTIFIER_ORDER_SUMMARY_LIST_CELL) as! OrderSummaryListCell
            
            if !arrOrderItems.isEmpty{
                let dictData: typeAliasStringDictionary = arrOrderItems[indexPath.row] as! typeAliasStringDictionary
                
                let stcurrency = SharedModel.getUpdateFlagInfo().valuForKeyString("currency")
                
                cell.imageViewProduct.setImageWith(URL(string: dictData.valuForKeyString("Menu_Image")), placeholderImage: UIImage(named: "no_image_available"), usingActivityIndicatorStyle: .gray)
                
                let priceLbelString = dictData.valuForKeyString("Discount_Label")
                let productPriceString = dictData.valuForKeyString("Menu_Price")
                
                if !priceLbelString.isEmpty {
                    cell.viewOff.alpha = 1
                    cell.lblProductPriceOff.text = priceLbelString
                }
                else {
                    cell.viewOff.alpha = 0
                }
                let menuQty = dictData.valuForKeyString("Menu_Qty")
                cell.lblProductName.text = dictData.valuForKeyString("Menu_Title")
                cell.lblProductDescription.text = dictData.valuForKeyString("Menu_Description")
                if menuQty != ""{
                    cell.lblProductQty.text =  "Qty : " + menuQty
                }else {
                    cell.lblProductQty.text = ""
                }
                cell.lblProductPrice.text = stcurrency + " " + productPriceString
                
                cell.viewAddProductPlus.isHidden = true
                cell.viewAddProduct.isHidden = true
            }
            return cell
        }
        else {
            let cell : OrderSummaryCell = tableView.dequeueReusableCell(withIdentifier: "OrderSummaryCell") as! OrderSummaryCell
            let dict = arrPayableAmount[indexPath.row]
            cell.lblTitle.text = dict.valuForKeyString("title")
            cell.lblValue.text = String.init(format: "%@ %@", stcurrency,dict.valuForKeyString("value"))
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == tableViewOrderItems {
            return HEIGHT_PRODUCT_LIST_CELL
        }
        else {
            return 30
        }
    }
}
