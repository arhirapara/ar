//
//  OrderSummaryListCell.swift
//  vincitore
//
//  Created by AR on 26/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class OrderSummaryListCell: UITableViewCell {

    @IBOutlet weak var viewOff: UIView!
    @IBOutlet weak var imageViewProduct: UIImageView!
    
    @IBOutlet weak var viewAddProduct: UIControl!
    @IBOutlet weak var viewAddProductPlus: UIControl!
    
    @IBOutlet weak var lblProductPriceOff: UILabel!
    @IBOutlet weak var lblProductPrice: UILabel!
    @IBOutlet weak var lblProductDescription: UILabel!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblProductQty: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
