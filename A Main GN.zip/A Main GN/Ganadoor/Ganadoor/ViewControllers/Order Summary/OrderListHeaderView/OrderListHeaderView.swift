//
//  OrderListHeaderView.swift
//  vincitore
//
//  Created by DNK062 on 29/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class OrderListHeaderView: UIView {

    @IBOutlet weak var lblOrderDate: UILabel!
    
}
