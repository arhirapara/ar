//
//  SplashScreenViewController.swift
//  Forevermark
//
//  Created by DNK062 on 31/03/20.
//  Copyright © 2020 DNK062. All rights reserved.
//

import UIKit

class SplashScreenViewController: UIViewController {
    
    @IBOutlet weak var activityIndicatorSplashScreen: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(timeOut), userInfo: nil, repeats: false)
        self.callServiceUpdateFlag()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    
    @objc func timeOut() {
        if SharedModel.getUserInfo().isEmpty{
            appDelegateObject().showSignUpOption()
        }
        else {
            appDelegate().showHome()
        }
    }
    
    //MARK:- Custom Method
    
    func callServiceUpdateFlag()  {
        activityIndicatorSplashScreen.isHidden = false
        activityIndicatorSplashScreen.startAnimating()
        let currentDevice = UIDevice.current
        let deviceId = currentDevice.identifierForVendor?.uuidString
        let dictUserInfo = SharedModel.getUserInfo()
        var userId: String = ""
        
        if !dictUserInfo.isEmpty {
            userId = dictUserInfo.valuForKeyString("User_Id")
        }
        
        var param = typeAliasDictionary()
       
        param[REQ_Device_token] = "00000"  as AnyObject
        param[REQ_Device_type] = KEY_IOS_DEVICE  as AnyObject
        param[REQ_Device_id] = deviceId  as AnyObject
        param[REQ_Device_version] = UIDevice.current.model  as AnyObject
        param[REQ_DEVICE_NAME] = UIDevice.current.name as AnyObject
        param[REQ_APP_VERSION] = SharedModel.getAppVersion()  as AnyObject
        param[REQ_User_id] = userId  as AnyObject
        param[REQ_Device_mac_id] = ""  as AnyObject
        
        callRestApi(API_Service_Update_Flag, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: false, onCompletion: { (response) in
            print(response)
            self.activityIndicatorSplashScreen.isHidden = true
            self.activityIndicatorSplashScreen.stopAnimating()
            if response.valuForKeyString("status") == "1" {
                SharedModel.setUpdateFlagInfo(response)
                self.timeOut()
            }
            else if response.valuForKeyString("status") == "0" {
                 self.timeOut()
            }
        }, onFailure: { (error) in
            print(error)
            self.activityIndicatorSplashScreen.isHidden = true
            self.activityIndicatorSplashScreen.stopAnimating()
            self.timeOut()
        })
    }
}
