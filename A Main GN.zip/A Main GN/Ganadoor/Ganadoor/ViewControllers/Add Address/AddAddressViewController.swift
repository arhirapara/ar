//
//  AddAddressViewController.swift
//  vincitore
//
//  Created by AR on 23/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let CELL_IDENTIFIER_ADDRESSES_TYPR_CELL =   "AddressTypeCell"
let HARIZONTAL_SPCE_IMAGE: CGFloat =        0
let VERTICAL_SPCE_IMAGE: CGFloat =          0
let COLUMN_IMAGE: CGFloat =                 3


import UIKit

class AddAddressViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var txtCollection: [UITextField]!
    
    @IBOutlet weak var collectionViewAddressTitle: UICollectionView!
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtMobileNumber: UITextField!
    @IBOutlet weak var txtHouseNo: UITextField!
    @IBOutlet weak var txtApartmentName: UITextField!
    @IBOutlet weak var txtStreetDetails: UITextField!
    @IBOutlet weak var txtLandmark: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtPinCode: UITextField!
    
    @IBOutlet weak var lblButtionTitle: UILabel!
    
    var _address_type = ADDRESS_TYPE.ADDRESS_DUMMY
    var isNewAddress: Bool = false
    var dictSelectedCity = typeAliasStringDictionary()
    var arrAddressTitle = [typeAliasStringDictionary]()
    var dictSelectedTitle = typeAliasStringDictionary()
    var dictUpdateAddress = typeAliasStringDictionary()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
        setTitle("ADDRESSLIST:Add New Address")
        
        arrAddressTitle = self.getAddressTitle()!
        collectionViewAddressTitle.register(UINib(nibName: CELL_IDENTIFIER_ADDRESSES_TYPR_CELL, bundle: nil), forCellWithReuseIdentifier: CELL_IDENTIFIER_ADDRESSES_TYPR_CELL)
        
        if _address_type == .ADD_ADDRESS || _address_type == .ADDRESS_DUMMY{
            dictSelectedTitle = arrAddressTitle.first!
            setTitle("ADDRESSLIST:Add New Address")
            lblButtionTitle.text = "ADDADDRESS:Add Address".localized
        }
        else if _address_type == .UPDATE_ADDRESS{
            lblButtionTitle.text = "ADDADDRESS:Update Address".localized
            setTitle("ADDADDRESS:Update Address")
            self.updateAddress()
        }
        collectionViewAddressTitle.reloadData()
        
        for txt in txtCollection{
            txt.paddingLeftCustom = 4
        }
        self.hidesBottomBarWhenPushed = true
        self.tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if appDelegateObject().contentViewController.selectedIndex == 3{
            self.hidesBottomBarWhenPushed = false
            self.tabBarController?.tabBar.isHidden = false
        }
        if isNewAddress{
            navigationController?.setNavigationBarHidden(false, animated: false)
        }
    }
    
    //MARK: Custom Method
    func updateAddress()  {
        print("Update Address : \(self.dictUpdateAddress)")
        let updateTitle = self.dictUpdateAddress.valuForKeyString("Address_Title")
        for dict in arrAddressTitle {
            let titleString = dict.valuForKeyString(PARAMETER_VALUE)
            if titleString.uppercased() == updateTitle.uppercased() {
                dictSelectedTitle = dict
            }
        }
        
        let dictCity = [
            "City_Id" : self.dictUpdateAddress.valuForKeyString("City_Id"),
            "City_Name" : self.dictUpdateAddress.valuForKeyString("City_Name")
        ]
        dictSelectedCity = dictCity
        
        let fullName = self.dictUpdateAddress.valuForKeyString("Person_Name")
        var fullNameArr = fullName.components(separatedBy: " ")
        let firstName: String = fullNameArr[0]
        fullNameArr.remove(at: 0)
        var finaleString = ""
        for st in fullNameArr {
                finaleString += " " + st
        }
        let lastName: String? = finaleString.trim()//fullNameArr.count > 1 ? fullNameArr[1] : ""
        
        let houseNumber = self.dictUpdateAddress.valuForKeyString("House_No")
        let apartmentNameString = self.dictUpdateAddress.valuForKeyString("Apartment_Name")
        let streetDetails = self.dictUpdateAddress.valuForKeyString("Street_Details")
        let landmark = self.dictUpdateAddress.valuForKeyString("Landmark")
        
        let pincode = self.dictUpdateAddress.valuForKeyString("Pincode")
        
        txtFirstName.text = firstName.trim()
        txtLastName.text = lastName!.trim()
        txtMobileNumber.text = self.dictUpdateAddress.valuForKeyString("Delivery_Mobile_No")
        txtHouseNo.text = houseNumber.trim()
        txtApartmentName.text = apartmentNameString.trim()
        txtStreetDetails.text = streetDetails.trim()
        txtCity.text = dictSelectedCity.valuForKeyString("City_Name")
        txtLandmark.text = landmark.trim()
        txtPinCode.text = pincode.trim()
        
        //["Address_Id": "36", "Address_Title": "WORK", "Address_1": "", "Pincode": "396256", "Person_Name": "ajay hirapara", "City_Id": "391", "Address_2": "", "Landmark": "Sudama chowk", "Apartment_Name": "varacha", "Street_Details": "yogi nagar", "House_No": "A-35", "Is_Default_Address": "1", "Delivery_Mobile_No": "9858525356", "City_Name": "Vrindavan"]
    }
    
    func hideKeyboard()  {
        for txt in txtCollection {
            txt.resignFirstResponder()
        }
    }
    
    func getAddressTitle() -> [typeAliasStringDictionary]? {
        
        let dict = [
            PARAMETER_VALUE : "ADDADDRESS:HOME".localized,
            PARAMETER_KEY : "1001"
        ]
        
        let dict1 = [
            PARAMETER_VALUE : "ADDADDRESS:WORK".localized,
            PARAMETER_KEY : "1002"
        ]
        
        let dict2 = [
            PARAMETER_VALUE : "ADDADDRESS:OTHER".localized,
            PARAMETER_KEY : "1003"
        ]
        //        let dict3 = [
        //            PARAMETER_VALUE : "Other",
        //            PARAMETER_KEY : "1004"
        //        ]
        
        let arrTitle = [dict, dict1, dict2]
        return arrTitle
    }
    
    
    func callAdd_UpdateDeliveryAddress(_ addressIdString: String, addressAction: String) {
        /* addressAction is
         
         ACTION
         1 = Add Address
         2 = Update Address
         Note :- ADDRESS_ID is Compolsory While Updating Address."
         */
        
        
        let firstNameString = txtFirstName.text?.trim()
        let lastNameString = txtLastName.text?.trim()
        let conteactNumberString = txtMobileNumber.text?.trim()
        let houseNumberString = txtHouseNo.text?.trim()
        let apartmentNameString = txtApartmentName.text?.trim()
        let streetDetailsString = txtStreetDetails.text?.trim()
        let landmarkString = txtLandmark.text?.trim()
        let cityString = txtCity.text?.trim()
        let pincodeString = txtPinCode.text?.trim()
        
        
        if firstNameString!.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "ADDADDRESS:Enter your first name.".localized, type: .WARNING)
            return
        }
        
        if lastNameString!.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "ADDADDRESS:Enter your last name.".localized, type: .WARNING)
            return
        }
        
        if conteactNumberString!.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "ADDADDRESS:Enter your mobile number.".localized, type: .WARNING)
            return
        }
            //else if !conteactNumberString!.validateMobileNo() {
        else if conteactNumberString!.count < 12 || conteactNumberString!.count > 12 {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "ADDADDRESS:Enter valid your mobile number.".localized, type: .WARNING)
            return
        }
        
        
        if houseNumberString!.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "ADDADDRESS:Enter your house number.".localized, type: .WARNING)
            return
        }
        
        if apartmentNameString!.isEmpty{
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "ADDADDRESS:Enter your apartment name.".localized, type: .WARNING)
            return
        }
        
        
        if streetDetailsString!.isEmpty{
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "ADDADDRESS:Enter your street details.".localized, type: .WARNING)
            return
        }
        
        if landmarkString!.isEmpty{
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "ADDADDRESS:Enter your near landmark.".localized, type: .WARNING)
            return
        }
        
        if cityString!.isEmpty || dictSelectedCity.isEmpty{
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "ADDADDRESS:Select your city.".localized, type: .WARNING)
            return
        }
        
        if pincodeString!.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "ADDADDRESS:Enter your pincode.".localized, type: .WARNING)
            return
        }
//        else if pincodeString!.count < 6 || pincodeString!.count > 6{
//            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "Please enter a valid 6 digit pincode.", type: .WARNING)
//            return
//        }
        
        let currentDevice = UIDevice.current
        let deviceId = currentDevice.identifierForVendor?.uuidString
        
        let personNameString: String = firstNameString! + " " + lastNameString!
        var param = typeAliasDictionary()

        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id")  as AnyObject
        param[REQ_ACTION] = addressAction as AnyObject
        param[REQ_ADDRESS_TITLE] = dictSelectedTitle.valuForKeyString(PARAMETER_VALUE) as AnyObject
        param[REQ_PERSON_NAME] = personNameString as AnyObject
        param[REQ_MOBILE_NO] = conteactNumberString as AnyObject
        param[REQ_HOUSE_NO] = houseNumberString as AnyObject
        param[REQ_APARTMENT_NAME] = apartmentNameString as AnyObject
        param[REQ_STREET_DETAILS] = streetDetailsString as AnyObject
        param[REQ_LANDMARK] = landmarkString as AnyObject
        param[REQ_PINCODE] = pincodeString as AnyObject
        param[REQ_CITY_ID] = dictSelectedCity.valuForKeyString("City_Id") as AnyObject
        param[REQ_ADDRESS_ID] = addressIdString as AnyObject //Optional
        
        callRestApi(API_Add_Update_Delivery_Address, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { (response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                showAlertWithTitle(title: MSG_PROJECT_TITLE, message: response.valuForKeyString("message"), type: .WARNING)
                self.navigationController?.popViewController(animated: true)
                for txt in self.txtCollection {
                    txt.text = ""
                }
            }
            else if response.valuForKeyString("status") == "0" {
                
            }
            //["status": 1, "token": hp/R7xYbycq9wzyGeRwFFbG9mDlL/DgtjY01eeyvUCg=, "address_id": 10, "message": Address added successfully]
        }, onFailure: { (error) in
            print(error)
        })
    }
    
    //MARK: Action
    @IBAction func viewAddAddressAction() {
        /* addressAction is
         
         ACTION
         1 = Add Address
         2 = Update Address
         Note :- ADDRESS_ID is Compolsory While Updating Address."
         */
        
        if _address_type == .ADDRESS_DUMMY || _address_type == .ADD_ADDRESS{
            self.callAdd_UpdateDeliveryAddress("", addressAction: "1")
        }
        else if _address_type == .UPDATE_ADDRESS {
            self.callAdd_UpdateDeliveryAddress(self.dictUpdateAddress.valuForKeyString("Address_Id"), addressAction: "2")
        }
    }
    
    //MARK: UITextField Delegate Method
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == txtFirstName {
            txtLastName.becomeFirstResponder()
        }
        else if textField == txtLastName {
            txtMobileNumber.becomeFirstResponder()
        }
        else if textField == txtMobileNumber {
            txtHouseNo.becomeFirstResponder()
        }
        else if textField == txtHouseNo {
            txtApartmentName.becomeFirstResponder()
        }
        else if textField == txtApartmentName {
            txtStreetDetails.becomeFirstResponder()
        }
        else if textField == txtStreetDetails {
            txtLandmark.becomeFirstResponder()
        }
        else if textField == txtLandmark {
            txtLandmark.resignFirstResponder()
        }
        else if textField == txtCity {
            txtPinCode.resignFirstResponder()
        }
        else if textField == txtPinCode {
            txtPinCode.resignFirstResponder()
        }
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == txtCity {
            DispatchQueue.main.asyncAfter(deadline: .now()) {
                if UIApplication.shared.isKeyboardPresented {
                    self.hideKeyboard()
                }
            }
            let frame = UIScreen.main.bounds
            let _cityListView = CityListView(frame: frame, firstTimeViewLoad: true)
            appDelegateObject().navigationController.view.addSubview(_cityListView)
            
            _cityListView.oncitySelection = { [weak self] (dictSelected) in
                print(dictSelected)
                self!.txtCity.text = dictSelected.valuForKeyString("City_Name")
                self!.dictSelectedCity = dictSelected
            }
        }
    }
}

extension AddAddressViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    // MARK: - UICollectionViewDelegateFlowLayout
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let widthImage = (collectionView.frame.size.width - CGFloat(((COLUMN_IMAGE - 1) * HARIZONTAL_SPCE_IMAGE))) / CGFloat(COLUMN_IMAGE)
        return CGSize(width: widthImage, height: 40)
    }
    
    //HORIZONTAL
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return HARIZONTAL_SPCE_IMAGE
    }
    
    //VERTICAL
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return VERTICAL_SPCE_IMAGE
    }
    
    // MARK: - UICollectionView Datasource
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrAddressTitle.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CELL_IDENTIFIER_ADDRESSES_TYPR_CELL, for: indexPath) as? AddressTypeCell
        
        let dict = arrAddressTitle[indexPath.row]
        
        let stringId = dict[PARAMETER_KEY]
        cell?.borderWidth = 0.5
        cell?.borderColor = UIColor.init(hexString: "DC6666")
        if !dictSelectedTitle.isEmpty {
            let stringSelectedId = dictSelectedTitle.valuForKeyString(PARAMETER_KEY)
            if (stringId == stringSelectedId) {
                cell?.viewBG.backgroundColor = UIColor.init(hexString: "DC6666")
                cell?.lblAddressType.textColor = UIColor.init(hexString: "ffffff")
            } else {
                cell?.viewBG.backgroundColor = UIColor.init(hexString: "ffffff")
                cell?.lblAddressType.textColor = UIColor.init(hexString: "B2B2B2")
            }
        }
        else {
            cell?.viewBG.backgroundColor = UIColor.init(hexString: "ffffff")
            cell?.lblAddressType.textColor = UIColor.init(hexString: "B2B2B2")
        }
        cell?.lblAddressType.text = dict.valuForKeyString(PARAMETER_VALUE)
        return cell!
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.hideKeyboard()
        let dict = arrAddressTitle[indexPath.row]
        dictSelectedTitle = dict
        collectionViewAddressTitle.reloadData()
    }
}
