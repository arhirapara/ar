//
//  AddressTypeCell.swift
//  vincitore
//
//  Created by AR on 25/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class AddressTypeCell: UICollectionViewCell {

    @IBOutlet weak var viewBG: UIView!
    @IBOutlet weak var lblAddressType: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
