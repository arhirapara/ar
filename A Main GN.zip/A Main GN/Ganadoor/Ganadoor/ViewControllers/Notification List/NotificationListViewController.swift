//
//  NotificationListViewController.swift
//  vincitore
//
//  Created by AR on 23/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let CELL_IDENTIFIER_NOTIFICATION_LIST_CELL         = "NotificationCell"
let HEIGHT_NOTIFICATION_LIST_CELL:CGFloat          = 145


import UIKit

class NotificationListViewController: UIViewController {
    
    @IBOutlet weak var notificationListTableView: UITableView!
    
    var totalPages: Int = 0
    var startPage: Int = 1
    var arrNotificationList = [typeAliasStringDictionary]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideBarBackButton { (str) in }
        setTitle("NOTIFICATIONS:Notifications")
        
        notificationListTableView.register(UINib.init(nibName: CELL_IDENTIFIER_NOTIFICATION_LIST_CELL, bundle: nil), forCellReuseIdentifier: CELL_IDENTIFIER_NOTIFICATION_LIST_CELL)
        notificationListTableView.estimatedRowHeight = HEIGHT_NOTIFICATION_LIST_CELL
        notificationListTableView.rowHeight = UITableView.automaticDimension
        notificationListTableView.tableFooterView = UIView(frame: CGRect.zero)
        self.hidesBottomBarWhenPushed = true
        self.tabBarController?.tabBar.isHidden = true
        
        self.callNotificationListWithSearch(startPage)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           self.hidesBottomBarWhenPushed = false
           self.tabBarController?.tabBar.isHidden = false
       }
    
    //MARK: Custom Function
    func callNotificationListWithSearch(_ pageNo: Int)  {
        var param = typeAliasDictionary()
       
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id")  as AnyObject
        //param[REQ_PAGE_NO] = "\(pageNo)"  as AnyObject
        
        callRestApi(API_Notification_List, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { (response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                
                let dictCatagoryData: typeAliasDictionary = response.valuForKeyDic("NotiData")
                
                self.arrNotificationList += response.valuForKeyDic("NotiData").valuForKeyArray("NotiList") as! [typeAliasStringDictionary]
                
                let strTotalRecords : String = "\(dictCatagoryData["totalPages"]!)"
                self.totalPages = Int(strTotalRecords)!
                //self.notificationListTableView.showNoDataView = false
                self.notificationListTableView.reloadData()
            }
            else if response.valuForKeyString("status") == "0" {
                self.notificationListTableView.showNoDataView = true
                self.notificationListTableView.reloadData()
            }
        }, onFailure: { (error) in
            self.notificationListTableView.showNoDataView = true
            self.notificationListTableView.reloadData()
            print(error)
        })
    }
}

extension NotificationListViewController:UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrNotificationList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : NotificationCell = tableView.dequeueReusableCell(withIdentifier: CELL_IDENTIFIER_NOTIFICATION_LIST_CELL) as! NotificationCell
        
        if !arrNotificationList.isEmpty{
            let dictData: typeAliasStringDictionary = arrNotificationList[indexPath.row]
            let dictUserData: typeAliasDictionary = SharedModel.getUserInfo()
            
            let notificationTitleColor: String = dictData.valuForKeyString("Notification_Color")
            if !notificationTitleColor.isEmpty {
                cell.lblTitle.textColor = UIColor.init(hexString: notificationTitleColor)
            }
            else {
                cell.lblTitle.textColor = UIColor.init(hexString: "07A76F")
            }
            cell.lblTitle.text =  dictData.valuForKeyString("Notication_Title")
            cell.lblDate.text =  dictData.valuForKeyString("Notification_Datetime")
            cell.lblDetails.text = dictData.valuForKeyString("Notification_Description")
            cell.lblName.text =  dictUserData.valuForKeyString("User_Name")
            
            if indexPath.row == self.arrNotificationList.count - 1 {
                print("Start Index: \(self.startPage)")
                let page: Int = startPage + 1
                if (page <= totalPages) {
                    startPage = page;
                    self.callNotificationListWithSearch(startPage)
                }
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    
}
