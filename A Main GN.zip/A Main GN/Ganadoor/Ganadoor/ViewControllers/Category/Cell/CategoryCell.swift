//
//  CategoryCell.swift
//  vincitore
//
//  Created by AR on 06/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class CategoryCell: UITableViewCell {

    @IBOutlet weak var constrintHeightLblCategoryname: NSLayoutConstraint!
   
    @IBOutlet weak var lblMiddaleCategoryName: UILabel!
    @IBOutlet weak var constrintHeightMiddaleLbl: NSLayoutConstraint!
    
    @IBOutlet weak var categoryImageView: UIImageView!
    @IBOutlet weak var lblCategroyName: UILabel!
    @IBOutlet weak var lblCategoryDescription: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        lblCategroyName.style(style: TextStyle.HeaderLabel16)
        lblMiddaleCategoryName.style(style: TextStyle.HeaderLabel)
        lblCategoryDescription.style(style: TextStyle.categoryDescription14)
    }
    
    func showLoader(){
        lblCategroyName.linesCornerRadius = 8
        lblCategoryDescription.linesCornerRadius = 8
        lblCategoryDescription.numberOfLines = 2
        lblCategoryDescription.lastLineFillPercent = 50
        lblCategoryDescription.lastLineFillingPercent = 50
        categoryImageView.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblCategroyName.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblCategoryDescription.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
    }
    
    func hideLoder(){
        lblCategoryDescription.numberOfLines = 0
        categoryImageView.hideSkeleton()
        lblCategroyName.hideSkeleton()
        lblCategoryDescription.hideSkeleton()
    }
    
}
