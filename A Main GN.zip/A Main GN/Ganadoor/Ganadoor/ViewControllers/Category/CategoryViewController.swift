//
//  CategoryViewController.swift
//  vincitore
//
//  Created by AR on 06/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let CELL_IDENTIFIER_CATEGORY_CELL         = "CategoryCell"
let HEIGHT_CATEGORY:CGFloat              = 135

import UIKit

class CategoryViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var categoryTableView: UITableView!
    
    var searchTimer: Timer? = nil
    var totalPages: Int = 0
    var startPage: Int = 1
    var dictCategoryData = typeAliasDictionary()
    var arrCategoryList = [typeAliasStringDictionary]()
    var isBackButtonBanner: Bool = false
    var isBackButtonBannerJump: Bool = false
    var isLoading: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
        //        sideBarLeftButton(imageName: "icn_notification") {[weak self] (str) in
        //            let notificationListVC = NotificationListViewController(nibName: "NotificationListViewController", bundle: nil)
        //            notificationListVC.isBackButton = true
        //            self?.navigationController?.pushViewController(notificationListVC, animated: true)
        //        }
        
        if !isBackButton {
            sideBarLeftButton(imageName: "icn_notification") {[weak self] (str) in
                let notificationListVC = NotificationListViewController(nibName: "NotificationListViewController", bundle: nil)
                notificationListVC.isBackButton = true
                self?.navigationController?.pushViewController(notificationListVC, animated: true)
            }
        }
        setTitle("CATEGORY:Categories")
        self.view.LableWithTag(100).style(style: TextStyle.HeaderLabel)
        categoryTableView.register(UINib(nibName: CategoryCell.reuseIdentifier, bundle: nil), forCellReuseIdentifier: CategoryCell.reuseIdentifier)
        categoryTableView.estimatedRowHeight = HEIGHT_CATEGORY
        categoryTableView.rowHeight = UITableView.automaticDimension
        categoryTableView.tableFooterView = UIView(frame: CGRect.zero)
        
        categoryTableView.dataSource = self
        categoryTableView.delegate = self
        
        txtSearch.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        txtSearch.setLeftImageView(25, image: UIImage(named: "icn_search")!)
        txtSearch.style(style: TextStyle.placeHolder)
        self.callCategoryListWithSearch(startPage, searchString: "")
        isBackButtonBannerJump = isBackButtonBanner
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isBackButtonBanner = isBackButtonBannerJump
        self.tabBarController?.tabBar.isHidden = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        txtSearch.resignFirstResponder()
        if isBackButtonBanner{
            navigationController?.setNavigationBarHidden(true, animated: false)
        }
    }
    
    //MARK: Custom Function
    func callCategoryListWithSearch(_ pageNo: Int, searchString: String)  {
        var categotrId = ""
        if !dictCategoryData.isEmpty{
            categotrId = dictCategoryData.valuForKeyString("Category_Id")
            if categotrId == "" {
                categotrId = dictCategoryData.valuForKeyString("mb_category_id")
            }
        }
        
        var param = typeAliasDictionary()
      
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id")  as AnyObject
        param[REQ_PAGE_NO] = "\(pageNo)"  as AnyObject
        param[REQ_CATEGORY_ID] = categotrId  as AnyObject
        param[REQ_CATEGORY_name] = searchString  as AnyObject
        
        callRestApi(API_Category_List_With_Search, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: false, onCompletion: { (response) in
            print(response)
            self.isLoading = false
            if response.valuForKeyString("status") == "1" {
                
                let dictCatagoryData: typeAliasDictionary = response.valuForKeyDic("Category_Data")
                self.arrCategoryList += response.valuForKeyDic("Category_Data").valuForKeyArray("Category_List") as! [typeAliasStringDictionary]
                
                let strTotalRecords : String = "\(dictCatagoryData["totalPages"]!)"
                self.totalPages = Int(strTotalRecords)!
                //self.categoryTableView.showNoDataView = false
                self.categoryTableView.reloadData()
            }
            else if response.valuForKeyString("status") == "0" {
                self.categoryTableView.showNoDataView = true
                self.categoryTableView.reloadData()
            }
        }, onFailure: { (error) in
            print(error)
            self.isLoading = false
            self.categoryTableView.showNoDataView = true
            self.categoryTableView.reloadData()
        })
    }
    
    @objc func textFieldDidChange(_ textField: UITextField?) {
        if searchTimer != nil {
            searchTimer!.invalidate()
            searchTimer = nil
        }
        
        searchTimer = Timer.scheduledTimer(timeInterval: 0.6, target: self, selector: #selector(search(forKeyword:)), userInfo: textField?.text, repeats: false)
    }
    
    @objc func search(forKeyword timer: Timer?) {
        let keyword = timer?.userInfo as? String
        print("Searching for keyword \(keyword ?? "")")
        let stSearch = keyword?.trim()
        txtSearch.text = stSearch
        startPage = 1
        arrCategoryList.removeAll()
        self.callCategoryListWithSearch(startPage, searchString: stSearch!)
    }
    
    //MARK: UITextField Delegate Method
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtSearch.resignFirstResponder()
        return true
    }
}

extension CategoryViewController:UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isLoading ? 15 : arrCategoryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CategoryCell.reuseIdentifier, for: indexPath) as! CategoryCell
        if !arrCategoryList.isEmpty{
            cell.hideLoder()
            let dictData: typeAliasStringDictionary = arrCategoryList[indexPath.row]
            
            let descriptionString = dictData.valuForKeyString("Category_Description")
            
            if descriptionString.isEmpty{
                cell.constrintHeightMiddaleLbl.constant = 50
                cell.constrintHeightLblCategoryname.constant = 0
                cell.lblCategroyName.text = ""
                cell.lblCategoryDescription.text = ""
                cell.lblMiddaleCategoryName.text = dictData.valuForKeyString("Category_Name")
            }
            else {
                cell.constrintHeightMiddaleLbl.constant = 0
                cell.constrintHeightLblCategoryname.constant = 20
                cell.lblCategoryDescription.text = descriptionString
                cell.lblMiddaleCategoryName.text = ""
                cell.lblCategroyName.text = dictData.valuForKeyString("Category_Name")
            }
            cell.lblCategoryDescription.numberOfLines = 3
            cell.categoryImageView.setImageWith(URL(string: dictData.valuForKeyString("Category_Image_Url")), placeholderImage: UIImage(named: "no_image_available"), usingActivityIndicatorStyle: .gray)
            
            if indexPath.row == self.arrCategoryList.count - 1 {
                print("Start Index: \(self.startPage)")
                let page: Int = startPage + 1
                if (page <= totalPages) {
                    startPage = page;
                    self.callCategoryListWithSearch(startPage, searchString: "")
                }
            }
        }
        else {
            cell.showLoader()
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if !arrCategoryList.isEmpty{
            isBackButtonBanner = false
            let productListVC = ProductListViewController(nibName: "ProductListViewController", bundle: nil)
            self.navigationController!.setNavigationBarHidden(false, animated: false)
            productListVC.dictProductData = arrCategoryList[indexPath.row]
            self.tabBarController?.tabBar.isHidden = true
            productListVC.isBackButton = true
            self.navigationController?.pushViewController(productListVC, animated: true)
        }
    }
}
