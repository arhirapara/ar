//
//  LoginViewController.swift
//  Ganadoor
//
//  Created by AR on 02/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var imageViewCheck: UIImageView!
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnForgetPassword: UIButton!
    
    @IBOutlet weak var btnSignUp: UIButton!
    
    var isSelectRemberMe: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
        self.view.LableWithTag(1).style(style: TextStyle.themeLabelSize20)
        self.view.LableWithTag(2).style(style: TextStyle.placeHolder15)
        self.view.LableWithTag(3).style(style: TextStyle.semiBold15)
        self.view.LableWithTag(4).style(style: TextStyle.placeHolder15)
        self.view.LableWithTag(5).style(style: TextStyle.placeHolder15)
        self.view.LableWithTag(6).style(style: TextStyle.placeHolder15)
        txtUsername.style(style: TextStyle.placeHolderMedium13)
        txtPassword.style(style: TextStyle.placeHolderMedium13)
        
        txtPassword.paddingLeftCustom = 8
        txtUsername.paddingLeftCustom = 8
        
        btnLogin.style(style: TextStyle.createNewAccount)
        btnForgetPassword.style(style: TextStyle.semiBold15)
        btnSignUp.style(style: TextStyle.themeSemiBoldLabelSize18)
        
        if SharedModel.getUserLoginInfo().isEmpty {
            imageViewCheck.image = UIImage(named: "icn_checkbox")
            isSelectRemberMe = false
        }
        else {
            let dictUserName = SharedModel.getUserLoginInfo()[0]
            let dictPassword = SharedModel.getUserLoginInfo()[1]
            txtUsername.text = dictUserName.valuForKeyString(KEY_USER_NAME)
            txtPassword.text = dictPassword.valuForKeyString(KEY_PASSWORD)
            imageViewCheck.image = UIImage(named: "icn_checkbox_s")
            isSelectRemberMe = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    func getUserLoginInfo() -> [typeAliasStringDictionary]? {
        let dict = [
            KEY_USER_NAME : txtUsername.text?.trim(),
            PARAMETER_KEY : "1001"
        ]
        let dict1 = [
            KEY_PASSWORD : txtPassword.text?.trim(),
            PARAMETER_KEY : "1002"
        ]
        let arrTitle = [dict, dict1]
        return (arrTitle as! [typeAliasStringDictionary])
    }
    
    @IBAction func viewCheckRemeberAction() {
        if isSelectRemberMe{
            //Selected
            isSelectRemberMe = false
            imageViewCheck.image = UIImage(named: "icn_checkbox")
        }
        else {
            //UNSelected
            isSelectRemberMe = true
            imageViewCheck.image = UIImage(named: "icn_checkbox_s")
        }
    }
    
    @IBAction func btnForgetPasswordAction(_ sender: UIButton) {
        let forgetVC = ForgetPasswordViewController(nibName: "ForgetPasswordViewController", bundle: nil)
        forgetVC.isBackButton = true
        navigationController?.pushViewController(forgetVC, animated: true)
    }
    
    @IBAction func btnLoginAction(_ sender: UIButton) {
        let userNameString = txtUsername.getText().trim()
        let passwordString = txtPassword.getText().trim()
        
        if userNameString.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "LOGIN:Enter your email.".localized, type: .WARNING)
            return
        }
        else if !userNameString.validateEmail() {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "LOGIN:Enter valid email.".localized, type: .WARNING)
            return
        }
        
        if passwordString.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "LOGIN:Enter your password.".localized, type: .WARNING)
            return
        }
        var param = typeAliasDictionary()
        param[REQ_Email] = userNameString as AnyObject  //"test_user@gmail.com" as AnyObject
        param[REQ_Password] = passwordString as AnyObject   //"test_user" as AnyObject
        
        callRestApi(API_User_Login, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { (response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                if !self.isSelectRemberMe{
                    self.isSelectRemberMe = false
                    SharedModel.setUserLoginInfo([typeAliasStringDictionary]())
                }
                else {
                    self.isSelectRemberMe = true
                    SharedModel.setUserLoginInfo(self.getUserLoginInfo()!)
                }
                SharedModel.setUserInfo(response.valuForKeyDic("User_Detail"))
                //            let homeVC = HomeViewController(nibName: "HomeViewController", bundle: nil)
                //            self.navigationController?.pushViewController(homeVC, animated: true)
                self.appDelegate().showHome()
            }
            else if response.valuForKeyString("status") == "0" {
                
            }
        }, onFailure: { (error) in
            print(error)
        })
    }
    
    @IBAction func btnSignUpAction(_ sender: UIButton) {
        let signUPVC = SignUpViewController(nibName: "SignUpViewController", bundle: nil)
        signUPVC.isBackButton = true
        navigationController?.pushViewController(signUPVC, animated: true)
    }
    
    //MARK:- UITextField Delegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == txtUsername {
            txtPassword.becomeFirstResponder()
        }
        else if textField == txtPassword {
            txtPassword.resignFirstResponder()
        }
        return true
    }
}
