//
//  ForgetPasswordViewController.swift
//  vincitore
//
//  Created by AR on 04/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class ForgetPasswordViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
        self.view.LableWithTag(10).style(style: TextStyle.themeLabelSize20)
        self.view.LableWithTag(20).style(style: TextStyle.semiBold15)
        self.view.LableWithTag(30).style(style: TextStyle.semiBold15)
        self.view.LableWithTag(40).style(style: TextStyle.semiBold15)
        self.view.LableWithTag(50).style(style: TextStyle.semiBold15)
        self.view.ButtonWithTag(100).style(style: TextStyle.createNewAccount)
        self.view.ButtonWithTag(200).style(style: TextStyle.selectedLabelFontSize15)
        self.view.TextFiledWithTag(300).style(style: TextStyle.placeHolder)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }

    @IBAction func btnLoginActin(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
}
