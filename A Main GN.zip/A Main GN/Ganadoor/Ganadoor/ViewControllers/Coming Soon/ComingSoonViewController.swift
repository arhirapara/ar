//
//  ComingSoonViewController.swift
//  vincitore
//
//  Created by AR on 05/06/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class ComingSoonViewController: UIViewController {

    var isNavigationBackButtionShow = false
    var navigationTitle = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
        setTitle(navigationTitle)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if isNavigationBackButtionShow{
            navigationController?.setNavigationBarHidden(true, animated: false)
        }
    }
}
