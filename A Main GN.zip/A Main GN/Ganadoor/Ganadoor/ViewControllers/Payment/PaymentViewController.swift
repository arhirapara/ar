//
//  PaymentViewController.swift
//  vincitore
//
//  Created by AR on 28/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let CELL_IDENTIFIER_PAYMENT_CELL         = "PaymentCell"
let HEIGHT_PAYMENT_CELL: CGFloat          = 44

import UIKit

class PaymentViewController: UIViewController {
    
    @IBOutlet weak var tableViewPayment: UITableView!
    
    @IBOutlet weak var lblSubTotal: UILabel!
    @IBOutlet weak var lblDeliveryCharge: UILabel!
    @IBOutlet weak var lblServiceTax: UILabel!
    @IBOutlet weak var lblTotalAmount: UILabel!
    @IBOutlet weak var btnPlaceOrder: UIButton!
    var arrPaymentAmount = typeAliasDictionary()
    var arrPaymentOption = [typeAliasStringDictionary]()
    var dictSelectedPaymentOption = typeAliasStringDictionary()
    var arrCart = [typeAliasDictionary]()
    var isBasketJump: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        setTitle("PAYMENT:Payment")
        sideBarBackButton { (str) in }
        btnPlaceOrder.style(style: TextStyle.boldWhite)
        arrPaymentOption = self.getPaymentTitle()!
        dictSelectedPaymentOption = arrPaymentOption.first!
        
        tableViewPayment.register(UINib.init(nibName: CELL_IDENTIFIER_PAYMENT_CELL, bundle: nil), forCellReuseIdentifier: CELL_IDENTIFIER_PAYMENT_CELL)
        tableViewPayment.rowHeight = HEIGHT_PAYMENT_CELL
        tableViewPayment.tableFooterView = UIView(frame: CGRect.zero)
        
        tableViewPayment.reloadData()
        self.setPaymentData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if appDelegateObject().contentViewController.selectedIndex == 3{
            self.tabBarController?.tabBar.isHidden = false
        }
        if isBasketJump{
            navigationController?.setNavigationBarHidden(true, animated: false)
        }
    }
    
    //MARK: Custom Method
    func setPaymentData(){
        let currencyString = SharedModel.getUpdateFlagInfo().valuForKeyString("currency")
        lblSubTotal.text = currencyString + " " +  arrPaymentAmount.valuForKeyString("MRP")
        lblServiceTax.text = currencyString + " " + arrPaymentAmount.valuForKeyString("ServiceTax")
        lblDeliveryCharge.text = currencyString + " " + arrPaymentAmount.valuForKeyString("DeliveryCharge")
        lblTotalAmount.text = currencyString + " " +  arrPaymentAmount.valuForKeyString("subTotal")
    }
    
    func getPaymentTitle() -> [typeAliasStringDictionary]? {
        
        let dict = [
            PARAMETER_VALUE : "PAYMENT:Cash on Delivery".localized,
            PARAMETER_KEY : "1001"
        ]
        
//        let dict1 = [
//            PARAMETER_VALUE : "Card on Delivery",
//            PARAMETER_KEY : "1002"
//        ]
//
//        let dict2 = [
//            PARAMETER_VALUE : "Credit / Debit Card",
//            PARAMETER_KEY : "1003"
//        ]
//        let dict3 = [
//            PARAMETER_VALUE : "Net Banking",
//            PARAMETER_KEY : "1004"
//        ]
//        let dict4 = [
//            PARAMETER_VALUE : "UPI Payment",
//            PARAMETER_KEY : "1005"
//        ]
//        let dict5 = [
//            PARAMETER_VALUE : "Wallets",
//            PARAMETER_KEY : "1006"
//        ]
        let arrTitle = [dict]
        //let arrTitle = [dict, dict1, dict2, dict3, dict4, dict5]
        return arrTitle
    }
    
    
    @IBAction func btnPlaceOrderAction(_ sender: UIButton) {
        var param = typeAliasDictionary()
        var dictcart = typeAliasDictionary()
        dictcart[REQ_ORDER_AMOUNT] = arrPaymentAmount.valuForKeyString("MRP") as AnyObject
        dictcart[REQ_SUB_TOTAL] = arrPaymentAmount.valuForKeyString("subTotal") as AnyObject
        dictcart[REQ_ADDRESS_ID] = arrPaymentAmount.valuForKeyString("Address_Id") as AnyObject
        dictcart[REQ_PAYMENT_MODE] = dictSelectedPaymentOption.valuForKeyString(PARAMETER_KEY) == "1001" ? "2" as AnyObject : "1" as AnyObject
        
        var arrMenu = [typeAliasDictionary]()
        for dict in arrCart {
            var dictMenu = typeAliasDictionary()
            dictMenu[REQ_MENU_ID] = dict.valuForKeyString("Menu_Id") as AnyObject
            dictMenu[REQ_MENU_QTY] = dict.valuForKeyString("Cart_Qty") as AnyObject
            arrMenu.append(dictMenu)
        }
        dictcart[REQ_MENU_DETAIL] = arrMenu.convertToJSonString() as AnyObject
        
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id") as AnyObject
        param[REQ_CART] = dictcart.convertToJSonString() as AnyObject
        param[REQ_DEVICE_TYPE] = "1" as AnyObject /// 1 is for Iphone static
        
        callRestApi(API_Place_Order, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { [weak self](response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                if response.valuForKeyString("PaymentGateway") == "0" {
                    self?.getOrderStatus(orderID:response.valuForKeyString("orderID"))
                }
                else {
                    // PAYMENT URL
                    self?.getOrderStatus(orderID:response.valuForKeyString("orderID"))
                }
                
               
            }
            else if response.valuForKeyString("status") == "0" {
                
            }
        }) { (error) in
            print(error)
        }
    }
    
    func getOrderStatus(orderID:String) {
        var param = typeAliasDictionary()
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id") as AnyObject
        param[REQ_ORDER_ID] = orderID as AnyObject
        
        callRestApi(API_Get_Order_Status, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { [weak self](response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                let orderSummaryVC = OrderSummaryViewController(nibName: "OrderSummaryViewController", bundle: nil)
                orderSummaryVC.orderSummary = .ORDER_SUMMARY_BASKET
                orderSummaryVC.isJumpPayment = true
                orderSummaryVC.dictSummary = response
                orderSummaryVC.isBackButton = true
                print(orderSummaryVC.dictSummary)
                self!.navigationController?.pushViewController(orderSummaryVC, animated: true)
            }
            else if response.valuForKeyString("status") == "0" {
                
            }
        }) { (error) in
            print(error)
        }
    }
}

extension PaymentViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return arrPaymentOption.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : PaymentCell = tableView.dequeueReusableCell(withIdentifier: CELL_IDENTIFIER_PAYMENT_CELL) as! PaymentCell
        
        if !arrPaymentOption.isEmpty {
            let dictData: typeAliasStringDictionary = arrPaymentOption[indexPath.row]
            let selectedId = dictSelectedPaymentOption.valuForKeyString(PARAMETER_KEY)
            let id = dictData.valuForKeyString(PARAMETER_KEY)
            
            cell.lblDeliveryOption.text = dictData.valuForKeyString(PARAMETER_VALUE)
            
            if selectedId == id {
                cell.lblDeliveryOption.style(style: TextStyle.semiBold15)
                cell.lblDeliveryOption.textColor = UIColor(hexString: "2f9f8e")
                cell.btnSelectDeliveryOption.isSelected = true
            }
            else {
                cell.lblDeliveryOption.style(style: TextStyle.placeHolderMedium)
                cell.lblDeliveryOption.textColor = UIColor(hexString: "5a5a5a")
                cell.btnSelectDeliveryOption.isSelected = false
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row <= 1 {
            dictSelectedPaymentOption = arrPaymentOption[indexPath.row]
            tableViewPayment.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return HEIGHT_PAYMENT_CELL
    }
    
    
}
