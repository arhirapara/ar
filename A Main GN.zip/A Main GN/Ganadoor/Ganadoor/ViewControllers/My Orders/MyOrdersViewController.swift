//
//  MyOrdersViewController.swift
//  vincitore
//
//  Created by DNK062 on 27/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class MyOrdersViewController: UIViewController {
    
    @IBOutlet weak var myOrderTableView: UITableView!
    var arrOrderList = [typeAliasDictionary]()
    var arrFinalOrderList = [typeAliasDictionary]()
    var totalPages: Int = 0
    var startPage: Int = 1
    var isNavigationBackButtionShow:Bool = false
    var isNavigationSideMenu:Bool = false
    var updateOrderMenu = typeAliasDictionary()
    var isLoading: Bool = true

    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
        setTitle("MYORDERLIST:My Orders")
        
        myOrderTableView.register(UINib.init(nibName: CELL_IDENTIFIER_MY_ORDER_LIST_CELL, bundle: nil), forCellReuseIdentifier: CELL_IDENTIFIER_MY_ORDER_LIST_CELL)
        
        myOrderTableView.register(UINib.init(nibName: CELL_IDENTIFIER_MY_ORDER_LIST_SKELETON_CELL, bundle: nil), forCellReuseIdentifier: CELL_IDENTIFIER_MY_ORDER_LIST_SKELETON_CELL)
        
        myOrderTableView.tableFooterView = UIView.init(frame: .zero)
        
        myOrderTableView.estimatedRowHeight = 130
        myOrderTableView.rowHeight = UITableView.automaticDimension
        getOrderList(pageNo: startPage)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isNavigationBackButtionShow = isNavigationSideMenu
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if isNavigationBackButtionShow{
            isNavigationBackButtionShow = false
            navigationController?.setNavigationBarHidden(true, animated: animated)
        }
    }
    
    func getOrderList(pageNo: Int) {
        var param = typeAliasDictionary()
        param[REQ_PAGE_NO] = "\(pageNo)" as AnyObject
        param[REQ_USER_ID] = SharedModel.getUserInfo().valuForKeyString("User_Id") as AnyObject
        
        callRestApi(API_My_Order_List, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: false, onCompletion: {[weak self] (response) in
            print(response)
            self!.isLoading = false
            if response.valuForKeyString("status") == "1" {
                self?.arrFinalOrderList += response.valuForKeyDic("MyOrderDetail").valuForKeyArray("MyOrderData") as! [typeAliasDictionary]
                self?.arrOrderList = (self?.setDataSectionWise(self!.arrFinalOrderList))!
                //self!.myOrderTableView.showNoDataView = false
                self!.totalPages = response.valuForKeyDic("MyOrderDetail").valuForKeyInt("totalPages")
                self?.myOrderTableView.reloadData()
                self!.updateOrderStatus(self!.updateOrderMenu)
            }
            else if response.valuForKeyString("status") == "0" {
                self!.myOrderTableView.showNoDataView = true
                self!.myOrderTableView.reloadData()
            }
            }, onFailure: { (error) in
                self.isLoading = false
                self.myOrderTableView.showNoDataView = true
                self.myOrderTableView.reloadData()
                print(error)
        })
    }
    
    func getOrderStatus(_ orderstatus: typeAliasDictionary){
        var stOrderstatus = orderstatus.valuForKeyString("OrderStatus")
        stOrderstatus = stOrderstatus.uppercased()
        if (stOrderstatus == "SUCCESS") || (stOrderstatus == "FAILED") || (stOrderstatus == "REFUNDED") {
            isNavigationBackButtionShow = false
            let orderSummaryVC = OrderSummaryViewController(nibName: "OrderSummaryViewController", bundle: nil)
            orderSummaryVC.orderSummary = .ORDER_SUMMARY_MYORDER
            orderSummaryVC.dictSummary = orderstatus
            orderSummaryVC.isBackButton = true
            self.navigationController?.setNavigationBarHidden(false, animated: true)
            self.navigationController?.pushViewController(orderSummaryVC, animated: true)
        }
        else {
            self.getOrderStatusForId(orderID: orderstatus.valuForKeyString("orderID"))
        }
    }
    
    func getOrderStatusForId(orderID:String) {
        var param = typeAliasDictionary()
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id") as AnyObject
        param[REQ_ORDER_ID] = orderID as AnyObject
        
        callRestApi(API_Get_Order_Status, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { [weak self](response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                self!.updateOrderMenu = response
                self!.updateOrderStatus(self!.updateOrderMenu)
                self!.isNavigationBackButtionShow = false
                let orderSummaryVC = OrderSummaryViewController(nibName: "OrderSummaryViewController", bundle: nil)
                orderSummaryVC.orderSummary = .ORDER_SUMMARY_BASKET
                orderSummaryVC.dictSummary = response
                orderSummaryVC.isBackButton = true
                self!.navigationController?.setNavigationBarHidden(false, animated: true)
                self!.navigationController?.pushViewController(orderSummaryVC, animated: true)
            }
            else if response.valuForKeyString("status") == "0" {
                
            }
        }) { (error) in
            print(error)
        }
    }
    
    func updateOrderStatus(_ dictOrderData: typeAliasDictionary){
        if !dictOrderData.isEmpty{
            if let dictResponse = dictOrderData.valuForKeyDic("OrderData") as? typeAliasDictionary {
                if let orderDict = dictResponse.valuForKeyDic("Order") as? typeAliasDictionary {
                    //print("OrderData: \(orderDict)")
                    let orderId = orderDict.valuForKeyString("OrderId")
                    for i in 0..<arrOrderList.count {
                        var dict = arrOrderList[i]
                        //  print("OrderSelectedData: \(dict)")
                        var arrData = dict.valuForKeyArray("SECTION_LIST") as! [typeAliasDictionary]
                        //print("arrData: \(arrData)")
                        for j in 0..<arrData.count {
                            var dictMenuData = arrData[j]
                            let selectedOrderId = dictMenuData.valuForKeyString("orderID")
                            if selectedOrderId == orderId{
                                dictMenuData["OrderStatus"] = orderDict.valuForKeyString("OrderStatus") as AnyObject
                                dictMenuData["OrderColor"] = orderDict.valuForKeyString("OrderColor") as AnyObject
                                arrData[j] = dictMenuData
                                dict["SECTION_LIST"] = arrData as AnyObject
                                arrOrderList[i] = dict
                                break;
                            }
                        }
                        
                    }
                    self.myOrderTableView.reloadData()
                }
            }
        }
    }
    
    func setDataSectionWise(_ arrMoneyCoinData: [typeAliasDictionary]) -> [typeAliasDictionary] {
        var arrDate = [String]()
        let dateFormat = DateFormatter()
        let locale = NSLocale(localeIdentifier: "en_US_POSIX")
        dateFormat.locale = locale as Locale
        dateFormat.dateFormat = "dd-MM-yyyy"
        
        var arrMoneyCoinsList = [typeAliasDictionary]()
        for dict in arrMoneyCoinData {
            let stDate = dict["OrderDate"]
            let date = dateFormat.date(from: stDate as! String)
            var stDateConverted: String? = ""
            if let date = date {
                stDateConverted = dateFormat.string(from: date)
            }
            if !(arrDate.contains(stDateConverted!)) {
                arrDate.append(stDateConverted!)
            }
        }
        
        for stDateValue in arrDate {
            var dictData = typeAliasDictionary()
            dictData["SECTION_DATE"] = stDateValue as AnyObject
            var arrSectionData = [typeAliasDictionary]()
            for i in 0..<arrMoneyCoinData.count {
                let dict = arrMoneyCoinData[i]
                let stDictValue = dict["OrderDate"]
                let date = dateFormat.date(from: stDictValue as! String)
                var stDateConverted: String? = nil
                if let date = date {
                    stDateConverted = dateFormat.string(from: date)
                }
                if (stDateConverted == stDateValue) {
                    if let dict: typeAliasDictionary = dict {
                        arrSectionData.append(dict)
                    }
                }
            }
            dictData["SECTION_LIST"] = arrSectionData as AnyObject
            arrMoneyCoinsList.append(dictData)
        }
        
        return arrMoneyCoinsList
    }
}

extension MyOrdersViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        if !arrOrderList.isEmpty {
            return arrOrderList.count
        }
        else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if !arrOrderList.isEmpty {
            let dict = arrOrderList[section]
            let arrData = dict.valuForKeyArray("SECTION_LIST")
            return arrData.count
        }
        else {
            if isLoading{
                return 15
            }
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell1 : MyOrderListSkeletonCell = tableView.dequeueReusableCell(withIdentifier: CELL_IDENTIFIER_MY_ORDER_LIST_SKELETON_CELL) as! MyOrderListSkeletonCell
        
        if !arrOrderList.isEmpty {
            let cell : MyOrderListTableViewCell = tableView.dequeueReusableCell(withIdentifier: CELL_IDENTIFIER_MY_ORDER_LIST_CELL) as! MyOrderListTableViewCell
            cell1.hideLoder()
            let dict = arrOrderList[indexPath.section]
            let arrData = dict.valuForKeyArray("SECTION_LIST")
            
            cell.setupCellData(dict: arrData[indexPath.row] as! typeAliasDictionary)
            
            if indexPath.row == arrData.count - 1 {
                print("Start Index: \(self.startPage)")
                let page: Int = startPage + 1
                if (page <= totalPages) {
                    startPage = page
                    getOrderList(pageNo: startPage)
                }
            }
            return cell
        }
        else {
            cell1.showLoader()
            return cell1
        }
        //return UITableViewCell.init()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if !arrOrderList.isEmpty {
            return UITableView.automaticDimension
        }
        else {
            if isLoading{
                return 122
            }
        }
        return 0
    }
    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        if !arrOrderList.isEmpty {
//            let view:OrderListHeaderView = UIView.fromNib()
//            let dict  = arrOrderList[section]
//            let date = dict.valuForKeyString("SECTION_DATE")
//            //view.
//            return "  " + date
//        }
//        return nil
//    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if !arrOrderList.isEmpty {
            return 40
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view:OrderListHeaderView = UIView.fromNib()
        let dict  = arrOrderList[section]
        view.lblOrderDate.text = dict.valuForKeyString("SECTION_DATE")
        return view
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if !arrOrderList.isEmpty {
            let dict = arrOrderList[indexPath.section]
            let arrData = dict.valuForKeyArray("SECTION_LIST")
            let dictOrder = arrData[indexPath.row]
            self.getOrderStatus(dictOrder as! typeAliasDictionary)
        }
    }
}
