//
//  MyOrderListSkeletonCell.swift
//  vincitore
//
//  Created by DNK062 on 27/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let CELL_IDENTIFIER_MY_ORDER_LIST_SKELETON_CELL         = "MyOrderListSkeletonCell"

import UIKit

class MyOrderListSkeletonCell: UITableViewCell {
    
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblDateNTime: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblOrderNo: UILabel!
    @IBOutlet weak var viewLblStatus: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        lblDescription.style(style: TextStyle.placeHolder)
        lblDateNTime.style(style: TextStyle.productDescription)
        lblPrice.style(style: TextStyle.productPriceLabel)
        lblOrderNo.style(style: TextStyle.HeaderLabel)
    }
    
    func showLoader(){
        lblDescription.linesCornerRadius = 8
        lblDateNTime.linesCornerRadius = 8
        
        lblPrice.linesCornerRadius = 8
        lblOrderNo.linesCornerRadius = 8
        
        viewLblStatus.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblDescription.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblDateNTime.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblPrice.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblOrderNo.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
    }
    
    func hideLoder(){
        viewLblStatus.hideSkeleton()
        lblDescription.hideSkeleton()
        lblDateNTime.hideSkeleton()
        lblPrice.hideSkeleton()
        lblOrderNo.hideSkeleton()
    }
    
}
