//
//  SignUpViewController.swift
//  vincitore
//
//  Created by AR on 04/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var lblTearm: UILabel!
    @IBOutlet weak var btnCheck: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
        self.setTextFieldStyle()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    //MARK:- Custom Method
    func setTextFieldStyle() {
        self.view.LableWithTag(1).style(style: TextStyle.themeLabelSize20)
        self.view.LableWithTag(2).style(style: TextStyle.semiBold15)
        self.view.LableWithTag(3).style(style: TextStyle.semiBold15)
        self.view.LableWithTag(4).style(style: TextStyle.placeHolder15)
        self.view.LableWithTag(5).style(style: TextStyle.placeHolder15)
        self.view.LableWithTag(6).style(style: TextStyle.placeHolder15)
        self.view.LableWithTag(7).style(style: TextStyle.placeHolder15)
        self.view.LableWithTag(8).style(style: TextStyle.placeHolder15)
        self.view.LableWithTag(9).style(style: TextStyle.placeHolder15)
        self.view.LableWithTag(10).style(style: TextStyle.placeHolder15)
        self.view.LableWithTag(11).style(style: TextStyle.placeHolder15)
        
        self.view.TextFiledWithTag(100).style(style: TextStyle.placeHolderMedium13)
        self.view.TextFiledWithTag(200).style(style: TextStyle.placeHolderMedium13)
        self.view.TextFiledWithTag(300).style(style: TextStyle.placeHolderMedium13)
        self.view.TextFiledWithTag(400).style(style: TextStyle.placeHolderMedium13)
        self.view.TextFiledWithTag(500).style(style: TextStyle.placeHolderMedium13)
        self.view.TextFiledWithTag(600).style(style: TextStyle.placeHolderMedium13)
        
        self.view.TextFiledWithTag(100).paddingLeftCustom = 8
        self.view.TextFiledWithTag(200).paddingLeftCustom = 8
        self.view.TextFiledWithTag(300).paddingLeftCustom = 8
        self.view.TextFiledWithTag(400).paddingLeftCustom = 8
        self.view.TextFiledWithTag(500).paddingLeftCustom = 8
        self.view.TextFiledWithTag(600).paddingLeftCustom = 8
        
        
        self.view.ButtonWithTag(1000).style(style: TextStyle.createNewAccount)
        self.view.ButtonWithTag(2000).style(style: TextStyle.themeSemiBoldLabelSize18)
        
        let textColor: UIColor = UIColor(hexString: "DC6666")
        let underLineColor: UIColor = UIColor(hexString: "DC6666")
        let underLineStyle = NSUnderlineStyle.single.rawValue
        
        let mainString = "SIGNUP:By clicking Sign up you agree to the our Terms and Conditions".localized
        let changeString = "SIGNUP:Terms and Conditions".localized
        
        let range = (mainString as NSString).range(of: changeString)
        let attributedString = NSMutableAttributedString(string: mainString)
        attributedString.addAttributes([NSAttributedString.Key.foregroundColor:textColor, NSAttributedString.Key.underlineStyle: underLineStyle, NSAttributedString.Key.underlineColor: underLineColor], range: range)
        
        lblTearm.attributedText = attributedString
    }
    
    func callUserRegistration() {
        let fullNameString = self.view.TextFiledWithTag(100).text?.trim()
        //let userNameString = self.view.TextFiledWithTag(200).text?.trim()
        let emailString = self.view.TextFiledWithTag(300).text?.trim()
        let phoneString = self.view.TextFiledWithTag(400).text?.trim()
        let passwordString = self.view.TextFiledWithTag(500).text?.trim()
        let confirmpasswordString = self.view.TextFiledWithTag(600).text?.trim()
        
        if fullNameString!.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "SIGNUP:Enter full name.".localized, type: .WARNING)
            return
        }
        
//        if userNameString!.isEmpty {
//            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "Enter user name", type: .WARNING)
//            return
//        }
        
        if emailString!.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "SIGNUP:Enter your email.".localized, type: .WARNING)
            return
        }
        else if !emailString!.validateEmail() {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "SIGNUP:Enter valid email.".localized, type: .WARNING)
            return
        }
        
        if phoneString!.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "SIGNUP:Enter your phone no.".localized, type: .WARNING)
            return
        }
            //else if !phoneString!.validateMobileNo() {
        else if phoneString!.count < 12 || phoneString!.count > 12 {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "SIGNUP:Enter your valid phone no.".localized, type: .WARNING)
            return
        }
        
        if passwordString!.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "SIGNUP:Enter your password.".localized, type: .WARNING)
            return
        }
        
        if confirmpasswordString!.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "SIGNUP:Enter your confirm password.".localized, type: .WARNING)
            return
        }
        else if confirmpasswordString != passwordString {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "SIGNUP:Password and confirm password must be same.".localized, type: .WARNING)
            return
        }
        if !btnCheck.isSelected {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "SIGNUP:You must agree to terms and conditions.".localized, type: .WARNING)
            return
        }
        let currentDevice = UIDevice.current
        let deviceId = currentDevice.identifierForVendor?.uuidString
        
        var param = typeAliasDictionary()
      
        param[REQ_Device_token] = "00000"  as AnyObject
        param[REQ_USER_email] = emailString  as AnyObject
        param[REQ_USER_password] = passwordString  as AnyObject
        param[REQ_FULL_name] = fullNameString  as AnyObject
        param[REQ_MOBILE_number] = phoneString  as AnyObject
        param[REQ_DEVICE_MODEL] = UIDevice.current.name as AnyObject
        param[REQ_Device_type] = KEY_IOS_DEVICE  as AnyObject
        param[REQ_Device_id] = deviceId  as AnyObject
        param[REQ_APP_VERSION] = SharedModel.getAppVersion()  as AnyObject
        
        callRestApi(API_User_Registration, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { (response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                showAlertWithTitle(title: MSG_PROJECT_TITLE, message: response.valuForKeyString("message"), type: .WARNING)
                let loginVC = LoginViewController(nibName: "LoginViewController", bundle: nil)
                self.navigationController?.pushViewController(loginVC, animated: true)
            }
            else if response.valuForKeyString("status") == "0" {
                
            }
        }, onFailure: { (error) in
            print(error)
        })
        
        
    }
    
    
    //MARK:- Button Action
    @IBAction func btnLoginAction(_ sender: UIButton) {
        let loginVC = LoginViewController(nibName: "LoginViewController", bundle: nil)
        navigationController?.pushViewController(loginVC, animated: true)
    }
    
    @IBAction func btnCreateAccountAction() {
        self.callUserRegistration()
    }
    
    @IBAction func btnCheckAction() {
        btnCheck.isSelected = !btnCheck.isSelected
    }
    
    @IBAction func btnTearmNdConditionAction() {
        let termsLink = SharedModel.getUpdateFlagInfo().valuForKeyString("terms_condition")
        let webVC = SwiftModalWebVC(urlString: termsLink, sharingEnabled: false)
        self.present(webVC, animated: true, completion: nil)
    }
    
    //MARK:- UITextField Delegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == self.view.TextFiledWithTag(100) {
            self.view.TextFiledWithTag(300).becomeFirstResponder()
        }
       // else if textField == self.view.TextFiledWithTag(200) {
         //   self.view.TextFiledWithTag(300).becomeFirstResponder()
        //}
        else if textField == self.view.TextFiledWithTag(300) {
            self.view.TextFiledWithTag(400).becomeFirstResponder()
        }
        else if textField == self.view.TextFiledWithTag(400) {
            self.view.TextFiledWithTag(500).becomeFirstResponder()
        }
        else if textField == self.view.TextFiledWithTag(500) {
            self.view.TextFiledWithTag(600).becomeFirstResponder()
        }
        else if textField == self.view.TextFiledWithTag(600) {
            self.view.TextFiledWithTag(600).resignFirstResponder()
        }
        return true
    }
}
