//
//  SearchViewController.swift
//  vincitore
//
//  Created by AR on 07/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController {

    @IBOutlet weak var searchTableView: UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    var searchedArray:[String] = ["Butter Milk","Lassi", "Holi", "Suns cream", "Water Bottle", "Apple Cider Vineger"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
       // sideBarLeftButton(imageName: "icn_notification") { (str) in }
        txtSearch.setLeftImageView(25, image: UIImage(named: "icn_search")!)
        setTitle("Search")
        searchTableView.register(UINib(nibName: SearchCell.reuseIdentifier, bundle: nil), forCellReuseIdentifier: SearchCell.reuseIdentifier)
        searchTableView.delegate = self
        searchTableView.dataSource = self
        searchTableView.tableFooterView = UIView.init(frame: .zero)
    }

}

extension SearchViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchedArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: SearchCell.reuseIdentifier, for: indexPath) as! SearchCell
        cell.lblSearchTitle.text = searchedArray[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 55
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 55))
        label.text = "   POPULAR SEARCH"
        label.backgroundColor = UIColor.init(hexString:"f5f5f5")
        label.style(style: TextStyle.HederBold)
        return label
    }
}
