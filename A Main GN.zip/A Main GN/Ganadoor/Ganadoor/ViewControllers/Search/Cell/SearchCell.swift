//
//  SearchCell.swift
//  vincitore
//
//  Created by AR on 07/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class SearchCell: UITableViewCell {

    @IBOutlet weak var lblSearchTitle: UILabel!
    @IBOutlet weak var btnClose: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
    }

}
