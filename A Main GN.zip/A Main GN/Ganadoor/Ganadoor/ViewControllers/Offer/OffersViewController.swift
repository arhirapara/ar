//
//  OffersViewController.swift
//  vincitore
//
//  Created by AR on 07/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class OffersViewController: UIViewController {

    @IBOutlet weak var scrollableStackView: ScrollableStackView!
    let offer1:OffersView = UIView.fromNib()
    let offer2:OffersView = UIView.fromNib()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
        //sideBarLeftButton(imageName: "icn_notification") { (str) in }
        setTitle("Offers")
        
        let ad1 = UIImageView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 225))
        ad1.image = UIImage(named: "ads")
        ad1.contentMode = .scaleToFill
        ad1.clipsToBounds = true
        ad1.heightAnchor.constraint(equalToConstant: 225).isActive = true
        scrollableStackView.stackView.addArrangedSubview(ad1)
        
        offer1.heightAnchor.constraint(equalToConstant: (screenWidth - 44)/3).isActive = true
        scrollableStackView.stackView.addArrangedSubview(offer1)
        
        let ad2 = UIImageView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 125))
        ad2.image = UIImage(named: "ads")
        ad2.contentMode = .scaleToFill
        ad2.clipsToBounds = true
        ad2.heightAnchor.constraint(equalToConstant: 125).isActive = true
        scrollableStackView.stackView.addArrangedSubview(ad2)
        
        offer2.heightAnchor.constraint(equalToConstant: (screenWidth - 44)/3).isActive = true
        scrollableStackView.stackView.addArrangedSubview(offer2)
        
        scrollableStackView.stackView.translatesAutoresizingMaskIntoConstraints = false
    }


}
