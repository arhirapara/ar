//
//  OffersCell.swift
//  vincitore
//
//  Created by AR on 08/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class OffersCell: UICollectionViewCell {

    @IBOutlet weak var offersAdImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
