//
//  BasketCell.swift
//  vincitore
//
//  Created by AR on 08/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class BasketCell: UITableViewCell {
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblProductDescription: UILabel!
    @IBOutlet weak var lblFinalPrice: UILabel!
    @IBOutlet weak var lblDisPrice: UILabel!
    @IBOutlet weak var lblOfferPer: UILabel!
    @IBOutlet weak var viewStepper: GMStepper!
    @IBOutlet weak var productImageView: UIImageView!
    
    let stcurrency = SharedModel.getUpdateFlagInfo().valuForKeyString("currency")
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        lblProductName.style(style: TextStyle.productName15)
        lblProductDescription.style(style: TextStyle.placeHolderMedium13)
        lblFinalPrice.style(style: TextStyle.HeaderLabel16)//final
        lblDisPrice.style(style: TextStyle.categoryDescription11)//dic
        lblOfferPer.style(style: TextStyle.offerLabel)
    }
    
    func setupCellData(dict:typeAliasDictionary) {
        lblProductName.text = dict.valuForKeyString("Menu_Title")
        lblProductDescription.text = dict.valuForKeyString("Menu_Description")
        lblFinalPrice.text = stcurrency + " " + dict.valuForKeyString("Cart_Price")
        lblOfferPer.text = dict.valuForKeyString("")
        viewStepper.maximumValue = dict.valuForKeyDouble("Max_Order_Qty")
        let productPriceString = dict.valuForKeyString("Menu_Price")
        if !productPriceString.isEmpty {
            let attributedString = NSMutableAttributedString(string: stcurrency + " " + productPriceString)
            attributedString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: NSNumber(value: NSUnderlineStyle.single.rawValue), range: NSMakeRange(0, attributedString.length))
            attributedString.addAttribute(NSAttributedString.Key.strikethroughColor, value: UIColor.red, range: NSMakeRange(0, attributedString.length))
            lblDisPrice.attributedText = attributedString
        }
        else {  lblDisPrice.text = "" }
        let productDiscount = dict.valuForKeyString("Discount_Label")
        if productDiscount.isEmpty{
            lblOfferPer.alpha = 0
            self.viewWithTag(10012)?.alpha = 0//10012
        }
        else {
            lblOfferPer.text = productDiscount
            self.viewWithTag(10012)?.alpha = 1
            lblOfferPer.alpha = 1
        }
        viewStepper.value = dict.valuForKeyDouble("Cart_Qty")
        productImageView.setImageWith(URL(string: dict.valuForKeyString("Menu_Image")), placeholderImage: UIImage(named: "no_image_available"), usingActivityIndicatorStyle: .gray)
    }
    
    func showLoader() {
        self.viewWithTag(10012)?.alpha = 0
        lblProductName.linesCornerRadius = 8
        lblProductDescription.linesCornerRadius = 8
        lblFinalPrice.linesCornerRadius = 8
        lblDisPrice.linesCornerRadius = 8
        lblOfferPer.linesCornerRadius = 8
        
        lblProductName.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblProductDescription.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblFinalPrice.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblDisPrice.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblOfferPer.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        viewStepper.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        productImageView.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
    }
    
    func hideLoder(){
        self.viewWithTag(10012)?.alpha = 1
        lblProductName.hideSkeleton()
        lblProductDescription.hideSkeleton()
        lblFinalPrice.hideSkeleton()
        lblDisPrice.hideSkeleton()
        lblOfferPer.hideSkeleton()
        viewStepper.hideSkeleton()
        productImageView.hideSkeleton()
    }
}
