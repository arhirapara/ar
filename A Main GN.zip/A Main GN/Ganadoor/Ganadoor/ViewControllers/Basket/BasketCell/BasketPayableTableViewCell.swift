//
//  BasketPayableTableViewCell.swift
//  vincitore
//
//  Created by DNK062 on 29/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class BasketPayableTableViewCell: UITableViewCell {

    @IBOutlet weak var lblKey: UILabel!
    @IBOutlet weak var lblValue: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
    }
    
//    func showLoader(){
//        lblKey.linesCornerRadius = 8
//        lblValue.linesCornerRadius = 8
//        
//        lblKey.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
//        lblValue.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
//    }
    
//    func hideLoder(){
//        lblKey.hideSkeleton()
//        lblValue.hideSkeleton()
//    }
    
}
