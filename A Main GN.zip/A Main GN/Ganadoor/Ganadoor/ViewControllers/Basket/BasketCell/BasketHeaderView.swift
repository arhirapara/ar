//
//  BasketHeaderView.swift
//  vincitore
//
//  Created by DNK062 on 29/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class BasketHeaderView: UIView {

    @IBOutlet weak var viewAddressFound: UIView!
    @IBOutlet weak var viewAddressNotFound: UIView!
    @IBOutlet weak var btnChange: UIButton!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var btnAddAddress: UIButton!
    
//    func showLoader(){
//        viewAddressNotFound.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
//        viewAddressFound.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
//
//        btnChange.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
//        lblAddress.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
//        btnAddAddress.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
//    }
//
//    func hideLoder(){
//        viewAddressFound.hideSkeleton()
//        viewAddressNotFound.hideSkeleton()
//        btnChange.hideSkeleton()
//        lblAddress.hideSkeleton()
//        btnAddAddress.hideSkeleton()
//    }
}
