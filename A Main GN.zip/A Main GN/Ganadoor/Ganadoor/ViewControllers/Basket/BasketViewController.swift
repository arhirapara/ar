//
//  BasketViewController.swift
//  vincitore
//
//  Created by AR on 07/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class BasketViewController: UIViewController {
    
    @IBOutlet weak var viewFooter: UIView!
    @IBOutlet weak var activityIndicatorHome: UIActivityIndicatorView!
    @IBOutlet weak var constraintBasketViewBottom: NSLayoutConstraint!
    @IBOutlet weak var lblTagLine: UILabel!
    @IBOutlet weak var topOfTableView: NSLayoutConstraint!
    @IBOutlet weak var basketTableView: UITableView!
    @IBOutlet weak var lblTotalItems: UILabel!
    @IBOutlet weak var lblTotalPrice: UILabel!
    var arrViewCart = [typeAliasDictionary]()
    var arrTotal = [typeAliasDictionary]()
    var address = typeAliasDictionary()
    var subTotal: String = ""
    var isCartEmpty:Bool = false
    var isSelectAddress:Bool = true
    var isNavigationBackButtionShow:Bool = false
    var isNavigationSideMenu:Bool = false
    var isShowLoder:Bool = true
    var onMenuChange:((typeAliasStringDictionary) -> Void)?
    let stcurrency = SharedModel.getUpdateFlagInfo().valuForKeyString("currency")
    var isLoading: Bool = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
        setTitle("BASKET:Cart")
        lblTagLine.style(style: TextStyle.HederBold)
        lblTotalItems.style(style: TextStyle.productLabel)
        lblTotalPrice.style(style: TextStyle.themeSemiBoldLabelSize18)
        self.view.LableWithTag(200).style(style: TextStyle.mediumWhite15)
        constraintBasketViewBottom.constant = 100//-150
        self.view.viewWithTag(232)?.alpha = 0
        basketTableView.register(UINib(nibName: BasketCell.reuseIdentifier, bundle: nil), forCellReuseIdentifier: BasketCell.reuseIdentifier)
        basketTableView.register(UINib(nibName: BasketPayableTableViewCell.reuseIdentifier, bundle: nil), forCellReuseIdentifier: BasketPayableTableViewCell.reuseIdentifier)
        basketTableView.delegate = self
        basketTableView.dataSource = self
        basketTableView.tableFooterView = UIView(frame:.zero)
        view.viewWithTag(8062020)?.alpha = 1
        activityIndicatorHome.isHidden = true
        activityIndicatorHome.stopAnimating()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if isSelectAddress{
            basketTableView.reloadData()
            callViewCart()
        }
        else {
            isSelectAddress = true
        }
        isNavigationBackButtionShow = isNavigationSideMenu
        appDelegateObject()._table_view_navigation = .TABLE_VIEW_NAVIGATION_HOME
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if appDelegateObject().contentViewController.selectedIndex == 3{
            viewFooter.alpha = 0
        }
        else {
            viewFooter.alpha = 1
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if isNavigationBackButtionShow{
            isNavigationBackButtionShow = false
            navigationController?.setNavigationBarHidden(true, animated: animated)
        }
    }
    
    @IBAction func btnPaymentAction(_ sender: UIControl) {
        if address.isEmpty {
            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "BASKET:Please add delivery address.".localized, type: .WARNING)
            return
        }
        isShowLoder = false
        isNavigationBackButtionShow = false
        let paymentVC = PaymentViewController(nibName: "PaymentViewController", bundle: nil)
        paymentVC.isBackButton = true
        self.tabBarController?.tabBar.isHidden = true
        paymentVC.arrCart = arrViewCart
        paymentVC.arrPaymentAmount["MRP"] = arrTotal[0].valuForKeyString("value") as AnyObject
        paymentVC.arrPaymentAmount["ServiceTax"] = arrTotal[1].valuForKeyString("value") as AnyObject
        paymentVC.arrPaymentAmount["DeliveryCharge"] = arrTotal[2].valuForKeyString("value") as AnyObject
        paymentVC.arrPaymentAmount["subTotal"] = subTotal as AnyObject
        paymentVC.arrPaymentAmount["Address_Id"] = address.valuForKeyString("Address_Id") as AnyObject
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        self.navigationController?.pushViewController(paymentVC, animated: true)
    }
    
    func setDeleteButton()  {
        if !self.arrViewCart.isEmpty{
            sideBarLeftButton(imageName: "ic_delete") { [weak self] (str) in
                if !self!.arrViewCart.isEmpty{
                    DNKAlertActionView().showYesNoAlertView(MSG_TITLE, message: "BASKET:Are you sure want to clear cart?".localized) { [weak self](str) in
                        if str == "Yes".localized {
                            self?.callClearCart()
                        }
                    }
                }
                else {
                    showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "BASKET:Cart is empty.".localized, type: .WARNING)
                }
            }
        }
        else {
            //showAlertWithTitle(title: MSG_PROJECT_TITLE, message: "Cart is empty", type: .WARNING)
        }
    }
    
    func callViewCart() {
        arrViewCart.removeAll()
        self.view.isUserInteractionEnabled = false
        var param = typeAliasDictionary()
        
        param[REQ_USER_ID] = SharedModel.getUserInfoForKey("User_Id") as AnyObject
        isShowLoder = false
        callRestApi(API_View_Cart, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: isShowLoder, onCompletion: {[weak self] (response) in
            self!.isLoading = false
            if response.valuForKeyString("status") == "1" {
                let dict = response.valuForKeyDic("Cart_Detail")
                self?.arrViewCart = dict.valuForKeyArray("Cart_Menu_Detail") as! [typeAliasDictionary]
                self?.arrTotal = dict.valuForKeyArray("Total_Payable") as! [typeAliasDictionary]
                self?.subTotal = dict.valuForKeyString("Sub_Total")
                self?.address = dict.valuForKeyDic("Address_Detail")
                self?.lblTotalItems.text = self!.arrViewCart.count.description + " ITEMS".localized
                self?.lblTotalPrice.text = self!.stcurrency + " " + dict.valuForKeyString("Sub_Total")
                if (self!.arrViewCart.count) > 0 {
                    self!.constraintBasketViewBottom.constant = 0
                    self!.view.viewWithTag(232)?.alpha = 1
                }
                else {
                    self?.constraintBasketViewBottom.constant = 100//-150
                    self!.view.viewWithTag(232)?.alpha = 0
                }
                UIView.animate(withDuration: 0.3) {
                    self?.view.layoutIfNeeded()
                    self!.isShowLoder = true
                    self!.view.viewWithTag(8062020)?.alpha = 1
                    self?.activityIndicatorHome.isHidden = true
                    self?.activityIndicatorHome.stopAnimating()
                }
                
            }
            else if response.valuForKeyString("status") == "0" {
                self!.setDeleteButton()
                self?.isCartEmpty = true
                self?.arrTotal.removeAll()
                self?.lblTotalItems.text = "0 ITEMS"
                self?.lblTotalPrice.text = self!.stcurrency + " 0.00"
                self?.basketTableView.showNoDataView = true
                
                self?.constraintBasketViewBottom.constant = 100//-150
                self!.view.viewWithTag(232)?.alpha = 0
                UIView.animate(withDuration: 0.3) {
                    self?.view.layoutIfNeeded()
                    self?.view.isUserInteractionEnabled = true
                    self!.view.viewWithTag(8062020)?.alpha = 1
                    self?.activityIndicatorHome.isHidden = true
                    self?.activityIndicatorHome.stopAnimating()
                }
                
                self?.basketTableView.reloadData()
            }
            if self!.arrTotal.count == 0 {
                self?.isCartEmpty = true
            } else {
                self?.isCartEmpty = false
            }
            
            if self!.arrTotal.isEmpty{
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: NOTIFICATION_CLEAR_CART), object: nil)
            }
            self?.basketTableView.reloadData()
            self!.setDeleteButton()
            self?.view.isUserInteractionEnabled = true
            }, onFailure: {[weak self] (error) in
                print(error)
                self!.isLoading = false
                self!.setDeleteButton()
                self?.isCartEmpty = true
                self?.arrTotal.removeAll()
                self?.lblTotalItems.text = "0 ITEMS"
                self?.lblTotalPrice.text = self!.stcurrency + " 0.00"
                self?.basketTableView.showNoDataView = true
                
                self?.constraintBasketViewBottom.constant = 100//-150
                self!.view.viewWithTag(232)?.alpha = 0
                UIView.animate(withDuration: 0.3) {
                    self?.view.layoutIfNeeded()
                    self?.view.isUserInteractionEnabled = true
                    self!.view.viewWithTag(8062020)?.alpha = 1
                    self?.activityIndicatorHome.isHidden = true
                    self?.activityIndicatorHome.stopAnimating()
                }
                self?.basketTableView.reloadData()
        })
    }
    
    //MARK: AddToCart
    func callAddToCart(categoryID:String, menuID:String, menuQty:String) {
        lblTotalItems.text = ""
        lblTotalPrice.text = ""
        self.view.viewWithTag(8062020)?.alpha = 0
        activityIndicatorHome.isHidden = false
        activityIndicatorHome.startAnimating()
        
        self.view.isUserInteractionEnabled = false
        arrViewCart = [typeAliasDictionary]()
        var param = typeAliasDictionary()
        
        param[REQ_USER_ID] = SharedModel.getUserInfoForKey("User_Id") as AnyObject
        param[REQ_CATEGORY_ID] = categoryID as AnyObject
        param[REQ_MENU_ID] = menuID as AnyObject
        param[REQ_MENU_QTY] = menuQty as AnyObject
        
        callRestApi(API_Add_To_Cart_Remove_Cart, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: false, onCompletion: { [weak self] (response) in
            if response.valuForKeyString("status") == "1" {
                let dict = [
                    "cart_total" : response.valuForKeyString("cart_total"),
                    "cart_count" : response.valuForKeyString("cart_count"),
                    "menu_price" : response.valuForKeyString("menu_price"),
                    "Cart_Qty" : menuQty,
                    "Menu_Id" : menuID
                ]
                self?.isShowLoder = false
                self?.callViewCart()
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: NOTIFICATION_GET_CART_VALUE), object: dict)
                guard let select = self!.onMenuChange else { return }
                select(dict)
            }
            else if response.valuForKeyString("status") == "0" {
                self!.view.viewWithTag(8062020)?.alpha = 1
                self?.activityIndicatorHome.isHidden = true
                self?.activityIndicatorHome.stopAnimating()
                // NotificationCenter.default.post(name: NSNotification.Name(rawValue: NOTIFICATION_CLEAR_CART), object: nil)
                self?.view.isUserInteractionEnabled = true
            }
            }, onFailure: { [weak self] (error) in
                print(error)
                
                self!.view.viewWithTag(8062020)?.alpha = 1
                self?.activityIndicatorHome.isHidden = true
                self?.activityIndicatorHome.stopAnimating()
                // NotificationCenter.default.post(name: NSNotification.Name(rawValue: NOTIFICATION_CLEAR_CART), object: nil)
                self?.view.isUserInteractionEnabled = true
        })
    }
    
    func callClearCart() {
        var param = typeAliasDictionary()
        
        param[REQ_USER_ID] = SharedModel.getUserInfoForKey("User_Id") as AnyObject
        
        callRestApi(API_Clear_Cart, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { [weak self] (response) in
            if response.valuForKeyString("status") == "1" {
                
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: NOTIFICATION_CLEAR_CART), object: nil)
                
                self?.arrViewCart.removeAll()
                self?.isCartEmpty = true
                self?.basketTableView.showNoDataView = true
                self?.constraintBasketViewBottom.constant = 100
                self!.view.viewWithTag(8062020)?.alpha = 1
                self?.activityIndicatorHome.isHidden = true
                self?.activityIndicatorHome.stopAnimating()
                self?.basketTableView.reloadData()
            }
            else if response.valuForKeyString("status") == "0" {
                
            }
            }, onFailure: { (error) in
                print(error)
        })
    }
    
    @IBAction func btnClose(_ sender: UIButton) {
        self.view.viewWithTag(100)?.removeFromSuperview()
        topOfTableView.constant = 0
    }
}

extension BasketViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return isLoading ? 15 : arrViewCart.count
        } else {
            return isCartEmpty ? 0 : arrTotal.count + 2
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: BasketCell.reuseIdentifier, for: indexPath) as! BasketCell
            if !arrViewCart.isEmpty{
                cell.hideLoder()
                if arrViewCart.indices ~= indexPath.row {
                    cell.setupCellData(dict: arrViewCart[indexPath.row])
                    cell.viewStepper.valueChanged = { [weak self]() in
                        if self!.arrViewCart.indices ~= indexPath.row {
                            self?.callAddToCart(categoryID: self!.arrViewCart[indexPath.row].valuForKeyString("Category_Id"), menuID: self!.arrViewCart[indexPath.row].valuForKeyString("Menu_Id"), menuQty: Int(cell.viewStepper!.value).description)
                        }
                    }
                }
            }
            else {
                cell.showLoader()
            }
            
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: BasketPayableTableViewCell.reuseIdentifier, for: indexPath) as! BasketPayableTableViewCell
            cell.separatorInset = UIEdgeInsets(top: 0, left: cell.bounds.size.width, bottom: 0, right: 0)
            cell.selectionStyle = .none
            if !arrTotal.isEmpty{
                // cell.hideLoder()
                if arrTotal.indexExists(indexPath.row-1) {
                    cell.lblKey.text = arrTotal[indexPath.row-1].valuForKeyString("key")
                    cell.lblValue.text = stcurrency + " " + arrTotal[indexPath.row-1].valuForKeyString("value")
                }
                
                if indexPath.row == arrTotal.count + 1 {
                    cell.viewWithTag(101010)?.isHidden = false
                    cell.lblKey.style(style: TextStyle.totalGreen15)
                    cell.lblValue.style(style: TextStyle.totalGreen15)
                    cell.lblKey.text = "BASKET:Sub Total".localized
                    cell.lblValue.text = stcurrency + " " + subTotal
                } else {
                    cell.viewWithTag(101010)?.isHidden = true
                    cell.lblKey.style(style: TextStyle.productLabel)
                    cell.lblValue.style(style: TextStyle.productLabel)
                }
                if indexPath.row == 0 {
                    cell.lblKey.text = "BASKET:TOTAL PAYABLE".localized
                    cell.lblValue.text = " "
                    cell.lblKey.style(style: TextStyle.productName15)
                    cell.backgroundColor = UIColor.init(hexString: "F5F5F5")
                } else {
                    cell.backgroundColor = .white
                }
            }
            else {
                // cell.showLoader()
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return HEIGHT_PRODUCT_LIST_CELL
        } else {
            return 35
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if isCartEmpty { return 0 }
        if section == 0 {
            if address.isEmpty{
                return 40
            }
            else {
                return 80
            }
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if isCartEmpty { return nil }
        if section == 0 {
            let view:BasketHeaderView = UIView.fromNib()
            if address.isEmpty{
                view.viewAddressNotFound.alpha = 1
                view.viewAddressFound.alpha = 0
                
                view.btnAddAddress.block_setAction { [weak self] (control) in
                    self!.isShowLoder = false
                    let addAddressVC = AddAddressViewController(nibName: "AddAddressViewController", bundle: nil)
                    addAddressVC._address_type = .ADD_ADDRESS
                    addAddressVC.isBackButton = true
                    addAddressVC.isNewAddress = true
                    self?.navigationController!.setNavigationBarHidden(false, animated: true)
                    self?.navigationController!.pushViewController(addAddressVC, animated: true)
                }
                return view
            }
            else {
                view.viewAddressNotFound.alpha = 0
                view.viewAddressFound.alpha = 1
            }
            view.btnChange.style(style: TextStyle.boldWhite14)
            view.btnChange.backgroundColor = UIColor.init(hexString: "DC6666")
            view.lblAddress.style(style: TextStyle.productLabel)
            
            let houseNumber = address.valuForKeyString("House_No")
            let apartmentNameString = address.valuForKeyString("Apartment_Name")
            let streetDetails = address.valuForKeyString("Street_Details")
            let landmark = address.valuForKeyString("Landmark")
            
            view.lblAddress.text = houseNumber + ", " + apartmentNameString + ", " + streetDetails + ", " + landmark + ", " + address.valuForKeyString("City_Name")
            view.btnChange.block_setAction { [weak self] (control) in
                self!.isNavigationBackButtionShow = false
                let addressVC = AddressListViewController(nibName: "AddressListViewController", bundle: nil)
                addressVC.isBackButton = true
                addressVC._address_type = .BASKET_CHANGE_ADDRESS
                addressVC.dictBasketAddress = self!.address
                addressVC.onAddressSelection = { [weak self] (dictSelected) in
                    print(dictSelected)
                    self!.isSelectAddress = false
                    self!.isShowLoder = false
                    self!.address = dictSelected;
                    self?.basketTableView.reloadData()
                }
                self?.navigationController?.pushViewController(addressVC, animated: true)
            }
            return view
        } else {
            return nil
        }
    }
}
