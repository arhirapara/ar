//
//  WebViewViewController.swift
//  vincitore
//
//  Created by AR on 28/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit
import WebKit


class WebViewViewController: UIViewController {
    
    @IBOutlet weak var lblTitle3: UILabel!
    @IBOutlet weak var lblTitle2: UILabel!
    @IBOutlet weak var lblTitle1: UILabel!
    @IBOutlet weak var webViewIndicator: UIActivityIndicatorView!
    @IBOutlet weak var viewWeb: UIView!
    
    var isNavigationSideMenu:Bool = false
    var isNavigationBackButtionShow:Bool = false
    var webView: WKWebView = WKWebView()
    var navigationBarTitle: String = ""
    var webUrlString: String = ""
    var hiddenSections = Set<Int>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in
            self.navigationController?.popViewController(animated: true)
        }
        setTitle("WEBVIEW:About Us")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isNavigationBackButtionShow = isNavigationSideMenu
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.createWebViewView()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if isNavigationBackButtionShow{
            isNavigationBackButtionShow = false
            navigationController?.setNavigationBarHidden(true, animated: animated)
        }
    }
    
    func loadWebView(){
        webViewIndicator.isHidden = false
        webViewIndicator.startAnimating()
        load_url(server_url: webUrlString)
    }
    
    func createWebViewView()  {
        webView.navigationDelegate = self
        webView.frame = CGRect(x: 0, y: 0, width: viewWeb.frame.size.width, height: viewWeb.frame.size.height)
        webView.backgroundColor = UIColor.clear
        webViewIndicator.isHidden = false
        webViewIndicator.startAnimating()
        load_url(server_url: webUrlString)
        self.viewWeb.addSubview(webView)
        self.view.layoutIfNeeded()
    }
    
    func setUrl(_ title: String) {
        if title ==  "WEBVIEW:About Us".localized{
            setTitle("WEBVIEW:About Us")
            webUrlString = SharedModel.getUpdateFlagInfo().valuForKeyString("about_us")
            self.loadWebView()
        }
        else if title ==  "WEBVIEW:Privacy Policy".localized{
            setTitle("WEBVIEW:Privacy Policy")
            webUrlString = SharedModel.getUpdateFlagInfo().valuForKeyString("privacy_policy")
            self.loadWebView()
        }
        else if title ==  "WEBVIEW:Terms & Conditions".localized{
            setTitle("WEBVIEW:Terms & Conditions")
            webUrlString = SharedModel.getUpdateFlagInfo().valuForKeyString("terms_condition")
            self.loadWebView()
        }
    }
    
    @IBAction func view2Action() {
        let title = lblTitle1.text
        lblTitle1.text = lblTitle3.text?.uppercased()
        lblTitle3.text = title?.capitalized
        self.setUrl(lblTitle1.text!.capitalized)
    }
    
    @IBAction func view1Action() {
        let title = lblTitle1.text
        lblTitle1.text = lblTitle2.text?.uppercased()
        lblTitle2.text = title?.capitalized
        self.setUrl(lblTitle1.text!.capitalized)
    }
}

extension WebViewViewController: WKUIDelegate, WKNavigationDelegate{
    
    func webView(_ webView: WKWebView, didFailLoadWithError error: Error) {
        print("Error Msg : \(error)")
        webViewIndicator.isHidden = true
        webViewIndicator.stopAnimating()
    }
    
    func load_url(server_url: String) {
        guard let webUrl = URL(string: server_url) else {
            print("Invalid URL")
            webViewIndicator.stopAnimating()
            webViewIndicator.isHidden = true
            return
        }
        webView.load(URLRequest(url: webUrl))
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        webViewIndicator.isHidden = true
        webViewIndicator.stopAnimating()
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        
        // get the statuscode
        guard let statusCode = (navigationResponse.response as? HTTPURLResponse)?.statusCode
            else {
                decisionHandler(.allow)
                return
        }
        
        // respond or pass-through however you like
        switch statusCode {
        case 400..<500:
            webView.isHidden = true
        case 500..<600:
            webView.isHidden = true
        default:
            print("all might be well")
        }
        decisionHandler(.allow)
    }
}
