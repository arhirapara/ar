//
//  MultiBannerCell.swift
//  vincitore
//
//  Created by AR on 10/06/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class MultiBannerCell: UICollectionViewCell {

    @IBOutlet weak var imageViewBanner: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
