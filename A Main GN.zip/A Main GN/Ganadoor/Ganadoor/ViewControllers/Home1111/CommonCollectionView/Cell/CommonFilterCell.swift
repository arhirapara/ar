//
//  CommonFilterCell.swift
//  vincitore
//
//  Created by AR on 05/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class CommonFilterCell: UICollectionViewCell {

    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblProductPrice: UILabel!
    @IBOutlet weak var lblProductWeight: UILabel!
    @IBOutlet weak var productDescriptionView: UIView!
    @IBOutlet weak var lblOfferWeight: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.borderColor = UIColor.init(hexString: "DCDCDC").cgColor
        self.layer.borderWidth = 0.5
        lblProductName.style(style: TextStyle.productLabel)
        lblProductPrice.style(style: TextStyle.productPriceLabel)
        lblProductWeight.style(style: TextStyle.productOfferLabel)
        lblOfferWeight.style(style: TextStyle.offerLabel)
    }

}
