//
//  CommonFilterView.swift
//  vincitore
//
//  Created by AR on 05/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class CommonFilterView: UIView {
    enum VIEW_TYPE:Int {
        case DUMMY
        case CATEGORY
        case OFFERS
    }
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnViewAll: UIButton!
    @IBOutlet weak var collectionView: UICollectionView!
    var collectionArray = [typeAliasDictionary]()
    var dictMain = typeAliasDictionary()
    var viewType:VIEW_TYPE = .DUMMY
    var parameterKey:String = ""
    var cartAdded:((typeAliasDictionary, Int)->Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionView.delegate = self
        collectionView.dataSource = self
        lblTitle.style(style: TextStyle.HeaderLabel)
        btnViewAll.style(style: TextStyle.subHeaderLabel)
        btnViewAll.setHyperLink()
    }
    
    func reloadData() {
        if viewType == .CATEGORY {
            collectionView.register(UINib(nibName: "CommonFilterCell", bundle: nil), forCellWithReuseIdentifier: "CommonFilterCell")
            var rowHeight = (collectionArray.count / 3)
            if rowHeight % 2 == 0 {
                rowHeight = (rowHeight * 161) + 50
            } else {
               // rowHeight += 1
                if collectionArray.count > 3{
                  rowHeight += 1
                }
                rowHeight = (rowHeight * 161) + 50
            }
            heightAnchor.constraint(equalToConstant: CGFloat(rowHeight)).isActive = true
        } else if viewType == .OFFERS {
            collectionView.register(UINib(nibName: "ProductCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ProductCollectionViewCell")
            var rowHeight = (collectionArray.count / 2)
            if rowHeight % 2 == 0 {
                rowHeight = (rowHeight * 193) + 50
            } else {
               // rowHeight += 1
                rowHeight = (rowHeight * 193) + 50
            }
            heightAnchor.constraint(equalToConstant: CGFloat(rowHeight)).isActive = true
        }
        collectionView.reloadData()
    }
    @IBAction func viewAllClick() {
        let tag = self.tag
        print(tag)
        var _HOME_SCREEN_NAVIGATION = HOME_SCREEN_NAVIGATION.HOME_SCREEN_DUMMY
        if !dictMain.isEmpty{
            print(dictMain)
            
            _HOME_SCREEN_NAVIGATION = HOME_SCREEN_NAVIGATION(rawValue: dictMain.valuForKeyInt("See_More_Screen_Id"))!
            print(_HOME_SCREEN_NAVIGATION)
            if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_HOME{
                
            }
            else if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_CATEGOTY{
                let categoryVC = CategoryViewController(nibName: "CategoryViewController", bundle: nil)
                categoryVC.isBackButton = true
                categoryVC.isBackButtonBanner = true
                //categoryVC.dictCategoryData = dictData
                appDelegateObject().navigationController!.setNavigationBarHidden(false, animated: false)
                appDelegateObject().navigationController?.pushViewController(categoryVC, animated: true)
            }
            else if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_PRODUCT{
                let productListVC = ProductListViewController(nibName: "ProductListViewController", bundle: nil)
                //productListVC.dictProductData = dictData as! typeAliasStringDictionary
                productListVC.isBackButton = true
                productListVC.isClickHomePage = true
                appDelegateObject().navigationController!.setNavigationBarHidden(false, animated: false)
                appDelegateObject().navigationController?.pushViewController(productListVC, animated: true)
            }
        }
        //let categoryVC = CategoryViewController(nibName: "CategoryViewController", bundle: nil)
        // categoryVC.isBackButton = true
        //appDelegateObject().navigationController?.pushViewController(categoryVC, animated: true)
    }
    
}
extension CommonFilterView:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if viewType == .CATEGORY {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CommonFilterCell", for: indexPath) as! CommonFilterCell
            cell.productImageView.setImageWith(URL(string: collectionArray[indexPath.row].valuForKeyString(parameterKey)), usingActivityIndicatorStyle: .gray)
            cell.lblProductName.text = collectionArray[indexPath.row].valuForKeyString("Category_Name")
            cell.productDescriptionView.isHidden = true
            return cell
        } else if viewType == .OFFERS {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductCollectionViewCell", for: indexPath) as! ProductCollectionViewCell
            
            let priceLbelString = collectionArray[indexPath.row].valuForKeyString("Discount_Label")
            
            let dictData: typeAliasDictionary = collectionArray[indexPath.row]
            let stcurrency = SharedModel.getUpdateFlagInfo().valuForKeyString("currency")
            
            if priceLbelString.isEmpty{
                cell.lblOfferWeight.alpha = 0
            }
            else {
                cell.lblOfferWeight.alpha = 1
                cell.lblOfferWeight.text = priceLbelString
            }
            cell.viewAddProductPlus.tag = indexPath.row
            cell.viewAddProduct.tag = indexPath.row
            
            cell.viewAddProductPlus.addTarget(self, action: #selector(btnAddProductAction(_:)), for: .touchUpInside)
            cell.viewAddProduct.addTarget(self, action: #selector(btnAddProductAction(_:)), for: .touchUpInside)
            cell.productImageView.contentMode = .scaleAspectFit
            cell.lblProductPrice.text = stcurrency + " " + collectionArray[indexPath.row].valuForKeyString("Menu_Discounted_Price")
            cell.productImageView.setImageWith(URL(string: collectionArray[indexPath.row].valuForKeyString(parameterKey)), usingActivityIndicatorStyle: .gray)
            cell.lblProductName.text = collectionArray[indexPath.row].valuForKeyString("Menu_Title")
            cell.lblOfferWeight.isHidden = false
            
            cell.viewStapper.valueChanged = { [weak self] () in
                if cell.viewStapper.value == cell.viewStapper.minimumValue {
                    cell.viewStapper.alpha = 0;
                    cell.viewAddProduct.alpha = 1;
                }
                
                guard let cartAddRemove = self?.cartAdded else { return }
                cartAddRemove(dictData, Int(cell.viewStapper.value))
            }
            
            cell.viewStapper.maximumValue = dictData.valuForKeyDouble("Menu_Max_Order_Qty")
            
            if dictData.valuForKeyInt("Cart_Qty") == 0 {
                cell.viewStapper.alpha = 0;
                cell.viewAddProduct.alpha = 1;
            } else {
                cell.viewStapper.value = dictData.valuForKeyDouble("Cart_Qty")
                cell.viewStapper.alpha = 1;
                cell.viewAddProduct.alpha = 0;
            }
            
            return cell
        }
        return UICollectionViewCell.init()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if viewType == .CATEGORY {
//            var rowHeight = (collectionArray.count / 3)
//            if rowHeight % 2 == 0 {
//                rowHeight = (rowHeight * 80) + 40
//            } else {
//                rowHeight += 1
//                rowHeight = (rowHeight * 80) + 40
//            }
            //return CGSize(width: (collectionView.frame.width) / 3 , height: 100)
            return CGSize(width: (collectionView.frame.width) / 3 , height: CGFloat(161))
        } else if viewType == .OFFERS {
            return CGSize(width: (collectionView.frame.width) / 2 , height: 193)
        } else {
            return CGSize(width: (collectionView.frame.width) / 3 , height: 80)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let dictData = collectionArray[indexPath.row]
        var _HOME_SCREEN_NAVIGATION = HOME_SCREEN_NAVIGATION.HOME_SCREEN_DUMMY
        if !dictMain.isEmpty{
            print(dictMain)
            
            _HOME_SCREEN_NAVIGATION = HOME_SCREEN_NAVIGATION(rawValue: dictMain.valuForKeyInt("Screen_Id"))!
            print(_HOME_SCREEN_NAVIGATION)
            if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_HOME{
                
            }
            else if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_CATEGOTY{
                let categoryVC = CategoryViewController(nibName: "CategoryViewController", bundle: nil)
                categoryVC.isBackButton = true
                categoryVC.dictCategoryData = dictData
                appDelegateObject().navigationController!.setNavigationBarHidden(false, animated: false)
                appDelegateObject().navigationController?.pushViewController(categoryVC, animated: true)
            }
            else if _HOME_SCREEN_NAVIGATION == .HOME_SCREEN_PRODUCT{
                let productListVC = ProductListViewController(nibName: "ProductListViewController", bundle: nil)
                productListVC.dictProductData = dictData as! typeAliasStringDictionary
                productListVC.isBackButton = true
                productListVC.isClickHomePage = true
                appDelegateObject().navigationController!.setNavigationBarHidden(false, animated: false)
                appDelegateObject().navigationController?.pushViewController(productListVC, animated: true)
            }
        }
    }
    
    //MARK: Action
    @objc func btnAddProductAction(_ sender: UIButton?) {
        let index = sender!.tag
        let dictData: typeAliasDictionary = collectionArray[index]
        let indexPath = IndexPath(row: index, section: 0)
        if let cell = collectionView.cellForItem(at: indexPath) as? ProductCollectionViewCell {
            cell.viewStapper.value = cell.viewStapper.stepValue
            cell.viewStapper.alpha = 1
            cell.viewAddProduct.alpha = 0
            guard let cartAddRemove = self.cartAdded else { return }
            cartAddRemove(dictData, Int(cell.viewStapper.value))
        }
    }
}
