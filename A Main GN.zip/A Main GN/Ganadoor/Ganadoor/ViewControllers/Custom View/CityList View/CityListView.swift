//
//  CityListView.swift
//  vincitore
//
//  Created by AR on 23/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let CELL_IDENTIFIER_CITY_LIST_CELL         = "CityListCell"
let HEIGHT_CITY_LIST:CGFloat               = 44

let  FRAME_SCREEN = UIScreen.main.bounds

import UIKit

class CityListView: UIView, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    
    @IBOutlet weak var constrintHeightForSuperView: NSLayoutConstraint!
    @IBOutlet weak var constrintBootomForSuperView: NSLayoutConstraint!
    @IBOutlet weak var cityListTablView: UITableView!
    
    @IBOutlet weak var txtSearchCity: UITextField!
    var searchTimer: Timer? = nil
    var isFirstTime: Bool = false
    var totalPages: Int = 0
    var startPage: Int = 1
    var arrCityList = [typeAliasStringDictionary]()
    var isLoading: Bool = false
    var isLoadingLogo: Bool = true

    var oncitySelection:((typeAliasStringDictionary) -> Void)?
    
    @IBOutlet weak var viewCityList: UIView!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    required init(frame: CGRect, firstTimeViewLoad: Bool)
    {
        super.init(frame: frame)
        isFirstTime = firstTimeViewLoad
        self.loadXIB()
    }
    
    fileprivate func loadXIB() {
        
        let view = Bundle.main.loadNibNamed(String(describing: type(of: self)), owner: self, options: nil)?[0] as! UIView
        view.translatesAutoresizingMaskIntoConstraints = false;
        for view in self.subviews {
            view.removeFromSuperview()
        }
        
        self.addSubview(view)
        
        //TOP
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: 0))
        
        //LEADING
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.leading, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.leading, multiplier: 1, constant:0))
        
        //WIDTH
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.width, multiplier: 1, constant:0))
        
        //HEIGHT
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.height, multiplier: 1, constant:0))
        
        self.layoutIfNeeded()
        txtSearchCity.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        txtSearchCity.paddingLeftCustom = 4
        constrintBootomForSuperView.constant = -(FRAME_SCREEN.height);
        constrintHeightForSuperView.constant = FRAME_SCREEN.height / 1.5
        self.callCityListWithSearch(startPage, searchString: "")
        
    }

    //MARK: Custom Method
    func showView()  {
        cityListTablView.register(UINib.init(nibName: CELL_IDENTIFIER_CITY_LIST_CELL, bundle: nil), forCellReuseIdentifier: CELL_IDENTIFIER_CITY_LIST_CELL)
        cityListTablView.rowHeight = HEIGHT_CITY_LIST
        cityListTablView.tableFooterView = UIView(frame: CGRect.zero)
        
        UIView.animate(withDuration: 0.5, animations: {
            self.viewCityList.isHidden = false
        }) { finished in
            self.constrintBootomForSuperView.constant = 0
            
            UIView.animate(withDuration: 0.5, animations: {
                //self.setCornerView()
                self.viewCityList.backgroundColor = UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 0.5)
                self.viewCityList.layoutIfNeeded()
            })
        }
    }
    
    func callCityListWithSearch(_ pageNo: Int, searchString: String) {
        var param = typeAliasDictionary()
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id")  as AnyObject
        param[REQ_PAGE_NO] = "\(pageNo)"  as AnyObject
        param[REQ_CITY_NAME] = searchString  as AnyObject
        
        callRestApi(API_City_List_With_Search, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: isLoadingLogo, onCompletion: { (response) in
            print(response)
            self.isLoadingLogo = false
            self.isLoading = false
            if response.valuForKeyString("status") == "1" {
                
                let dictCityListData: typeAliasDictionary = response.valuForKeyDic("CityData")
                
                self.arrCityList += response.valuForKeyDic("CityData").valuForKeyArray("CityList") as! [typeAliasStringDictionary]
                
                let strTotalRecords : String = "\(dictCityListData["totalPages"]!)"
                self.totalPages = Int(strTotalRecords)!
                
                self.cityListTablView.reloadData()
                
                if self.isFirstTime {
                    self.isFirstTime = false
                    self.showView()
                }
            }
            else if response.valuForKeyString("status") == "0" {
                self.arrCityList = [typeAliasStringDictionary]()
                self.cityListTablView.reloadData()
            }
        }, onFailure: { (error) in
            print(error)
            self.isLoadingLogo = false
            self.isLoading = false
            self.arrCityList = [typeAliasStringDictionary]()
            self.cityListTablView.reloadData()
        })
    }
    
    @objc func textFieldDidChange(_ textField: UITextField?) {
        if searchTimer != nil {
            searchTimer!.invalidate()
            searchTimer = nil
        }
        
        searchTimer = Timer.scheduledTimer(timeInterval: 0.6, target: self, selector: #selector(search(forKeyword:)), userInfo: textField?.text, repeats: false)
    }
    
    @objc func search(forKeyword timer: Timer?) {
        let keyword = timer?.userInfo as? String
        print("Searching for keyword \(keyword ?? "")")
        let stSearch = keyword?.trim()
        txtSearchCity.text = stSearch
        startPage = 1
        arrCityList.removeAll()
        isLoading = true
        txtSearchCity.resignFirstResponder()
        cityListTablView.reloadData()
        self.callCityListWithSearch(startPage, searchString: stSearch!)
    }
    
    //MARK: UITextField Delegate Method
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtSearchCity.resignFirstResponder()
        return true
    }
    
    //MARK: Action
    @IBAction func btnCloseAction() {
        let height: CGFloat = self.frame.size.height + 800
        self.constrintBootomForSuperView.constant = -height
        UIView.animate(withDuration: 0.5, animations: {
            self.viewCityList.layoutIfNeeded()
        }) { finished in
            self.removeFromSuperview()
            self.viewCityList.isHidden = true
        }
    }
    
    //MARK: TableView Datasource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return arrCityList.count
        return isLoading ? 15 : arrCityList.count

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : CityListCell = tableView.dequeueReusableCell(withIdentifier: CELL_IDENTIFIER_CITY_LIST_CELL) as! CityListCell
        
        if !arrCityList.isEmpty{
            let dictData: typeAliasStringDictionary = arrCityList[indexPath.row]
            
            cell.hideLoder()
            cell.lblcityName.text = dictData.valuForKeyString("City_Name")
            
            if indexPath.row == self.arrCityList.count - 1 {
                print("Start Index: \(self.startPage)")
                let page: Int = startPage + 1
                if (page <= totalPages) {
                    startPage = page;
                    isLoading = true
                    self.callCityListWithSearch(startPage, searchString: "")
                }
            }
        }
        else {
            if isLoading{
                cell.showLoader()
            }
        }
        return cell
    }
    
    //MARK: TableView Delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if !arrCityList.isEmpty{
            if arrCityList.indices ~= indexPath.row {
                guard let select = oncitySelection else { return }
                select(arrCityList[indexPath.row])
                self.btnCloseAction()
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return HEIGHT_CITY_LIST
    }
}
