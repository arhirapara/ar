//
//  CityListCell.swift
//  vincitore
//
//  Created by AR on 25/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class CityListCell: UITableViewCell {

    @IBOutlet weak var lblcityName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func showLoader(){
        lblcityName.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
    }
    
    func hideLoder(){
        lblcityName.hideSkeleton()
    }
    
}
