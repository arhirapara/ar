//
//  AddressListViewController.swift
//  vincitore
//
//  Created by AR on 21/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let CELL_IDENTIFIER_ADDRESS_LIST_CELL         = "AddressListCell"
let HEIGHT_ADDRESS_LIST_CELL:CGFloat          = 100

import UIKit

class AddressListViewController: UIViewController {
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var addressListTableView: UITableView!
    
    var arrAddressList = [typeAliasDictionary]()
    var dictSelectedAddress = typeAliasDictionary()
    var _address_type = ADDRESS_TYPE.ADDRESS_DUMMY
    var dictBasketAddress = typeAliasDictionary()
    var isNavigationBackButtionShow:Bool = false
    var onAddressSelection:((typeAliasDictionary) -> Void)?
    var isNavigationSideMenu:Bool = false
    var isLoading: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in
            if self._address_type == .BASKET_CHANGE_ADDRESS {
                //dictSelectedAddress = arrAddressList[indexPath.row]
                guard let select = self.onAddressSelection else { return }
                select(self.dictSelectedAddress as typeAliasDictionary)
                self.addressListTableView.reloadData()
                //self.navigationController?.popViewController(animated: true)
            }
            
        }
        if _address_type == .BASKET_CHANGE_ADDRESS {
            setTitle("ADDRESSLIST:Choose Delivery Address")
        }
        else {
            setTitle("ADDRESSLIST:My Addresses")
        }
        //self.viewMain.alpha = 0;
        self.view.viewWithTag(10001)?.alpha = 0
        addressListTableView.register(UINib.init(nibName: CELL_IDENTIFIER_ADDRESS_LIST_CELL, bundle: nil), forCellReuseIdentifier: CELL_IDENTIFIER_ADDRESS_LIST_CELL)
        addressListTableView.estimatedRowHeight = HEIGHT_ADDRESS_LIST_CELL
        addressListTableView.rowHeight = UITableView.automaticDimension
        addressListTableView.tableFooterView = UIView(frame: CGRect.zero)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
        self.callListDeliveryAddress()
         isNavigationBackButtionShow = isNavigationSideMenu
         if _address_type == .BASKET_CHANGE_ADDRESS {
            self.tabBarController?.tabBar.isHidden = true
            self.hidesBottomBarWhenPushed = true
        }
     }
     
     override func viewWillDisappear(_ animated: Bool) {
         super.viewWillDisappear(animated)
         if isNavigationBackButtionShow{
             isNavigationBackButtionShow = false
             navigationController?.setNavigationBarHidden(true, animated: animated)
         }
        if _address_type == .BASKET_CHANGE_ADDRESS {
            self.tabBarController?.tabBar.isHidden = false
            self.hidesBottomBarWhenPushed = false
        }
     }
    
    //MARK: Custom Method
    func callListDeliveryAddress(){
        self.view.viewWithTag(10001)?.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        var param = typeAliasDictionary()
       
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id")  as AnyObject
        
        callRestApi(API_List_Delivery_Address, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: false, onCompletion: { (response) in
            print(response)
            self.view.viewWithTag(10001)?.hideSkeleton()
            self.isLoading = false
            if response.valuForKeyString("status") == "1" {
                
                self.viewMain.alpha = 1;
                self.view.viewWithTag(10001)?.alpha = 1
                self.arrAddressList = response.valuForKeyArray("address_list") as! [typeAliasDictionary]
                if self._address_type == .BASKET_CHANGE_ADDRESS{
                    self.dictSelectedAddress = self.dictBasketAddress
                }
                //self.addressListTableView.showNoDataView = false
                self.addressListTableView.reloadData()
            }
            else if response.valuForKeyString("status") == "0" {
                self.addressListTableView.showNoDataView = true
                self.addressListTableView.reloadData()
                self.view.viewWithTag(10001)?.alpha = 0
            }
        }, onFailure: { (error) in
            print(error)
            self.view.viewWithTag(10001)?.hideSkeleton()
            self.isLoading = false
            //self.viewMain.alpha = 0;
            self.addressListTableView.showNoDataView = true
            self.addressListTableView.reloadData()
            self.view.viewWithTag(10001)?.alpha = 0
        })
    }
    
    func callRemoveDeliveryAddress(_ addressId: String, index: IndexPath){
        var param = typeAliasDictionary()
        
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id")  as AnyObject
        param[REQ_Address_Id] = addressId  as AnyObject
        
        callRestApi(API_Remove_Delivery_Address, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { (response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                
                self.arrAddressList.remove(at: index.row)
                showAlertWithTitle(title: MSG_PROJECT_TITLE, message: response.valuForKeyString("message"), type: .WARNING)
                //self.addressListTableView.showNoDataView = false
                if self.arrAddressList.isEmpty {
                    //self.viewMain.alpha = 0;
                    self.addressListTableView.showNoDataView = true
                    self.view.viewWithTag(10001)?.alpha = 0
                    self.dictSelectedAddress.removeAll()
                    self.dictBasketAddress.removeAll()
                }
                self.addressListTableView.reloadData()
            }
            else if response.valuForKeyString("status") == "0" {
                self.view.viewWithTag(10001)?.alpha = 0
            }
        }, onFailure: { (error) in
            print(error)
            //self.viewMain.alpha = 0;
            self.view.viewWithTag(10001)?.alpha = 0
        })
    }
    
    func deleteAddress(_ index: Int)  {
        let indexPath = IndexPath(row: index, section: 0)
        
        DNKAlertActionView().showYesNoAlertView(MSG_PROJECT_TITLE, message: "ADDRESSLIST:Are you sure want to delete this address?".localized) { (YES) in
            if YES == "Yes".localized{
                let dictDeleteAddress = self.arrAddressList[index]
                let addressIDString = dictDeleteAddress.valuForKeyString("Address_Id")
                if !addressIDString.isEmpty{
                    self.callRemoveDeliveryAddress(addressIDString, index: indexPath)
                }
            }
        }
    }
    
    func editAddress(_ index: Int)  {
        isNavigationBackButtionShow = false
        let addAddressVC = AddAddressViewController(nibName: "AddAddressViewController", bundle: nil)
        addAddressVC.isBackButton = true
        addAddressVC._address_type = .UPDATE_ADDRESS
        addAddressVC.dictUpdateAddress = self.arrAddressList[index] as! typeAliasStringDictionary
        self.navigationController?.pushViewController(addAddressVC, animated: true)
    }
    
    //MARK: Action
    @IBAction func viewClickAddNewAddress() {
        isNavigationBackButtionShow = false
        let addAddressVC = AddAddressViewController(nibName: "AddAddressViewController", bundle: nil)
        addAddressVC._address_type = .ADD_ADDRESS
        addAddressVC.isBackButton = true
        self.navigationController?.pushViewController(addAddressVC, animated: true)
    }
    
    @objc func viewEditAction(_ sender: UIButton?) {
        let index = sender!.tag
        self.editAddress(index)
    }
    
    @objc func viewDeleteAction(_ sender: UIButton?) {
        let index = sender!.tag
        self.deleteAddress(index)
    }
}

extension AddressListViewController:UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isLoading ? 15 : arrAddressList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : AddressListCell = tableView.dequeueReusableCell(withIdentifier: CELL_IDENTIFIER_ADDRESS_LIST_CELL) as! AddressListCell
        
        if !arrAddressList.isEmpty{
            cell.hideLoder()
            let dictData: typeAliasDictionary = arrAddressList[indexPath.row]
            
            let addressTitleString = dictData.valuForKeyString("Address_Title")
            let personNameString = dictData.valuForKeyString("Person_Name")
            let pincodeString = dictData.valuForKeyString("Pincode")
            let mobileNumberString = dictData.valuForKeyString("Delivery_Mobile_No")
            let addressIDString = dictData.valuForKeyString("Address_Id")
            let defaultAddress = dictData.valuForKeyString("Is_Default_Address")
            let houseNo = dictData.valuForKeyString("House_No")
            let apartmentName = dictData.valuForKeyString("Apartment_Name")
            let streetDetails = dictData.valuForKeyString("Street_Details")
            let landmark = dictData.valuForKeyString("Landmark")
            
            if defaultAddress == "1"{
                cell.btnSelectUnselectAddress.isSelected = true
                cell.lblTitle.textColor = UIColor.init(hexString: "2e9f8d")
                cell.lblTitle.text = addressTitleString + " (Default Address)".localized
            }
            else {
                cell.btnSelectUnselectAddress.isSelected = false
                cell.lblTitle.textColor = UIColor.init(hexString: "464646")
                cell.lblTitle.text = addressTitleString
            }
            
            cell.lblName.text = personNameString
            cell.lblAddress.text =  houseNo + " " + apartmentName + ", " + streetDetails + ", " + landmark + " " + pincodeString + "\n\n" + "MO.: " + mobileNumberString + "\n"
            
            cell.viewEdit.tag = indexPath.row
            cell.viewDelete.tag = indexPath.row
            
            cell.viewEdit.addTarget(self, action: #selector(viewEditAction(_:)), for: .touchUpInside)
            cell.viewDelete.addTarget(self, action: #selector(viewDeleteAction(_:)), for: .touchUpInside)
            
            if _address_type == .BASKET_CHANGE_ADDRESS {
                cell.viewWithTag(11062020)?.isHidden = false
                cell.constrintLeadingViewLblAddress.constant = 0
            }
            else {
                cell.viewWithTag(11062020)?.isHidden = true
                cell.constrintLeadingViewLblAddress.constant = 10
            }
            
            if !dictSelectedAddress.isEmpty {
                let selectedAddressIDString = dictSelectedAddress.valuForKeyString("Address_Id")
                if addressIDString == selectedAddressIDString {
                    cell.btnSelectUnselectAddress.isSelected = true
                    cell.lblTitle.textColor = UIColor.init(hexString: "2e9f8d")
                    cell.lblTitle.text = addressTitleString + " (Default Address)".localized
                }
                else {
                    cell.btnSelectUnselectAddress.isSelected = false
                    cell.lblTitle.textColor = UIColor.init(hexString: "464646")
                    cell.lblTitle.text = addressTitleString
                }
            }
//            else {
//                cell.btnSelectUnselectAddress.isSelected = false
//                cell.lblTitle.textColor = UIColor.init(hexString: "464646")
//                cell.lblTitle.text = addressTitleString
//            }
        }
        else {
            cell.showLoader()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //dictSelectedAddress = arrAddressList[indexPath.row]
        //self.addressListTableView.reloadData()
        if !arrAddressList.isEmpty{
            if _address_type == .BASKET_CHANGE_ADDRESS {
                dictSelectedAddress = arrAddressList[indexPath.row]
                guard let select = onAddressSelection else { return }
                select(dictSelectedAddress as typeAliasDictionary)
                self.addressListTableView.reloadData()
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let contextItemDelete = UIContextualAction(style: .destructive, title: "ADDRESSLIST:Delete".localized) {  (contextualAction, view, boolValue) in
            self.deleteAddress(indexPath.row)
        }
        let contextItemEdit = UIContextualAction(style: .normal, title: "ADDRESSLIST:Edit".localized) {  (contextualAction, view, boolValue) in
            print("Edit")
            self.editAddress(indexPath.row)
        }
        let swipeActions = UISwipeActionsConfiguration(actions: [contextItemDelete, contextItemEdit])
        return swipeActions
    }
}
