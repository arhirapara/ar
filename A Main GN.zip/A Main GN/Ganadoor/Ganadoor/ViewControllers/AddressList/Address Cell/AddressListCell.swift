//
//  AddressListCell.swift
//  vincitore
//
//  Created by AR on 21/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class AddressListCell: UITableViewCell {

    @IBOutlet weak var viewEdit: UIControl!
    @IBOutlet weak var viewDelete: UIControl!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnSelectUnselectAddress: UIButton!
    
    @IBOutlet weak var constrintLeadingViewLblAddress: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func showLoader(){
        viewEdit.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        viewDelete.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblAddress.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblName.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblTitle.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        btnSelectUnselectAddress.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
    }
    
    func hideLoder(){
        viewEdit.hideSkeleton()
        viewDelete.hideSkeleton()
        lblAddress.hideSkeleton()
        lblName.hideSkeleton()
        lblTitle.hideSkeleton()
        btnSelectUnselectAddress.hideSkeleton()
    }
    
}
