//
//  DeliveryOptionViewController.swift
//  vincitore
//
//  Created by DNK040 on 28/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class DeliveryOptionViewController: UIViewController {

    @IBOutlet weak var deliveryTextField: UITextField!
    @IBOutlet weak var deliveryType: UILabel!
    @IBOutlet weak var shipmentChargeLabel: UILabel!
    @IBOutlet weak var deliveryChargeLabel: UILabel!
    @IBOutlet weak var deliveryTime: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        sideBarBackButton { (str) in }
        setTitle("Delivery Option")
    }

    @IBAction func changeAddressClick() {
    }
}
