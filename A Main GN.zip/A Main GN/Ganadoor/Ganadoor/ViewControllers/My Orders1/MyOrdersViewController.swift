//
//  MyOrdersViewController.swift
//  vincitore
//
//  Created by DNK062 on 27/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class MyOrdersViewController: UIViewController {
    
    @IBOutlet weak var myOrderTableView: UITableView!
    var arrOrderList = [typeAliasDictionary]()
    var arrFinalOrderList = [typeAliasDictionary]()
    var totalPages: Int = 0
    var startPage: Int = 1
    var isNavigationBackButtionShow:Bool = false
    var isNavigationSideMenu:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarBackButton { (str) in }
        setTitle("MY ORDERS")
        myOrderTableView.tableFooterView = UIView.init(frame: .zero)
        myOrderTableView.register(UINib(nibName: MyOrderListTableViewCell.reuseIdentifier, bundle: nil), forCellReuseIdentifier: MyOrderListTableViewCell.reuseIdentifier)
        myOrderTableView.estimatedRowHeight = 122
        myOrderTableView.rowHeight = UITableView.automaticDimension
        getOrderList(pageNo: startPage)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isNavigationBackButtionShow = isNavigationSideMenu
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if isNavigationBackButtionShow{
            isNavigationBackButtionShow = false
            navigationController?.setNavigationBarHidden(true, animated: animated)
        }
    }
    
    func getOrderList(pageNo: Int) {
        var param = typeAliasDictionary()
        param[REQ_HEADER] = "hp/R7xYbycq9wzyGeRwFFbG9mDlL/DgtjY01eeyvUCg=" as AnyObject
        param[REQ_RANDOM_NUMBER] = "123" as AnyObject
        param[REQ_PAGE_NO] = "\(pageNo)" as AnyObject
        param[REQ_USER_ID] = SharedModel.getUserInfo().valuForKeyString("User_Id") as AnyObject
        
        callRestApi(API_My_Order_List, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: {[weak self] (response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                self?.arrFinalOrderList += response.valuForKeyDic("MyOrderDetail").valuForKeyArray("MyOrderData") as! [typeAliasDictionary]
                self?.arrOrderList = (self?.setDataSectionWise(self!.arrFinalOrderList))!
                //self!.myOrderTableView.showNoDataView = false
                self!.totalPages = response.valuForKeyDic("MyOrderDetail").valuForKeyInt("totalPages")
                self?.myOrderTableView.reloadData()
            }
            else if response.valuForKeyString("status") == "0" {
                self!.myOrderTableView.showNoDataView = true
                self!.myOrderTableView.reloadData()
            }
            }, onFailure: { (error) in
                self.myOrderTableView.showNoDataView = true
                self.myOrderTableView.reloadData()
                print(error)
        })
    }
    
    func getOrderStatus(_ orderstatus: typeAliasDictionary){
        var stOrderstatus = orderstatus.valuForKeyString("OrderStatus")
        stOrderstatus = stOrderstatus.uppercased()
        if (stOrderstatus == "SUCCESS") || (stOrderstatus == "FAILED") || (stOrderstatus == "REFUNDED") {
            isNavigationBackButtionShow = false
            let orderSummaryVC = OrderSummaryViewController(nibName: "OrderSummaryViewController", bundle: nil)
            orderSummaryVC.orderSummary = .ORDER_SUMMARY_MYORDER
            orderSummaryVC.dictSummary = orderstatus
            orderSummaryVC.isBackButton = true
            self.navigationController?.setNavigationBarHidden(false, animated: true)
            self.navigationController?.pushViewController(orderSummaryVC, animated: true)
        }
        else {
            self.getOrderStatusForId(orderID: orderstatus.valuForKeyString("orderID"))
        }
    }
    
    func getOrderStatusForId(orderID:String) {
        var param = typeAliasDictionary()
        param[REQ_Header] = "hp/R7xYbycq9wzyGeRwFFbG9mDlL/DgtjY01eeyvUCg=" as AnyObject
        param[REQ_Random_No] = "123" as AnyObject
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id") as AnyObject
        param[REQ_ORDER_ID] = orderID as AnyObject
        
        callRestApi(API_Get_Order_Status, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { [weak self](response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                self!.startPage = 1
                self!.isNavigationBackButtionShow = false
                let orderSummaryVC = OrderSummaryViewController(nibName: "OrderSummaryViewController", bundle: nil)
                orderSummaryVC.orderSummary = .ORDER_SUMMARY_BASKET
                orderSummaryVC.dictSummary = response
                orderSummaryVC.isBackButton = true
                self!.navigationController?.setNavigationBarHidden(false, animated: true)
                self!.navigationController?.pushViewController(orderSummaryVC, animated: true)
                self!.getOrderList(pageNo: self!.startPage)
            }
            else if response.valuForKeyString("status") == "0" {
                
            }
        }) { (error) in
            print(error)
        }
    }
    
    func setDataSectionWise(_ arrMoneyCoinData: [typeAliasDictionary]) -> [typeAliasDictionary] {
        var arrDate = [String]()
        let dateFormat = DateFormatter()
        let locale = NSLocale(localeIdentifier: "en_US_POSIX")
        dateFormat.locale = locale as Locale
        dateFormat.dateFormat = "dd-MM-yyyy"
        
        var arrMoneyCoinsList = [typeAliasDictionary]()
        for dict in arrMoneyCoinData {
            let stDate = dict["OrderDate"]
            let date = dateFormat.date(from: stDate as! String)
            var stDateConverted: String? = ""
            if let date = date {
                stDateConverted = dateFormat.string(from: date)
            }
            if !(arrDate.contains(stDateConverted!)) {
                arrDate.append(stDateConverted!)
            }
        }
        
        for stDateValue in arrDate {
            var dictData = typeAliasDictionary()
            dictData["SECTION_DATE"] = stDateValue as AnyObject
            var arrSectionData = [typeAliasDictionary]()
            for i in 0..<arrMoneyCoinData.count {
                let dict = arrMoneyCoinData[i]
                let stDictValue = dict["OrderDate"]
                let date = dateFormat.date(from: stDictValue as! String)
                var stDateConverted: String? = nil
                if let date = date {
                    stDateConverted = dateFormat.string(from: date)
                }
                if (stDateConverted == stDateValue) {
                    if let dict: typeAliasDictionary = dict {
                        arrSectionData.append(dict)
                    }
                }
            }
            dictData["SECTION_LIST"] = arrSectionData as AnyObject
            arrMoneyCoinsList.append(dictData)
        }
        
        return arrMoneyCoinsList
    }
}

extension MyOrdersViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        if !arrOrderList.isEmpty {
            return arrOrderList.count
        }
        else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if !arrOrderList.isEmpty {
            let dict = arrOrderList[section]
            let arrData = dict.valuForKeyArray("SECTION_LIST")
            return arrData.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MyOrderListTableViewCell.reuseIdentifier, for: indexPath) as! MyOrderListTableViewCell
        
        let dict = arrOrderList[indexPath.section]
        let arrData = dict.valuForKeyArray("SECTION_LIST")
        
        cell.setupCellData(dict: arrData[indexPath.row] as! typeAliasDictionary)
        
        if indexPath.row == arrData.count - 1 {
            print("Start Index: \(self.startPage)")
            let page: Int = startPage + 1
            if (page <= totalPages) {
                startPage = page
                getOrderList(pageNo: startPage)
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        if !arrOrderList.isEmpty {
//            let view:OrderListHeaderView = UIView.fromNib()
//            let dict  = arrOrderList[section]
//            let date = dict.valuForKeyString("SECTION_DATE")
//            //view.
//            return "  " + date
//        }
//        return nil
//    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if !arrOrderList.isEmpty {
            return 40
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view:OrderListHeaderView = UIView.fromNib()
        let dict  = arrOrderList[section]
        view.lblOrderDate.text = dict.valuForKeyString("SECTION_DATE")
        return view
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if !arrOrderList.isEmpty {
            let dict = arrOrderList[indexPath.section]
            let arrData = dict.valuForKeyArray("SECTION_LIST")
            let dictOrder = arrData[indexPath.row]
            self.getOrderStatus(dictOrder as! typeAliasDictionary)
        }
    }
}
