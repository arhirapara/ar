//
//  MyOrderListTableViewCell.swift
//  vincitore
//
//  Created by DNK062 on 27/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class MyOrderListTableViewCell: UITableViewCell {

    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblDateNTime: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblOrderNo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        lblDescription.style(style: TextStyle.placeHolder)
        lblDateNTime.style(style: TextStyle.productDescription)
        lblStatus.style(style: TextStyle.totalGreen15)
        lblPrice.style(style: TextStyle.productPriceLabel)
        lblOrderNo.style(style: TextStyle.HeaderLabel)
    }
    
    func setupCellData(dict:typeAliasDictionary) {
        lblDescription.text = dict.valuForKeyString("Menu_Content_Label")
        lblDateNTime.text = dict.valuForKeyString("Order_Date")
        lblStatus.text = dict.valuForKeyString("OrderStatus")
        lblStatus.textColor = UIColor.init(hexString: dict.valuForKeyString("OrderColor"))
        lblPrice.text = "   ₹ " + dict.valuForKeyString("OrderAmount") + "  "
        lblOrderNo.text = "Order No. : " + dict.valuForKeyString("orderID")
    }

}
