//
//  SideMenuViewController.swift
//  vincitore
//
//  Created by AR on 04/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class SideMenuViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var sideMenuTableView: UITableView!
    var menuItem = [typeAliasStringDictionary]()
    override func viewDidLoad() {
        super.viewDidLoad()
        let dict1 = ["name":"SIDEMENU:Home".localized, "image":"icn_home"]
        let dict2 = ["name":"SIDEMENU:Categories".localized, "image":"icn_category"]
//        let dict3 = ["name":"SIDEMENU:Offers".localized, "image":"icn_offer"]
        let dict4 = ["name":"SIDEMENU:My Cart".localized, "image":"icn_Cart"]
        let dict5 = ["name":"SIDEMENU:My Orders".localized, "image":"icn_order"]
//        let dict6 = ["name":"SIDEMENU:My Wallet".localized, "image":"icn_wallet"]
        let dict7 = ["name":"SIDEMENU:My Addresses".localized, "image":"icn_my_address"]
        let dict8 = ["name":"SIDEMENU:Customer Support".localized, "image":"icn_support"]
        //let dict9 = ["name":"SIDEMENU:Rate Us".localized, "image":"icn_rating"]
        let dict10 = ["name":"SIDEMENU:Share".localized, "image":"icn_share"]
        let dict11 = ["name":"SIDEMENU:About Us".localized, "image":"icn_help"]
        SideMenuController.preferences.basic.menuWidth = screenWidth * 0.7
        SideMenuController.preferences.basic.position = .above
        SideMenuController.preferences.basic.direction = .left
        menuItem = [dict1, dict2, dict4, dict5, dict7, dict8, dict10,dict11]
        sideMenuTableView.register(UINib(nibName: SideMenuCell.reuseIdentifier, bundle: nil), forCellReuseIdentifier: SideMenuCell.reuseIdentifier)
        sideMenuTableView.delegate = self
        sideMenuTableView.dataSource = self
        sideMenuTableView.tableFooterView = UIView()
        self.view.LableWithTag(10).style(style: TextStyle.placeHolder)
        lblUsername.style(style: TextStyle.semiBold15)
        let dictUserData: typeAliasDictionary = SharedModel.getUserInfo()
        lblUsername.text = dictUserData.valuForKeyString("User_Name")
    }
    
    @IBAction func btnLogoutAction(_ sender: UIButton) {
        DNKAlertActionView().showYesNoAlertView(MSG_PROJECT_TITLE, message: "SIDEMENU:Are you sure want to logout?".localized) { (YES) in
            if YES == "Yes".localized{
                self.appDelegate().logOut()
            }
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let selectionIndexPath = self.sideMenuTableView.indexPathForSelectedRow {
            self.sideMenuTableView.deselectRow(at: selectionIndexPath, animated: animated)
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: SideMenuCell.reuseIdentifier, for: indexPath) as! SideMenuCell
        cell.lblSideMenuTitle.text = menuItem[indexPath.row].valuForKeyString("name")
        cell.iconImageView.image = UIImage(named: menuItem[indexPath.row].valuForKeyString("image"))
        cell.lblSideMenuTitle.style(style: TextStyle.semiBold15)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        appDelegate().clickOnSideMenu(indexPath.row)
    }
}
