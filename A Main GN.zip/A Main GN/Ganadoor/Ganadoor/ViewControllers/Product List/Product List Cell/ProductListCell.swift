//
//  ProductListCell.swift
//  vincitore
//
//  Created by AR on 26/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class ProductListCell: UITableViewCell {

    @IBOutlet weak var viewOff: UIView!
    @IBOutlet weak var imageViewProduct: UIImageView!
    
    @IBOutlet weak var constrintViewForImageProductLeading: NSLayoutConstraint!
    @IBOutlet weak var viewStapper: GMStepper!
    @IBOutlet weak var viewAddProduct: UIControl!
    @IBOutlet weak var viewAddProductPlus: UIControl!
    
    @IBOutlet weak var lblProductPriceOff: UILabel!
    @IBOutlet weak var lblProductPrice: UILabel!
    @IBOutlet weak var lblProductDescription: UILabel!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblProductDic: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func showLoader(){
        lblProductName.linesCornerRadius = 8
        lblProductDescription.linesCornerRadius = 8
        lblProductPriceOff.linesCornerRadius = 8
        
        constrintViewForImageProductLeading.constant = 8
        self.viewWithTag(1262020)!.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        imageViewProduct.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        viewAddProduct.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblProductPriceOff.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblProductPrice.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        viewAddProductPlus.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblProductDescription.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblProductName.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
        lblProductDic.showAnimatedGradientSkeleton(usingGradient: SkeletonGradient.init(baseColor: UIColor(hexString: "f5f5f5")), animation: animation)
    }
    
    func hideLoder(){
        constrintViewForImageProductLeading.constant = 0
        self.viewWithTag(1262020)!.hideSkeleton()
        imageViewProduct.hideSkeleton()
        viewAddProduct.hideSkeleton()
        lblProductPriceOff.hideSkeleton()
        viewAddProductPlus.hideSkeleton()
        lblProductPrice.hideSkeleton()
        lblProductDescription.hideSkeleton()
        lblProductName.hideSkeleton()
        lblProductDic.hideSkeleton()
    }
    
}
