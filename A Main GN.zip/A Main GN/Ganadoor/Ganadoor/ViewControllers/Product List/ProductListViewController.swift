//
//  ProductListViewController.swift
//  vincitore
//
//  Created by AR on 26/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let CELL_IDENTIFIER_PRODUCT_LIST_CELL         = "ProductListCell"
let HEIGHT_PRODUCT_LIST_CELL:CGFloat          = 130//140
let NOTIFICATION_GET_CART_VALUE               = "NOTIFICATION_GET_CART_VALUE"
let NOTIFICATION_CLEAR_CART                   = "NOTIFICATION_CLEAR_CART"

import UIKit

class ProductListViewController: UIViewController {
    let stcurrency = SharedModel.getUpdateFlagInfo().valuForKeyString("currency")
    @IBOutlet weak var activityIndicatorHome: UIActivityIndicatorView!
    
    @IBOutlet weak var tableViewProductList: UITableView!
    @IBOutlet weak var lblTotalItems: UILabel!
    @IBOutlet weak var lblTotalPrice: UILabel!
    var totalPages: Int = 0
    var startPage: Int = 1
    var arrProductList = [typeAliasStringDictionary]()
    var dictProductData = typeAliasStringDictionary()
    var isClickHomePage: Bool = false
    var isClickHomeToBasketPage: Bool = false
    var isLoading: Bool = true

    
    @IBOutlet weak var constraintViewCartBottom: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        lblTotalItems.style(style: TextStyle.productLabel)
        lblTotalPrice.style(style: TextStyle.themeSemiBoldLabelSize18)
        self.view.LableWithTag(200).style(style: TextStyle.mediumWhite15)
        sideBarBackButton { (str) in }
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.cartValueUpdate), name: NSNotification.Name(rawValue: NOTIFICATION_GET_CART_VALUE), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.removeAllCart), name: NSNotification.Name(rawValue: NOTIFICATION_CLEAR_CART), object: nil)
        
        if dictProductData.valuForKeyString("Category_Name").isEmpty {
            setTitle("PRODUCT:Products")
        }
        else {
            setTitle(dictProductData.valuForKeyString("Category_Name"))
        }
        tableViewProductList.register(UINib.init(nibName: CELL_IDENTIFIER_PRODUCT_LIST_CELL, bundle: nil), forCellReuseIdentifier: CELL_IDENTIFIER_PRODUCT_LIST_CELL)
        //        tableViewProductList.estimatedRowHeight = HEIGHT_PRODUCT_LIST_CELL
        //tableViewProductList.rowHeight = UITableView.automaticDimension
        tableViewProductList.rowHeight = HEIGHT_PRODUCT_LIST_CELL
        tableViewProductList.tableFooterView = UIView(frame: CGRect.zero)
        constraintViewCartBottom.constant = -50//-150
        self.view.layoutIfNeeded()
        isClickHomeToBasketPage = isClickHomePage
        self.callProductListWithSearch(startPage)
        view.viewWithTag(8062020)?.alpha = 1
        activityIndicatorHome.isHidden = true
        activityIndicatorHome.stopAnimating()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isClickHomePage = isClickHomeToBasketPage
        //arrProductList.removeAll()
        //startPage = 1
        //self.callProductListWithSearch(startPage)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if isClickHomePage{
            navigationController!.setNavigationBarHidden(true, animated: false)
        }
    }
    
    func showSearchIcon(){
        if !arrProductList.isEmpty{
            sideBarLeftButton(imageName: "icn_search") { [weak self] (str) in
                //self?.appDelegate().contentViewController.selectedIndex = 2
                let searchVC = SearchViewController(nibName: "SearchViewController", bundle: nil)
                searchVC.isBackButton = true
                searchVC.dictProductData = self!.dictProductData
                searchVC.isClickHomeToBasketPage = true
                searchVC.onMenuChange = { [weak self] (dictSelected) in
                    print(dictSelected)
                    self!.replaceMenuQty(dictSelected as typeAliasDictionary)
                }
                self!.navigationController!.setNavigationBarHidden(false, animated: true)
                self!.navigationController?.pushViewController(searchVC, animated: true)
            }
        }
    }
    
    func cartCountUpdate(_ dictCountUpdate: typeAliasDictionary){
        if dictCountUpdate.valuForKeyString("cart_count") == "0" || dictCountUpdate.valuForKeyString("cart_count") == "" {
            self.constraintViewCartBottom.constant = -50//-150
        }
        else {
            self.constraintViewCartBottom.constant = 0
            self.lblTotalItems.text = dictCountUpdate.valuForKeyString("cart_count") + " ITEMS".localized
            self.lblTotalPrice.text = "\(stcurrency) " + dictCountUpdate.valuForKeyString("cart_total")
        }
    }
    
    @IBAction func btnViewCartAction(_ sender: UIControl) {
        isClickHomePage = false
        let cartVC = BasketViewController(nibName: "BasketViewController", bundle: nil)
        cartVC.isBackButton = true
        cartVC.onMenuChange = { [weak self] (dictSelected) in
            print(dictSelected)
            self!.replaceMenuQty(dictSelected as typeAliasDictionary)
        }
        self.navigationController?.pushViewController(cartVC, animated: true)
    }
    
    //MARK: Custom Function
    @objc func removeAllCart() {
        if !arrProductList.isEmpty {
            for i in 0..<arrProductList.count {
                var dict = arrProductList[i]
                dict["Cart_Qty"] = "0"
                arrProductList[i] = dict
            }
        }
        self.constraintViewCartBottom.constant = -50//-150
        self.tableViewProductList.reloadData()
    }
    
    func replaceMenuQty(_ dictMenuData: typeAliasDictionary){
        let dictSelected: typeAliasDictionary = dictMenuData
        if !self.arrProductList.isEmpty {
            for i in 0..<self.arrProductList.count {
                var dict = self.arrProductList[i]
                let menuId = dict.valuForKeyString("Menu_Id")
                let menuUpdateDictId = dictSelected.valuForKeyString("Menu_Id")
                if menuId == menuUpdateDictId{
                    dict["Cart_Qty"] = dictSelected.valuForKeyString("Cart_Qty")
                    self.cartCountUpdate(dictSelected)
                    self.arrProductList[i] = dict
                    break;
                }
                else{
                    self.cartCountUpdate(dictSelected)
                }
            }
        }
        else {
            self.cartCountUpdate(dictSelected)
        }
        self.tableViewProductList.reloadData()
    }
    
    @objc func cartValueUpdate(notification: Notification) {
        let dictSelected: typeAliasDictionary = notification.object! as! typeAliasDictionary
        self.replaceMenuQty(dictSelected)
    }
    
    func callProductListWithSearch(_ pageNo: Int)  {
        var menuId = ""
        var categotrId = ""
        menuId = dictProductData.valuForKeyString("Menu_Id")
        categotrId = dictProductData.valuForKeyString("Category_Id")
        
        if categotrId == "" {
            categotrId = dictProductData.valuForKeyString("mb_category_id")
        }
        if menuId == "" {
            menuId = dictProductData.valuForKeyString("mb_menu_id")
        }
        var param = typeAliasDictionary()
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id") as AnyObject
        param[REQ_PAGE_NO] = "\(pageNo)"  as AnyObject
        param[REQ_CATEGORY_ID] = categotrId  as AnyObject
        param[REQ_MENU_ID] = menuId as AnyObject
        param[REQ_MENU_TITLE] = ""  as AnyObject
        
        callRestApi(API_Product_List_With_Search, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: false, onCompletion: {[weak self] (response) in
            print(response)
            self!.isLoading = false
            if response.valuForKeyString("status") == "1" {
                let dictData: typeAliasDictionary = response.valuForKeyDic("Menu_Data")
                
                self?.arrProductList += response.valuForKeyDic("Menu_Data").valuForKeyArray("Menu_List") as! [typeAliasStringDictionary]
                
                self?.totalPages = dictData.valuForKeyInt("totalPages")
                
                if response.valuForKeyDic("CartData").valuForKeyString("cart_count") == "0" || response.valuForKeyDic("CartData").valuForKeyString("cart_count") == "" {
                    self?.constraintViewCartBottom.constant = -50//-150
                }
                else {
                    self?.constraintViewCartBottom.constant = 0
                    self?.lblTotalItems.text = response.valuForKeyDic("CartData").valuForKeyString("cart_count") + " ITEMS".localized
                    self?.lblTotalPrice.text = "\(self!.stcurrency) " + response.valuForKeyDic("CartData").valuForKeyString("cart_total")
                }
                UIView.animate(withDuration: 0.3) {
                    self?.view.layoutIfNeeded()
                    //self!.tableViewProductList.showNoDataView = false
                }
                self?.tableViewProductList.reloadData()
            }
            else if response.valuForKeyString("status") == "0" {
                let cardObject = response.valuForKeyDic("CartData")
                if !cardObject.isEmpty{
                    if cardObject.valuForKeyString("cart_count") == "0" || cardObject.valuForKeyString("cart_count") == "" {
                        self?.constraintViewCartBottom.constant = -50//-150
                    }
                    else {
                        self?.constraintViewCartBottom.constant = 0
                        self?.lblTotalItems.text = cardObject.valuForKeyString("cart_count") + " ITEMS".localized
                        self?.lblTotalPrice.text = "\(self!.stcurrency) " + cardObject.valuForKeyString("cart_total")
                    }
                }
                
                self!.tableViewProductList.showNoDataView = true
                self!.tableViewProductList.reloadData()
            }
            self!.showSearchIcon()
            }, onFailure: { (error) in
                self.isLoading = false
                self.tableViewProductList.showNoDataView = true
                self.tableViewProductList.reloadData()
                print(error)
        })
    }
    
    //MARK: AddToCart
    func callAddToCart(categoryID:String, menuID:String, menuQty:String) {
        lblTotalItems.text = ""
        lblTotalPrice.text = ""
        self.view.viewWithTag(8062020)?.alpha = 0
        activityIndicatorHome.isHidden = false
        activityIndicatorHome.startAnimating()
        
        self.view.isUserInteractionEnabled = false
        var param = typeAliasDictionary()
        param[REQ_USER_ID] = SharedModel.getUserInfo().valuForKeyString("User_Id") as AnyObject
        param[REQ_CATEGORY_ID] = categoryID as AnyObject
        param[REQ_MENU_ID] = menuID as AnyObject
        param[REQ_MENU_QTY] = menuQty as AnyObject
        
        callRestApi(API_Add_To_Cart_Remove_Cart, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: false, onCompletion: { [weak self] (response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                let dict = [
                    "cart_total" : response.valuForKeyString("cart_total"),
                    "cart_count" : response.valuForKeyString("cart_count"),
                    "menu_price" : response.valuForKeyString("menu_price"),
                    "Cart_Qty" : menuQty,
                    "Menu_Id" : menuID
                ]
                
                if response.valuForKeyString("cart_count") == "0" || response.valuForKeyString("cart_count") == "" {
                    self?.constraintViewCartBottom.constant = -50//-150
                }
                else {
                    self?.constraintViewCartBottom.constant = 0
                    self?.lblTotalItems.text = response.valuForKeyString("cart_count") + " ITEMS".localized
                    self?.lblTotalPrice.text = "\(self!.stcurrency) " + response.valuForKeyString("cart_total")
                }
                UIView.animate(withDuration: 0.3) {
                    self?.view.layoutIfNeeded()
                    self?.view.isUserInteractionEnabled = true
                    self!.view.viewWithTag(8062020)?.alpha = 1
                    self?.activityIndicatorHome.isHidden = true
                    self?.activityIndicatorHome.stopAnimating()
                }
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: NOTIFICATION_GET_CART_VALUE), object: dict)
            }
            else if response.valuForKeyString("status") == "0" {
                self!.view.viewWithTag(8062020)?.alpha = 1
                self?.activityIndicatorHome.isHidden = true
                self?.activityIndicatorHome.stopAnimating()
                self?.view.isUserInteractionEnabled = true
            }
            
            }, onFailure: { [weak self] (error) in
                print(error)
                self!.view.viewWithTag(8062020)?.alpha = 1
                self?.activityIndicatorHome.isHidden = true
                self?.activityIndicatorHome.stopAnimating()
                self?.view.isUserInteractionEnabled = true
        })
    }
    
    //MARK: Action
    @objc func btnAddProductAction(_ sender: UIButton?) {
        let index = sender!.tag
        let indexPath = IndexPath(row: index, section: 0)
        if let cell = tableViewProductList.cellForRow(at: indexPath) as? ProductListCell {
            cell.viewStapper.value = cell.viewStapper.stepValue
            cell.viewStapper.alpha = 1
            cell.viewAddProduct.alpha = 0
            callAddToCart(categoryID: arrProductList[indexPath.row].valuForKeyString("Category_Id"), menuID:arrProductList[indexPath.row].valuForKeyString("Menu_Id"), menuQty: Int(cell.viewStapper!.value).description)
        }
    }
    
}

extension ProductListViewController:UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isLoading ? 15 : arrProductList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : ProductListCell = tableView.dequeueReusableCell(withIdentifier: CELL_IDENTIFIER_PRODUCT_LIST_CELL) as! ProductListCell
        
        if !arrProductList.isEmpty{
            cell.hideLoder()
            var dictData = typeAliasStringDictionary()
            
            if arrProductList.indices ~= indexPath.row {
                dictData = arrProductList[indexPath.row]
            }
            else {
                return cell
            }
            
            let stcurrency = SharedModel.getUpdateFlagInfo().valuForKeyString("currency")
            
            cell.imageViewProduct.setImageWith(URL(string: dictData.valuForKeyString("Menu_Image")), placeholderImage: UIImage(named: "no_image_available"), usingActivityIndicatorStyle: .gray)
            
            let priceLbelString = dictData.valuForKeyString("Discount_Label")
            let productPriceString = dictData.valuForKeyString("Menu_Price")
            
            let productDicString = stcurrency + " " + dictData.valuForKeyString("Menu_Discounted_Price")
            
            if !priceLbelString.isEmpty {
                cell.viewOff.alpha = 1
                cell.lblProductPriceOff.text = priceLbelString
            }
            else {
                cell.viewOff.alpha = 0
            }
            
            cell.lblProductName.text = dictData.valuForKeyString("Menu_Title")
            cell.lblProductDescription.text = dictData.valuForKeyString("Menu_Description")
            cell.lblProductPrice.text =  productDicString
            
            if !productDicString.isEmpty {
                let attributedString = NSMutableAttributedString(string: stcurrency + " " + productPriceString)
                attributedString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: NSNumber(value: NSUnderlineStyle.single.rawValue), range: NSMakeRange(0, attributedString.length))
                attributedString.addAttribute(NSAttributedString.Key.strikethroughColor, value: UIColor.red, range: NSMakeRange(0, attributedString.length))
                cell.lblProductDic.attributedText = attributedString
            }
            else { cell.lblProductDic.text = "" }
            
            cell.viewAddProductPlus.tag = indexPath.row
            cell.viewAddProduct.tag = indexPath.row
            cell.viewStapper.tag = indexPath.row
            
            cell.viewAddProductPlus.addTarget(self, action: #selector(btnAddProductAction(_:)), for: .touchUpInside)
            cell.viewAddProduct.addTarget(self, action: #selector(btnAddProductAction(_:)), for: .touchUpInside)
            
            cell.viewStapper.valueChanged = { [weak self] () in
                if cell.viewStapper.value == cell.viewStapper.minimumValue {
                    cell.viewStapper.alpha = 0;
                    cell.viewAddProduct.alpha = 1;
                }
                self?.callAddToCart(categoryID: self!.arrProductList[indexPath.row].valuForKeyString("Category_Id"), menuID: self!.arrProductList[indexPath.row].valuForKeyString("Menu_Id"), menuQty: Int(cell.viewStapper!.value).description)
            }
            
            cell.viewStapper.maximumValue = dictData.valuForKeyDouble("Menu_Max_Order_Qty")
            
            if dictData.valuForKeyInt("Cart_Qty") == 0 {
                cell.viewStapper.alpha = 0;
                cell.viewAddProduct.alpha = 1;
            } else {
                cell.viewStapper.value = dictData.valuForKeyDouble("Cart_Qty")
                cell.viewStapper.alpha = 1;
                cell.viewAddProduct.alpha = 0;
            }
            
            
            if indexPath.row == self.arrProductList.count - 1 {
                print("Start Index: \(self.startPage)")
                let page: Int = startPage + 1
                if (page <= totalPages) {
                    startPage = page;
                    self.callProductListWithSearch(startPage)
                }
            }
        }
        else {
            cell.showLoader()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return HEIGHT_PRODUCT_LIST_CELL
    }
    
    
}
