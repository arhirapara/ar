//
//  AppNavigationController.swift
//  Forevermark
//
//  Created by DNK062 on 31/03/20.
//  Copyright © 2020 DNK062. All rights reserved.
//

import UIKit

class AppNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationBar.isTranslucent = false
        self.navigationBar.barTintColor = UIColor.white
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }
    
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        
        super.pushViewController(viewController, animated: animated)
    }

}

extension UIViewController {
    
    /// CALL THIS FUNCATION FOR NEED ONLY MENU
    /// - Parameter onClick: onClick description
    func sideBarBackButton(_ onClick: @escaping (_ errorCode: String) -> Void) {
        
        var imageName = "icn_menu"
        if self.isBackButton {
            imageName = "icn_back"
        }
        
        let button:UIButton = UIButton(frame: CGRect(x: 0 , y: 0, width: 10, height: 10))
        button.tintColor = .black
        button.setImage(UIImage(named: imageName), for: .normal)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: button)
        button.block_setAction {[weak self] controll in
            onClick("")
            
            if self!.isBackButton{
                self?.navigationController?.popViewController(animated: true)
            }else{
                self?.sideMenuController?.revealMenu()
            }
        }
    }
    
    func setTitle(_ title:String) {
        navigationItem.title = title.localized
        navigationController?.navigationBar.titleTextAttributes =
            [NSAttributedString.Key.font: UIFont(name: defaultFontSemiBold, size: 16)!,
             NSAttributedString.Key.foregroundColor: UIColor.black]
    }
    
    func sideBarLeftButton(imageName:String ,_ onClick: @escaping (_ errorCode: String) -> Void) {
        
        let button:UIButton = UIButton(frame: CGRect(x: 0 , y: 0, width: 10, height: 10))
        button.tintColor = .black
        button.setImage(UIImage(named: imageName), for: .normal)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: button)
        button.block_setAction { controll in
            onClick("")
        }
    }
}
