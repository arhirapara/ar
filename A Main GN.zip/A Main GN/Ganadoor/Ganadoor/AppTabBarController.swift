//
//  AppTabBarController.swift
//  vincitore
//
//  Created by AR on 07/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

import UIKit

class AppTabBarController: UITabBarController, UITabBarControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        delegate = self
        sideBarBackButton { (str) in }
        
       let firstTabNavigationController =/*HomeViewController()*/ AppNavigationController.init(rootViewController: (HomeViewController(nibName: "HomeViewController", bundle: nil)))
       let secondTabNavigationControoller = AppNavigationController.init(rootViewController: (CategoryViewController(nibName: "CategoryViewController", bundle: nil)))
        //CategoryViewController() //AppNavigationController.init(rootViewController: )
       let thirdTabNavigationController = AppNavigationController.init(rootViewController: (SearchViewController(nibName: "SearchViewController", bundle: nil)))
        //SearchViewController() //AppNavigationController.init(rootViewController: )
//       let fourthTabNavigationControoller = AppNavigationController.init(rootViewController: (OffersViewController(nibName: "OffersViewController", bundle: nil))) // OffersViewController() //AppNavigationController.init(rootViewController: )
       let fifthTabNavigationController = AppNavigationController.init(rootViewController: (BasketViewController(nibName: "BasketViewController", bundle: nil)))
        //  BasketViewController() //AppNavigationController.init(rootViewController: )

        viewControllers = [firstTabNavigationController, secondTabNavigationControoller, thirdTabNavigationController, fifthTabNavigationController]
               
        let item1 = UITabBarItem(title: "APPTABBAR:Home".localized, image: UIImage(named: "icn_home"), selectedImage: UIImage(named: "icn_home_s")!.withRenderingMode(.alwaysOriginal))
        let item2 = UITabBarItem(title: "APPTABBAR:Categories".localized, image:  UIImage(named: "icn_category"), selectedImage: UIImage(named: "icn_category_s")!.withRenderingMode(.alwaysOriginal))
        let item3 = UITabBarItem(title: "APPTABBAR:Search".localized, image:  UIImage(named: "icn_search"), selectedImage: UIImage(named: "icn_search_s")!.withRenderingMode(.alwaysOriginal))
//        let item4 = UITabBarItem(title: "APPTABBAR:Offers".localized, image:  UIImage(named: "icn_offer"), selectedImage: UIImage(named: "icn_offer_s")!.withRenderingMode(.alwaysOriginal))
        let item5 = UITabBarItem(title: "APPTABBAR:Cart".localized, image:  UIImage(named: "icn_Cart"), selectedImage: UIImage(named: "icn_cart"))

        firstTabNavigationController.tabBarItem = item1
        secondTabNavigationControoller.tabBarItem = item2
        thirdTabNavigationController.tabBarItem = item3
//        fourthTabNavigationControoller.tabBarItem = item4
        fifthTabNavigationController.tabBarItem = item5
        
        UITabBar.appearance().tintColor = UIColor.init(hexString: "#DC6666")
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.font: UIFont(name: defaultFontSemiBold, size: 10)!], for: .normal)
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.font: UIFont(name: defaultFontSemiBold, size: 10)!], for: .selected)
        
        tabBar.selectionIndicatorImage = createSelectionIndicator(color: UIColor.init(hexString: "#DC6666"), size: CGSize(width: tabBar.frame.width/CGFloat(tabBar.items!.count), height: tabBar.frame.height), lineHeight: 2.0)
    }
    
    
    func createSelectionIndicator(color: UIColor, size: CGSize, lineHeight: CGFloat) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(size, false, 0)
        color.setFill()
        UIRectFill(CGRect(x: 8, y: size.height - lineHeight, width: size.width - 8, height: lineHeight))
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        print(viewController, tabBarController)
//        if let vc = (self.viewControllers?[3] as? AppNavigationController)?.children[0] as? BasketViewController {
//            vc.hidesBottomBarWhenPushed = true
//        }
    }
    
}
