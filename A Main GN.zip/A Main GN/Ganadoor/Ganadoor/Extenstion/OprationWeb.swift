//
//  OprationWeb.swift
//  JODHANI
//
//  Created by DNK157 on 03/01/20.
//  Copyright © 2020 DNK KISHAN. All rights reserved.
//
import Foundation

import UIKit



func callRestApi(_ methodName: String, methodType: METHOD_TYPE, parameters: typeAliasDictionary, contentType:CONTENT_TYPE,showLoding: Bool,onCompletion: @escaping (_ dictServiceContent: typeAliasDictionary) -> Void, onFailure: @escaping (_ errorCode: String) -> Void)
{
    guard let API_ROOT = UserDefaults.standard.object(forKey: "ROOT_API") as? String else {
        showAlertWithTitle(title: MSG_TITLE, message: "Please Enter Proper URL." , type: .WARNING)
        return
    }
    
    
    if showLoding {
        showLoder()
    }
    if Reachability.isConnectedToNetwork(){
        print("Internet Connection Available!")
        _ = DispatchSemaphore (value: 0)
        
        var dictParameters: typeAliasDictionary = parameters
        var headerToken = ""
        
        if SharedModel.getHeaderToken() == ""{
            headerToken =  "hp/R7xYbycq9wzyGeRwFFbG9mDlL/DgtjY01eeyvUCg="
        }
        else {
            headerToken = SharedModel.getHeaderToken()
        }
        
        dictParameters[REQ_MethodName] = methodName as AnyObject
        dictParameters[REQ_Header] = headerToken as AnyObject
        dictParameters[REQ_Random_No] = UUID().uuidString as AnyObject
        
        //         var theRequest: URLRequest = URLRequest(url: URL(string: API_ROOT)!)
        var theRequest = URLRequest(url: URL(string: "http://test.wibrate.com/Vincitore/API/V1nQhUF51xOLvRHdp/VncNxO2y1Qv9P/eKG4Axk52QKY/")!,timeoutInterval: Double.infinity)
        
        dLog(message: "Call \(methodName) PARAMETERS:\(dictParameters)")
        var dataBody = Data()
        
        var stMethodType: String = ""
        
        switch methodType {
        case .GET:
            stMethodType = "GET"
            break
            
        case .POST:
            stMethodType = "POST"
            var params = dictParameters
            
            var stJson = (params.convertToJSonString()).trim()
            
            do {
                //  let key: Array<UInt8> = Array(KEY_FOR_REQ.utf8)
                //  let iv: Array<UInt8> = Array(IV_FOR_REQ.utf8)
                //                let aes = try AES(key:KEY_FOR_REQ , iv:IV_FOR_REQ) // aes128
                //                let encrypted = try aes.encrypt(Array(stJson.utf8))
                //                stJson = encrypted.toHexString()
                // let aes = try AES.init(key: key, blockMode: CBC.init(iv: iv), padding: .pkcs7)
                let aes = try AES.init(key: KEY_FOR_REQ.bytes, blockMode: CBC.init(iv: IV_FOR_REQ.bytes), padding: .pkcs7)
                let encrypted = try aes.encrypt(Array(stJson.utf8))
                let encData = Data(bytes: encrypted, count: Int(encrypted.count))
                stJson = encData.base64EncodedString(options: []) //NEW ENCRYPTION
                
            } catch {
                print(error)
            }
            var stPostData = "details=\(stJson)"
            print(stPostData)
            stPostData = stPostData.replace("+", withString: "%2B")
            //
            //                   theRequest.httpBody = stPostData.data(using: .utf8)
            //                   theRequest.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-type")
            //
            //                     theRequest.httpMethod = "POST"
            theRequest.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "content-type")
            
            theRequest.httpMethod = "POST"
            let postData =  stPostData.data(using: .utf8)
            
            theRequest.httpBody = postData
        default:
            break
        }
        
        dLog(message: " THEREQUEST:\(theRequest)")
        
        let dataTask = URLSession.shared.dataTask(with: theRequest as URLRequest, completionHandler: { (data, response, error) -> Void in
            
            //        semaphore.signal()
            
            DispatchQueue.main.async(execute: {
                if showLoding { hideLoder() }
                if (error != nil) {
                    print(error as Any)
                    //                    onFailure(String((error! as NSError).code))
                    onFailure("SERVERERROR".localized)
                } else {
                    do {
                        if data != nil {
                            let dictContent:typeAliasDictionary = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions()) as! typeAliasDictionary
                            let stResponse = dictContent.valuForKeyString("response")
                            var jsonResponse = ""
                            do {
                                //                                let aes = try AES(key: KEY_FOR_RES, iv: IV_FOR_RES)// aes128
                                //                                let decrypted = try aes.decrypt([UInt8](stResponse.toHexBytes()))
                                //                                jsonResponse = (String.init(bytes: decrypted, encoding: .utf8)?.trim())!
                                //                                jsonResponse = jsonResponse.replace("\0", withString: "")
                                //                                if jsonResponse != "" {
                                //                                    onCompletion(jsonResponse.convertToDictionary())
                                //                                }
                                
                                let aes:AES = try AES.init(key: KEY_FOR_RES.bytes, blockMode: CBC.init(iv: IV_FOR_RES.bytes), padding: .pkcs7)
                                let decdata:Data = Data.init(base64Encoded: stResponse)!
                                let decrypted = try aes.decrypt(Array(decdata))
                                let decDataRes = Data(bytes: decrypted, count: Int(decrypted.count))
                                jsonResponse = String(data: decDataRes, encoding: .utf8)!
                                if jsonResponse != "" {
                                    let dictFinalData = jsonResponse.convertToDictionary()
                                    print("Final Data : \(dictFinalData)")
                                    let status = dictFinalData.valuForKeyString("status")
                                    print("status : \(status)")
                                    if status == "1"{
                                        print("Final Token : \(dictFinalData.valuForKeyString("token"))")
                                        SharedModel.setHeaderToken(dictFinalData.valuForKeyString("token"))
                                        onCompletion(jsonResponse.convertToDictionary())
                                    }
                                    else if status == "0"{
                                        print("Method Name : \(methodName)")
                                        if methodName == "THJOPWVBCGFTYH" || methodName == "UHLPQERDVCHFYG" || methodName == "PQZMLAWNXIRBVG" || methodName == "VGTFKLPWVBCHGT" || methodName == "KLOSDEBNHXDVOQ" || methodName == "MKLSRFEVCHGYHB" {
                                            
                                            onCompletion(jsonResponse.convertToDictionary())
                                        }
                                        else {
                                            showAlertWithTitle(title: MSG_PROJECT_TITLE, message: dictFinalData.valuForKeyString("message"), type: .WARNING)
                                            onCompletion(jsonResponse.convertToDictionary())
                                        }
                                    }
                                    else if status == "2"{
                                        appDelegateObject().logOut()
                                    }
                                    else {
                                        onFailure("Failed")
                                    }
                                }
                                
                            } catch {
                                print(error)
                            }
                        }
                    } catch {
                        print(error)
                        return
                    }
                }
            })
        })
        
        dataTask.resume()
        //    semaphore.wait()
        
    }else{
        if showLoding { hideLoder() }
        
        let actionMenuView :  NoInterNet = UIView.fromNib()
        if var topController = UIApplication.shared.keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            topController.showPopUp(popupView: actionMenuView, gravity: .Center,isDismisOnBgClick:false)
        }
        
        actionMenuView.btnStoneFound.block_setAction { (click) in
            if var topController = UIApplication.shared.keyWindow?.rootViewController {
                while let presentedViewController = topController.presentedViewController {
                    topController = presentedViewController
                }
                topController.dismissMaskView()
            }
            callRestApi(methodName, methodType: methodType, parameters: parameters, contentType: contentType, showLoding: showLoding, onCompletion: { (responce) in
                onCompletion(responce)
                
            }, onFailure: { (isfaill) in
                onFailure(isfaill)
                
            })
        }
    }
}

func getReplaceCodeForKeys(_ stCode: String) -> String {
    var st_CodeNew: String = stCode
    st_CodeNew = st_CodeNew.replace("&", withString: "&amp;")
    st_CodeNew = st_CodeNew.replace("<", withString: "&lt;")
    st_CodeNew = st_CodeNew.replace(">", withString: "&gt;")
    st_CodeNew = st_CodeNew.replace("'", withString: "&apos;")
    st_CodeNew = st_CodeNew.replace("\"", withString: "&quot;")
    return st_CodeNew
}
func queryItems(dictionary: [String:Any]) -> String {
    var components = URLComponents()
    components.queryItems = dictionary.map {
        URLQueryItem(name: $0, value: ($1  as! String))
    }
    return (components.url?.absoluteString)!
}
//MARK:- Rest method privet Funcations
func generateBoundary() -> String {
    return "Boundary-\(NSUUID().uuidString)"
}
func createDataBody(withParameters params: typeAliasDictionary?, boundary: String) -> Data {
    
    let lineBreak = "\r\n"
    var body = Data()
    
    if let parameters = params {
        for (key, value) in parameters {
            
            
            if value is Data  {
                body.append(("--\(boundary + lineBreak)").data(using: .utf8)!)
                body.append(("Content-Disposition: form-data; name=\"\(key)\"").data(using: .utf8)!)
                body += ";filename=\"\(key).jpeg\"\r\n".data(using: .utf8)!
                body += "Content-Type: image/jpg \r\n\r\n".data(using: .utf8)!
                body += value as! Data
                body += lineBreak.data(using: .utf8)!
            }
            else {
                body.append(("--\(boundary + lineBreak)").data(using: .utf8)!)
                body.append(("Content-Disposition: form-data; name=\"\(key)\"\(lineBreak + lineBreak)").data(using: .utf8)!)
                body.append(("\((value as! String) + lineBreak)").data(using: .utf8)!)
            }
        }
        //body.append(("--\(boundary + lineBreak)").data(using: .utf8)!)
        
    }
    
    body.append(("--\(boundary + lineBreak)").data(using: .utf8)!)
    
    return body
}
