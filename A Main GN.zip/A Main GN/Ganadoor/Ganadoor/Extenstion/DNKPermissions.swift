//
//  DNKPermissions.swift
//  Cubber
//
//  Created by Dhaval Nagar on 08/08/19.
//  Copyright © 2019 com.DnkTechnology. All rights reserved.
//
import AVFoundation
import CoreLocation
import Contacts
import Photos


/// Enum for diffenrent Permission types
///
/// - camera: For camera use permission
/// - microphone: For microphone use permission
/// - locationWhenInUse: For location when in use  permission
/// - locationAlways: For location always in use  permission
/// - photoLibrary: For get photo library
/// - contacts: For get contacts
enum PermissionType:String {
    case camera = "camera"
    case microphone = "microphone"
    case locationWhenInUse = "location when in use"
    case locationAlways = "location always"
    case photoLibrary = "photos"
    case contacts = "contacts"
}


/// Enum for status of permission
///
/// - allowed: Returned when the user authorises usage for the requested permission.
/// - denied: Returned when the user taps on the Deny button on the iOS Permission alert.
enum PermissionStatus {
    case allowed
    case denied
}


enum LocationType {
    case whenInUse
    case always
}

import UIKit

/// DNKPermissions is library implemented to get permissions from user for different Apple Public APIs (camera,microphone,locationWhenInUse,locationAlways,photoLibrary,contacts) using single function.
/// Includes class functions to ask permissions and for open permission settings if user denies.
class DNKPermissions: NSObject , CLLocationManagerDelegate {
    
    static var sharedInstacne:DNKPermissions = DNKPermissions()
    static var permissionResult:((PermissionStatus)->Void)?
    static var status: PermissionStatus?
    public static var iscompulsory: Bool = false
    public static var locationManager:CLLocationManager = CLLocationManager()
    public static var locationType:LocationType = LocationType.whenInUse
    
     /// Class function to ask or prompt permiossion dialogue for given permission type. It includes completion handler which return PermissionStatus based on whether user denied or granted permission.
     ///
     /// - Parameters:
     ///   - type: Enum PermissionType for differnet permissions.
     ///   - result: returns completion hanlder with permission status.
     public class func askFor(_ type:PermissionType ,  result:  @escaping (PermissionStatus) -> Void ) {
        permissionResult = result
        switch type {
        case .camera:
            self.askForCamera()
            break
        case .microphone:
            self.askForMicrophone()
            break
        case .locationWhenInUse:
            locationType = .whenInUse
            self.askForLocation()
            break
        case .locationAlways:
            locationType = .always
            self.askForLocation()
            break
        case .photoLibrary:
            self.askForPhotoLibrary()
            break
        case .contacts:
            self.askForContacts()
            break
        }
    }
    
    private class func askForLocation() {
        locationManager.delegate = DNKPermissions.sharedInstacne
        switch locationType {
        case .whenInUse:
            locationManager.requestWhenInUseAuthorization()
        case .always:
            locationManager.requestAlwaysAuthorization()
        }
    }
    
    private class func askForMicrophone() {
        
        switch AVAudioSession.sharedInstance().recordPermission {
        case AVAudioSessionRecordPermission.granted:
            status =  .allowed
            self.permissionResult!(status!)
        case AVAudioSessionRecordPermission.denied:
            status =  .denied
            self.permissionResult!(status!)
        case AVAudioSessionRecordPermission.undetermined:
            AVAudioSession.sharedInstance().requestRecordPermission({ (granted) in
                if granted {
                    status =  .allowed
                    self.permissionResult!(status!)
                }
                else{
                    status =  .denied
                    self.permissionResult!(status!)
                }
            })
        @unknown default:
            status =  .denied
            self.permissionResult!(status!)
        }
    }
    
    private class func askForPhotoLibrary(){
        
        let authStatus = PHPhotoLibrary.authorizationStatus()
        switch authStatus {
        case .authorized:
            status =  .allowed
            self.permissionResult!(status!)
            break
        case .denied:
            status =  .denied
            self.permissionResult!(status!)
            break
        case .notDetermined,.restricted:
            PHPhotoLibrary.requestAuthorization { (astatus) in
                if astatus == .authorized {
                    status =  .allowed
                    self.permissionResult!(status!)
                }
                else {
                    status =  .denied
                    self.permissionResult!(status!)
                }
            }
            break
        @unknown default:
            status =  .denied
            self.permissionResult!(status!)
        }
        
    }
    
    //FOR CAMERA
    
    private class func askForCamera() {
        
       let cameraStatus = AVCaptureDevice.authorizationStatus(for: .video)
        
        switch cameraStatus {
        case .authorized    :
            status =  .allowed
            self.permissionResult!(status!)
            break
        case .denied        :
            status =  .denied
            self.permissionResult!(status!)
            break
        case .notDetermined , .restricted :
            AVCaptureDevice.requestAccess(for: AVMediaType.video) { response in
                if response {
                    status =  .allowed
                    self.permissionResult!(status!)
                } else {
                    status =  .denied
                    self.permissionResult!(status!)
                }
            }
            break
        @unknown default:
            status =  .denied
            self.permissionResult!(status!)
        }

    }
    
    //FOR CONTACTS
    
    class func askForContacts() {
        
        switch CNContactStore.authorizationStatus(for: .contacts) {
        case .authorized:
            status = .allowed
            permissionResult!(status!)
            break
        case .denied:
            status = .denied
            permissionResult!(status!)
            break
        case .restricted, .notDetermined:
            let store = CNContactStore()
            store.requestAccess(for: .contacts) { granted, error in
                if granted {
                    status = .allowed
                    permissionResult!(status!)
                } else {
                    status = .denied
                    permissionResult!(status!)
                }
            }
        @unknown default:
            status = .denied
            permissionResult!(status!)
        }
        
    }
    
    /// Use this function to show alert to user for open application permission settings for your application if permission is denied by user.
    /// Pass true in isCompulsory for force alert
    /// - Parameters:
    ///   - permissionType: type of permission
    ///   - isCompulsory:  true if want show alert with out cancel button
    ///   - completionHandler: will return Bool if user clicked yes or cancel
    class func showSettingsAlert(permissionType:PermissionType , isCompulsory:Bool ,_ completionHandler : @escaping (Bool) -> Void) {
        
        let message = "This app requires access to \(permissionType.rawValue) to proceed. Would you like to open settings and grant permission to \(permissionType.rawValue)?"
        
        let alert = UIAlertController(title: (Bundle.main.infoDictionary!["CFBundleDisplayName"] as! String), message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Open Settings", style: .default) { action in
            completionHandler(true)
            UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)
        })
        
        if !isCompulsory {
                alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { action in
                    completionHandler(false)
                })
        }
        UIApplication.shared.keyWindow?.rootViewController!.present(alert, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedAlways:
            DNKPermissions.permissionResult!(PermissionStatus.allowed)
            break
        case .authorizedWhenInUse:
            if DNKPermissions.locationType == .whenInUse {
                DNKPermissions.permissionResult!(PermissionStatus.allowed)
            } else {
                DNKPermissions.permissionResult!(PermissionStatus.denied)
            }
            
        case .denied:
            DNKPermissions.permissionResult!(PermissionStatus.denied)
            break
        default:
            break;
        }
    }
}

