//
//  Styleguide.swift
//
//  Created by Göksel Köksal on 18/06/16.
//  Copyright © 2016 Mangu. All rights reserved.
//

import UIKit

enum Color {
    static let black = UIColor.black
    static let tint = UIColor.green
}

enum Alpha {
    static let none     = CGFloat(0.0)
    static let veryLow  = CGFloat(0.05)
    static let low      = CGFloat(0.30)
    static let medium1  = CGFloat(0.40)
    static let medium2  = CGFloat(0.50)
    static let medium3  = CGFloat(0.60)
    static let high     = CGFloat(0.87)
    static let full     = CGFloat(1.0)
}

enum Font {
    static func withSize(_ size: CGFloat, weight: CGFloat) -> UIFont {
        return UIFont.systemFont(ofSize: size, weight: UIFont.Weight(rawValue: weight))
    }
}

extension TextStyle {
    
    
    /// FONT :- WorkSans-Bold SIZE:- 15 COLOR #787878
    static let HederBold = TextStyle(
        
        font:  UIFont.init(name: "WorkSans-Bold", size: 15.0) ?? Font.withSize(15, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.4705882353, green: 0.4705882353, blue: 0.4705882353, alpha: 1)
    )
    
    /// Font :WorkSans-Medium  Color :- #787878
       static let semiBold15 = TextStyle(
           font: UIFont.init(name: "WorkSans-SemiBold", size: 15.0) ?? Font.withSize(15, weight: UIFont.Weight.light.rawValue),
           color: #colorLiteral(red: 0.4705882353, green: 0.4705882353, blue: 0.4705882353, alpha: 1)
       )
    
    /// Font:- WorkSans-Medium  Color :- #787878
    static let placeHolder = TextStyle(
        font: UIFont.init(name: "WorkSans-Medium", size: 13.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.4705882353, green: 0.4705882353, blue: 0.4705882353, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #B3B3B3
    static let placeHolderMedium13 = TextStyle(
        font: UIFont.init(name: "WorkSans-Medium", size: 13.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.7019607843, green: 0.7019607843, blue: 0.7019607843, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #787878
    static let placeHolder15 = TextStyle(
        font: UIFont.init(name: "WorkSans-Medium", size: 15.0) ?? Font.withSize(15.0, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.4705882353, green: 0.4705882353, blue: 0.4705882353, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #787878
    static let placeHolderMedium = TextStyle(
        font: UIFont.init(name: "WorkSans-Medium", size: 15.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.4705882353, green: 0.4705882353, blue: 0.4705882353, alpha: 1)
    )
    
    /// Font:- WorkSans-Bold  Color :- #464646
    static let LoginText = TextStyle(
        font: UIFont.init(name: "WorkSans-Bold", size: 20.0) ?? Font.withSize(20, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.2745098039, green: 0.2745098039, blue: 0.2745098039, alpha: 1)
    )
    
    /// Font:- WorkSans-SemiBold  Color :- #464646
    static let productName = TextStyle(
        font: UIFont.init(name: "WorkSans-SemiBold", size: 16.0) ?? Font.withSize(16, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.2745098039, green: 0.2745098039, blue: 0.2745098039, alpha: 1)
    )
    
    /// Font:- WorkSans-SemiBold  Color :- #464646
    static let productName15 = TextStyle(
        font: UIFont.init(name: "WorkSans-SemiBold", size: 15.0) ?? Font.withSize(15, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.2745098039, green: 0.2745098039, blue: 0.2745098039, alpha: 1)
    )
    
    /// Font:- WorkSans-SemiBold  Color :- #969696
       static let productDescription = TextStyle(
           font: UIFont.init(name: "WorkSans-SemiBold", size: 13.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
           color: #colorLiteral(red: 0.5882352941, green: 0.5882352941, blue: 0.5882352941, alpha: 1)
       )
    
    /// Font:- WorkSans-SemiBold  Color :- #323232
    static let HeaderLabel = TextStyle(
        font: UIFont.init(name: "WorkSans-SemiBold", size: 15.0) ?? Font.withSize(15, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.1960784314, green: 0.1960784314, blue: 0.1960784314, alpha: 1)
    )
    
    /// Font:- WorkSans-SemiBold  Color :- #323232
    static let HeaderLabel16 = TextStyle(
        font: UIFont.init(name: "WorkSans-SemiBold", size: 14.0) ?? Font.withSize(14, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.1960784314, green: 0.1960784314, blue: 0.1960784314, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #828282
    static let categoryDescription = TextStyle(
        font: UIFont.init(name: "WorkSans-Medium", size: 15.0) ?? Font.withSize(15, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.5098039216, green: 0.5098039216, blue: 0.5098039216, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #828282
       static let categoryDescription14 = TextStyle(
           font: UIFont.init(name: "WorkSans-Medium", size: 13.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
           color: #colorLiteral(red: 0.5098039216, green: 0.5098039216, blue: 0.5098039216, alpha: 1)
       )
    
    /// Font:- WorkSans-Medium  Color :- #828282
          static let categoryDescription11 = TextStyle(
              font: UIFont.init(name: "WorkSans-Medium", size: 11.0) ?? Font.withSize(11, weight: UIFont.Weight.light.rawValue),
              color: #colorLiteral(red: 0.5098039216, green: 0.5098039216, blue: 0.5098039216, alpha: 1)
          )
    
    /// Font:- WorkSans-SemiBold  Color :- #5A5A5A
    static let subHeaderLabel = TextStyle(
        font: UIFont.init(name: "WorkSans-SemiBold", size: 14.0) ?? Font.withSize(14, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.3529411765, green: 0.3529411765, blue: 0.3529411765, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #5A5A5A
       static let productLabel = TextStyle(
           font: UIFont.init(name: "WorkSans-Medium", size: 12.0) ?? Font.withSize(12, weight: UIFont.Weight.light.rawValue),
           color: #colorLiteral(red: 0.3529411765, green: 0.3529411765, blue: 0.3529411765, alpha: 1)
       )
    
    /// Font:- WorkSans-Bold  Color :- #1E1E1E
    static let productPriceLabel = TextStyle(
        font: UIFont.init(name: "WorkSans-Bold", size: 13.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.1176470588, green: 0.1176470588, blue: 0.1176470588, alpha: 1)
    )
    
    /// Font:- WorkSans-Bold  Color :- #1E1E1E
    static let productPriceLabel14 = TextStyle(
        font: UIFont.init(name: "WorkSans-Bold", size: 14.0) ?? Font.withSize(14, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.1176470588, green: 0.1176470588, blue: 0.1176470588, alpha: 1)
    )
    
    /// Font :WorkSans-Medium  Color :- #787878
    static let productOfferLabel = TextStyle(
        font: UIFont.init(name: "WorkSans-Medium", size: 13.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.4705882353, green: 0.4705882353, blue: 0.4705882353, alpha: 1)
    )
    
    /// Font:- WorkSans-SemiBold  Color :- #ffffff
    static let createNewAccount = TextStyle(
        font: UIFont.init(name: "WorkSans-SemiBold", size: 20.0) ?? Font.withSize(20, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    )
    
    /// Font:- WorkSans-SemiBold  Color :- #ffffff
    static let offerLabel = TextStyle(
        font: UIFont.init(name: "WorkSans-SemiBold", size: 13.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #DC6666
    static let selectedLabel = TextStyle(
        font: UIFont.init(name: "WorkSans-Medium", size: 13.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.862745098, green: 0.4, blue: 0.4, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #ffffff
    static let mediumWhite17 = TextStyle(
        font: UIFont.init(name: "WorkSans-Medium", size: 17.0) ?? Font.withSize(17, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #ffffff
    static let mediumWhite15 = TextStyle(
        font: UIFont.init(name: "WorkSans-Medium", size: 15.0) ?? Font.withSize(15, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    )
    
    /// Font:- WorkSans-Bold  Color :- #ffffff
    static let boldWhite14 = TextStyle(
        font: UIFont.init(name: "WorkSans-Bold", size: 13.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #ffffff
    static let boldWhite = TextStyle(
        font: UIFont.init(name: "WorkSans-Bold", size: 16.0) ?? Font.withSize(16, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    )
    
    /// Font:- WorkSans-Bold  Color :- #DC6666
    static let themeLabelSize20 = TextStyle(
        font: UIFont.init(name: "WorkSans-Bold", size: 20.0) ?? Font.withSize(20, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.862745098, green: 0.4, blue: 0.4, alpha: 1)
    )
    
    /// Font:- WorkSans-SemiBold  Color :- #DC6666
    static let themeSemiBoldLabelSize18 = TextStyle(
        font: UIFont.init(name: "WorkSans-Bold", size: 13.0) ?? Font.withSize(13, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.862745098, green: 0.4, blue: 0.4, alpha: 1)
    )
    
    /// Font:- WorkSans-SemiBold  Color :- #DC6666
    static let themeLabelSize18 = TextStyle(
        font: UIFont.init(name: "WorkSans-SemiBold", size: 18.0) ?? Font.withSize(18, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.862745098, green: 0.4, blue: 0.4, alpha: 1)
    )
    
    /// Font:- WorkSans-Medium  Color :- #DC6666
    static let selectedLabelFontSize15 = TextStyle(
        font: UIFont.init(name: "WorkSans-Medium", size: 15.0) ?? Font.withSize(15, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.862745098, green: 0.4, blue: 0.4, alpha: 1)
    )
    
    /// Font:- WorkSans-SemiBold  Color :- #2F9F8E
    static let totalGreen15 = TextStyle(
        font: UIFont.init(name: "WorkSans-SemiBold", size: 14.0) ?? Font.withSize(14, weight: UIFont.Weight.light.rawValue),
        color: #colorLiteral(red: 0.1843137255, green: 0.6235294118, blue: 0.5568627451, alpha: 1)
    )
    
    
}

extension TextStyle {
    
    enum Button {
        static let action = TextStyle(
            font: Font.withSize(16.0, weight: UIFont.Weight.medium.rawValue),
            color: Color.tint
        )
    }
}
