//
//  LongClickButton.swift
//  SheetalGroup
//
//  Created by DNK157 on 18/01/20.
//  Copyright © 2020 DNKTechnologies. All rights reserved.
//

import UIKit

class LongClickButton: UIButton,UIGestureRecognizerDelegate {
    var touchStart:(() -> ())?
    var touchEnd:(() -> ())?

    override func awakeFromNib() {
        super .awakeFromNib()
        
    }
    
    func addLongPress(){
        let longPressGestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(sender:)))
        
        // do something
        self.addGestureRecognizer(longPressGestureRecognizer)
    }
    
    @objc func handleLongPress(sender: UILongPressGestureRecognizer) {
         guard let button = sender.view else {
             fatalError("could not get the button attached to the gesturerecognizer")
         }
         if sender.state == .ended {
             print("Long press Ended")
            guard let refresh = self.touchEnd else {return}
                       refresh()
         } else if sender.state == .began {
             print("Long press detected")
            guard let refresh = self.touchStart else {return}
                                  refresh()
         }
     }
}
