//
//  UpdateVersionView.swift
//  Tedalali


import UIKit
let MSG_APP_UPDATE                          = "This version of “Jodhani Brothers“  is no longer supported. Please update to the latest version."

class UpdateAppVersionView: UIView, UIGestureRecognizerDelegate {
    
    //MARK: Outlet
    @IBOutlet weak var viewBG: UIView!
    @IBOutlet weak var lblCurrenntVersion: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    
    @IBOutlet weak var viewBtnUpdate: UIView!
    @IBOutlet weak var btnUpdate: UIButton!
     var updateMessage: String? = MSG_APP_UPDATE
    
    //MARK:- Variable
    fileprivate let obj_AppDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    fileprivate var isUpdateCloseView: Bool = false
    fileprivate var dictAppData = typeAliasDictionary()
    fileprivate var stCurrentVersionData: String = ""
    
    override init(frame: CGRect) { super.init(frame: frame) }
    
    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    init(info stDiscription: String?, dictAppUpdatedata: typeAliasDictionary, stCurrentVersion: String) {
        
        super.init(frame: UIScreen.main.bounds)
        dictAppData = dictAppUpdatedata
        stCurrentVersionData = stCurrentVersion
        updateMessage = stDiscription
        loadXIB()
    }
    
    fileprivate func loadXIB() {
        self.alpha = 1
        let view = Bundle.main.loadNibNamed(String(describing: type(of: self)), owner: self, options: nil)?[0] as! UIView
        view.translatesAutoresizingMaskIntoConstraints = false;
        self.addSubview(view)
        
        //TOP
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: 0))
        
        //LEADING
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.leading, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.leading, multiplier: 1, constant: 0))
        
        //WIDTH
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.width, multiplier: 1, constant: 0))
        
        //HEIGHT
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.height, multiplier: 1, constant: 0))
        
        self.layoutIfNeeded()
        
        self.backgroundColor = UIColor(r: 0, g: 0, b: 0, a: 0.4)
         if var topController = UIApplication.shared.keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            topController.view.addSubview(self)
        }
 
        lblCurrenntVersion.text = NSLocalizedString("Current Version", comment: "") + " " + stCurrentVersionData
        lblDescription.text = NSLocalizedString(updateMessage!, comment: "")
        
        viewBG.alpha = 0;
        var sFrame: CGRect = viewBG.frame;
        sFrame.origin.y = -(viewBG.frame.height)
        viewBG.frame = sFrame;
        
        let velocity: CGFloat = 10
        let duration: CGFloat = 0.8
        let damping: CGFloat = 0.7
        
        UIView.animate(withDuration: TimeInterval(duration), delay: 0.1, usingSpringWithDamping: damping, initialSpringVelocity: velocity, options: UIView.AnimationOptions.beginFromCurrentState, animations: { self.viewBG.alpha = 1; self.viewBG.center = CGPoint(x: self.frame.width / 2, y: self.frame.height / 2); }, completion: nil)
    }
    
    //MARK:- Action
    @IBAction func btnCloseAction() {
        UIView.animateKeyframes(withDuration: 0.5, delay: 0.0, options: UIView.KeyframeAnimationOptions.beginFromCurrentState, animations: {
            var frame = self.viewBG.frame
            frame.origin.y = self.frame.maxY + frame.height
            self.viewBG.frame = frame
        }, completion: { (finished) in
            UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.beginFromCurrentState, animations: { self.alpha = 0 }, completion:{ (finished) in self.removeFromSuperview() })
        })
    }
        
    @IBAction func btnUpdateVersionAction() {
        UIApplication.shared.openURL(NSURL(string: "https://itunes.apple.com/app/id1155376337")! as URL)
    }
}
