//
//  Design Color.swift
//  JODHANI
//
//  Created by DNK062 on 07/02/20.
//  Copyright © 2020 DNK KISHAN. All rights reserved.
//


/*
white alternet bg : #FFFFFF
gray alternet bg : #FAFAFA

title bg : #F0F0F0

line color : #F0F0F0

*/

