//
//  DNKActionSheet.swift
//  Romil
//
//  Created by KISHAN on 4/24/19.
//  Copyright © 2019 Kishan Sutariya. All rights reserved.
//

import Foundation
import UIKit
let MSG_TITLE           = "Tembo"
let MSG_PROJECT_TITLE   = "Tembo"
let CANCEL_TITLE        = "CANCEL"

class DNKAlertActionView : NSObject{
    /// SHOW Yes or No Popup
    ///
    /// - Parameters:
    ///   - title: pass title of alertVIew
    ///   - message: passmessage of alertview
    ///   - onSelection: deleget that retun selection
    internal func showYesNoAlertView (_ title:String ,message: String,onSelection: @escaping (_ title: String) -> Void){
        
        var allertitle = title;
        if title.isEmpty{
            allertitle = MSG_TITLE;
        }
        let alertController = UIAlertController.init(title: allertitle, message: message, preferredStyle: UIAlertController.Style.alert)

        alertController.addAction(UIAlertAction.init(title: NSLocalizedString("Yes".localized, comment: ""), style: UIAlertAction.Style.default) { (action) in
            onSelection(action.title!)
        })
        
        alertController.addAction(UIAlertAction.init(title: NSLocalizedString("No".localized, comment: ""), style: UIAlertAction.Style.destructive) { (action) in
            onSelection(action.title!)
        })
        
        if var topController = UIApplication.shared.keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            topController.present(alertController, animated: true, completion: nil)
        }
    }
    
    /// SHOW Ok Popup
    ///
    /// - Parameters:
    ///   - title: pass title of alertVIew
    ///   - message: passmessage of alertview
    ///   - onSelection: deleget that retun selection
    internal func showOkAlertView (_ title:String ,message: String,onSelection: @escaping (_ title: String) -> Void){
        var allertitle = title;
        if title.isEmpty{
            allertitle = MSG_TITLE;
        }
        let alertController = UIAlertController.init(title: allertitle, message: message, preferredStyle: UIAlertController.Style.alert)
        
        alertController.addAction(UIAlertAction.init(title: NSLocalizedString("OK".localized, comment: ""), style: UIAlertAction.Style.default) { (action) in
            onSelection(action.title!)
        })
    
        
        if var topController = UIApplication.shared.keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            topController.present(alertController, animated: true, completion: nil)
        }
    }

    /// show action sheet for selection
    ///
    /// - Parameters:
    ///   - title: passtitle
    ///   - message: pass message
    ///   - buttonTitle: pass button title as a string array
    ///   - isIncludeCancelButton: pass true false for show cancel button
    ///   - onSelection: delegate retun selected button title includeing cancel
    internal func showActionAlertView (_ title:String ,message: String,buttonTitle : [String],isIncludeCancelButton:Bool, alertType: UIAlertController.Style ,onSelection: @escaping (_ title: String) -> Void){
        
        var allertitle = title;
        if title.isEmpty{
            allertitle = MSG_TITLE;
        }
        let alertController = UIAlertController.init(title: allertitle, message: message, preferredStyle: alertType)
        
        for i in 0..<buttonTitle.count {
            alertController.addAction(UIAlertAction.init(title: NSLocalizedString(buttonTitle[i], comment: ""), style: UIAlertAction.Style.default) { (action) in
                onSelection(action.title!)
            })
        }
        
        if isIncludeCancelButton {
            alertController.addAction(UIAlertAction.init(title: NSLocalizedString(CANCEL_TITLE, comment: ""), style: UIAlertAction.Style.cancel) { (action) in
                onSelection(action.title!)
            })
        }
        
        if var topController = UIApplication.shared.keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            topController.present(alertController, animated: true, completion: nil)
        }
    }
    
    
}
