//
//  NSArray+sum.h
//  Demo
//
//  Created by DNK157 on 3/23/19.
//  Copyright © 2019 DNK. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSArray (sum)
-(NSNumber *)sumofArray;
@end

NS_ASSUME_NONNULL_END
