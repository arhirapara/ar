//
//  DNKTableNoDataView.swift
//  JBBROS
//
//  Created by DNK157 on 28/06/19.
//  Copyright © 2019 DNKTechnologies. All rights reserved.
//

import UIKit
let DNKTableNoDataViewLABELTAG = 3899271
let DNKTableNoDataViewIMAGETAG = 3899272

/*
 Please use this coding in you appdelegate class to enable automatic
 func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
 UITableView().noDataListioner()
 return true
 }
 
 */

/// use UITableView().noDataListioner() in appdelegate click here for more details 
class DNKTableNoDataView: UIView {
    
    @IBOutlet weak var btnGotoNavigation: UIButton!
    var btnClickEvent:(()->Void)?
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    
    @IBAction func btnClick(_ sender: UIButton) {
        guard let click = btnClickEvent else { return }
        click()
    }
}

//LOGIC FOR ADD NO DATA VIEW IN ALL ARE GOES HERE

extension UIView{
    class func DNKTableViewfromNib<T: UIView>() -> T {
        return Bundle.main.loadNibNamed(String(describing: T.self), owner: nil, options: nil)![0] as! T
    }
    
    func DNKTableViewLableWithTag(_ tag:Int) -> UILabel {
        if let lable = self.viewWithTag(tag){
            return lable as! UILabel
        }
        return  UILabel()
    }
    func DNKTableViewImageViewWithTag(_ tag:Int) -> UIImageView {
        if let lable = self.viewWithTag(tag){
            return lable as! UIImageView
        }
        return  UIImageView()
    }
    
}

extension UITableView {
    
    func click() {
        if appDelegateObject()._table_view_navigation == .TABLE_VIEW_NAVIGATION_HOME {
            appDelegateObject().showHome()
        }
        else if appDelegateObject()._table_view_navigation == .TABLE_VIEW_NAVIGATION_DUMMY {
            print("OK")
        }
    }
    
    @objc func swizzled_ReloadData() {
        
        swizzled_ReloadData()
        
        if self.showNoDataView{
            if  let method = self.dataSource?.numberOfSections?(in: self){
                if method > 0{
                    if  let count = self.dataSource?.tableView(self, numberOfRowsInSection: 0){
                        if count > 0{
                            //SOME DATA FOUND PLEASE HIDE THE VIEW OF NO DATA FOUND THANKS FOR READ
                            self.backgroundView = nil
                            
                        }else{
                            
                            let holdSuccessView: DNKTableNoDataView = UIView.DNKTableViewfromNib()
                            holdSuccessView.frame  = self.bounds
                            self.backgroundView = holdSuccessView
                            holdSuccessView.btnClickEvent = { () in
                                self.click()
                            }
                            if hideShowButtion {
                                holdSuccessView.btnGotoNavigation.isHidden = false
                                holdSuccessView.btnGotoNavigation.setTitle(buttonTitleMessage, for: .normal)
                            }
                            else {
                                holdSuccessView.btnGotoNavigation.isHidden = true
                                holdSuccessView.btnGotoNavigation.setTitle(buttonTitleMessage, for: .normal)
                            }
                            self.DNKTableViewLableWithTag(DNKTableNoDataViewLABELTAG).text = self.noDataMessage
                            self.DNKTableViewImageViewWithTag(DNKTableNoDataViewIMAGETAG).image = self.noDataImage
                            print("THERE IS NO DATA FOUND")
                            
                        }
                    }
                }else{
                    
                    let holdSuccessView: DNKTableNoDataView = UIView.DNKTableViewfromNib()
                    holdSuccessView.frame  = self.bounds
                    self.backgroundView = holdSuccessView
                    self.DNKTableViewLableWithTag(DNKTableNoDataViewLABELTAG).text = self.noDataMessage
                    self.DNKTableViewImageViewWithTag(DNKTableNoDataViewIMAGETAG).image = self.noDataImage
                    print("THERE IS NO DATA FOUND")
                    
                    
                }
                
            }else{
//                let holdSuccessView: DNKTableNoDataView = UIView.DNKTableViewfromNib()
//                holdSuccessView.frame  = self.bounds
//                self.backgroundView = holdSuccessView
//                self.DNKTableViewLableWithTag(DNKTableNoDataViewLABELTAG).text = self.noDataMessage
//                self.DNKTableViewImageViewWithTag(DNKTableNoDataViewIMAGETAG).image = self.noDataImage
                print("THERE IS NO DATA FOUND")
            }
        }else{
            print("NOT DATA DISABLE")
            
        }
        
    }
    @IBInspectable var showNoDataView:Bool {
        set {
            self.layer.setValue(newValue, forKey: "ISSHOWNODATA")
        }
        get {
            if let message : Bool = self.layer.value(forKey:"ISSHOWNODATA") as? Bool {
                return message
            }else{
                return false
            }
        }
    }
    
    @IBInspectable var hideShowButtion:Bool {
        set {
            self.layer.setValue(newValue, forKey: "ISHIDESHOWBUTTION")
        }
        get {
            if let message : Bool = self.layer.value(forKey:"ISHIDESHOWBUTTION") as? Bool {
                return message
            }else{
                return false
            }
        }
    }
    
    @IBInspectable var buttonTitleMessage:String {
        set {
            self.layer.setValue(newValue, forKey: "BUTTONMESSAGE")
        }
        get {
            if let message : String = self.layer.value(forKey:"BUTTONMESSAGE") as? String {
                return message.localized
            }else{
                return ""//"Loding Data"
            }
        }
        
    }
    
    @IBInspectable var noDataMessage:String {
        set {
            self.layer.setValue(newValue, forKey: "NODATAMESSAGE")
        }
        get {
            if let message : String = self.layer.value(forKey:"NODATAMESSAGE") as? String {
                return message.localized
            }else{
                return ""//"Loding Data"
            }
        }
        
    }
    
    
    @IBInspectable var noDataImage: UIImage? {
        set {
            self.layer.setValue(newValue, forKey: "NODATAImage")
        }
        get {
            if let image : UIImage = (self.layer.value(forKey:"NODATAImage") as? UIImage) {
                return image
            }
            return UIImage()
        }
    }
    
    func noDataListioner(){
        let originalSelector = #selector(reloadData)
        let swizzledSelector = #selector(swizzled_ReloadData)
        
        //        let new = class_getInstanceMethod(UITableView.self, originalSelector)!
        //        let old = class_getClassMethod(UITableView.self, originalSelector)
        //        if new == old{
        //            print("EQUAL \n\n")
        //        }else{
        //            print("NOT EQAL \n\n")
        //        }
        self.DnkTableSwizzling(originalSelector, with: swizzledSelector)
    }
    
    func DnkTableSwizzling(_ oldSelector: Selector, with newSelector: Selector) {
        let oldMethod = class_getInstanceMethod(UITableView.self, oldSelector)!
        let newMethod = class_getInstanceMethod(UITableView.self, newSelector)!
        let oldImplementation = method_getImplementation(oldMethod)
        let newImplementation = method_getImplementation(newMethod)
        _ = method_setImplementation(oldMethod, newImplementation)
        _ = method_setImplementation(newMethod, oldImplementation)
        
    }
}



