//
//  Cubber_Enum.swift
//

import Foundation
/// THIS IS FOR service calling Content Type
///
/// - DUMMY: reguler data
/// - FORM_DATA: for image uploading use form data
/// - X_WWW_FORM: for www form data type
/// - RAW: for Row data type
enum CONTENT_TYPE {
    case DUMMY
    case FORM_DATA
    case X_WWW_FORM
    case RAW
}

public enum METHOD_TYPE: Int {
    case GET
    case POST
    case PUT
    case DELETE
}

public enum PAGE_TYPE :Int{
    case home, aboutus, show_events, reachus, calender, manufacturing_Facility, jb_grading
}

public enum ORDER_SUMMARY :Int{
    case ORDER_SUMMARY_BASKET
    case ORDER_SUMMARY_MYORDER
}
   
public enum Model : String {
    case simulator = "simulator/sandbox",
    iPod1          = "iPod 1",
    iPod2          = "iPod 2",
    iPod3          = "iPod 3",
    iPod4          = "iPod 4",
    iPod5          = "iPod 5",
    iPad2          = "iPad 2",
    iPad3          = "iPad 3",
    iPad4          = "iPad 4",
    iPhone4        = "iPhone 4",
    iPhone4S       = "iPhone 4S",
    iPhone5        = "iPhone 5",
    iPhone5S       = "iPhone 5S",
    iPhone5C       = "iPhone 5C",
    iPadMini1      = "iPad Mini 1",
    iPadMini2      = "iPad Mini 2",
    iPadMini3      = "iPad Mini 3",
    iPadAir1       = "iPad Air 1",
    iPadAir2       = "iPad Air 2",
    iPhone6        = "iPhone 6",
    iPhone6plus    = "iPhone 6 Plus",
    iPhone6S       = "iPhone 6S",
    iPhone6Splus   = "iPhone 6S Plus",
    unrecognized   = "?unrecognized?"
}

public enum RESULT_PAGE_TYPE: Int {
    case RESULT_DUMMY
    case MY_ENQUIRY
    case SEARCH_DIAMOND
    case MY_WISHLIST
    case MY_SAVED_SEARCH
    case MY_SALES_LEAD
}

public enum ADDRESS_TYPE: Int {
    case ADDRESS_DUMMY
    case ADD_ADDRESS
    case UPDATE_ADDRESS
    case BASKET_CHANGE_ADDRESS
}

public enum WEB_VIEW: Int {
    case WED_DUMMY
    case WEB_ABOUT_US
    case WEB_PRIVACY_POLICY
    case WEB_TERMS_CONDITION
}

public enum TABLE_VIEW_NAVIGATION: Int {
    case TABLE_VIEW_NAVIGATION_DUMMY
    case TABLE_VIEW_NAVIGATION_HOME
}

public enum HOME_SCREEN_NAVIGATION: Int {
    case HOME_SCREEN_DUMMY = 0
    case HOME_SCREEN_HOME = 1
    case HOME_SCREEN_CATEGOTY = 2
    case HOME_SCREEN_PRODUCT = 3
}

public enum LGD_SIDE_MENU: Int {
    
    case LGD_SIDE_MENU_DUMMY
    case LGD_SIDE_MENU_LOGIN
    case LGD_SIDE_MENU_DASHBOARD
    case LGD_SIDE_MENU_SEARCH_STONE
    case LGD_SIDE_MENU_DIAMOND_RESULT
    case LGD_SIDE_MENU_STONE_DETAIL
    case LGD_SIDE_MENU_MY_ENQUIRY
    case LGD_SIDE_MENU_MYWISHLIST
    case LGD_SIDE_MENU_RECENT_SEARCH
    case LGD_SIDE_MENU_NOTIFICATION
    case LGD_SIDE_MENU_SAVE_SEARCH
    case LGD_SIDE_MENU_MYACCOUNT
    case LGD_SIDE_MENU_SELLER_INFO
    case LGD_SIDE_MENU_CONTACT_DETAIL
    case LGD_SIDE_MENU_ABOUT_COMPANY
    case LGD_SIDE_MENU_EXECUTIVE
    case LGD_SIDE_REDIRECT_OUTSIDE
    case LGD_SIDE_REDIRECT_BROWSER
    case LGD_SIDE_REGISTER_SCREEN
    case LGD_SALES_LEAD
    case LGD_SUBSCRIPTION
    case LGD_SIDE_MENU_LOGOUT
    case LGD_SIDE_MENU_FORSE_LOGOUT
    case LGD_LOGIN_PAGE
    
    
    //    case LGD_SIDE_MENU_DUMMY
    //    case LGD_SIDE_MENU_SEARCH_STONE
    //    case LGD_SIDE_MENU_MY_ENQUIRY
    //    case LGD_SIDE_MENU_MYWISHLIST
    //    case LGD_SIDE_MENU_SAVE_SEARCH
    //    case LGD_SIDE_MENU_MYACCOUNT
    //    case LGD_SIDE_MENU_LOGOUT
    //    case LGD_SIDE_MENU
    //    case LGD_SIDE_MENU_DASHBOARD
    //    case LGD_SIDE_MENU_CONTACT_DETAIL
    //    case LGD_SIDE_MENU_FORSE_LOGOUT
    
}
 
 
