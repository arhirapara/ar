//
//  WebConstant.swift
//
//  Copyright © 2018 DNKTechnologies. All rights reserved.∫
//

import Foundation


let IV_FOR_REQ                      = "2#$)<[M!#$*&()17"
let KEY_FOR_REQ                     = "$%3})[(!#9&^)($$"

let IV_FOR_RES                      = "^&H{$@6^\\+-=@{}#"
let KEY_FOR_RES                     = "]!-/=&5(}{>$0D%3"


//let API_ROOT                                       = "http://test.wibrate.com/Vincitore/API/V1nQhUF51xOLvRHdp/VncNxO2y1Qv9P/eKG4Axk52QKY/"

//http://fmxindia.jorjoto.in/service/V1Android/V1HkljJHGasdhllasdgjhJHhjds/Tkplsn


let API_ROOT_IMAGE_URL                                    = "https://appdev.lgdtrade.com/V1anRuiasdJKGk/V1HkljJHGasdhllasdgjhJHhjds/DALHDBQOUBHZAY"


// Response Parameter
let PARAMETER_KEY                               = "PARAMETER_KEY"
let PARAMETER_VALUE                             = "PARAMETER_VALUE"
let PARAMETER_TYPE_ID                           = "Parameter_Type_Id"
let PARAMETER_IMAGE_LINK                        = "Parameter_Image_Link"
let PARAMETER_SEQUENCE_NO                       = "Sequence_No"


// Parameter Type Id
let PARAMETER_TYPE_SHAPE                        = "1"
let PARAMETER_TYPE_FANCY_SIZE                   = "2"
let PARAMETER_TYPE_COLOR                        = "3"
let PARAMETER_TYPE_CLARITY                      = "4"
let PARAMETER_TYPE_LAB                          = "5"
let PARAMETER_TYPE_CUT                          = "6"
let PARAMETER_TYPE_SYMMETRY                     = "7"
let PARAMETER_TYPE_POLISH                       = "8"
let PARAMETER_TYPE_FLUORESCENCE                 = "9"
let PARAMETER_TYPE_FANCY_COLOR                  = "10"
let PARAMETER_TYPE_FANCY_OVERTONE               = "11"
let PARAMETER_TYPE_FANCY_INTENSITY              = "12"
let PARAMETER_TYPE_SHADE                        = "14"
let PARAMETER_METAL_TYPE                        = "15"
let PARAMETER_TYPE_COUNTRY                      = "16"
let PARAMETER_TYPE_BUSINESS                     = "17"
let PARAMETER_TYPE_TYPE                         = "18"

// Side Menu parameter Type Id
let PARAMETER_TYPE_Search_Stone                 = "1"
let PARAMETER_TYPE_My_Enquiry                   = "2"
let PARAMETER_TYPE_My_Wishlist                  = "3"
let PARAMETER_TYPE_Saved_Search                 = "4"
let PARAMETER_TYPE_My_Account                   = "5"
let PARAMETER_TYPE_Logout                       = "6"

//Constant Variable
let KEY_IOS_DEVICE                              = "1"

let KEY_USER_NAME                               = "KEY_USER_NAME"
let KEY_PASSWORD                                = "KEY_PASSWORD"

//Service Name
let API_User_Registration                       = "KQRFGCVBFHTJKN"
let API_User_Login                              = "RFGDYHJKCHYFBV"
let API_Super_Home                              = "SKMLBHCGYRFBVO"
let API_Category_List_With_Search               = "THJOPWVBCGFTYH"
let API_List_Delivery_Address                   = "PQZMLAWNXIRBVG"
let API_Remove_Delivery_Address                 = "UKLPQRFCGFYHBV"
let API_Service_Update_Flag                     = "UPMHYGVFRDCVHP"
let API_Notification_List                       = "MKLSRFEVCHGYHB"
let API_Add_Update_Delivery_Address             = "BUKLPRFDCXYUMQ"
let API_City_List_With_Search                   = "POZXMNQWJHTRCV"
let API_My_Order_List                           = "KLOSDEBNHXDVOQ"
let API_Product_List_With_Search                = "UHLPQERDVCHFYG"
let API_Single_Order_Detail                     = "OHXWHMLHAYVFSI"
let API_Add_To_Cart_Remove_Cart                 = "LUJHTRFVCGDRTG"
let API_View_Cart                               = "VGTFKLPWVBCHGT"
let API_Place_Order                             = "HQPMLZJGTFDGSJ"
let API_Get_Order_Status                        = "GYHQOLMNVBTYDF"
let API_Clear_Cart                              = "QXMKJUPLSGCRFH"
let API_Share                                   = "SQLPJHGFVBNYXD"
