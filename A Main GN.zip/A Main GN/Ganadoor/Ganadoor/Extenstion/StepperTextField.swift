//
//  StepperTextField.swift
//  SheetalGroup
//
//  Created by DNK157 on 10/01/20.
//  Copyright © 2020 DNKTechnologies. All rights reserved.
//

import UIKit

class StepperTextField: UITextField,UITextFieldDelegate {
    
    var maximumValue : Float? = 1000000.0
    var minimumValue : Float? = -10000000.0
    var gapValue : Float? = 1.0
    
    var leftTitle : String? = "-"
    var rightTitle : String? = "+"
    var valueChange:(() -> ())?
    
    override func awakeFromNib() {
        self.adjustsFontSizeToFitWidth = true;
        self.minimumFontSize = 9.0; //Optionally specify min size
        
        delegate = self
        //LEFT SIDE BUTTON
        leftViewMode = .always
        
        let leftSidebutton = LongClickButton.init(frame: CGRect(x: 0, y: 0, width: 30, height: 30))
        leftSidebutton.setTitle(leftTitle, for: .normal)
        leftSidebutton.tintColor = .black
        leftSidebutton.setTitleColor(.black, for: .normal)
        leftSidebutton.addLongPress()
        let leftsideview = UIView.init(frame: CGRect(x: 0, y: 0, width: 31, height: 30))
        leftsideview.addSubview(leftSidebutton)
        
        let leftsideLineview = UIView.init(frame: CGRect(x: 30, y: 5, width: 0.5, height: 20))
        leftsideview.addSubview(leftsideLineview)
        leftsideLineview.backgroundColor = .black
        
        leftView = leftsideview
        
        
        
        //right SIDE BUTTON
        rightViewMode = .always
        
        let rightSidebutton = LongClickButton.init(frame: CGRect(x: 1, y: 0, width: 30, height: 30))
        rightSidebutton.setTitle(rightTitle, for: .normal)
        rightSidebutton.addLongPress()
        let rightsideview = UIView.init(frame: CGRect(x: 0, y: 0, width: 31, height: 30))
        rightsideview.addSubview(rightSidebutton)
        
        let righsideLineview = UIView.init(frame: CGRect(x: 0, y: 5, width: 0.5, height: 20))
        rightsideview.addSubview(righsideLineview)
        righsideLineview.backgroundColor = .black
        rightView = rightsideview
        
        rightSidebutton.tintColor = .black
        rightSidebutton
            .setTitleColor(.black, for: .normal)
        var leftTimer: Timer?
        var rightTimer: Timer?

        leftSidebutton.block_setAction { (click) in
           let cuntValue = (self.getText() as NSString).floatValue
           let expected = cuntValue - self.gapValue!
           if self.minimumValue! > expected
           {
               //show message
           }else{
               self.text = "\(expected)"
           }
           guard let refresh = self.valueChange else {return}
           refresh()
        }
        
        leftSidebutton.touchStart = {()   in
            if (rightTimer != nil){
                rightTimer!.invalidate()
            }
            if (leftTimer != nil){
                leftTimer!.invalidate()
            }
         
            leftTimer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: { (time) in
                let cuntValue = (self.getText() as NSString).floatValue
                let expected = cuntValue - self.gapValue!
                if self.minimumValue! > expected
                {
                    //show message
                }else{
                    self.text = "\(expected)"
                }
                guard let refresh = self.valueChange else {return}
                refresh()
            })
        }
        
        leftSidebutton.touchEnd = {()   in
            if (rightTimer != nil){
                rightTimer!.invalidate()
            }
            if (leftTimer != nil){
                leftTimer!.invalidate()
            }
        }
        

        rightSidebutton.block_setAction { (click) in
            let cuntValue = (self.getText() as NSString).floatValue

            let expected = cuntValue + self.gapValue!
            self.text = "\(expected)"
            guard let refresh = self.valueChange else {return}
            refresh()
        }
        
        rightSidebutton.touchEnd = {()   in
            if (rightTimer != nil){
                rightTimer!.invalidate()
            }
            if (leftTimer != nil){
                leftTimer!.invalidate()
            }
        }
        rightSidebutton.touchStart = {()   in
            if (rightTimer != nil){
                rightTimer!.invalidate()
            }
            if (leftTimer != nil){
                leftTimer!.invalidate()
            }
            rightTimer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: { (time) in
                let cuntValue = (self.getText() as NSString).floatValue
                
                let expected = cuntValue + self.gapValue!
                self.text = "\(expected)"
                guard let refresh = self.valueChange else {return}
                refresh()
            })
            
        }
        isUserInteractionEnabled = true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let enteredText = string.trimmingCharacters(in: .whitespacesAndNewlines)
        
        let currentText = textField.text ?? ""
        let newText = (currentText as NSString).replacingCharacters(in: range, with: enteredText)
        return isValid(newText,maxIntegerDigit: 100,maxFractionDigit: 2,decimalSeparator: ".")
    }
    
    func hideStepper(){
        leftViewMode = .never
        rightViewMode = .never
        self.backgroundColor = "#eaeaea".hexToUIColor()
    }
    func showStepper(){
        leftViewMode = .whileEditing
        rightViewMode = .whileEditing
        self.backgroundColor = .white
    }
    
}
   private func isValid(_ string: String?, maxIntegerDigit integerDigit: Int, maxFractionDigit fractionDigit: Int, decimalSeparator separator: String) -> Bool {
       
       guard let value = string else {
           return false
       }
       
       // Default regex pattern
       var pattern = "^\\d{0,\(integerDigit)}(\\\(separator)\\d{0,\(fractionDigit)})?$"
       if (string?.hasPrefix("-"))! {
           pattern = "^-\\d{0,\(integerDigit)}(\\\(separator)\\d{0,\(fractionDigit)})?$"
       }else if (string?.hasPrefix("+"))! {
           pattern = "^+\\d{0,\(integerDigit)}(\\\(separator)\\d{0,\(fractionDigit)})?$"
       }
       
        
       
       do {
           let regex = try NSRegularExpression(pattern: pattern, options: .caseInsensitive)
           let result = regex.matches(in: value, options: [], range: NSMakeRange(0, value.count))
           
           return (result.count > 0)
           
       } catch {
           return false
       }
   }
