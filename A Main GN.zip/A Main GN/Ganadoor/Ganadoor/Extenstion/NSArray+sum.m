//
//  NSArray+sum.m
//  Demo
//
//  Created by DNK157 on 3/23/19.
//  Copyright © 2019 DNK. All rights reserved.
//

#import "NSArray+sum.h"

@implementation NSArray (sum)
-(NSNumber *)sumofArray{
    @try {
        return [self valueForKeyPath:@"@sum.doubleValue"];
     } @catch (NSException *exception) {
        return [NSNumber numberWithInt:0];
    } @finally {
    }
}
@end
