//
//  ThemeFile.swift
//  JODHANI
//
//  Created by DNK062 on 06/01/20.
//  Copyright © 2020 DNK KISHAN. All rights reserved.
//

import Foundation

extension UIColor {
    static let themeSelectionColor = UIColor.black//(hexString: "#58B1D1")
    static let fontLightGrayColor = UIColor(hexString: "#828282")
    
    static let redStatusColor = UIColor(hexString: "#A22B2E")
    static let yellowStatusColor = UIColor(hexString: "#AE731A")
//    static let fontDarkGrayColor = UIColor(hexString: "#464646")
//    static let themeLightSelectionColor = UIColor(hexString: "#EBF0f7")
}
