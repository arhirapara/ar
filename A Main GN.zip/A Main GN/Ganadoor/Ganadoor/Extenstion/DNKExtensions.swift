//
//  DNKExtensions.swift
//  DNK LIB PROJECT
//
//  Copyright © 2018 DNKTechnologies. All rights reserved.
//
// THIS CLass is write by kishan Sutariya also content VKExtensions.swift most off method with out other dependancy try to add without import any other class YOUR MOST WELCOME For any better soloution and update of this class
// NOTE: You need to add `CommonParameter.swift` for typeAliasDictionary and typeAliasStringDictionary

import Foundation
import UIKit


fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l < r
    case (nil, _?):
        return true
    default:
        return false
    }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l > r
    default:
        return rhs < lhs
    }
}

public enum Gravity: Int {
    case Top = 0
    case Center = 1
    case Bottom = 2
    case Right = 3
}

let appDelegateVar =  UIApplication.shared.delegate as! AppDelegate
func appDelegateObject() -> AppDelegate {
    return UIApplication.shared.delegate as! AppDelegate
}

extension UIViewController {
    
    //THIS IS RETUREN APP DELEGARE
    func appDelegate() -> AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    /// get parent view controller from any where
    var parentViewController: UIViewController? {
        var parentResponder: UIResponder? = self
        while parentResponder != nil {
            parentResponder = parentResponder!.next
            if let viewController = parentResponder as? UIViewController {
                return viewController
            }
        }
        return nil
    }
    
    func showPopUp(popupView:UIView, gravity:Gravity) {
        showPopUp(popupView: popupView, gravity: gravity, isDismisOnBgClick: true)
    }
    /// Showing popup on the screen with gravity (LOL!! `Gravity` IS enam please check before use) see `dismissMaskView` for remove from view
    ///
    /// - Parameters:
    ///   - popupView: your view what you want to show as popup
    ///   - gravity: See Gravity line no 31
    func showPopUp(popupView:UIView, gravity:Gravity,isDismisOnBgClick:Bool,Istag:Int? = 666) {
        if (self.view.viewWithTag(Istag!)) != nil {
            return  // already setted..
        } else {
            let maskView = UIView()
            maskView.tag = Istag!
            maskView.frame = UIScreen.main.bounds
            maskView.backgroundColor = UIColor.init(white: 0, alpha: 0.5)
            popupView.center = CGPoint(x: UIScreen.main.bounds.width/2, y: UIScreen.main.bounds.height/2)
            switch gravity{
                
            case .Top:
                do{
                    popupView.setY(y: 0)
                }
            case .Center:do{   popupView.center = CGPoint(x: UIScreen.main.bounds.width/2, y: UIScreen.main.bounds.height/2)
                }
                
            case .Right: do {
                var topSafeAreaHeight: CGFloat = 0
                var bottomSafeAreaHeight: CGFloat = 0
                
                if #available(iOS 11.0, *) {
                    let window = UIApplication.shared.windows[0]
                    let safeFrame = window.safeAreaLayoutGuide.layoutFrame
                    topSafeAreaHeight = safeFrame.minY
                    bottomSafeAreaHeight = window.frame.maxY - safeFrame.maxY
                }
                
                popupView.setX(x: screenWidth * 0.65)
                popupView.setY(y: 0)
                maskView.backgroundColor = UIColor.init(white: 0, alpha: 0.5)
                }
            case .Bottom:
                do{
                    popupView.setY(y: UIScreen.main.bounds.height-popupView.frame.height)
                }
            }
            if isDismisOnBgClick{
                let TapButton : UIButton = UIButton.init(frame: UIScreen.main.bounds)
                maskView.addSubview(TapButton)
                TapButton.addTarget(self, action: #selector(dismissMaskView), for: .touchUpInside)
            }
            maskView.addSubview(popupView)
            
            
            if gravity == .Right{
                if var topController = UIApplication.shared.keyWindow?.rootViewController {
                    while let presentedViewController = topController.presentedViewController {
                        topController = presentedViewController
                    }
                    topController.view.addSubview(maskView)
                    UIView.animate(withDuration: 0.3, delay: 0.1, options: UIView.AnimationOptions.curveEaseInOut, animations: {
                        popupView.setX(x: screenWidth * 0.65)
                        maskView.backgroundColor = UIColor.init(white: 0, alpha: 0.5)
                    })
                    { (finished) in
                        UIApplication.shared.endIgnoringInteractionEvents()
                    }
                }
                
            }else{
                
                // This view will be added to some view
                UIView.animate(withDuration: 0.5, delay: 0.0, usingSpringWithDamping: 0.6, initialSpringVelocity: 30.0, options: .curveEaseInOut, animations: {
                    //...
                    //                self.appDelegate.window?.addSubview(maskView)
                    if var topController = UIApplication.shared.keyWindow?.rootViewController {
                        while let presentedViewController = topController.presentedViewController {
                            topController = presentedViewController
                        }
                        topController.view.addSubview(maskView)
                    }
                    
                }, completion: { (finish) in
                    
                })
            }
        }
    }
    
    /// dismiss method to popup view
    @objc func dismissMaskView()
    {
        if var topController = UIApplication.shared.keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            if let theMask = topController.view.viewWithTag(666) {
                theMask.removeFromSuperview()
            }
        }
    }
    
    func dismissMaskView(_ Istag:Int? = 666)
    {
        if var topController = UIApplication.shared.keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            if let theMask = topController.view.viewWithTag(Istag!) {
                theMask.removeFromSuperview()
            }
        }
    }
}

// KeyBoard Dismiss
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

extension UITextView {
    
    
    open override func awakeFromNib() {
        //        self.autocapitalizationType = UITextAutocapitalizationType.none;
        //        self.autocorrectionType = UITextAutocorrectionType.no;
        //
        //        let view = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: self.frame.height))
        //
        //        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(UITextView.viewClick))
        //        view.addGestureRecognizer(tapGesture)
        //        view.isUserInteractionEnabled = true
        //        view.isMultipleTouchEnabled = true
        //
        //        let toolbar = UIToolbar.init()
        //        toolbar.sizeToFit()
        //        let barFlexible = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: self, action: nil)
        //
        //        let barBtnDone = UIBarButtonItem.init(image: #imageLiteral(resourceName: "icn_keyboard"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(btnBarDoneAction))
        //        barBtnDone.tintColor = UIColor.black
        //        toolbar.barTintColor = UIColor.lightGray
        //        toolbar.tintColor = UIColor.black
        //        toolbar.items = [barFlexible,barBtnDone]
        //        toolbar.alpha = 0.9
        
        //        self.inputAccessoryView = toolbar
    }
    
    @objc func viewClick() { self.becomeFirstResponder(); }
    @objc func btnBarDoneAction() { self.resignFirstResponder() }
    /// use this method while you need text from text field as there never crash and get "" alwasys string
    ///
    /// - Returns: return value description
    func getText(_ string : String)-> String{
        if (self.text?.count)! > 0{
            return self.text!
        }else{
            return string
        }
    }
    /// use this method while you need text from text field as there never crash and get "" alwasys string
    ///
    /// - Returns: <#return value description#>
    func getText()-> String{
        if (self.text?.count)! > 0{
            return self.text!
        }else{
            return ""
        }
    }
    
} //copy this code

extension UITextField {
    open override func awakeFromNib() {
        super.awakeFromNib()
        //        self.autocapitalizationType = UITextAutocapitalizationType.none;
        //        self.autocorrectionType = UITextAutocorrectionType.no;
        //
        //        let toolbar = UIToolbar.init()
        //        toolbar.sizeToFit()
        //        let barFlexible = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: self, action: nil)
        //        let barBtnDone = UIBarButtonItem.init(image: #imageLiteral(resourceName: "icn_menu"), style: UIBarButtonItemStyle.plain, target: self, action: #selector(btnBarDoneAction))
        //        barBtnDone.tintColor = UIColor.black
        //        toolbar.barTintColor = UIColor.lightGray
        //        toolbar.tintColor = UIColor.black
        //        toolbar.items = [barFlexible,barBtnDone]
        //        toolbar.alpha = 0.8
        //        self.inputAccessoryView = toolbar
    }
    
    /// use this method while you need text from text field as there never crash and get "" alwasys string
    ///
    /// - Returns: return value description
    func getText(_ string : String)-> String{
        if (self.text?.count)! > 0{
            return self.text!
        }else{
            return string
        }
    }
    /// use this method while you need text from text field as there never crash and get "" alwasys string
    ///
    /// - Returns: <#return value description#>
    func getText()-> String{
        if (self.text?.count)! > 0{
            return self.text!
        }else{
            return ""
        }
    }
    
    
    /// For cheking is user endet any value or not
    ///
    /// - Returns: return value description
    func isEmpty()-> Bool{
        if (self.text?.count)! > 0{
            return false
        }else{
            return true
        }
    }
    
    func viewClick() { self.becomeFirstResponder(); }
    
    @objc func btnBarDoneAction() { self.resignFirstResponder() }
    
    
    /// this method to set right side image view when you need to set also check parameters
    ///
    /// - Parameters:
    ///   - width: pass width of image you want
    ///   - image: pass image (NOTE: you need to pass UIImage)
    func setRightImageView(_ width: CGFloat, image: UIImage) {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: width , height: self.frame.height))
        let imageView: UIImageView = UIImageView().createImageView(CGRect(x: 0, y: 0, width: view.frame.width*0.7, height: view.frame.height*0.7), image: image, contentMode: .scaleAspectFit)
        view.addSubview(imageView)
        imageView.center = CGPoint(x: view.frame.width / 2, y: view.frame.height / 2)
        self.rightViewMode = UITextField.ViewMode.always;
        self.rightView = view;
    }
    
    
    /// to make space distance to right side
    ///
    /// - Parameter width: pass width what you want right side clean
    func setRightClearView(_ width: CGFloat) {
        let view = UIView(frame: CGRect(x: 0 , y: 0, width: width, height: self.frame.height))
        view.backgroundColor = UIColor.clear
        self.rightViewMode = UITextField.ViewMode.always;
        self.rightView = view;
    }
    
    
    /// to make space distance on left side
    ///
    /// - Parameter width:  pass width what you want left side clean
    func setLeftClearView(_ width: CGFloat) {
        let view = UIView(frame: CGRect(x: 0 , y: 0, width: width, height: self.frame.height))
        view.backgroundColor = UIColor.clear
        self.leftViewMode = UITextField.ViewMode.always;
        self.leftView = view;
    }
    
    
    /// this method to set left side image view when you need to set also check parameters
    ///
    /// - Parameters:
    ///   - width: pass width of image you want
    ///   - image: pass image (NOTE: you need to pass UIImage)
    func setLeftImageView(_ width: CGFloat, image: UIImage) {
        let view = UIView(frame: CGRect(x: 0 , y: 0, width: width + 10, height: 28))
        let imageView: UIImageView = UIImageView().createImageView(CGRect(x: 8 , y: 0, width: view.frame.width * 0.8, height: view.frame.height*0.8), image: image, contentMode: .scaleAspectFit)
        
        view.addSubview(imageView)
        view.layoutIfNeeded()
        imageView.center = CGPoint(x: view.frame.width / 2, y: view.frame.height / 2)
        self.leftViewMode = UITextField.ViewMode.always;
        //iconImageView.frame = CGRectMake(0 + padding, 0, 16, 16);
        self.leftView = view;
        self.leftViewMode = .always
    }
    
    
}

extension UIButton {
    
    /// when ever you want button with underline just call this function
    func setHyperLink() {
        let text: String = self.currentTitle!
        let dictAttribute: [NSAttributedString.Key : Any] = [NSAttributedString.Key.font: self.titleLabel?.font as AnyObject, NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue as AnyObject, NSAttributedString.Key.foregroundColor:(self.titleLabel?.textColor)!]
        self.titleLabel?.attributedText = NSAttributedString(string: text, attributes: dictAttribute)
    }
    
    func removeUnderLine() {
        let text: String = self.currentTitle!
        let dictAttribute: [NSAttributedString.Key : Any] = [NSAttributedString.Key.font: self.titleLabel?.font as AnyObject, NSAttributedString.Key.foregroundColor:(self.titleLabel?.textColor)!]
        self.titleLabel?.attributedText = NSAttributedString(string: text, attributes: dictAttribute)
    }
    
    
    /// when ever you want multiline text in button just call me
    func setMultiLineText() {
        self.titleLabel?.numberOfLines = 0
        self.titleLabel?.textAlignment = NSTextAlignment.center
    }
    
}

extension UIImage {
    
    /// retun image with resize with %
    ///
    /// - Parameter percentage: pass %
    /// - Returns: return reduce UIImage
    func resizeWithPercent(percentage: CGFloat) -> UIImage? {
        let imageView = UIImageView(frame: CGRect(origin: .zero, size: CGSize(width: size.width * percentage, height: size.height * percentage)))
        imageView.contentMode = .scaleAspectFit
        imageView.image = self
        UIGraphicsBeginImageContextWithOptions(imageView.bounds.size, false, scale)
        guard let context = UIGraphicsGetCurrentContext() else { return nil }
        imageView.layer.render(in: context)
        guard let result = UIGraphicsGetImageFromCurrentImageContext() else { return nil }
        UIGraphicsEndImageContext()
        return result
    }
    
    
    /// when you want a image with color overlay use me i will retun with given color
    ///
    /// - Parameter color: pass UIColor what you want as overlay
    /// - Returns: return UIImage with color overlay
    func imageWithColor(color: UIColor) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        let context = UIGraphicsGetCurrentContext()!
        
        let rect = CGRect(origin: CGPoint.zero, size: size)
        
        color.setFill()
        self.draw(in: rect)
        
        context.setBlendMode(.sourceIn)
        context.fill(rect)
        
        let resultImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return resultImage
    }
    
    
    /// when you need color from image call me i will retun color of that point
    ///
    /// - Parameters:
    ///   - location: pass location point from where you want color
    ///   - size: give image size so i find exect what you want
    /// - Returns: return color of that point
    func getPixelColor(atLocation location: CGPoint, withFrameSize size: CGSize) -> UIColor {
        let x: CGFloat = (self.size.width) * location.x / size.width
        let y: CGFloat = (self.size.height) * location.y / size.height
        
        let pixelPoint: CGPoint = CGPoint(x: x, y: y)
        
        let pixelData = self.cgImage!.dataProvider!.data
        let data: UnsafePointer<UInt8> = CFDataGetBytePtr(pixelData)
        
        let pixelIndex: Int = ((Int(self.size.width) * Int(pixelPoint.y)) + Int(pixelPoint.x)) * 4
        
        let r = CGFloat(data[pixelIndex]) / CGFloat(255.0)
        let g = CGFloat(data[pixelIndex+1]) / CGFloat(255.0)
        let b = CGFloat(data[pixelIndex+2]) / CGFloat(255.0)
        let a = CGFloat(data[pixelIndex+3]) / CGFloat(255.0)
        
        return UIColor(red: r, green: g, blue: b, alpha: a)
    }
    
    
    /// color overlay with given color
    ///
    /// - Parameter color: UIColor for over lay
    /// - Returns: return value UIimage with color overlay
    func colorized(color : UIColor) -> UIImage {
        
        let rect = CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height)
        
        UIGraphicsBeginImageContextWithOptions(rect.size, false, 0.0)
        if let context = UIGraphicsGetCurrentContext() {
            context.setBlendMode(.multiply)
            context.translateBy(x: 0, y: self.size.height)
            context.scaleBy(x: 1.0, y: -1.0)
            context.draw(self.cgImage!, in: rect)
            context.clip(to: rect, mask: self.cgImage!)
            context.setFillColor(color.cgColor)
            context.fill(rect)
        }
        
        let colorizedImage = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        return colorizedImage!
        
    }
}


extension UILabel {
    
    
    func makeOutLine(oulineColor: UIColor, foregroundColor: UIColor){
        let strokeTextAttributes = [
            NSAttributedString.Key.strokeColor : oulineColor,
            NSAttributedString.Key.foregroundColor : foregroundColor,
            NSAttributedString.Key.strokeWidth : -4.0,
            NSAttributedString.Key.font : font ?? UIFont.systemFontSize
            ] as [NSAttributedString.Key : Any]
        self.attributedText = NSMutableAttributedString(string: self.text ?? "", attributes: strokeTextAttributes)
    }
    
    func underline() {
        if let textString = text {
            let attributedString = NSMutableAttributedString(string: textString)
            attributedString.addAttribute(   NSAttributedString.Key.underlineStyle,
                                             value: NSUnderlineStyle.single.rawValue,
                                             range: NSRange(location: 0,
                                                            length: attributedString.length))
            attributedText = attributedString
        }
    }
    
    
    /// calculation of hight of lable to use make height dynamic
    ///
    /// - Returns: retun final hight of lable
    func estimatedHeightOfLabel() -> CGFloat {
        let size = CGSize(width: self.frame.width - 16, height: CGFloat.greatestFiniteMagnitude)
        let options = NSStringDrawingOptions.usesFontLeading.union(.usesLineFragmentOrigin)
        let attributes: [NSAttributedString.Key : Any] = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 17)]
        let rectangleHeight = String(self.text!).boundingRect(with: size, options: options, attributes: attributes, context: nil).height
        return rectangleHeight + 5
    }
    
    
    /// calculation of hight of lable to use make height dynamic when you have fix width
    ///
    /// - Parameters:
    ///   - textWidth: pass width what you want
    ///   - textFont: pass font of text
    /// - Returns: return hight of that text
    func textHeight(_ textWidth: CGFloat, textFont: UIFont) -> CGFloat {
        let textRect: CGRect = String(self.text!).boundingRect(with: CGSize(width: textWidth, height: CGFloat.greatestFiniteMagnitude), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: textFont], context: nil)
        let textSize: CGSize = textRect.size;
        return self.text! == "" ? 0.0 : textSize.height
    }
    
    
}

extension UIImageView {
    
    func hasImage(named imageName: String) -> Bool {
      guard let buttonImage = self.image, let namedImage = UIImage(named: imageName) else {
        return false
      }
      return buttonImage.pngData() == namedImage.pngData()
    }
    
    /// this is normal function to create UIImageView in one line
    ///
    /// - Parameters:
    ///   - frame: pass UIImageView frame
    ///   - image: pass UIImage what you need in that image view
    ///   - contentMode: pass content mode
    /// - Returns: UIImageView with give modes
    func createImageView(_ frame: CGRect, image: UIImage, contentMode: UIView.ContentMode) -> UIImageView
    {
        let imageView: UIImageView = UIImageView.init(frame: frame);
        imageView.image = image;
        imageView.contentMode = contentMode;
        return imageView;
    }
    
    
    /// set imageview tint color
    ///
    /// - Parameter color: set color what you want on overlay
    func setImageColor(color: UIColor) {
        let templateImage = self.image?.withRenderingMode(.alwaysTemplate)
        self.image = templateImage
        self.tintColor = color
    }
}

extension Double {
    /// Rounds the double to decimal places value
    func rounded(toPlaces places:Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
    func roundTo(places: Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
    
}

extension String {
    
    func getLowerSplit(splitBy: String) -> String {
        return ((self[self.startIndex..<self.range(of: splitBy)!.lowerBound])).description
    }
    
    func getUpperSplit(splitBy:String) -> String {
        return ((self[self.range(of: splitBy)!.upperBound...])).description
    }
    
    func CGFloatValue() -> CGFloat? {
        guard let doubleValue = Double(self) else {
            return nil
        }
        
        return CGFloat(doubleValue)
    }
    ///expaned function of null value
    func getSign( getresult: @escaping (_ value: String,_ sign:String) -> Void) {
        var value = self.getFloatValue
        if  value > 0{
            getresult("\(value)","+")
        }else  if  value == 0{
            getresult("\(0)","-")
        }
        else{
            value = -1 * value
            getresult("\(value)","-")
        }
    }
    /// replace text in string
    ///
    /// - Parameters:
    ///   - string: orignal string
    ///   - withString: replace string
    /// - Returns: give final string
    mutating func replace(_ string: String, withString: String) -> String {
        return self.replacingOccurrences(of: string, with: withString)
    }
    
    
    /// replace blank space with given string
    ///
    /// - Parameter withString: pass replaeing string
    /// - Returns: return final string with replacement
    mutating func replaceWhiteSpace(_ withString: String) -> String {
        let components = self.components(separatedBy: CharacterSet.whitespaces)
        let filtered = components.filter({!$0.isEmpty})
        return filtered.joined(separator: "")
    }
    
    
    /// give string witdh
    ///
    /// - Parameters:
    ///   - textHeight: give height what you need in width
    ///   - textFont: pass font
    /// - Returns: return width as per height and font
    func textWidth(_ textHeight: CGFloat, textFont: UIFont) -> CGFloat {
        let textRect: CGRect = self.boundingRect(with: CGSize(width: CGFloat.greatestFiniteMagnitude, height: textHeight), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: textFont], context: nil)
        let textSize: CGSize = textRect.size
        return ceil(textSize.width)
    }
    
    
    /// give string height as per width and font
    ///
    /// - Parameters:
    ///   - textWidth: pass fix width
    ///   - textFont: pass font
    /// - Returns: retun height as per width and font
    func textHeight(_ textWidth: CGFloat, textFont: UIFont) -> CGFloat {
        let textRect: CGRect = self.boundingRect(with: CGSize(width: textWidth, height: CGFloat.greatestFiniteMagnitude), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: textFont], context: nil)
        let textSize: CGSize = textRect.size
        return ceil(textSize.height)
    }
    
    func textSize(_ textFont: UIFont) -> CGSize {
        let textRect: CGRect = self.boundingRect(with: CGSize(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: textFont], context: nil)
        return textRect.size;
    }
    
    /// Trim whire space from before and ending
    ///
    /// - Returns: retun string from remove white space
    func trimWhiteSpace() -> String
    {
        return self.trimmingCharacters(in: .whitespaces)
    }
    
    /// trime white space and new line give final string
    ///
    /// - Returns:
    func trim() -> String { return self.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) }
    
    /// trim white space from first and last possition
    ///
    /// - Returns: remove space from first and last
    func trimTrailingWhitespace() -> String {
        if let trailingWs = self.range(of: "\\s+$", options: .regularExpression) {
            return self.replacingCharacters(in: trailingWs, with: "")
        } else {
            return self
        }
    }
    
    /// get phone number from string
    ///
    /// - Returns:
    mutating func extractPhoneNo() -> String {
        self = self.trim()
        return self
    }
    
    
    func leftPadding(toLength: Int, withPad: String = " ") -> Int {
        guard toLength > self.count else { return Int(self)! }
        let padding = String(repeating: withPad, count: toLength - self.count)
        return Int(padding + self)!
    }
    
    
    /// check is string content emoji
    ///
    /// - Returns: return value bool yes if have emoji
    func containsEmoji() -> Bool {
        for scalar in unicodeScalars {
            switch scalar.value {
            case 0x1F600...0x1F64F, // Emoticons
            0x1F300...0x1F5FF, // Misc Symbols and Pictographs
            0x1F680...0x1F6FF, // Transport and Map
            0x2600...0x26FF,   // Misc symbols
            0x2700...0x27BF,   // Dingbats
            0xFE00...0xFE0F:   // Variation Selectors
                return true
            default:
                continue
            }
        }
        return false
    }
    
    
    
    /// convert string to url (NOTE: if string are already content %20 then don't use this )
    ///
    /// - Returns: return url of given string with replce of http or any other extance
    func convertToUrl() -> URL {
        let data:Data = self.data(using: String.Encoding.utf8)!
        var resultStr: String = String(data: data, encoding: String.Encoding.nonLossyASCII)!
        
        if !(resultStr.hasPrefix("itms://")) && !(resultStr.hasPrefix("file://")) && !(resultStr.hasPrefix("http://")) && !(resultStr.hasPrefix("skype:")) && !(resultStr.hasPrefix("https://")) { resultStr = "http://" + resultStr }
        
        resultStr = resultStr.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        return URL(string: resultStr)!
    }
    
    
    /// encoding the strong
    ///
    /// - Returns: <#return value description#>
    mutating func encode() -> String {
        let customAllowedSet =  CharacterSet(charactersIn:" !+=\"#%/<>?@\\^`{|}$&()*-").inverted
        self = self.addingPercentEncoding(withAllowedCharacters: customAllowedSet)!
        return self
    }
    
    
    /// check string is contnt numrical value or not
    ///
    /// - Returns: return yes if numric
    func isNumeric() -> Bool {
        var holder: Float = 0.00
        let scan: Scanner = Scanner(string: self)
        let RET: Bool = scan.scanFloat(&holder) && scan.isAtEnd
        if self == "." { return false }
        return RET
    }
    
    
    /// comper two string and retun is that string content other string
    ///
    /// - Parameter subString: pass the string what you want to check
    /// - Returns: return with is contain then true or not then false
    func isContainString(_ subString: String) -> Bool {
        let range = self.range(of: subString, options: NSString.CompareOptions.caseInsensitive, range: self.range(of: self))
        return range == nil ? false : true
    }
    
    
    /// return locaized string
    ///
    /// - Parameter language: pass language what you want
    /// - Returns: localize string with given language
    func localized(forLanguage language: String = Locale.preferredLanguages.first!.components(separatedBy: "-").first!) -> String {
        guard let path = Bundle.main.path(forResource: language == "en" ? "Base" : language, ofType: "lproj") else {
            let basePath = Bundle.main.path(forResource: "Base", ofType: "lproj")!
            return Bundle(path: basePath)!.localizedString(forKey: self, value: "", table: nil)
        }
        return Bundle(path: path)!.localizedString(forKey: self, value: "", table: nil)
    }
    
    /// set thousand seperator
    ///
    /// - Returns: return value with 2 decimal point
    func setThousandSeperator() ->String {
        return self.setThousandSeperator(self, decimal: 2)
    }
    
    /// set thousand seperator
    ///
    /// - Returns: return value with 2 decimal point
    func setThousandSeperator(decimal:Int) ->String {
        return self.setThousandSeperator(self, decimal: decimal)
    }
    
    /// set thousand seperator with given decimal number
    ///
    /// - Parameters:
    ///   - string: pass sting of what you want thousand saprator
    ///   - decimal: pass decimal point
    /// - Returns: return value with passed
    func setThousandSeperator(_ string: String, decimal: Int) -> String {
        let numberFormatter = NumberFormatter.init()
        numberFormatter.groupingSeparator = ","
        numberFormatter.groupingSize = 3
        //        numberFormatter.locale = Locale.init(identifier: "en_IN")
        //        numberFormatter.currencyCode = "INR"
        numberFormatter.currencySymbol = ""
        numberFormatter.decimalSeparator = "."
        numberFormatter.maximumFractionDigits = decimal
        numberFormatter.numberStyle = NumberFormatter.Style.currency
        numberFormatter.usesGroupingSeparator = true
        if string.isEmpty { return "0.00" }
        return numberFormatter.string(from: NSNumber.init(value: Double(string)! as Double))!
    }
    /// give two decimal point value
    ///
    /// - Returns: <#return value description#>
    func setDecimalPointNominimum(_ point:Int) -> String {
        let numberFormatter:NumberFormatter = NumberFormatter.init()
        numberFormatter.decimalSeparator = "."
        numberFormatter.maximumFractionDigits = point
        //        numberFormatter.minimumIntegerDigits = 1
        return  numberFormatter.string(from: NSNumber.init(value: Double(self)! as Double))!
    }
    
    /// give two decimal point value
    ///
    /// - Returns: <#return value description#>
    func setDecimalPoint(_ point:Int) -> String {
        let numberFormatter:NumberFormatter = NumberFormatter.init()
        numberFormatter.decimalSeparator = "."
        numberFormatter.maximumFractionDigits = point
        numberFormatter.minimumFractionDigits = point
        //        numberFormatter.minimumIntegerDigits = 1
        return  numberFormatter.string(from: NSNumber.init(value: getDouble(value: self)))!
    }
    /// give two decimal point value
    ///
    /// - Returns: <#return value description#>
    func setDecimalPoint() -> String {
        let numberFormatter:NumberFormatter = NumberFormatter.init()
        numberFormatter.decimalSeparator = "."
        numberFormatter.maximumFractionDigits = 2
        numberFormatter.minimumFractionDigits = 2
        //        numberFormatter.minimumIntegerDigits = 1
        return  numberFormatter.string(from: NSNumber.init(value: getDouble(value: self)))!
    }
    
    
    /// validate mobile number with regex
    ///
    /// - Returns: true for right number faluse for not right
    func validateMobileNo() -> Bool {
        do {
            let pattern: String = "^[789]\\d{9}$"
            let regex = try NSRegularExpression(pattern: pattern, options: [])
            let nsString = self as NSString
            let results = regex.matches(in: self, options: [], range: NSMakeRange(0, nsString.length))
            return results.count > 0 ? true : false
            
        } catch let error as NSError {
            print("Invalid regex: \(error.localizedDescription)")
            return false
        }
    }
    
    
    /// validate email formate
    ///
    /// - Returns: true if right false for wrong
    func validateEmail() -> Bool {
        do {
            let pattern: String = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
            //  let pattern: String = "[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\\.)+[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?"
            let regex = try NSRegularExpression(pattern: pattern, options: [])
            let nsString = self as NSString
            let results = regex.matches(in: self, options: [], range: NSMakeRange(0, nsString.length))
            return results.count > 0 ? true : false
            
        } catch let error as NSError {
            print("Invalid regex: \(error.localizedDescription)")
            return false
        }
    }
    
    /// validation of password rang 6 to 32
    ///
    /// - Returns: true for valid 6 digit pass or wrong false for
    func validatePassword() -> Bool {
        return self.count >= 6 && self.count <= 32 ? true : false
    }
    
    /// make json string to dic
    ///
    /// - Returns: typeAliasStringDictionary
    func convertToStringDictionary() -> typeAliasStringDictionary {
        let jsonData: Data = self.data(using: String.Encoding.utf8)!
        do {
            let dict: typeAliasStringDictionary = try JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions()) as! typeAliasStringDictionary
            return dict
        } catch let error as NSError { print(error) }
        return typeAliasStringDictionary()
    }
    
    
    /// make json string to typeAliasDictionary
    ///
    /// - Returns: return value typeAliasDictionary
    func convertToDictionary() -> typeAliasDictionary {
        let jsonData: Data = self.data(using: String.Encoding.utf8)!
        do {
            let dict: typeAliasDictionary = try JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions()) as! typeAliasDictionary
            return dict
        } catch let error as NSError { print(error) }
        return typeAliasDictionary()
    }
    
    
    /// make json to array 
    ///
    /// - Returns: return value dic value in array
    func convertToArray() -> [typeAliasDictionary] {
        let jsonData: Data = self.data(using: String.Encoding.utf8)!
        do {
            let array: [typeAliasDictionary] = try JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions()) as! [typeAliasDictionary]
            return array
        } catch let error as NSError { print(error) }
        
        return [typeAliasDictionary]()
    }
    
    
    /// make json to string array
    ///
    /// - Returns: return value string array
    func convertToStringArray() -> [String] {
        let jsonData: Data = self.data(using: String.Encoding.utf8)!
        do {
            let array: [String] = try JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions()) as! [String]
            return array
        } catch let error as NSError { print(error) }
        
        return [String]()
    }
    
    /// encode in base 64
    ///
    /// - Returns: return value base 64
    func base64Encoded() -> String {
        if let data = self.data(using: .utf8) { return data.base64EncodedString() }
        return ""
    }
    
    /// decode from base64
    ///
    /// - Returns: return value of base 64
    func base64Decoded() -> String {
        if let data = Data(base64Encoded: self) { return String(data: data, encoding: .utf8)! }
        return ""
    }
    
    
    /// hex string to UIColor
    ///
    /// - Returns: UIColor
    func hexToUIColor () -> UIColor {
        var cString:String = self.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) { cString.remove(at: cString.startIndex) }
        
        if ((cString.count) != 6) { return UIColor.gray }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    
    /// get redins form give sring digree
    ///
    /// - Returns: <#return value description#>
    func getRediansFromDegrees() -> Double {
        let degree: Double = Double(self)!
        return degree * .pi / 180.0
    }
    
    
    func extractString(_ checkingType: NSTextCheckingResult.CheckingType) -> [String] {
        var arrText = [String]()
        let detector = try! NSDataDetector(types: checkingType.rawValue)
        let matches = detector.matches(in: self, options: [], range: NSRange(location: 0, length: self.utf16.count))
        
        for match in matches {
            let url = (self as NSString).substring(with: match.range)
            arrText.append(url)
        }
        return arrText
    }
    
    
    
    /// get phone number from give string
    ///
    /// - Returns: <#return value description#>
    func getPhoneNumber() -> [String] { return self.extractString(.phoneNumber) }
    
    
    /// get url from string
    ///
    /// - Returns: <#return value description#>
    func getUrl() -> [String]  { return self.extractString(.link) }
    
    /// get address from string
    ///
    /// - Returns: <#return value description#>
    func getAddress() -> [String]  { return self.extractString(.address) }
    
    /// get email address from string
    ///
    /// - Returns: <#return value description#>
    func getEmail() -> [String]  {
        var arrEmail = [String]()
        let arrText = self.components(separatedBy: ["\n"," ","."])
        for st in arrText {
            let isEmail: Bool = st.validateEmail()
            if isEmail { arrEmail.append(st) }
        }
        return arrEmail
    }
    
    /// get all int value from string
    var getIntergerFromString: String {
        let pattern = UnicodeScalar("0")..."9"
        return String(unicodeScalars.compactMap { pattern ~= $0 ? Character($0) : nil })
    }
    
    /// get Float Value from string
    var getFloatValue: Float {
        return (self as NSString).floatValue
    }
    
    /// get Float Value from string
    var getDoubleValue: Double {
        return (self as NSString).doubleValue
    }
    /// add % endcoing value
    ///
    /// - Returns: <#return value description#>
    public func addingPercentEncodingForQueryParameter() -> String? {
        return addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed)
    }
    
    public func attributedCompalsorySign() -> NSMutableAttributedString {
        var str:String = self
        if !self.contains("*") {
            str = self + " *"
        }
        let compalsorySign = NSMutableAttributedString(string: str)
        compalsorySign.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.red, range: NSRange(location: str.distance(from: str.startIndex, to: str.range(of: "*")!.lowerBound), length: 1))
        return compalsorySign
    }
    
    func toHexBytes() -> [UInt8] {
        
        
        var data = [UInt8]()
        let utfff = Array<UInt8>(self.utf8)
        let skip0x = self.hasPrefix("0x") ? 2 : 0
        for idx in stride(from: utfff.startIndex.advanced(by: skip0x), to: utfff.endIndex, by: utfff.startIndex.advanced(by: 2)) {
            let byteHex = "\(UnicodeScalar(utfff[idx]))\(UnicodeScalar(utfff[idx.advanced(by: 1)]))"
            if let byte = UInt8(byteHex, radix: 16) {
                data.append(byte)
            }
        }
        return data
    }
    
    var htmlToAttributedString: NSAttributedString? {
           guard let data = data(using: .utf8) else { return NSAttributedString() }
           do {
               return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)
           } catch {
               return NSAttributedString()
           }
       }
       var htmlToString: String {
           return htmlToAttributedString?.string ?? ""
       }
}

extension Float {
    /// get Rid of Decimal Point and get Integer Value
    var cleanDecimal: String {
        return self.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", self) : String(self)
    }
}


extension Date {
    /// Returns the amount of years from another date
    func years(from date: Date) -> Int {
        return Calendar.current.dateComponents([.year], from: date, to: self).year ?? 0
    }
    /// Returns the amount of months from another date
    func months(from date: Date) -> Int {
        return Calendar.current.dateComponents([.month], from: date, to: self).month ?? 0
    }
    /// Returns the amount of weeks from another date
    func weeks(from date: Date) -> Int {
        return Calendar.current.dateComponents([.weekOfMonth], from: date, to: self).weekOfMonth ?? 0
    }
    /// Returns the amount of days from another date
    func days(from date: Date) -> Int {
        return Calendar.current.dateComponents([.day], from: date, to: self).day ?? 0
    }
    /// Returns the amount of hours from another date
    func hours(from date: Date) -> Int {
        return Calendar.current.dateComponents([.hour], from: date, to: self).hour ?? 0
    }
    /// Returns the amount of minutes from another date
    func minutes(from date: Date) -> Int {
        return Calendar.current.dateComponents([.minute], from: date, to: self).minute ?? 0
    }
    /// Returns the amount of seconds from another date
    func seconds(from date: Date) -> Int {
        return Calendar.current.dateComponents([.second], from: date, to: self).second ?? 0
    }
    /// Returns the amount of nanoseconds from another date
    func nanoseconds(from date: Date) -> Int {
        return Calendar.current.dateComponents([.nanosecond], from: date, to: self).nanosecond ?? 0
    }
    /// Returns the a custom time interval description from another date
    func offset(from date: Date) -> String {
        var _: String = ""
        //        if years(from: date)   > 0 { return "\(years(from: date))y"   }
        //        if months(from: date)  > 0 { return "\(months(from: date))M"  }
        //        if weeks(from: date)   > 0 { return "\(weeks(from: date))w"   }
        if seconds(from: date) > 0 { return "\(seconds(from: date))" }
        //        if days(from: date)    > 0 { result = result + " " + "\(days(from: date)) D" }
        //        if hours(from: date)   > 0 { result = result + " " + "\(hours(from: date)) H" }
        //        if minutes(from: date) > 0 { result = result + " " + "\(minutes(from: date)) M" }
        //        if seconds(from: date) > 0 { return "\(seconds(from: date))" }
        return ""
    }
    
    func localizedDateOnly( dateFormat format  : String ) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: self)
    }
}

extension CharacterSet {
    static let urlQueryValueAllowed: CharacterSet = {
        let generalDelimitersToEncode = ":#[]@" // does not include "?" or "/" due to RFC 3986 - Section 3.4
        let subDelimitersToEncode = "!$&'()*+,;="
        
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: generalDelimitersToEncode + subDelimitersToEncode)
        
        return allowed
    }()
}

extension Dictionary {
    
    func nullKeyRemoval() -> [AnyHashable: Any] {
        var dict: [AnyHashable: Any] = self
        
        let keysToRemove = dict.keys.filter { dict[$0] is NSNull }
        let keysToCheck = dict.keys.filter({ dict[$0] is Dictionary })
        let keysToArrayCheck = dict.keys.filter({ dict[$0] is [Any] })
        for key in keysToRemove {
            dict[key] = ""
        }
        for key in keysToCheck {
            if let valueDict = dict[key] as? [AnyHashable: Any] {
                dict.updateValue(valueDict.nullKeyRemoval(), forKey: key)
            }
        }
        for key in keysToArrayCheck {
            if var arrayDict = dict[key] as? [Any] {
                for i in  0..<arrayDict.count {
                    if let dictObj = arrayDict[i] as? typeAliasDictionary {
                        arrayDict[i] = dictObj.nullKeyRemoval()
                    }
                }
                dict.updateValue(arrayDict, forKey: key)
            }
        }
        return dict
    }
    
    /// convert dictionary to json string
    ///
    /// - Returns: <#return value description#>
    func convertToJSonString() -> String {
        do {
            let dataJSon = try JSONSerialization.data(withJSONObject: self as AnyObject, options: JSONSerialization.WritingOptions.prettyPrinted)
            let st: NSString = NSString.init(data: dataJSon, encoding: String.Encoding.utf8.rawValue)!
            return st as String
        } catch let error as NSError { print(error) }
        return ""
    }
    
    
    /// check given key have value or not
    ///
    /// - Parameter stKey: pass key what you want check
    /// - Returns: true if exist
    func isKeyNull(_ stKey: String) -> Bool {
        let dict: typeAliasDictionary = (self as AnyObject) as! typeAliasDictionary
        if let val = dict[stKey] { return val is NSNull ? true : false }
        return true
    }
    
    
    
    /// handal carsh when null valu or key not found
    ///
    /// - Parameter stKey: pass the key of object
    /// - Returns: blank string or value if exist
    func valuForKeyString(_ stKey: String) -> String {
        return valuForKeyString(stKey, nullValue: "")
    }
    
    func valuForKeyString( _ stKey:String, nullValue:String) -> String {
        let dict: typeAliasDictionary = (self as AnyObject) as! typeAliasDictionary
        if let val = dict[stKey] {
            if val is NSNull{
                return nullValue
            }else if (val as? NSNumber) != nil {
                return  val.stringValue
                
            }else if (val as? String) != nil {
                return val as! String
            }else{
                return val as! String
            }
        }
        return nullValue
    }
    
    func valuForKeyInt( _ any:String) -> Int {
        return valuForKeyInt(any,nullValue: 0)
    }
    func valuForKeyInt( _ any:String,nullValue :Int) -> Int {
        var iValue: Int = 0
        let dict: typeAliasDictionary = self as! typeAliasDictionary
        if let val = dict[any] {
            if val is NSNull {
                return 0
            }
            else {
                if val is Int {
                    iValue = val as! Int
                }
                else if val is Double {
                    iValue = Int(val as! Double)
                }
                else if val is String {
                    let stValue: String = val as! String
                    iValue = (stValue as NSString).integerValue
                }
                else if val is Float {
                    iValue = Int(val as! Float)
                }else{
                    let error = NSError(domain:any,
                                        code: 100,
                                        userInfo:dict)
                }
            }
        }
        return iValue
    }
    
    func valuForKeyDouble(_ stKey: String) -> Double {
        var dValue: Double = 0.0
        let dict: typeAliasDictionary = self as! typeAliasDictionary
        if let val = dict[stKey] {
            if val is NSNull {
                return 0.0
            }
            else {
                if val is Double {
                    dValue = val as! Double
                }
                else if val is Int {
                    dValue = Double(val as! Double)
                }
                else if val is String {
                    let stValue: String = val as! String
                    dValue = (stValue as NSString).doubleValue
                }
                else if val is Float {
                    dValue = Double(val as! Double)
                }else {
                    let error = NSError(domain:stKey,
                                        code: 100,
                                        userInfo:dict)
                }
            }
        }
        return dValue
    }
    
    func valuForKeyFloat( _ any:String) -> Float {
        return valuForKeyFloat(any,nullValue: 0.0)
    }
    
    func valuForKeyFloat( _ any:String,nullValue :Float ) -> Float {
        var fValue: Float = nullValue
        let dict: typeAliasDictionary = self as! typeAliasDictionary
        if let val = dict[any] {
            if val is NSNull {
                return fValue
            }
            else {
                if val is Int {
                    fValue = val as! Float
                }
                else if val is Double {
                    fValue = Float(val as! Double)
                }
                else if val is String {
                    let stValue: String = val as! String
                    fValue = (stValue as NSString).floatValue
                }
                else if val is Float {
                    fValue = Float(val as! Float)
                }else{
                    let error = NSError(domain:any,
                                        code: 100,
                                        userInfo:dict)
                    //Crashlytics.sharedInstance().recordError(error)
                }
            }
        }
        return fValue
    }
    ///expaned function of null value
    func valuForKeyString(_ stKey: String,_ nullvalue:String) -> String {
        return  self.valuForKeyWithNullString(Key: stKey, NullReplaceValue: nullvalue)
    }
    
    ///expaned function of null value
    func valuForKeyString(_ stKey: String,nullvalue:String) -> String {
        return  self.valuForKeyWithNullString(Key: stKey, NullReplaceValue: nullvalue)
    }
    
    /// Update dic with other Dictionary
    ///
    /// - Parameter other: add second Dictionary which one you want to add
    mutating func update(other:Dictionary) {
        for (key,value) in other {
            self.updateValue(value, forKey:key)
        }
    }
    
    
    /// USE TO GET VALUE FOR KEY if key not found or null then replace with the string
    ///
    /// - Parameters:
    ///   - stKey: pass key of dic
    ///   - NullReplaceValue: set value what you want retun if that key is nill
    /// - Returns: retun key value if exist or return null replace value
    func valuForKeyWithNullString(Key stKey: String,NullReplaceValue:String) -> String {
        let dict: typeAliasDictionary = (self as AnyObject) as! typeAliasDictionary
        if let val = dict[stKey] {
            if val is NSNull{
                dLog(message: val)
                return NullReplaceValue
            } else{
                if (val as? NSNumber) != nil {
                    return  val.stringValue
                }else{
                    return val as! String == "" ? NullReplaceValue : val as! String
                }
            }
        }
        return NullReplaceValue
    }
    
    func valuForKeyWithNullWithPlaseString(Key stKey: String,NullReplaceValue:String) -> String {
        let dict: typeAliasDictionary = (self as AnyObject) as! typeAliasDictionary
        if let val = dict[stKey] {
            if val is NSNull{
                dLog(message: val)
                return NullReplaceValue
            } else{
                if (val as? NSNumber) != nil {
                    if Int(truncating: val as! NSNumber) > 0{
                        return  "+" + val.stringValue
                    }
                }else{
                    if Int(val as! String) > 0{
                        return val as! String == "" ? NullReplaceValue : "+" + (val as! String) 
                    }else{
                        return val as! String == "" ? NullReplaceValue : val as! String
                    }
                    
                }
            }
        }
        return NullReplaceValue
    }
    
    func valuForKeyArray(_ stKey: String) -> Array<Any> {
        let dict: typeAliasDictionary = (self as AnyObject) as! typeAliasDictionary
        if let val = dict[stKey] {
            if val is NSNull{
                return []
            } else{
                return val as! Array<Any>
            }
        }
        return []
    }
    
    
    func valuForKeyDic(_ stKey: String) ->  typeAliasDictionary {
        let dict: typeAliasDictionary = (self as AnyObject) as! typeAliasDictionary
        if let val = dict[stKey] {
            if val is NSNull{
                return  typeAliasDictionary()
            }else if val is Array<Any>{
                return  [stKey:val]
            }else if val is typeAliasDictionary{
                return val as! typeAliasDictionary
            }else{
                return typeAliasDictionary()
            }
        }
        return typeAliasDictionary()
    }
    /// This is function for convert dicticonery to xml string also check log for other type of string i only handal 2 or 3 type of stct 
    ///
    /// - Returns: return xml string
    func createXML()-> String{
        
        var xml = ""
        for k in self.keys {
            
            if let str = self[k] as? String{
                xml.append("<\(k as! String)>")
                xml.append(str)
                xml.append("</\(k as! String)>")
                
            }else if let dic =  self[k] as? Dictionary{
                xml.append("<\(k as! String)>")
                xml.append(dic.createXML())
                xml.append("</\(k as! String)>")
                
            }else if let array : NSArray =  self[k] as? NSArray{
                for i in 0..<array.count {
                    xml.append("<\(k as! String)>")
                    if let dic =  array[i] as? Dictionary{
                        xml.append(dic.createXML())
                    }else if let str = array[i]  as? String{
                        xml.append(str)
                    }else{
                        dLog(message: array[i])
                        fatalError("[XML]  associated with \(self[k] as Any) not any type!")
                    }
                    xml.append("</\(k as! String)>")
                    
                }
            }else if let dic =  self[k] as? NSDictionary{
                xml.append("<\(k as! String)>")
                
                let newdic = dic as! Dictionary<String,Any>
                xml.append(newdic.createXML())
                xml.append("</\(k as! String)>")
                
            }
            else{
                dLog(message: self[k] as Any)
                fatalError("[XML]  associated with \(self[k] as Any) not any type!")
            }
        }
        
        return xml
    }
    
    
}

extension UISegmentedControl {
    func setUnseen_SeenLayout() {
        UILabel.appearance(whenContainedInInstancesOf: [UISegmentedControl.self]).numberOfLines = 0
        self.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
        self.setTitleTextAttributes([.foregroundColor: UIColor.darkGray], for: .normal)
        if #available(iOS 13.0, *) {
            //HP
            // self.selectedSegmentTintColor = UIColor.init(hexString: "#51B0B4")
        } else {
            self.tintColor = UIColor.init(hexString: "#51B0B4")
        }
    }
}

extension UIStackView {
    
    func removeAllArrangedSubviews() {
        
        let removedSubviews = arrangedSubviews.reduce([]) { (allSubviews, subview) -> [UIView] in
            self.removeArrangedSubview(subview)
            return allSubviews + [subview]
        }
        
        // Deactivate all constraints
        NSLayoutConstraint.deactivate(removedSubviews.flatMap({ $0.constraints }))
        
        // Remove the views from self
        removedSubviews.forEach({ $0.removeFromSuperview() })
    }
}

extension Array {
    
    func indexExists(_ index: Int) -> Bool {
        return self.indices.contains(index)
    }
    
    func convertToJSonString() -> String {
        do {
            let dataJSon = try JSONSerialization.data(withJSONObject: self as AnyObject, options: JSONSerialization.WritingOptions.prettyPrinted)
            //let st: NSString = NSString.init(data: dataJSon, encoding: String.Encoding.utf8.rawValue)!
            let st: String = String(data: dataJSon, encoding: .utf8)!
            return st
        } catch let error as NSError { print(error) }
        return ""
    }
    
    func getArrayFromArrayOfDictionary(key: String, valueString: String, valueInt: String) -> [typeAliasDictionary] {
        if !valueString.isEmpty {
            let predicate = NSPredicate(format: "%K LIKE[cd] %@", key, valueString)
            print(predicate)
            return (self as NSArray).filtered(using: predicate) as! [typeAliasDictionary]
        }
        else if !valueInt.isEmpty {
            let predicate = NSPredicate(format: "%K = %d", key, Int(valueInt)!)
            return (self as NSArray).filtered(using: predicate) as! [typeAliasDictionary]
        }
        return [typeAliasDictionary]()
    }
    
    func getArrayFromArrayOfDictionaryKeys(key: String, valueArray: NSArray) -> [typeAliasDictionary] {
        if valueArray.count > 0 {
            let pridictarray = NSMutableArray()
            for value in valueArray{
                let predicate = NSPredicate(format: "%K = %@", key, value as! CVarArg)
                pridictarray.add(predicate)
                
            }
            let andPredicate = NSCompoundPredicate(type: .or, subpredicates: pridictarray as! [NSPredicate] )
            
            //            dLog(message: andPredicate)
            //            dLog(message: self)
            return (self as NSArray).filtered(using: andPredicate) as! [typeAliasDictionary]
        }
        
        return [typeAliasDictionary]()
    }
    
    func getArrayFromArrayOfDictionary(key: String, notValueString: [String], notValueInt: [String]) -> [typeAliasDictionary] {
        if !notValueString.isEmpty {
            var arrCondition = [String]()
            for value in notValueString { arrCondition.append("(NOT \(key) LIKE[cd] \"\(value)\")") }
            let stCondition: String = arrCondition.joined(separator: " AND ")
            
            let predicate = NSPredicate(format: stCondition)
            return (self as NSArray).filtered(using: predicate) as! [typeAliasDictionary]
        }
        else if !notValueInt.isEmpty {
            //            let predicate = NSPredicate(format: "%K != %d", key, Int(notValueInt)!)
            //            return (self as NSArray).filtered(using: predicate) as! [typeAliasDictionary]
        }
        
        return [typeAliasDictionary]()
    }
    
    func getArrayFromArrayOfDictionary2(key: String, valueString: String, valueInt: String) -> [typeAliasStringDictionary] {
        if !valueString.isEmpty {
            let predicate = NSPredicate(format: "%K LIKE[cd] %@", key, valueString)
            return (self as NSArray).filtered(using: predicate) as! [typeAliasStringDictionary]
        }
        else if !valueInt.isEmpty {
            let predicate = NSPredicate(format: "%K = %d", key, Int(valueInt)!)
            return (self as NSArray).filtered(using: predicate) as! [typeAliasStringDictionary]
        }
        return [typeAliasStringDictionary]()
    }
    
    func getArrayFromArrayOfString(valueString: String, valueInt: String) -> [String] {
        
        if !valueString.isEmpty {
            let predicate = NSPredicate(format: "SELF LIKE[cd] %@", valueString)
            return (self as NSArray).filtered(using: predicate) as! [String]
        }
        else if !valueInt.isEmpty {
            let predicate = NSPredicate(format: "SELF = %d", Int(valueInt)!)
            return (self as NSArray).filtered(using: predicate) as! [String]
        }
        
        return [String]()
    }
}

extension NSRange {
    func toRange(string: String) -> Range<String.Index> {
        let startIndex = string.index(string.startIndex, offsetBy: location)
        let endIndex = string.index(startIndex, offsetBy: length)
        return startIndex..<endIndex
    }
}

extension UIView {
    
    func roundCorners(corners:CACornerMask, radius: CGFloat) {
        self.layer.cornerRadius = radius
        self.layer.maskedCorners = corners
    }
    
    
    
    var heightConstaint: NSLayoutConstraint? {
        get {
            return constraints.first(where: {
                $0.firstAttribute == .height && $0.relation == .equal
            })
        }
        set { setNeedsLayout() }
    }
    
    var widthConstaint: NSLayoutConstraint? {
        get {
            return constraints.first(where: {
                $0.firstAttribute == .width && $0.relation == .equal
            })
        }
        set { setNeedsLayout() }
    }
    static var reuseIdentifier: String {
        return String(describing: self)
    }
    
    class func fromNib<T: UIView>() -> T {
        return Bundle.main.loadNibNamed(String(describing: T.self), owner: nil, options: nil)![0] as! T
    }
    /** This is the function to get subViews of a view of a particular type
     */
    func subViews<T : UIView>(type : T.Type) -> [T]{
        var all = [T]()
        for view in self.subviews {
            if let aView = view as? T{
                all.append(aView)
            }
        }
        return all
    }
    
    
    /** This is a function to get subViews of a particular type from view recursively. It would look recursively in all subviews and return back the subviews of the type T */
    func allSubViewsOf<T : UIView>(type : T.Type) -> [T]{
        var all = [T]()
        func getSubview(view: UIView) {
            if let aView = view as? T{
                all.append(aView)
            }
            guard view.subviews.count>0 else { return }
            view.subviews.forEach{ getSubview(view: $0) }
        }
        getSubview(view: self)
        return all
    }
    /// Returns the first constraint with the given identifier, if available.
    ///
    /// - Parameter identifier: The constraint identifier.
    func constraintWithIdentifier(_ identifier: String) -> NSLayoutConstraint? {
        dLog(message: self.constraints.first as Any)
        if let constants = (self.constraints.first { $0.identifier == identifier }){
            return constants
        }
        for view in self.allSubViewsOf(type: UIView.self) {
            if let constants = (view.constraints.first { $0.identifier == identifier }){
                return constants
            }
        }
        return self.constraints.first { $0.identifier == identifier }
    }
    
    @IBInspectable var borderColor:UIColor? {
        set {
            layer.borderColor = newValue!.cgColor
        }
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor:color)
            }
            else {
                return nil
            }
        }
    }
    @IBInspectable var borderWidth:CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    @IBInspectable var cornerRadius:CGFloat {
        set {
            layer.cornerRadius = newValue
            clipsToBounds = newValue > 0
        }
        get {
            return layer.cornerRadius
        }
    }
    
    class func loadFromNibNamed(_ nibNamed: String, bundle : Bundle? = nil) -> UIView? {
        return UINib(nibName: nibNamed, bundle: bundle).instantiate(withOwner: nil, options: nil)[0] as? UIView
    }
    
    func round(corners: UIRectCorner, radius: CGFloat) -> Void {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
    
    func setHighlight() {
        self.setViewBorder(UIColor.black, borderWidth: 2, isShadow: false, cornerRadius: 0, backColor: UIColor.clear)
    }
    
    func unSetHighlight() {
        self.setViewBorder(UIColor.black, borderWidth: 1, isShadow: false, cornerRadius: 0, backColor: UIColor.clear)
    }
    
    func setBottomBorder(_ borderColor: UIColor, borderWidth: CGFloat) {
        let tagLayer: String = "100000"
        if self.layer.sublayers?.count > 1 && self.layer.sublayers?.last?.accessibilityLabel == tagLayer {
            self.layer.sublayers?.last?.removeFromSuperlayer()
        }
        let border: CALayer = CALayer()
        border.backgroundColor = borderColor.cgColor;
        border.accessibilityLabel = tagLayer;
        border.frame = CGRect(x: 0, y: self.frame.height - borderWidth, width: self.frame.width, height: borderWidth);
        self.layer.addSublayer(border)
    }
    
    func setViewBorder(_ borderColor: UIColor, borderWidth: CGFloat, isShadow: Bool, cornerRadius: CGFloat, backColor: UIColor) {
        self.backgroundColor = backColor;
        self.layer.borderWidth = borderWidth;
        self.layer.borderColor = borderColor.cgColor;
        self.layer.cornerRadius = cornerRadius;
        //if isShadow { self.dropShadow() }
    }
    
    func applyGradient(colours: [UIColor]) -> Void {
        self.applyGradient(colours: colours, locations: nil)
    }
    
    func applyGradient(colours: [UIColor], locations: [NSNumber]?) -> Void {
        let gradient: CAGradientLayer = CAGradientLayer()
        gradient.frame = self.bounds
        gradient.colors = colours.map { $0.cgColor }
        gradient.locations = locations
        self.layer.insertSublayer(gradient, at: 0)
    }
    
    func dropShadow(_ shadowColor: UIColor, shadowOffset: CGSize, shadowOpacity: Float, shadowRadius: CGFloat) {
        layer.shadowColor = shadowColor.cgColor
        layer.shadowOffset = shadowOffset
        layer.shadowOpacity = shadowOpacity
        layer.shadowRadius = shadowRadius
        layer.masksToBounds = false
    }
    
    func animationZoom(scaleX: CGFloat, y: CGFloat) {
        self.transform = CGAffineTransform(scaleX: scaleX, y: y)
    }
    
    func animationRoted(angle : CGFloat) {
        self.transform = self.transform.rotated(by: angle)
    }
    
    func fadeTransition(_ duration:CFTimeInterval) {
        let animation = CATransition()
        animation.timingFunction = CAMediaTimingFunction(name:
            CAMediaTimingFunctionName.easeInEaseOut)
        animation.type = CATransitionType.fade
        animation.duration = duration
        layer.add(animation, forKey: convertFromCATransitionType(CATransitionType.fade))
    }
    
    @IBInspectable
    var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    
    @IBInspectable
    var ShadowOpacity: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }
    
    @IBInspectable
    var ShadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }
    
    @IBInspectable
    var ShadowColor: UIColor? {
        get {
            if let color = layer.shadowColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.shadowColor = color.cgColor
            } else {
                layer.shadowColor = nil
            }
        }
    }
    
    /**
     Set x Position
     
     :param: x CGFloat
     by Kishan Sutariya
     */
    func setX(x:CGFloat) {
        var frame:CGRect = self.frame
        frame.origin.x = x
        self.frame = frame
    }
    /**
     Set y Position
     
     :param: y CGFloat
     by Kishan Sutariya
     */
    func setY(y:CGFloat) {
        var frame:CGRect = self.frame
        frame.origin.y = y
        self.frame = frame
    }
    /**
     Set Width
     
     :param: width CGFloat
     by Kishan Sutariya
     */
    func setWidth(width:CGFloat) {
        var frame:CGRect = self.frame
        frame.size.width = width
        self.frame = frame
    }
    /**
     Set Height
     
     :param: height CGFloat
     by Kishan Sutariya
     */
    func setHeight(height:CGFloat) {
        var frame:CGRect = self.frame
        frame.size.height = height
        self.frame = frame
    }
    
    func LableWithTag(_ tag:Int) -> UILabel {
        if let lable = self.viewWithTag(tag){
            return lable as! UILabel
        }
        return  UILabel()
    }
    func ImageViewWithTag(_ tag:Int) -> UIImageView {
        if let lable = self.viewWithTag(tag){
            return lable as! UIImageView
        }
        return  UIImageView()
    }
    func ButtonWithTag(_ tag:Int) -> UIButton {
        if let lable = self.viewWithTag(tag){
            return lable as! UIButton
        }
        return  UIButton()
    }
    
    func TextFiledWithTag(_ tag:Int) -> UITextField {
        if let lable = self.viewWithTag(tag){
            return lable as! UITextField
        }
        return  UITextField()
    }
    
    var globalFrame: CGRect? {
        let rootView = UIApplication.shared.keyWindow?.rootViewController?.view
        return self.superview?.convert(self.frame, to: rootView)
    }
    
    
    var parentViewController: UIViewController? {
        var parentResponder: UIResponder? = self
        while parentResponder != nil {
            // swiftlint:disable:next force_unwrapping
            parentResponder = parentResponder!.next
            if let viewController = parentResponder as? UIViewController {
                return viewController
            }
        }
        return nil
    }
    
    var parentNavigationController: UINavigationController? {
        let currentViewController = parentViewController
        if let navigationController = currentViewController as? UINavigationController {
            return navigationController
        }
        return currentViewController?.navigationController
    }
    
    func height(constant: CGFloat) {
        setConstraint(value: constant, attribute: .height)
    }
    
    func width(constant: CGFloat) {
        setConstraint(value: constant, attribute: .width)
    }
    
    private func removeConstraint(attribute: NSLayoutConstraint.Attribute) {
        constraints.forEach {
            if $0.firstAttribute == attribute {
                removeConstraint($0)
            }
        }
    }
    
    private func setConstraint(value: CGFloat, attribute: NSLayoutConstraint.Attribute) {
        removeConstraint(attribute: attribute)
        let constraint =
            NSLayoutConstraint(item: self,
                               attribute: attribute,
                               relatedBy: NSLayoutConstraint.Relation.equal,
                               toItem: nil,
                               attribute: NSLayoutConstraint.Attribute.notAnAttribute,
                               multiplier: 1,
                               constant: value)
        self.addConstraint(constraint)
    }
    
    /**
    Set accessibilityIdentifier any UIView

    by Ajay
    */
    var id: String? {
          get {
              return self.accessibilityIdentifier
          }
          set {
              self.accessibilityIdentifier = newValue
          }
      }

      func view(withId id: String) -> UIView? {
          if self.id == id {
              return self
          }
          for view in self.subviews {
              if let view = view.view(withId: id) {
                  return view
              }
          }
          return nil
      }
    
}

extension UITableView {
    func setEmptyView(title: String, message: String) {
        let emptyView = UIView(frame: CGRect(x: self.center.x, y: self.center.y, width: self.bounds.size.width, height: self.bounds.size.height))
        let titleLabel = UILabel()
        let messageLabel = UILabel()
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.textColor = UIColor.black
        titleLabel.font = UIFont.themeFontSize
        messageLabel.textColor = UIColor.lightGray
        messageLabel.font = UIFont.themeFontSize
        emptyView.addSubview(titleLabel)
        emptyView.addSubview(messageLabel)
        titleLabel.centerYAnchor.constraint(equalTo: emptyView.centerYAnchor).isActive = true
        titleLabel.centerXAnchor.constraint(equalTo: emptyView.centerXAnchor).isActive = true
        messageLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20).isActive = true
        messageLabel.leftAnchor.constraint(equalTo: emptyView.leftAnchor, constant: 20).isActive = true
        messageLabel.rightAnchor.constraint(equalTo: emptyView.rightAnchor, constant: -20).isActive = true
        titleLabel.text = title
        messageLabel.text = message
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        // The only tricky part is here:
        self.backgroundView = emptyView
        self.separatorStyle = .none
    }
    func restore() {
        self.backgroundView = nil
        self.separatorStyle = .singleLine
    }
}

extension UITableView {
    
    func setEmptyView(title: String, message: String, messageImage: UIImage) {
        
        let emptyView = UIView(frame: CGRect(x: self.center.x, y: self.center.y, width: self.bounds.size.width, height: self.bounds.size.height))
        
        let messageImageView = UIImageView()
        let titleLabel = UILabel()
        let messageLabel = UILabel()
        
        messageImageView.backgroundColor = .clear
        
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        messageImageView.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        
        titleLabel.textColor = UIColor.black
        titleLabel.font = UIFont.themeFontSize
        
        messageLabel.textColor = UIColor.lightGray
        messageLabel.font = UIFont.themeFontSize
        
        emptyView.addSubview(titleLabel)
        emptyView.addSubview(messageImageView)
        emptyView.addSubview(messageLabel)
        
        messageImageView.centerXAnchor.constraint(equalTo: emptyView.centerXAnchor).isActive = true
        messageImageView.centerYAnchor.constraint(equalTo: emptyView.centerYAnchor, constant: -20).isActive = true
        messageImageView.widthAnchor.constraint(equalToConstant: 200).isActive = true
        messageImageView.heightAnchor.constraint(equalToConstant: 200).isActive = true
        
        titleLabel.topAnchor.constraint(equalTo: messageImageView.bottomAnchor, constant: 10).isActive = true
        titleLabel.centerXAnchor.constraint(equalTo: emptyView.centerXAnchor).isActive = true
        
        messageLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10).isActive = true
        messageLabel.centerXAnchor.constraint(equalTo: emptyView.centerXAnchor).isActive = true
        
        messageImageView.image = messageImage
        titleLabel.text = title
        messageLabel.text = message
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        
        self.backgroundView = emptyView
        self.separatorStyle = .none
    }
}

extension UISegmentedControl {
    func setCubberLayout() {
        //        if #available(iOS 9.0, *) {
        //            UILabel.appearanceWhenContainedInInstancesOfClasses([UISegmentedControl.self]).numberOfLines = 0
        //        } else {
        //            // Fallback on earlier versions
        //        }
        self.tintColor = UIColor.blue
        self.subviews[0].tintColor = UIColor.yellow
        self.titleForSegment(at: 0)
    }
}

extension URL {
    func getDataFromQueryString() -> typeAliasStringDictionary {
        let urlComponents: URLComponents = URLComponents(url: self, resolvingAgainstBaseURL: false)!
        let arrQueryItems: Array<URLQueryItem> = urlComponents.queryItems!
        var dictParams = typeAliasStringDictionary()
        for item:URLQueryItem in arrQueryItems { dictParams[item.name] = item.value }
        return dictParams
    }
}
extension UIScrollView {
    func scrollToTop() {
        let desiredOffset = CGPoint(x: 0, y: -contentInset.top)
        setContentOffset(desiredOffset, animated: true)
    }
}
public extension UIDevice {
    
    var modelName: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8 , value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        
        switch identifier {
        case "iPod5,1":                                 return "iPod Touch 5"
        case "iPod7,1":                                 return "iPod Touch 6"
        case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
        case "iPhone4,1":                               return "iPhone 4s"
        case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
        case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
        case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
        case "iPhone7,2":                               return "iPhone 6"
        case "iPhone7,1":                               return "iPhone 6 Plus"
        case "iPhone8,1":                               return "iPhone 6s"
        case "iPhone8,2":                               return "iPhone 6s Plus"
        case "iPhone9,1", "iPhone9,3":                  return "iPhone 7"
        case "iPhone9,2", "iPhone9,4":                  return "iPhone 7 Plus"
        case "iPhone8,4":                               return "iPhone SE"
        case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
        case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad 3"
        case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad 4"
        case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
        case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
        case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad Mini"
        case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad Mini 2"
        case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad Mini 3"
        case "iPad5,1", "iPad5,2":                      return "iPad Mini 4"
        case "iPad6,3", "iPad6,4", "iPad6,7", "iPad6,8":return "iPad Pro"
        case "AppleTV5,3":                              return "Apple TV"
        case "i386", "x86_64":                          return "Simulator"
        default:                                        return identifier
        }
    }
}

extension UIFont {
    static let themeFontSize = UIFont(name: "WorkSans-Regular", size: 15)
    static let themeFontBoldSize = UIFont(name: "WorkSans-Bold", size: 15)
}
extension UIColor {
    
    /// color with int
    ///
    /// - Parameters:
    ///   - red: value of rad
    ///   - green: value of green
    ///   - blue: value of blue
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    
    convenience init(rgb: Int) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF
        )
    }
    
    convenience init(r: Int, g: Int, b: Int , a:CGFloat ) {
        
        self.init(red: CGFloat(r) / 255.0, green: CGFloat(g) / 255.0, blue: CGFloat(b) / 255.0, alpha: a)
    }
    
    //    static let themeSelectionColor = UIColor(hexString: "#0248A8")
    //    static let fontLightGrayColor = UIColor(hexString: "#828282")
    static let fontDarkGrayColor = UIColor(hexString: "#464646")
    static let themeLightSelectionColor = UIColor(hexString: "#EBF0f7")
    static let ThemeColor = UIColor(hexString: "#0498D0")
    
    static let collectionUnselectedColor = UIColor(r: 248, g: 248, b: 248, a: 1.0)
    
    /// color with hax string
    ///
    /// - Parameter hexString: <#hexString description#>
    convenience init(hexString:String) {
        let hexString:NSString = hexString.trimmingCharacters(in: CharacterSet.whitespaces) as NSString
        let scanner            = Scanner(string: hexString as String)
        
        if (hexString.hasPrefix("#")) {
            scanner.scanLocation = 1
        }
        
        var color:UInt32 = 0
        scanner.scanHexInt32(&color)
        
        let mask = 0x000000FF
        let r = Int(color >> 16) & mask
        let g = Int(color >> 8) & mask
        let b = Int(color) & mask
        
        let red   = CGFloat(r) / 255.0
        let green = CGFloat(g) / 255.0
        let blue  = CGFloat(b) / 255.0
        
        self.init(displayP3Red: red, green: green, blue: blue, alpha: 1)
        //self.init(red:red, green:green, blue:blue, alpha:1)
    }
    
    
    /// uicolor to hax string
    ///
    /// - Returns: <#return value description#>
    func toHexString() -> String {
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        
        getRed(&r, green: &g, blue: &b, alpha: &a)
        
        let rgb:Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
        
        return NSString(format:"#%06x", rgb) as String
    }
    
    
}




/*
 Block of UIControl
 */

/// Typealias for UIBarButtonItem closure.
typealias UIBarButtonItemTargetClosure = (UIBarButtonItem) -> ()

class UIBarButtonItemClosureWrapper: NSObject {
    let closure: UIBarButtonItemTargetClosure
    init(_ closure: @escaping UIBarButtonItemTargetClosure) {
        self.closure = closure
    }
}

extension UIBarButtonItem {
    
    private struct AssociatedKeys {
        static var targetClosure = "targetClosure"
    }
    
    private var targetClosure: UIBarButtonItemTargetClosure? {
        get {
            guard let closureWrapper = objc_getAssociatedObject(self, &AssociatedKeys.targetClosure) as? UIBarButtonItemClosureWrapper else { return nil }
            return closureWrapper.closure
        }
        set(newValue) {
            guard let newValue = newValue else { return }
            objc_setAssociatedObject(self, &AssociatedKeys.targetClosure, UIBarButtonItemClosureWrapper(newValue), objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    convenience init(title: String?, style: UIBarButtonItem.Style, closure: @escaping UIBarButtonItemTargetClosure) {
        self.init(title: title, style: style, target: nil, action: nil)
        targetClosure = closure
        action = #selector(UIBarButtonItem.closureAction)
    }
    
    
    @objc func closureAction() {
        guard let targetClosure = targetClosure else { return }
        targetClosure(self)
    }
}

//class ClosureSleeve {
//    let closure: () -> ()
//    
//    init(attachTo: AnyObject, closure: @escaping () -> ()) {
//        self.closure = closure
//        objc_setAssociatedObject(attachTo, "[\(arc4random())]", self, .OBJC_ASSOCIATION_RETAIN)
//    }
//    
//    @objc func invoke() {
//        closure()
//    }
//}


extension UIControl {
    //    func addAction(for controlEvents: UIControl.Event = .primaryActionTriggered, action: @escaping () -> ()) {
    //        let sleeve = ClosureSleeve(attachTo: self, closure: action)
    //        addTarget(sleeve, action: #selector(ClosureSleeve.invoke), for: controlEvents)
    //    }
    
    func block_setAction(block: @escaping BlockButtonActionBlock) {
        objc_setAssociatedObject(self, &ActionBlockKey, ActionBlockWrapper(block: block), objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        addTarget(self, action: #selector(block_handleAction), for: .touchUpInside)
    }
    
    func block_editDonesetAction(block: @escaping BlockButtonActionBlock) {
        objc_setAssociatedObject(self, &ActionBlockKey, ActionBlockWrapper(block: block), objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        addTarget(self, action: #selector(block_handleAction), for: .editingDidEnd)
    }
    
    @objc func block_handleAction() {
        let wrapper = objc_getAssociatedObject(self, &ActionBlockKey) as! ActionBlockWrapper
        wrapper.block(self)
    }
}

var ActionBlockKey: UInt8 = 0

// a type for our action block closure
typealias BlockButtonActionBlock = (_ sender: UIControl) -> Void

class ActionBlockWrapper : NSObject {
    var block : BlockButtonActionBlock
    init(block: @escaping BlockButtonActionBlock) {
        self.block = block
    }
}


extension NSNumber {
    func toCurrency() -> String {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .currency
        return numberFormatter.string(from: self)!
    }
}


extension Data {
    var hexString: String {
        let hexString = map { String(format: "%02.2hhx", $0) }.joined()
        return hexString
    }
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromCATransitionType(_ input: CATransitionType) -> String {
    return input.rawValue
}



//MARK:- Shadow Class
class shadowView: UIView {
    override func awakeFromNib() {
        // shadow
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOffset = CGSize(width: 1, height: 1)
        self.layer.shadowOpacity = 0.2
        self.layer.shadowRadius = 2.0
        super.awakeFromNib()
        
    }
}
// Definition:
extension Notification.Name {
    static let SEARCHNOTIFICATION = Notification.Name("SERACHNOTIFICATION")
}

func getString(value: Any?,nullValue : String? = "") -> String{
    if let val = value {
        if val is NSNull{
            return nullValue!
        }else if (val as? NSNumber) != nil {
            return  (val as AnyObject).stringValue
            
        }else if (val as? String) != nil {
            return val as! String
        }else{
            return val as! String
        }
    }
    return nullValue!
}


func getDouble(value: Any?,nullValue :Double? = 0.0 ) -> Double {
    var fValue: Double = nullValue!
    if let val = value {
        if val is NSNull {
            return fValue
        }
        else {
            if val is Int {
                fValue = Double(val as! Int)
            }
            else if val is String {
                let stValue: String = val as! String
                fValue = (stValue as NSString).doubleValue
            }
            else if val is Float {
                fValue = Double(val as! Float)
            }else if val is Double {
                fValue = val as! Double
            }else{
                return fValue
            }
        }
    }
    return fValue
}
func getInt(value: Any?,nullValue :Int? = 0  ) -> Int {
    var fValue: Int = nullValue!
    if let val = value {
        if val is NSNull {
            return 0
        }
        else {
            if val is Int {
                fValue = val as! Int
            }
            else if val is Double {
                fValue = Int(val as! Double)
            }
            else if val is String {
                let stValue: String = val as! String
                fValue = (stValue as NSString).integerValue
            }
            else if val is Float {
                fValue = Int(val as! Float)
            }else{
                
            }
        }
    }
    return fValue
}
extension UIApplication {
    /// Checks if view hierarchy of application contains `UIRemoteKeyboardWindow` if it does, keyboard is presented
    var isKeyboardPresented: Bool {
        if let keyboardWindowClass = NSClassFromString("UIRemoteKeyboardWindow"),
            self.windows.contains(where: { $0.isKind(of: keyboardWindowClass) }) {
            return true
        } else {
            return false
        }
    }
}

extension UIPageViewController {
    var isPagingEnabled: Bool {
        get {
            var isEnabled: Bool = true
            for view in view.subviews {
                if let subView = view as? UIScrollView {
                    isEnabled = subView.isScrollEnabled
                }
            }
            return isEnabled
        }
        set {
            for view in view.subviews {
                if let subView = view as? UIScrollView {
                    subView.isScrollEnabled = newValue
                }
            }
        }
    }
}

/**
 - This is for setup Constraint equeal to the super view
 //   -
 // | - |
 //   -
 - Parameter view: PassView which need to equal to super View
 /// ads
 */
func setequalSuperView(_ view:UIView){
    view.translatesAutoresizingMaskIntoConstraints = false
    let attributes: [NSLayoutConstraint.Attribute] = [.top, .bottom, .right, .left]
    if (view.superview != nil) {
        NSLayoutConstraint.activate(attributes.map {
            NSLayoutConstraint(item: view, attribute: $0, relatedBy: .equal, toItem: view.superview, attribute: $0, multiplier: 1, constant: 0)
        })
    }else{
        dLog(message: "\n\nPlease add to subview fist after call this line\n\n")
    }
    
}

//datetextfield
extension UITextField {
    
    func addInputViewDatePicker(target: Any, selector: Selector,minDate:Date) {
        
        let screenWidth = UIScreen.main.bounds.width
        
        //Add DatePicker as inputView
        let datePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
        datePicker.datePickerMode = .date
        datePicker.minimumDate = minDate
        
        self.inputView = datePicker
        
        //Add Tool Bar as input AccessoryView
        let toolBar = UIToolbar(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 44))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelBarButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelPressed))
        let doneBarButton = UIBarButtonItem(title: "Done", style: .plain, target: target, action: selector)
        toolBar.setItems([cancelBarButton, flexibleSpace, doneBarButton], animated: false)
        
        self.inputAccessoryView = toolBar
    }
    
    @objc func cancelPressed() {
        self.resignFirstResponder()
    }
}
extension UIView {
    func setHeight(_ h:CGFloat, animateTime:TimeInterval?=nil) {
        
        if let c = self.constraints.first(where: { $0.firstAttribute == .height && $0.relation == .equal }) {
            c.constant = CGFloat(h)
            
            if let animateTime = animateTime {
                //                UIView.animate(withDuration: animateTime, animations:{
                self.superview?.layoutIfNeeded()
                //                })
            }
            else {
                self.superview?.layoutIfNeeded()
            }
        }
    }
}
