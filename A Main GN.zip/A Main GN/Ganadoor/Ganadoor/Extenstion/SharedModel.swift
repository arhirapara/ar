//
//  SharedModel.swift
//

let NS_UDID                                     = "NS_UDID"
let NS_ShapeImage                               = "NS_ShapeImage"
let NS_LabImage                                 = "NS_LabImage"

let NS_USER_INFO                                = "NS_USER_INFO"
let NS_ROLE_DATA                                = "NS_ROLE_DATA"
let NS_PS_INFO                                  = "NS_PS_INFO"
let NS_LANGUAGE_STATUS                                 = "NS_LANGUAGE_STATUS"
let NS_IS_RESET_SEARCH_CRITERIA                 = "NS_IS_RESET_SEARCH_CRITERIA"
let NS_IS_RESET_SAVE_SEARCH_CRITERIA            = "NS_IS_RESET_SAVE_SEARCH_CRITERIA"
let NS_SEARCH_CRITERIA_LIST                     = "NS_SEARCH_CRITERIA_LIST"

let NS_TOOLTIP_RESULT                           = "NS_TOOLTIP_RESULT"
let NS_TOOLTIP_DETAIL                           = "NS_TOOLTIP_DETAIL"

let NS_USERNAME                                 = "NS_USERNAME"
let NS_PASSWORD                                 = "NS_PASSWORD"

let NS_Token                                 = "NS_Token"

let NS_TIMER                                    = "NS_TIMER"
let NS_USER_BIO                                = "NS_USER_BIO"
let NS_UPDATE_FLAG                                = "NS_UPDATE_FLAG"
let NS_MENU_DATA                                = "NS_MENU_DATA"
let NS_REMEBER_ME                                = "NS_REMEBER_ME"

let NS_CHANGE_SELLER_LAN                         = "NS_CHANGE_SELLER_LAN"
let NS_HEADER_TOKEN                             = "NS_HEADER_TOKEN"
let HEADER_DEFAULT                              = "hp/R7xYbycq9wzyGeRwFFbG9mDlL/DgtjY01eeyvUCg="

let NS_LOGIN_STATUS                             = "NS_LOGIN_STATUS"
let NS_SIDE_MENU                                = "NS_SIDE_MENU"
let NS_NOTIFICATION_COUNT                       = "NS_NOTIFICATION_COUNT"
let NS_SWITCHJEWELLERY_STATUS                   = "NS_SWITCHJEWELLERY_STATUS"
/// Get Entity Model
let SHAPE                        = 0;
let CARAT                        = 1;
let CLARITY                      = 2;
let COLOR                        = 3;
let CUT                          = 4;
let SUB_CLARITY                  = 5;
let SUB_COLOR                    = 6;
let FLOROSCENCE                  = 8;
let LUSTER                       = 9;
let SYMMETRY                     = 11;
let CULET                        = 13;
let GIRDLE                       = 14;
let EXTRA_FACATE_CROWN           = 18;
let POLISH                       = 20;
let COLOR_SHADE                  = 21;
let OPEN_PAVILION_INCLUSION      = 22;
let TABLE_INCLUSION              = 23;
let TYPE_OF_INCLUSION            = 30;
let HEART_ARROW                  = 31;
let LAB                          = 34;
let OPEN_TABLE_INCLUSION         = 47;
let OPEN_CROWN_INCLUSION         = 48;
let PAVILION                     = 50;
let BLACK_INCLON_SIDE            = 51;
let BLACK_INCLON_CENTER          = 52;
let FLOROSCENCE_COLOR            = 58;
let EYE_CLEAN                    = 66;
let FANCY_COLOR                  = 67;
let INTENSITY                    = 68;
let OVERTONE                     = 69;
let EXTRA_FACATE_PAVALION        = 70;
let LOCATION                     = 76;
let BOW_TIE                      = 87;
let KEY_TO_SYMBOL                = 89;
let REPORT_COMMENTS              = 90;
let MINE                         = 1001;
let ROUGH_ORIGIN                 = 1002;



import UIKit

class SharedModel: NSObject {
    class func setUDID(_ udid: String) {
        UserDefaults.standard.setValue(udid, forKey:NS_UDID)
        UserDefaults.standard.synchronize()
    }
    
    class func getUDID() -> String {
        var udid: String = " "
        if UserDefaults.standard.value(forKey: NS_UDID) != nil {
            udid = (UserDefaults.standard.value(forKey: NS_UDID) as! String)
        }
        return udid
    }
    
    struct NetInfo {
        let ip: String
        let netmask: String
    }
    
    class func setLanguageStatus(_ status: Bool) {
        UserDefaults.standard.set(status, forKey: NS_LANGUAGE_STATUS)
        UserDefaults.standard.synchronize()
    }
    
    class func getLanguageStatus() -> Bool {
        return UserDefaults.standard.bool(forKey: NS_LANGUAGE_STATUS)
    }
    
    class func  setBioMatrix(_ onoff:Bool){
        UserDefaults.standard.set(onoff, forKey: NS_USER_BIO)
        UserDefaults.standard.synchronize()
    }
    
    class func  getBioMatrix() -> Bool{
        var pwd: Bool = false
        pwd = UserDefaults.standard.bool(forKey: NS_USER_BIO)
        return pwd
    }
    
    class func getIPAddress() -> String {
        var addresses = [NetInfo]()
        
        // Get list of all interfaces on the local machine:
        var ifaddr : UnsafeMutablePointer<ifaddrs>? = nil
        if getifaddrs(&ifaddr) == 0 {
            
            var ptr = ifaddr;
            while ptr != nil {
                
                let flags = Int32((ptr?.pointee.ifa_flags)!)
                var addr = ptr?.pointee.ifa_addr.pointee
                
                // Check for running IPv4, IPv6 interfaces. Skip the loopback interface.
                if (flags & (IFF_UP|IFF_RUNNING|IFF_LOOPBACK)) == (IFF_UP|IFF_RUNNING) {
                    if addr?.sa_family == UInt8(AF_INET) || addr?.sa_family == UInt8(AF_INET6) {
                        
                        // Convert interface address to a human readable string:
                        var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                        if (getnameinfo(&addr!, socklen_t((addr?.sa_len)!), &hostname, socklen_t(hostname.count),
                                        nil, socklen_t(0), NI_NUMERICHOST) == 0) {
                            if let address = String.init(validatingUTF8:hostname) {
                                
                                var net = ptr?.pointee.ifa_netmask.pointee
                                var netmaskName = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                                getnameinfo(&net!, socklen_t((net?.sa_len)!), &netmaskName, socklen_t(netmaskName.count),
                                            nil, socklen_t(0), NI_NUMERICHOST)// == 0
                                if let netmask = String.init(validatingUTF8:netmaskName) {
                                    addresses.append(NetInfo(ip: address, netmask: netmask))
                                }
                            }
                        }
                    }
                }
                ptr = ptr?.pointee.ifa_next
            }
            freeifaddrs(ifaddr)
        }
        
        if addresses.last?.ip == nil { return "" }
        return (addresses.last?.ip)!
    }
    
    class func getAppVersion() -> String? {
        return Bundle.main.infoDictionary!["CFBundleShortVersionString"] as? String
    }
    
    //--> Login Remember
    class func setUsername(_ username: String) {
        UserDefaults.standard.setValue(username, forKey:NS_USERNAME)
        UserDefaults.standard.synchronize()
    }
    
    class func getUsername() -> String {
        var username: String = ""
        if UserDefaults.standard.value(forKey: NS_USERNAME) != nil { username = (UserDefaults.standard.value(forKey: NS_USERNAME) as! String) }
        return username
    }
    
    class func setPassword(_ pwd: String) {
        UserDefaults.standard.setValue(pwd, forKey:NS_PASSWORD)
        UserDefaults.standard.synchronize()
    }
    
    class func getPassword() -> String {
        var pwd: String = ""
        if UserDefaults.standard.value(forKey: NS_PASSWORD) != nil { pwd = (UserDefaults.standard.value(forKey: NS_PASSWORD) as! String) }
        return pwd
    }
    
    class func setToken(_ token: String) {
        UserDefaults.standard.setValue(token, forKey:NS_Token)
        UserDefaults.standard.synchronize()
    }
    
    class func getToken() -> String {
        var token: String = ""
        if UserDefaults.standard.value(forKey: NS_Token) != nil { token = (UserDefaults.standard.value(forKey: NS_Token) as! String) }
        return token
    }
    
    class func removeUsername() {
        UserDefaults.standard.removeObject(forKey: NS_USERNAME)
        UserDefaults.standard.synchronize()
    }
    
    class func removePassword() {
        UserDefaults.standard.removeObject(forKey: NS_PASSWORD)
        UserDefaults.standard.synchronize()
    }
    //<--
    
    class func setNotificationCount(_ token: String) {
        UserDefaults.standard.setValue(token, forKey:NS_NOTIFICATION_COUNT)
        UserDefaults.standard.synchronize()
    }
    
    
    class func GetNotificationCount() -> String {
        var Notification_Count: String = ""
        if UserDefaults.standard.value(forKey: NS_NOTIFICATION_COUNT) != nil {
            Notification_Count = (UserDefaults.standard.value(forKey: NS_NOTIFICATION_COUNT) as! String)
        }
        return Notification_Count
    }
    
    //Help Kit
    class func setTooltipResult(_ status: Bool) {
        UserDefaults.standard.set(status, forKey: NS_TOOLTIP_RESULT)
        UserDefaults.standard.synchronize()
    }
    
    class func getTooltipResult() -> Bool {
        return UserDefaults.standard.bool(forKey: NS_TOOLTIP_RESULT)
    }
    
    class func setTooltipDetail(_ status: Bool) {
        UserDefaults.standard.set(status, forKey: NS_TOOLTIP_DETAIL)
        UserDefaults.standard.synchronize()
    }
    
    class func getTooltipDetail() -> Bool {
        return UserDefaults.standard.bool(forKey: NS_TOOLTIP_DETAIL)
    }
    
    class func setLoginStatus(_ status: Bool) {
        UserDefaults.standard.set(status, forKey: NS_LOGIN_STATUS)
        UserDefaults.standard.synchronize()
    }
    
    class func getLoginStatus() -> Bool {
        
        var status = false
        if UserDefaults.standard.object(forKey: NS_LOGIN_STATUS) != nil { status = UserDefaults.standard.object(forKey: NS_LOGIN_STATUS) as! Bool }
        return status
        
    }
    
    class func setSwitchJewelleryStatus(_ status: Bool) {
        UserDefaults.standard.set(status, forKey: NS_SWITCHJEWELLERY_STATUS)
        UserDefaults.standard.synchronize()
    }
    
    class func getSwitchJewelleryStatus() -> Bool {
        
        var status = false
        if UserDefaults.standard.object(forKey: NS_SWITCHJEWELLERY_STATUS) != nil { status = UserDefaults.standard.object(forKey: NS_SWITCHJEWELLERY_STATUS) as! Bool }
        return status
        
    }
    
    //UserInfo
    class func setUserInfo(_ dict: typeAliasDictionary) {
        UserDefaults.standard.set(dict, forKey: NS_USER_INFO)
        UserDefaults.standard.synchronize()
    }
    
    class func getUserInfo() -> typeAliasDictionary {
        var dictUserInfo = typeAliasDictionary()
        if UserDefaults.standard.object(forKey: NS_USER_INFO) != nil { dictUserInfo = UserDefaults.standard.object(forKey: NS_USER_INFO) as! typeAliasDictionary }
        return dictUserInfo
    }
    
    class func setUserLoginInfo(_ array: [typeAliasStringDictionary]) {
        UserDefaults.standard.set(array, forKey:NS_REMEBER_ME)
        UserDefaults.standard.synchronize()
    }
    
    class func getUserLoginInfo() -> [typeAliasStringDictionary] {
        return UserDefaults.standard.object(forKey: NS_REMEBER_ME) != nil ? UserDefaults.standard.object(forKey: NS_REMEBER_ME) as! [typeAliasStringDictionary] : [typeAliasStringDictionary]()
    }
    
    
    class func removeUserInfo() {
        UserDefaults.standard.removeObject(forKey: NS_USER_INFO)
        UserDefaults.standard.synchronize()
    }
    
    /// Use this fucntion to get any user infromation by key 
    /// - Parameter key: <#key description#>
    class func getUserInfoForKey(_ key:String) -> String {
        var dictUserInfo = typeAliasDictionary()
        if UserDefaults.standard.object(forKey: NS_USER_INFO) != nil { dictUserInfo = UserDefaults.standard.object(forKey: NS_USER_INFO) as! typeAliasDictionary }
        return  dictUserInfo.valuForKeyWithNullString(Key: key, NullReplaceValue: "")
    }
    
    //Role data
    class func setRoleData(_ array: [typeAliasDictionary]) {
        UserDefaults.standard.set(array, forKey:NS_ROLE_DATA)
        UserDefaults.standard.synchronize()
    }
    
    class func getRoleData() -> [typeAliasDictionary] {
        return UserDefaults.standard.object(forKey: NS_ROLE_DATA) != nil ? UserDefaults.standard.object(forKey: NS_ROLE_DATA) as! [typeAliasDictionary] : [typeAliasDictionary]()
    }
    
    class func setMenuData(_ array: [typeAliasDictionary]) {
        UserDefaults.standard.set(array, forKey:NS_MENU_DATA)
        UserDefaults.standard.synchronize()
    }
    
    class func getMenuData() -> [typeAliasDictionary] {
        return UserDefaults.standard.object(forKey: NS_MENU_DATA) != nil ? UserDefaults.standard.object(forKey: NS_MENU_DATA) as! [typeAliasDictionary] : [typeAliasDictionary]()
    }
    
    //PsInfo
    class func setPsInfo(_ dict: typeAliasDictionary) {
        UserDefaults.standard.set(dict, forKey: NS_PS_INFO)
        UserDefaults.standard.synchronize()
    }
    
    class func getPsInfo() -> typeAliasDictionary {
        var dictUserInfo = typeAliasDictionary()
        if UserDefaults.standard.object(forKey: NS_PS_INFO) != nil { dictUserInfo = UserDefaults.standard.object(forKey: NS_PS_INFO) as! typeAliasDictionary }
        return dictUserInfo
    }
    
    class func setUpdateFlagInfo(_ dict: typeAliasDictionary) {
        UserDefaults.standard.set(dict, forKey: NS_UPDATE_FLAG)
        UserDefaults.standard.synchronize()
    }
    
    class func getUpdateFlagInfo() -> typeAliasDictionary {
        var dictUserInfo = typeAliasDictionary()
        if UserDefaults.standard.object(forKey: NS_UPDATE_FLAG) != nil { dictUserInfo = UserDefaults.standard.object(forKey: NS_UPDATE_FLAG) as! typeAliasDictionary }
        return dictUserInfo
    }
    
    //set search criateria
    class func setSearchCriteria(_ criteriaDict: typeAliasDictionary) {
        UserDefaults.standard.set(criteriaDict.nullKeyRemoval(), forKey: NS_SEARCH_CRITERIA_LIST)
        UserDefaults.standard.synchronize()
    }
    class func getSearchCriteria() -> typeAliasDictionary {
        //        UserDefaults.standard.set(criteriaDict.nullKeyRemoval(), forKey: NS_SEARCH_CRITERIA_LIST)
        if UserDefaults.standard.object(forKey: NS_SEARCH_CRITERIA_LIST) != nil
        {
            return UserDefaults.standard.object(forKey: NS_SEARCH_CRITERIA_LIST) as! typeAliasDictionary
        } else {
            return typeAliasDictionary()
        }
        //        return UserDefaults.standard.dictionary(forKey: NS_SEARCH_CRITERIA_LIST)! as typeAliasDictionary
    }
    
    
    class func setShapeImage(_ stShapeImage: String) {
        UserDefaults.standard.setValue(stShapeImage, forKey:NS_ShapeImage)
        UserDefaults.standard.synchronize()
    }
    
    class func getShapeImage() -> String {
        var stShapeImage: String = " "
        if UserDefaults.standard.value(forKey: NS_ShapeImage) != nil {
            stShapeImage = (UserDefaults.standard.value(forKey: NS_ShapeImage) as! String)
        }
        return stShapeImage
    }
    
    class func setLabImage(_ stLabImage: String) {
        UserDefaults.standard.setValue(stLabImage, forKey:NS_LabImage)
        UserDefaults.standard.synchronize()
    }
    
    class func getLabImage() -> String {
        var stLabImage: String = " "
        if UserDefaults.standard.value(forKey: NS_LabImage) != nil {
            stLabImage = (UserDefaults.standard.value(forKey: NS_LabImage) as! String)
        }
        return stLabImage
    }
    // ---------->>
    class func setIsResetSearchCriteria(_ isResetSearchCriteria: Bool) {
        UserDefaults.standard.set(isResetSearchCriteria, forKey: NS_IS_RESET_SEARCH_CRITERIA)
        UserDefaults.standard.synchronize()
    }
    
    class func getIsResetSearchCriteria() -> Bool {
        return UserDefaults.standard.bool(forKey: NS_IS_RESET_SEARCH_CRITERIA)
    }
    
    class func setIsResetSaveSearchCriteria(_ isSetSaveSearchCriteria: Bool) {
        UserDefaults.standard.set(isSetSaveSearchCriteria, forKey: NS_IS_RESET_SAVE_SEARCH_CRITERIA)
        UserDefaults.standard.synchronize()
    }
    
    class func getIsResetSaveSearchCriteria() -> Bool {
        return UserDefaults.standard.bool(forKey: NS_IS_RESET_SAVE_SEARCH_CRITERIA)
    }
    
    class func setSideMenu(_ menuList:[typeAliasDictionary]) {
        UserDefaults.standard.set(menuList, forKey: NS_SIDE_MENU)
        UserDefaults.standard.synchronize()
    }
    
    class func getSideMenu() -> [typeAliasDictionary] {
        return UserDefaults.standard.array(forKey: NS_SIDE_MENU) as! [typeAliasDictionary]
    }
    
    class func setSellerLan(_ HideHoldTerms: Bool) {
        UserDefaults.standard.setValue(HideHoldTerms, forKey:NS_CHANGE_SELLER_LAN)
        UserDefaults.standard.synchronize()
    }
    
    class func setHeaderToken(_ token: String) {
        UserDefaults.standard.setValue(token, forKey:NS_HEADER_TOKEN)
        UserDefaults.standard.synchronize()
    }
    class func getHeaderToken() -> String {
        
        var headerToken: String = HEADER_DEFAULT
        if UserDefaults.standard.value(forKey: NS_HEADER_TOKEN) != nil {
            headerToken = (UserDefaults.standard.value(forKey: NS_HEADER_TOKEN) as! String)
            headerToken = headerToken.isEmpty ? HEADER_DEFAULT : headerToken
        }
        return headerToken
    }
    
    class func getDeviceName() -> String {
        return UIDevice.current.name
    }
    
    class func getVendorIdentifier() -> String {
        return (UIDevice.current.identifierForVendor?.uuidString)!
    }
    
    class func getAppBuildVersion() -> String {
        return Bundle.main.infoDictionary!.valuForKeyString("CFBundleVersion")
    }
}

func getDateFormate(_ sdate:String) -> String{
    // create dateFormatter with UTC time format
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
    dateFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone?
    if let date = dateFormatter.date(from: sdate)
    {
        // change to a readable time format and change to local time zone
        dateFormatter.dateFormat = "d/MM/yyyy h:mm a"
        dateFormatter.timeZone = NSTimeZone.local
        return  dateFormatter.string(from: date)
    }else{
        //if date not found then retun currunt date
        return  dateFormatter.string(from:Date())
    }
}

func getDateFormate(_ sdate:String,fromFormate:String,toFormate:String) -> String{
    // create dateFormatter with UTC time format
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = fromFormate//"yyyy-MM-dd'T'HH:mm:ss.SSS"
    dateFormatter.timeZone = NSTimeZone.local
    if let date = dateFormatter.date(from: sdate)
    {
        // change to a readable time format and change to local time zone
        dateFormatter.dateFormat = toFormate // "d/MM/yyyy h:mm a"
        dateFormatter.timeZone = NSTimeZone.local
        return  dateFormatter.string(from: date)
    }else{
        //if date not found then retun currunt date
        return  dateFormatter.string(from:Date())
    }
}

func setDateFormat(_ sdate:String) -> String{
    // create dateFormatter with UTC time format
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
    dateFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone?
    if let date = dateFormatter.date(from: sdate)
    {
        // change to a readable time format and change to local time zone
        dateFormatter.dateFormat = "d/MM/yyyy h:mm a"
        dateFormatter.timeZone = NSTimeZone.local
        return  dateFormatter.string(from: date)
    }else{
        //if date not found then retun currunt date
        dateFormatter.dateFormat = "d/MM/yyyy h:mm a"
        return  dateFormatter.string(from:Date())
    }
}

func setDateFormatForMail (_ sdate:String) -> String{
    // create dateFormatter with UTC time format
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
    dateFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone?
    if let date = dateFormatter.date(from: sdate)
    {
        // change to a readable time format and change to local time zone
        dateFormatter.dateFormat = "EEE, MMM d, yy"
        dateFormatter.timeZone = NSTimeZone.local
        return  dateFormatter.string(from: date)
    }else{
        //if date not found then retun currunt date
        dateFormatter.dateFormat = "EEE, MMM d, yy"
        return  dateFormatter.string(from:Date())
    }
}

public enum ALERT_MESSAGE_TYPE: Int {
    case SUCCESS
    case FAILURE
    case WARNING
}


func showAlertWithTitle(title : String, message : String, type : ALERT_MESSAGE_TYPE) {
    
    if type == .SUCCESS {
        ISMessages.showCardAlert(withTitle: title  , message: message.localized , duration: 2.0, hideOnSwipe: true, hideOnTap: true, alertType: ISAlertType(rawValue: 0)!, alertPosition: ISAlertPosition.top, didHide: nil)
    }
    
    if type == .FAILURE  {
        ISMessages.showCardAlert(withTitle: title , message: message.localized , duration: 2.0, hideOnSwipe: true, hideOnTap: true, alertType: ISAlertType(rawValue: 1)!, alertPosition: ISAlertPosition.top, didHide: nil)
    }
    
    if type == .WARNING {
        ISMessages.showCardAlert(withTitle: title  , message: message.localized , duration: 2.0, hideOnSwipe: true, hideOnTap: true, alertType: ISAlertType(rawValue: 2)!, alertPosition: ISAlertPosition.top, didHide: nil)
    }
}
