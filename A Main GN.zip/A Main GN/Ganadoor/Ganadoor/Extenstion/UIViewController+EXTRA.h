//
//  UIViewController+EXTRA.h
//  Demo
//
//  Created by DNK157 on 3/29/19.
//  Copyright © 2019 DNK. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (EXTRA)
@property (readwrite) BOOL isBackButton;

@end

NS_ASSUME_NONNULL_END
