//
//  RequestElement.swift
//  JODHANI
//
//  Created by DNK062 on 08/01/20.
//  Copyright © 2020 DNK KISHAN. All rights reserved.
//

import Foundation

let REQ_MethodName          = "JGTKMIOOHO";

//ServiceUpdateFlag
let REQ_Device_token        = "ILJYKMNBHY"
let REQ_Device_type         = "LQWVBUTFKZ"
let REQ_Device_version      = "CLWRVGDOGL"
let REQ_User_id             = "YXMTBLCMNB"
let REQ_User_mobile         = "UBIRWQBVXT"
let REQ_Outlet_id           = "GYHNMDEQPI"
let REQ_Giftcard_id         = "IKRFWSHNPL"
let REQ_Device_mac_id       = "FIZWPLBCRS"
let REQ_DEVICE_NAME         = "SERFDCVXGT"

//Sign_Up
let REQ_USER_email          = "MKIOLHBGFV"
let REQ_USER_password       = "KJNHVBFGDT"
let REQ_FULL_name           = "CWERGDFAPC"
let REQ_MOBILE_number       = "UBIFWDBVZT"
let REQ_APP_VERSION         = "GHYROKMBVF"
let REQ_Device_id           = "QETUOMBCAL"
let REQ_DEVICE_MODEL        = "SERFDCVXGT"

//Login
let REQ_Header              = "WHNGUBPIKG"
let REQ_Random_No           = "DBPTWSKPPY"
let REQ_Email               = "MKIOLHBGFV"
let REQ_Password            = "KJNHVBFGDT"

//Category List With Search
let REQ_CATEGORY_name       = "UJMNHYTFRD"
let REQ_PAGE_NO             = "MNLRWMSPPW"

//Remove Delivery Address
let REQ_Address_Id          = "FDFGMXNCMJ"

//Add_update Address
let REQ_ACTION              = "DFXTIDREML"
let REQ_ADDRESS_TITLE       = "DDFRVWEGPM"
let REQ_PERSON_NAME         = "GHDLNOUPRC"
let REQ_MOBILE_NO           = "UBIFWDBVZT"
//let REQ_ADDRESS_1           = "ASPFGHPKLB"
//let REQ_ADDRESS_2           = "OLJXHGFPSE"
let REQ_PINCODE             = "PLFJHUIPND"
let REQ_CITY_ID             = "NXPUKSRQVX"
let REQ_ADDRESS_ID          = "FDFGMXNCMJ"
let REQ_HOUSE_NO            = "HYUJKLQRFV"
let REQ_APARTMENT_NAME      = "KXZVBGFYTH"
let REQ_STREET_DETAILS      = "ZPQBVHJDUJ"
let REQ_LANDMARK            = "GNJHBVGTRF"

//City List With Search
let REQ_CITY_NAME          = "OIUZXCGFDQ"

//My Order List
let REQ_SERVICE_NAME       = "JGTKMIOOHO"
let REQ_HEADER             = "WHNGUBPIKG"
let REQ_RANDOM_NUMBER      = "DBPTWSKPPY"
let REQ_USER_ID            = "YXMTBLCMNB"

//Product List With Search
let REQ_CATEGORY_ID          = "FYDSDVMQGP"
let REQ_MENU_TITLE           = "LOZSMULXCP"
let REQ_MENU_ID              = "FCSBWVQTFJ"
let REQ_ORDER_ID             = "EIHXDLCSHP"
let REQ_MENU_QTY             = "QSWGBCLKTP"
let REQ_DEVICE_TYPE          = "LQWRFDGCHT"


// Place Order

let REQ_ORDER_AMOUNT        = "FWJGVGSPWC"
let REQ_SUB_TOTAL           = "WJNZOFLDZB"
let REQ_PAYMENT_MODE        = "MARADXBKLQ"
let REQ_CART                = "QRCVNVKXHD"
let REQ_MENU_DETAIL         = "FGRVPBHNDKJ"
