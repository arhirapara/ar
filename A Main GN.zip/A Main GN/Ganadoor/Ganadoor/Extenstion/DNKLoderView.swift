//
//  DNKLoderView.swift
//  Vaibhav Gems
//
//  Created by DNK157 on 01/10/19.
//  Copyright © 2019 Kishan Sutariya. All rights reserved.
//

import UIKit
let shareKeyWindow = UIApplication.shared.keyWindow

class DNKLoderView: UIView {
    @IBOutlet var saveControll: NVActivityIndicatorView!
    override func awakeFromNib() {
        saveControll.startAnimating()
    }
    func stopanimation(){
        saveControll.stopAnimating()
        saveControll.removeFromSuperview()
        
    }
}

func showLoder(){
    
    if let window = shareKeyWindow ,window.viewWithTag(1231231231) == nil{
        // Do stuff
        let loderView: DNKLoderView = UIView.fromNib()
        loderView.frame = window.frame
        loderView.tag = 1231231231
        window.addSubview(loderView)
     }

}

func hideLoder(){
    if let window = shareKeyWindow ,window.viewWithTag(1231231231) != nil{
        let loderView: DNKLoderView = window.viewWithTag(1231231231) as! DNKLoderView
        loderView.stopanimation()
        loderView.removeFromSuperview()
    }
}
