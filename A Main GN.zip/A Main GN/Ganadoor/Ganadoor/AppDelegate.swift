//
//  AppDelegate.swift
//  Tembo
//
//  Created by AR on 02/05/20.
//  Copyright © 2020 DNK028. All rights reserved.
//

let APPLE_LANGUAGE                              = "AppleLanguages"

import UIKit
import FBSDKCoreKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var navigationController: AppNavigationController!
    var sideMenuController :SideMenuController!
    var contentViewController : AppTabBarController!
    var _table_view_navigation = TABLE_VIEW_NAVIGATION.TABLE_VIEW_NAVIGATION_DUMMY
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        IQKeyboardManager.shared.enable = true
        window = UIWindow.init(frame: UIScreen.main.bounds)
//        self.changeLanguage("en")
        showSplash()

        let userDefaultsROOT = ["ROOT_API" : "http://test.wibrate.com/Vincitore/API/V1nQhUF51xOLvRHdp/VncNxO2y1Qv9P/eKG4Axk52QKY/"]
        UserDefaults.standard.register(defaults: userDefaultsROOT)
        UITableView().noDataListioner()
        return true
    }
    
    func showSplash() {
        let splash = SplashScreenViewController.init(nibName: "SplashScreenViewController", bundle: nil)
        var navigationController: AppNavigationController!
        navigationController = AppNavigationController.init(rootViewController: splash)
        window?.rootViewController = navigationController
        window?.backgroundColor = UIColor.white
        window?.makeKeyAndVisible()
    }

    func logOut() {
        SharedModel.setHeaderToken("")
        SharedModel.setUserInfo(typeAliasDictionary())
        self.showSignUpOption()
    }
    
    func showHome() {
//        let contentViewController = HomeViewController(nibName: "HomeViewController", bundle: nil)
        contentViewController = AppTabBarController(nibName: "AppTabBarController", bundle: nil)
//        var homeNavigationController: AppNavigationController!
        navigationController = AppNavigationController.init(rootViewController: contentViewController)
        let menuViewController = SideMenuViewController(nibName: "SideMenuViewController", bundle: nil)
        
//
        self.sideMenuController =  SideMenuController(nibName:nil,bundle:nil)
//
        self.sideMenuController.contentViewController = navigationController
        self.sideMenuController.menuViewController = menuViewController
        navigationController.setNavigationBarHidden(true, animated: false);
        self.window?.rootViewController = self.sideMenuController
        self.window?.backgroundColor = UIColor.white
        self.window?.makeKeyAndVisible()
    }
    
    func showSignUpOption()  {
        let signupOption = SignupOptionsViewController(nibName: "SignupOptionsViewController", bundle: nil)
        navigationController = AppNavigationController.init(rootViewController: signupOption)
        window?.rootViewController = navigationController
    }
    
}
//FACEBOOK
extension AppDelegate{
    func application(
        _ app: UIApplication,
        open url: URL,
        options: [UIApplication.OpenURLOptionsKey : Any] = [:]
    ) -> Bool {
        
        ApplicationDelegate.shared.application(
            app,
            open: url,
            sourceApplication: options[UIApplication.OpenURLOptionsKey.sourceApplication] as? String,
            annotation: options[UIApplication.OpenURLOptionsKey.annotation]
        )
        
    }
    
    //MARK: SIDEMENU ACTION
    func clickOnSideMenu(_ sideMenu: Int) {
        let navigationController :AppNavigationController = self.sideMenuController?.contentViewController as! AppNavigationController
        
        switch sideMenu {
        case 0:
            contentViewController.selectedIndex = 0
            navigationController.setNavigationBarHidden(true, animated: false);
            sideMenuController.hideMenu()
        case 1:
            contentViewController.selectedIndex = 1
            navigationController.setNavigationBarHidden(true, animated: false);
            
            sideMenuController.hideMenu()
            //        case 2:
            //            contentViewController.selectedIndex = 2
            //            navigationController.setNavigationBarHidden(true, animated: false);
        //            sideMenuController.hideMenu()
        case 2:
//
//            let cartVC = BasketViewController(nibName: "BasketViewController", bundle: nil)
//            cartVC.isBackButton = true
//            cartVC.isNavigationBackButtionShow = true
//            cartVC.isNavigationSideMenu = true
//            navigationController.pushViewController(cartVC, animated: true)
//            navigationController.setNavigationBarHidden(false, animated: false);
            
            contentViewController.selectedIndex = 3
            navigationController.setNavigationBarHidden(true, animated: false);
            
            //sideMenuController.hideMenu()
            
            sideMenuController.hideMenu()
        case 3:
            let VC = MyOrdersViewController(nibName: "MyOrdersViewController", bundle: nil)
            VC.isBackButton = true
            VC.isNavigationBackButtionShow = true
            VC.isNavigationSideMenu = true
            navigationController.pushViewController(VC, animated: true)
            navigationController.setNavigationBarHidden(false, animated: false);
            
            sideMenuController.hideMenu()
        case 4:
            let VC = AddressListViewController(nibName: "AddressListViewController", bundle: nil)
            VC.isBackButton = true
            VC.isNavigationBackButtionShow = true
            VC.isNavigationSideMenu = true
            navigationController.pushViewController(VC, animated: true)
            navigationController.setNavigationBarHidden(false, animated: false);
            sideMenuController.hideMenu()
        case 5:
            let VC = ComingSoonViewController(nibName: "ComingSoonViewController", bundle: nil)
            VC.isBackButton = true
            VC.navigationTitle = "Customer Support"
            VC.isNavigationBackButtionShow = true
            navigationController.setNavigationBarHidden(false, animated: false);
            navigationController.pushViewController(VC, animated: true)
            sideMenuController.hideMenu()
        case 6:
            self.callShareApi()
        case 7:
            let VC = WebViewViewController(nibName: "WebViewViewController", bundle: nil)
            VC.navigationBarTitle = "About Us"
            VC.isNavigationBackButtionShow = true
            VC.isNavigationSideMenu = true
            VC.isBackButton = true
            VC.webUrlString = SharedModel.getUpdateFlagInfo().valuForKeyString("about_us")
            navigationController.pushViewController(VC, animated: true)
            navigationController.setNavigationBarHidden(false, animated: false);
            sideMenuController.hideMenu()
        default:
            sideMenuController.hideMenu()
        }
    }
    
    //MARK: Custom Function
    func shareImage(_ dictShare: typeAliasDictionary) {
        let img = UIImageView()
        
        let messageStr = dictShare.valuForKeyString("share_content")
        
        img.setImageWith(URL(string: dictShare.valuForKeyString("share_banner")), completed: { (image, url, cath, s) in
            if (image == nil){
                let activityViewController:UIActivityViewController = UIActivityViewController(activityItems:  [messageStr], applicationActivities: nil)
                activityViewController.excludedActivityTypes = [UIActivity.ActivityType.print, UIActivity.ActivityType.postToWeibo, UIActivity.ActivityType.copyToPasteboard, UIActivity.ActivityType.addToReadingList, UIActivity.ActivityType.postToVimeo]
                self.navigationController.present(activityViewController, animated: true, completion: nil)
            }else {
                let activityViewController:UIActivityViewController = UIActivityViewController(activityItems:  [image!, messageStr], applicationActivities: nil)
                activityViewController.excludedActivityTypes = [UIActivity.ActivityType.print, UIActivity.ActivityType.postToWeibo, UIActivity.ActivityType.copyToPasteboard, UIActivity.ActivityType.addToReadingList, UIActivity.ActivityType.postToVimeo]
                self.navigationController.present(activityViewController, animated: true, completion: nil)
            }
        }, usingActivityIndicatorStyle: .gray)
    }
    
    func callShareApi(){
        var param = typeAliasDictionary()
       
        param[REQ_User_id] = SharedModel.getUserInfo().valuForKeyString("User_Id")  as AnyObject
        
        callRestApi(API_Share, methodType: .POST, parameters: param, contentType: .X_WWW_FORM, showLoding: true, onCompletion: { (response) in
            print(response)
            if response.valuForKeyString("status") == "1" {
                self.shareImage(response.valuForKeyDic("Share_App_Data"))
                self.sideMenuController.hideMenu()
            }
            else if response.valuForKeyString("status") == "0" {
                
            }
        }, onFailure: { (error) in
            print(error)
        })
    }
    
    public func changeLanguage(_ languageCode: String) {
        if let arr = (UserDefaults.standard.object(forKey: APPLE_LANGUAGE) as? [String]) {
            if arr[0] == languageCode { return }
        }
        UserDefaults.standard.set([languageCode], forKey: APPLE_LANGUAGE)
        UserDefaults.standard.synchronize()
        
        //Run time conversion if you want
        Bundle.setLanguage(languageCode)//Magic Line ;)
    }
    
    func restartApp() {
        DispatchQueue.global().async {
            DispatchQueue.main.async {
                self.showSplash()
            }
        }
    }
    
}

 
