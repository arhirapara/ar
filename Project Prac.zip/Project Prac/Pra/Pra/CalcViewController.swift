//
//  CalcViewController.swift
//  Pra
//
//  Created by MacBook on 30/03/19.
//  Copyright © 2019 dnk. All rights reserved.
//

let CELL_CalcCell               =  "CalcCell"

import UIKit

class CalcViewController: UIViewController, UITextFieldDelegate{
    
    @IBOutlet var scrVilew: UIScrollView!
    // @IBOutlet var tablviewCell: UITableView!
    @IBOutlet var btnNext: UIButton!
    @IBOutlet var btnPrivew: UIButton!
    @IBOutlet var txtNumber: UITextField!
    
    var arr :[String] = [""]
    var arrInt = [Int]()
    
    override func viewDidLoad() { super.viewDidLoad()
        
    }
    
    
    

    @IBAction func btnNextAction(_ sender: UIButton) {
        
    }
 
    @IBAction func btnPreviewCation(_ sender: UIButton) {
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        arrInt = []
        if textField == txtNumber {
            var index:Int = 0
            index = Int(txtNumber.text!)!
            var colm = Double(index) / Double(4.0)
            //var colm = Double(index/4)
            colm = colm.rounded()
            index = (4*Int(colm))
            var counter = 0
            for _ in 0..<index {
                counter += 1
                if counter > Int(txtNumber.text!)! {
                    counter = 1
                }
                arrInt.append(counter)
            }
            
            let intColn = Int(colm)
            for i in 0..<intColn {
                let  oX = (CGFloat(i) * FRAME_SCREEN.width)
                let min = 4*i
                var max = 4*i+3
                if max >= arrInt.count { max = arrInt.count-1 }
                let arrSub = Array(arrInt[min...(max)])
                let _Viewcalc = Viewcalc.init(info: arrSub, frame: CGRect(x: oX, y: 0, width: FRAME_SCREEN.width, height: scrVilew.frame.height))
                
                scrVilew.addSubview(_Viewcalc)
            }
            scrVilew.contentSize = CGSize.init(width: CGFloat(intColn)*FRAME_SCREEN.width, height: scrVilew.frame.height)
            txtNumber.resignFirstResponder()
        return true
        }
        return true
    }
}
