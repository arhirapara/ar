//
//  CalcCell.swift
//  Pra
//
//  Created by MacBook on 30/03/19.
//  Copyright © 2019 dnk. All rights reserved.
//

import UIKit

class CalcCell: UITableViewCell {

    @IBOutlet var txtData: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
