//
//  Viewcalc.swift
//  Pra
//
//  Created by MacBook on 01/04/19.
//  Copyright © 2019 dnk. All rights reserved.
//

let FRAME_SCREEN                        = UIScreen.main.bounds
import UIKit

class Viewcalc: UIView, UITableViewDelegate, UITableViewDataSource {

    //MARK:- PROPERTY
    @IBOutlet var tableViewCalc: UITableView!
    
    var arrInt = [Int]()
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    init(info arr: [Int] , frame:CGRect) {
//         super.init(frame: CGRect(x: 0, y: 0, width: FRAME_SCREEN.width, height: FRAME_SCREEN.height))
        super.init(frame: frame)
        arrInt = arr
        loadXIB()
        tableViewCalc.reloadData()
    }
    
    //MARK:- loadXIB Function
    fileprivate func loadXIB() {
        self.alpha = 1
        let view = Bundle.main.loadNibNamed(String(describing: type(of: self)), owner: self, options: nil)?[0] as! UIView
        view.translatesAutoresizingMaskIntoConstraints = false;
        self.addSubview(view)
        
        //TOP
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: 0))
        
        //LEADING
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.leading, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.leading, multiplier: 1, constant: 0))
        
        //WIDTH
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.width, multiplier: 1, constant: 0))
        
        //HEIGHT
        self.addConstraint(NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self, attribute: NSLayoutConstraint.Attribute.height, multiplier: 1, constant: 0))
        
        self.layoutIfNeeded()
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int { return 1; }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { return arrInt.count }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = CalcCell()
        if let c = tableView.dequeueReusableCell(withIdentifier: CELL_CalcCell) { cell = c as! CalcCell }
        else { cell = Bundle.main.loadNibNamed(CELL_CalcCell, owner: self, options: nil)?[0] as! CalcCell }
        
        let stValue: String = String(arrInt[indexPath.row])
        cell.txtData.text = stValue
        
        return cell
    }
}
