//
//  ViewController.swift
//  api
//
//  Created by Kartum Infotech on 12/09/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let params = ["device_id":"ios"]

           let headers: HTTPHeaders = ["YEMINI-API-KEY":"kkcoswggwgwkkc8w4ok808o48kswc40c0www4wss",
                                       "USER-ID":"12","YEMINI-LOGIN-TOKEN":"04cswo8okkoso8g4oo44o0oko4g8c4oo"]

        //put slash before \ (base64Credentials)

        AF.request("https://wepixel.in/yemini/api/v1/auth/logout", method: .post, parameters: params,encoding: URLEncoding.default, headers: headers).authenticate(username: "YEMINI-API", password: "API@YEMINI!#$WEB$") .responseJSON { response in
                switch response.result {
                    case .success:
                        print(response)
                        let value = response.value as! [String:AnyObject]
                       print(value)
//                        if let results = value["data"] as? [String:Any] {
//                            if let values = results["user"] as? [String:Any]{
//                                   self.lbl1.text = values["city"] as? String ?? ""
//                                    self.lbl2.text = values["email"] as? String ?? ""
//                                     self.lbl3.text = values["first_name"] as? String ?? "123"
//                            }
//                            
//                        }

                    break
            
                    case .failure(let err):
                    print(err)
            //your failure code
                    }
            }
  
    }

}


