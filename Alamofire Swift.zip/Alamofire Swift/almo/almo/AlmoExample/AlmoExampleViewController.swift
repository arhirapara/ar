//
//  AlmoExampleViewController.swift
//  almo
//
//  Created by MacBook on 08/04/19.
//  Copyright © 2019 dnk. All rights reserved.
//

import UIKit
import Alamofire

class AlmoExampleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        var dict = [String:String]()
        let ur = "http://tadalali.jorjoto.in/V3/V1fjfghfTghg/V1fjfghfTghg/categoryList"
        dict = ["token":"hp/R7xYbycq9wzyGeRwFFbG9mDlL/DgtjY01eeyvUCg=","userId":"9","page":"1","appType":"2"]
        let url = URL(string: ur)
        
        //[self.theRequest addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        let heder = ["Content-Type":"application/x-www-form-urlencoded"]
        
        Alamofire.request(url!, method: .post, parameters: dict, headers: nil)
            .responseJSON { response in
                print(response.request as Any)  // original URL request
                print(response.response as Any) // URL response
                print(response.result.value as Any)
        }
        
//        Alamofire.request(url!, method: .post, parameters: dict, encoding: JSONEncoding.default, headers: heder)
//            .responseJSON { response in
//                print(response.request as Any)  // original URL request
//                print(response.response as Any) // URL response
//                print(response.result.value as Any)
//        }
       
    }
}
