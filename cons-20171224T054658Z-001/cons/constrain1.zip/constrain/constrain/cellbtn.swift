//
//  cellbtn.swift
//  constrain
//
//  Created by tops on 12/23/17.
//  Copyright © 2017 tops. All rights reserved.
//

import UIKit

class cellbtn: UICollectionViewCell {

    @IBOutlet weak var btn: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
