//
//  imgcell.swift
//  constrain
//
//  Created by tops on 12/23/17.
//  Copyright © 2017 tops. All rights reserved.
//

import UIKit

class imgcell: UICollectionViewCell {
    
    @IBOutlet weak var img: UIImageView!
    
    
   
    @IBOutlet weak var lbl: UILabel!
}
