//
//  ViewController.swift
//  constrain
//
//  Created by tops on 12/23/17.
//  Copyright © 2017 tops. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource,XMLParserDelegate{

    @IBOutlet weak var cell1: UICollectionView!
    
    @IBOutlet weak var cell2: UICollectionView!
    
    @IBOutlet weak var cell7: UICollectionView!
    @IBOutlet weak var cell5: UICollectionView!
    
    @IBOutlet weak var cell8: UICollectionView!
    @IBOutlet weak var cell6: UICollectionView!
    @IBOutlet weak var cell4: UICollectionView!
    @IBOutlet weak var cell3: UICollectionView!
    
    var str = ""
    
    var brr:[Any] = []
   // var json = NSDictionary()?
    
    
    let arr = ["if_Grid_1031514.png","if_Grid_1031514.png","if_Grid_1031514.png","if_Grid_1031514.png","if_Grid_1031514.png","if_Grid_1031514.png","if_Grid_1031514.png","if_Grid_1031514.png","if_Grid_1031514.png","if_Grid_1031514.png"]
    
    let butn = ["a","b","c","a","b","c","a","b","c","a","b","c","a","b","c","a","b","c","a","b","c","a","b","c","a","b","c"]
    var pqr:[Any] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let nib = UINib(nibName: "cellbtn", bundle: nil)
        
        self.cell1.register(nib, forCellWithReuseIdentifier: "cell1")
        self.cell2.register(nib, forCellWithReuseIdentifier: "cell2")
        self.cell3.register(nib, forCellWithReuseIdentifier: "cell3")
        self.cell4.register(nib, forCellWithReuseIdentifier: "cell4")
        self.cell5.register(nib, forCellWithReuseIdentifier: "cell5")
        self.cell6.register(nib, forCellWithReuseIdentifier: "cell6")
        self.cell7.register(nib, forCellWithReuseIdentifier: "cell7")
        self.cell8.register(nib, forCellWithReuseIdentifier: "cell8")
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //MARK:- Button action
    @IBAction func btnser(_ sender: Any) {
        
        
        let soapmsg = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body>      <Get xmlns=\"http://tempuri.org/\" /></soap:Body>       </soap:Envelope>"
        
        
        
        
         let urlString = "http://freeproduct.somee.com/WebService.asmx"
        
        let url1 = URL(string: urlString)
        
        var request = URLRequest(url: url1!)
        
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.addValue(String(soapmsg.characters.count), forHTTPHeaderField: "Content-Length")
        request.addValue("http://tempuri.org/Get", forHTTPHeaderField: "SOAPAction")
        request.httpMethod = "POST"
        
        request.httpBody = soapmsg.data(using: String.Encoding.utf8)
        
        let connection = URLSession.shared
        
        let datask = connection.dataTask(with: request, completionHandler: {(data, resp, err) in
        
//     print(String(data: data!, encoding: String.Encoding.utf8))
        
            let parser = XMLParser(data: data!)
            
            parser.delegate = self
            
            parser.parse()
        })
        
        
      
        datask.resume()
        
        
    }
    
    //MARK:- XML method
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        
        str = string
        
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        
        
        if elementName == "GetResult"
        {
            
            
        }
        
    }
    
    
    func parserDidEndDocument(_ parser: XMLParser) {
        
        
    let dt = str.data(using: String.Encoding.utf8)
        
        
        
        do {
            let  json = try JSONSerialization.jsonObject(with: dt!, options: []) as! [NSDictionary]
            
            
            for i in json
            {
               // print(i)
                var tem:[Int] = []
                let ProductID = i["ProductID"]
              // let ProductName = i["ProductName"]
                tem.append(ProductID as! Int )
               // tem.append(ProductName as! String)
                brr.append(tem)
            }
           // print(brr)
            
         //  brr.append(json)
         // print(json)
            cell1.reloadData()
            
        } catch  {
            
        }
        
       
        
        
    }
   //MARK:- CollectionView Method
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        
        if collectionView.tag == 0
        {
            return arr.count
        }
        
        else if collectionView.tag == 1{
            return brr.count
        }
        else if collectionView.tag == 2{
            return butn.count
        }
        else if collectionView.tag == 3{
            return butn.count
        }
        else if collectionView.tag == 4{
            return butn.count
        }
        else if collectionView.tag == 5{
            return butn.count
        }
        else if collectionView.tag == 6{
            return butn.count
        }
        else if collectionView.tag == 7{
            return butn.count
        }
        else{
            
            return butn.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView.tag == 0{
            
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! imgcell
        
            cell.layer.cornerRadius = 5
            cell.layer.borderColor = UIColor.red.cgColor
            cell.layer.borderWidth = 1
        cell.img.image = UIImage(named: arr[indexPath.row])
        cell.lbl.text = arr[indexPath.row]
        return cell
        }
        
        else if collectionView.tag == 1{
            
            

            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell1", for: indexPath) as! cellbtn
            
            let temp = brr[indexPath.row]
           print(temp)
            
           
            
            //let dic = temp[indexPath.row]
           // print(dic)
           // cell.layer.cornerRadius = 2
            //cell.layer.borderColor = UIColor.red.cgColor
            //cell.layer.borderWidth = 1
            //cell.layer.backgroundColor = UIColor.clear.cgColor
           cell.btn.setTitle(brr[indexPath.row] as! String , for: .normal)
            return cell
            
        }
        else if collectionView.tag == 2{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell2", for: indexPath) as! cellbtn
            
            cell.btn.setTitle(butn[indexPath.row], for: .normal)
            return cell
            
        }
        else if collectionView.tag == 3{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell3", for: indexPath) as! cellbtn
            
            cell.btn.setTitle(butn[indexPath.row], for: .normal)
            return cell
            
        }
        else if collectionView.tag == 4{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell4", for: indexPath) as! cellbtn
            
            cell.btn.setTitle(butn[indexPath.row], for: .normal)
            return cell
            
        }
        else if collectionView.tag == 5{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell5", for: indexPath) as! cellbtn
            
            cell.btn.setTitle(butn[indexPath.row], for: .normal)
            return cell
            
        }
        else if collectionView.tag == 6{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell6", for: indexPath) as! cellbtn
            
            cell.btn.setTitle(butn[indexPath.row], for: .normal)
            return cell
            
        }
        else if collectionView.tag == 7{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell7", for: indexPath) as! cellbtn
            
            cell.btn.setTitle(butn[indexPath.row], for: .normal)
            return cell
            
        }
        else {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell8", for: indexPath) as! cellbtn
            
            cell.btn.setTitle(butn[indexPath.row], for: .normal)
            return cell
            
        }
       

        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

