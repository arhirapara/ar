//
//  CollectionViewSplaceCell.swift
//  test
//
//  Created by AR on 25/06/20.
//  Copyright © 2020 asfasf. All rights reserved.
//

import UIKit

class CollectionViewSplaceCell: UICollectionViewCell {
    @IBOutlet weak var imageViewLogo: UIImageView!
    
    @IBOutlet weak var lblTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
