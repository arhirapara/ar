//
//  ViewController.swift
//  sqlitecode
//
//  Created by TOPS on 9/28/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate{

    
    @IBOutlet weak var btn: UIButton!
   
    
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtid: UITextField!
    
    
    var finalarr:[Any] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        bild()
        
        //let arr = db.
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func bild()  {
        
        
        
        
        let db = dbclass()
        
        
        
        let arr = db.getdata(query: "select * from tblemp")
        print(arr)
        finalarr = arr
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return finalarr.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        return 2
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let temp = finalarr[indexPath.section] as! [String]
        
        cell.textLabel?.text = temp[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let temp = finalarr[indexPath.section] as! [String]
        let empid = temp[0]
        
        let query  = "delete from tblemp where emp_id='\(empid)'"
        
        let db = dbclass()
        
        let st = db.dmloperation(query: query)
        
        if st == true{
            finalarr.remove(at: indexPath.section)
            tableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let temp = finalarr[indexPath.section] as! [String]
        
        txtid.text = temp[0]
        txtname.text = temp[1]
        btn.setTitle("Update", for: .normal)
        
        
        
    }    
    
    @IBAction func btn(_ sender: Any) {
        
        
        if btn.titleLabel?.text == "insert"
        {
            let db = dbclass()
            
            let query = "insert into tblemp(emp_id,emp_name)values('\(txtid.text!)','\(txtname.text!)')"
            
            let st = db.dmloperation(query: query)
            
            if st == true
            {
                print("yes")
                bild()
                tbl.reloadData()
                // btn.setTitle("Update", for: .normal)
                txtid.becomeFirstResponder()
            }
                
            else
            {
                print("no")
            }
        }
        else
        {
            let db = dbclass()
            
            let query = "update tblemp set emp_name = '\(txtname.text!)'where emp_id = '\(txtid.text!)'"
            
            let st = db.dmloperation(query: query)
            
            if st == true
            {
                print("yes")
                txtid.text = ""
                txtname.text = ""
                bild()
                txtid.becomeFirstResponder()
                btn.setTitle("insert", for: .normal)
                tbl.reloadData()
            }
                
            else
            {
                
                print("no")
            }
            
        }
        
    }
    
   

    @IBAction func dlt(_ sender: Any) {
        let db = dbclass()
        //DELETE FROM std WHERE id = '$id'
        
        
        let query = "delete from tblemp where emp_id='\(txtid.text!)'"
        
        let st = db.dmloperation(query: query)
        
        if st == true
        {
            print("yes")
            bild()
            txtid.text = ""
            txtname.text = ""
            tbl.reloadData()
            
        }
            
        else
        {
            print("no")
        }
        
    }
   
        
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

