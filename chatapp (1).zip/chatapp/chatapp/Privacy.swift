//
//  Privacy.swift
//  chatapp
//
//  Created by MACOS on 03/10/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class Privacy: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var alt = UIAlertController()
    var arr = ["Last seen","Profile photo","About","Status"]
    var brr = ["Everyone","My contact","Nobady"]
    var crr:[String] = ["Everyone","Everyone","Everyone","Everyone"]
    var str:[Int] = []
    @IBOutlet weak var maintable: UITableView!
    let viewcontrl = UIViewController()
    let tbl = UITableView()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tbl.frame = CGRect(x: 0, y: 0, width: 300, height: 150)
        viewcontrl.preferredContentSize  = CGSize( width: 300, height: 140)
         tbl.delegate = self
            tbl.dataSource = self
        tbl.tag = 2
        tbl.separatorStyle = .none
        tbl.isScrollEnabled = false
        viewcontrl.view.addSubview(tbl)
        maintable.reloadData()
        // Do any additional setup after loading the view.
    }

    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 1
        {
        return arr.count
        }
      else
       {
            return brr.count
      }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
       if tableView.tag == 1
       {
      
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row]
        cell.detailTextLabel?.text = crr[indexPath.row]
        return cell
        }
      
        
        
     
       else
        {
       
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell1")
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
            cell.textLabel?.text = brr[indexPath.row]
            return cell
    
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         //str.append(indexPath.row)
        //str.append(indexPath.row)
        
       if tableView.tag == 1
       {
        str.removeAll()

        str.append(indexPath.row)
        print(str)
             alt = UIAlertController(title: arr[indexPath.row], message: nil, preferredStyle: .alert)
            alt.setValue(viewcontrl, forKey: "ContentViewController")
            let cancle = UIAlertAction(title: "Cancel", style: .default, handler: {action in
                tableView.reloadData()
                
            })
            alt.addAction(cancle)
           // crr.removeAll()
            
            self.present(alt, animated: true, completion: nil)
        }
        else
       {
        
        
        crr.remove(at: str[0])
        crr.insert(brr[indexPath.row], at: str[0])
            self.dismiss(animated: true, completion: nil)
        maintable.reloadData()
        
        
        }
            //    print(crr)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
