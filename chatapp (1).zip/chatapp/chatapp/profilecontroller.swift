//
//  profilecontroller.swift
//  chatapp
//
//  Created by MACOS on 06/10/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

@objc protocol prodelegate{
    @objc optional func strreturn(str: String)
    

}


class profilecontroller: NSObject {
    
    var delegate:prodelegate?
    
   // var arr:[Any] = []
    
    func registrationdetails(obj: profilemodel ,url: String) {
        
        
        
        var dic:[String: String] = [:];
        
       
        
        dic["moblie_no"] = obj.moblie_no
         dic["code"] = obj.code
        dic["name"] = obj.name
        
        dic["profile_pic"] = obj.profile_pic
        
        
        
        do {
            
            let dt = try JSONSerialization.data(withJSONObject: dic, options: [])
            
            let url = URL(string: url)
            
            var request = URLRequest(url: url!)
            
            request.addValue(String(dt.count), forHTTPHeaderField: "Content-Length")
            
            
            
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            
            
            
            request.httpBody = dt
            
            request.httpMethod = "POST";
            
            
            
            let session = URLSession.shared
            
            let datatask = session.dataTask(with: request, completionHandler: {(data1, resp, err) in
                
                
                
                
                
                let str = String(data: data1!, encoding: String.Encoding.utf8);
                
                DispatchQueue.main.async {
                    
                    print(str!);
                    
                  self.delegate?.strreturn!(str: str!)
                    
                  
                }
                
              
                
            })
            
         
            datatask.resume();
            
       
        } catch  {
            
            
            
        }
        
    
    }
    
   
}


@objc protocol seldelegate{
    
    @objc optional func strreturn1(str1: [Any])
}

class displaycontroller: NSObject {
      var delegate1:seldelegate?
    
    func selectresult(obj:profileselect,url:String)
    {
        
        
        let u = "http://localhost/chatapp/select2.php"
           let storybord = "mobile_no=\(obj.moblie_no!)"
             let url1 = URL(string: u)
               var request = URLRequest(url: url1!)
        
     
       request.addValue(String(storybord.characters.count), forHTTPHeaderField: "Content-Length")
     
        

        request.httpBody = storybord.data(using: String.Encoding.utf8)
        request.httpMethod = "POST"

       
        
    
        let session = URLSession.shared;
        let datatask1 = session.dataTask(with: request, completionHandler: {(data2, req, err)  in
     
            
            DispatchQueue.main.async {
                
                do
                {
                     let str5 = String(data: data2!, encoding: String.Encoding.utf8)
                    print(str5!)
                    print(data2!)
                   let jasondata = try JSONSerialization.jsonObject(with: data2!, options: []) as! [[String:String]]
                    
                    var jrr:[String] = []
                    for item in jasondata
                    {
                        let name = item["name"]
                        jrr.append(name!)
                        
                        let  profile_pic = item["profile_pic"]
                        jrr.append(profile_pic!)

                        
                        let status = item["status"]
                        jrr.append(status!)
                        
                        let mobile_no = item["mobile_no"]
                        jrr.append(mobile_no!)
                        
                        let code = item["code"]
                        jrr.append(code!)
                        
                        let id = item["id"]
                        jrr.append(id!)


                    }
                   self.delegate1?.strreturn1!(str1: jrr)
                   
                }
                catch
                {
                   
                }
                
            }
        })
        datatask1.resume()
    }
}

@objc protocol updatepro{
    @objc optional func returnstr2(str3:String)
}

class updatecontroller:NSObject
{
    var delegate2:updatepro?
    
    
    func updateprofile(obj: updateprofile ,url: String) {
        
        
        
        var dic:[String: String] = [:];
        
        
        
        dic["moblie_no"] = obj.mobile_no
        dic["code"] = obj.code
        dic["name"] = obj.name
        
        dic["status"] = obj.status
        dic["id"] = obj.id
        
        
        do {
            
            let dt = try JSONSerialization.data(withJSONObject: dic, options: [])
            
            let url = URL(string: url)
            
            var request = URLRequest(url: url!)
            
            request.addValue(String(dt.count), forHTTPHeaderField: "Content-Length")
            
            
            
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            
            
            
            request.httpBody = dt
            
            request.httpMethod = "POST";
            
            
            
            let session = URLSession.shared
            
            let datatask = session.dataTask(with: request, completionHandler: {(data1, resp, err) in
                
                
                
                
                
                let str = String(data: data1!, encoding: String.Encoding.utf8);
                
                DispatchQueue.main.async {
                    
                    print(str!);
                    
                    self.delegate2?.returnstr2!(str3: str!)
                    
                    
                }
                
                
                
            })
            
            
            datatask.resume();
            
            
        } catch  {
            
            
            
        }
        
        
    }

    
  }

@objc protocol updateprofilepic{
    @objc optional func returnstr3(str4:String)
}

class updatepp:NSObject
{
    var delegate3:updateprofilepic?
    
    func updatepic(obj:updatepic ,url:String)
    {
        var dic:[String:String] = [:]
        
        dic["moblie_no"] = obj.mobile_no
        dic["profile_pic"] = obj.profile_pic
        
        
        do {
            let jsondata = try JSONSerialization.data(withJSONObject: dic, options: [])
            let url1 = URL(string: url)
            var request = URLRequest(url: url1!)
            request.addValue(String(jsondata.count), forHTTPHeaderField: "Content-Length")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            request.addValue("application/jxson", forHTTPHeaderField: "Content-Type")
            
            request.httpBody = jsondata
            request.httpMethod = "POST"
            
            let session = URLSession.shared
            
            let datatask = session.dataTask(with: request, completionHandler: { (data1, resp, err) in
                
                let str = String(data: data1!, encoding: String.Encoding.utf8)
                
                DispatchQueue.main.async {
                    print(str!)
                    self.delegate3?.returnstr3!(str4: str!)
        }
            })
            datatask.resume()
            
        }
        catch
        {
            
        }
        
    }
}
