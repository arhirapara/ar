//
//  chatapp-Bridging-Header.h
//  chatapp
//
//  Created by MACOS on 06/10/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

#ifndef chatapp_Bridging_Header_h
#define chatapp_Bridging_Header_h

#import "base64.h"
#endif /* chatapp_Bridging_Header_h */
