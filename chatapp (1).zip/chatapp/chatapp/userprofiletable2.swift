//
//  userprofiletable2.swift
//  chatapp
//
//  Created by MACOS on 29/09/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class userprofiletable2: UITableViewCell {

    
    @IBOutlet weak var lbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
