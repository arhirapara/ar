//
//  start.swift
//  chatapp
//
//  Created by MACOS on 20/09/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class start: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {

      var arr:[String] = []
     let pick = UIPickerView()
     var num:[String] = []
    @IBOutlet weak var code: UITextField!
    
    @IBOutlet weak var mob: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: "backimage")?.draw(in: self.view.bounds)
        let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        self.view.backgroundColor = UIColor(patternImage: image)
        self.navigationController?.isNavigationBarHidden = true
        num.removeAll()
        //country code
        let str = Bundle.main.path(forResource: "countries" , ofType: "json")
        
        
        
        
        
        do {
            
            let jsondata1 = try String(contentsOfFile: str!);
            
            
            
            let myNSData = jsondata1.data(using: String.Encoding(rawValue: String.Encoding.utf8.rawValue))!
            
            
            
            do
                
            {
                
                
                
                
                
                let jsondata = try JSONSerialization.jsonObject(with: myNSData, options: []) as! [[String:Any]]
                
                
                
                for iteam in jsondata
                    
                {
                    
                    let code = iteam["dial_code"]  as? String ?? "0";
                    
                    //  let c_name = iteam["name"]  as? String ?? "0";
                    
                    
                    
                    arr.append(code)
                    
                    //arr.append(c_name)
                    
                    
                    
                    print(arr)
                    
                    
                    
                }
                
                
                
            } catch  {
                
                
                
            }
            
            
            
            
            
        }
            
        catch
            
        {
            
            
            
            
            
        }


    }
    
    @IBAction func code(_ sender: Any) {
        
        
     //   let alt = UIAlertController(title: "Contry code", message: "Select a code", preferredStyle: .actionSheet)
        
       
        pick.dataSource =  self
        pick.delegate = self
        
         code.inputView = pick
 
     //   self.present(alt, animated: true, completion: nil)
    }

    
    @IBAction func btn(_ sender: Any) {
        let f = storyboard?.instantiateViewController(withIdentifier: "otp") as! otp
        //let num = code.text! + mob.text!
        
       
        num.append(code.text!)
        num.append(mob.text!)
        f.str = num
        self.navigationController?.pushViewController(f, animated: true)

    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        
        self.view.endEditing(true)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
      
        return arr[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        code.text = arr[row]
   
        self.view.endEditing(true)
          }
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
