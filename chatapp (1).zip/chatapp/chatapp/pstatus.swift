//
//  pstatus.swift
//  chatapp
//
//  Created by MACOS on 02/10/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class pstatus: UIViewController,updatepro,seldelegate {

    @IBOutlet weak var txtstatus: UITextField!
    var v:String = ""
    
    var arr:[String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let dif = UserDefaults()
         v = dif.value(forKey: "mob") as! String

        let obj = profileselect(mobile_no1: v)
        let dp = displaycontroller()
        dp.delegate1 = self
        dp.selectresult(obj: obj, url: "http://localhost/chatapp/select2.php")
        // Do any additional setup after loading the view.
    }
    func strreturn1(str1: [Any]) {
        arr.removeAll()
        arr.insert(str1[0] as! String, at: 0) //name
        arr.insert(str1[2] as! String, at: 1) //status
        arr.insert(str1[4] as! String, at: 2) //code
        print(arr)
        
        txtstatus.text = arr[1]
    }
    
    func returnstr2(str3: String) {
        print(str3)
    }
    @IBAction func ok(_ sender: Any) {
        
               let obj = updateprofile(mobile_no1: v, name1: arr[0], status1: txtstatus.text!, code1: arr[2], id1: "")
        print(obj)
        let up = updatecontroller()
        up.delegate2 = self
        up.updateprofile(obj: obj, url: "http://localhost/chatapp/update.php")
    }
    @IBAction func back(_ sender: Any) {
         self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
