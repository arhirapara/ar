//
//  changename.swift
//  chatapp
//
//  Created by MACOS on 01/10/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class changename: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,updatepro,seldelegate{

    @IBOutlet weak var coll: UICollectionView!
    @IBOutlet weak var name: UITextField!
    var emojiarray:[String] = []
    var arr:[String] = []
     var v:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        let emojiRanges = [
            0x1F601...0x1F64F,
            0x2702...0x27B0,
            0x1F680...0x1F6C0,
            0x1F170...0x1F251
        ]
               for range in emojiRanges {
            for i in range {
                let c = String(UnicodeScalar(i)!)
                emojiarray.append(c)
            }
        }
       
        coll.isHidden = true
        
        //get data
        
        let dif = UserDefaults()
        v = dif.value(forKey: "mob") as! String
        
        let obj = profileselect(mobile_no1: v)
        let dp = displaycontroller()
        dp.delegate1 = self
        dp.selectresult(obj: obj, url: "http://localhost/chatapp/select2.php")
//
       
        // Do any additional setup after loading the view.
    }
    func strreturn1(str1: [Any]) {
        arr.removeAll()
        arr.insert(str1[0] as! String, at: 0) //name
        arr.insert(str1[2] as! String, at: 1) //status
        arr.insert(str1[4] as! String, at: 2) //code
        
         name.text = arr[0]
    }
    func returnstr2(str3: String) {
        print(str3)
    }
    @IBAction func emoji(_ sender: Any) {
   
        coll.isHidden = false
    }
    
   
    @IBAction func ok(_ sender: Any) {
        
       
        let obj = updateprofile(mobile_no1: v, name1: name.text, status1: arr[1], code1: arr[2], id1: "")
        print(obj)
        let up = updatecontroller()
        up.delegate2 = self
        up.updateprofile(obj: obj, url: "http://localhost/chatapp/update.php")
    }
    
    @IBAction func back(_ sender: Any) {
         self.navigationController?.popViewController(animated: true)
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        print(emojiarray.count);
        
        return emojiarray.count
        
    }

    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

          //collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "Cell")
        
        
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! custcellcollection
        
        cell.lbl.text = emojiarray[indexPath.row]
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        
        name.text?.append(emojiarray[indexPath.row])
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
/*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
