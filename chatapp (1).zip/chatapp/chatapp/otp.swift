//
//  otp.swift
//  chatapp
//
//  Created by MACOS on 20/09/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class otp: UIViewController {
    var str:[String] = []
    @IBOutlet weak var lbl: UILabel!
    
    @IBOutlet weak var lblcode: UILabel!
    @IBOutlet weak var resend: UIButton!
    
    @IBOutlet weak var txt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: "backimage")?.draw(in: self.view.bounds)
        let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        self.view.backgroundColor = UIColor(patternImage: image)
        
        
        
        
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.setHidesBackButton(true, animated: true)
        navigationItem.title = "Verify"
        navigationItem.title?.append(str[0]+str[1])
        
        lblcode.text = str[0]
        lbl.text = str[1]

        // Do any additional setup after loading the view.
    }

    @IBAction func txtotp(_ sender: Any) {
     
        if txt.text?.characters.count == 6
        {
            let f = storyboard?.instantiateViewController(withIdentifier: "pro") as! profile
            var crr:[String] = []
            crr.removeAll()
            crr.append(str[0])
             crr.append(str[1])
            f.str = crr

            self.navigationController?.pushViewController(f, animated: true)
            print("thay gyu")
        }
        else
        {
            print("not count")
        }

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
