//
//  profilephoto.swift
//  chatapp
//
//  Created by MACOS on 01/10/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class profilephoto: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,seldelegate,updatepro,updateprofilepic{
    let imgpicker = UIImagePickerController()
    var sarr:[Any] = []
    var sar:[String] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        let dif = UserDefaults()
        let char = dif.value(forKey: "mob")as! String
        
        let obj = profileselect(mobile_no1: char)
        let dis = displaycontroller()
        dis.delegate1 = self
        dis.selectresult(obj: obj, url:"http://localhost/chatapp/select2.php")
        
        
        
       
        // Do any additional setup after loading the view.
    }
    func strreturn1(str1: [Any]) {
        sar.removeAll()
        sar.insert(str1[0] as! String, at: 0)//name
        sar.insert(str1[1] as! String, at: 1)//profile name
        sar.insert(str1[2] as! String, at: 2)//status
        sar.insert(str1[3] as! String, at: 3)//mobile number
        sar.insert(str1[4] as! String, at: 4)//code
        sar.insert(str1[5] as! String, at: 5)//id
    
        
        //display image
       
        
        var str = "http://localhost/chatapp/"
        str.append(str1[1] as! String)
        
        
        let url = URL(string: str)
        do {
            let data1 = try Data(contentsOf: url!)
            img.image = UIImage(data: data1)
            sarr.removeAll()
            sarr.append(img)
        } catch  {
            
        }
        

        

    }
    
    @IBOutlet weak var img: UIImageView!
    @IBAction func back(_ sender: Any) {
        
       // self.storyboard?.instantiateViewController(withIdentifier: "up") as! userprofile
      self.navigationController?.popViewController(animated: true)
        viewWillAppear(true)
    }
    
    
    @IBAction func share(_ sender: Any) {
        
        let act = UIActivityViewController(activityItems: sarr, applicationActivities: nil)
        print(sarr)
        self.present(act, animated: true, completion: nil)
        
     }
    @IBAction func chnge(_ sender: Any) {
        
        imgpicker.delegate = self
        imgpicker.sourceType = .photoLibrary
        self.present(imgpicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage
        img.image = img1
        
        self.dismiss(animated: true, completion: nil)
       
      
        let img2 = img.image
        
        let imgdata = UIImageJPEGRepresentation(img2!, 1.0)
        
        let base64string = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)

        let obj = updatepic(mobile_no1: sar[3], profile_pic1:base64string)
        let upp = updatepp()
        upp.delegate3 = self
        upp.updatepic(obj: obj, url: "http://localhost/chatapp/updatepic.php")
        
       
        
    }
    
    func returnstr3(str4: String) {
        print("update your profile")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
