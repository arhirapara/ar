//
//  userprofile.swift
//  chatapp
//
//  Created by MACOS on 28/09/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class userprofile: UIViewController,UITableViewDelegate,UITableViewDataSource,prodelegate,seldelegate{

    
    @IBOutlet weak var tbl: UITableView!
    var arr:[String] = ["account","sagar","hy","541251121"]
    override func viewDidLoad() {
        super.viewDidLoad()
        tbl.isScrollEnabled = false
    
        
    //    time = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.action), userInfo: nil, repeats: false)
        
        
        let dif = UserDefaults()
        let  mob = dif.value(forKey: "mob") as! String
        
        let char = mob
        print(char)
        let obj = profileselect(mobile_no1: char)
        let dis = displaycontroller()
        dis.delegate1 = self
        dis.selectresult(obj: obj, url: "http://localhost/chatapp/select2.php")
        
        
    }
      
  /*  func action(sender:Timer) {
        
    }*/
  func strreturn1(str1: [Any]) {
        arr.removeAll()
        arr.insert(str1[1] as! String, at: 0)
        arr.insert(str1[0] as! String, at: 1)
        arr.insert(str1[2] as! String, at: 2)
    let number = str1[4] as! String
    let numer1 =  str1[3]as! String
    
    let sun = number + numer1
    arr.insert(sun, at: 3)
    
    
    print(arr)
    tbl.reloadData()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       if section == 0
        {
            return 1
        }
        else if section == 1
        {
            return 1
        }
        else if section == 2
        {
                return 1
        }
        else if section == 3
        {
            return 1
        }
        else
       {
            return 1
        }
 
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
   
        
        if indexPath.section == 0
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! userprofiletable
            cell.img.image = UIImage(named: "account")
            cell.img.layer.cornerRadius = cell.img.frame.size.width/2
            cell.img.clipsToBounds = true
            cell.backgroundColor = UIColor.lightGray
           
            var str = "http://localhost/chatapp/"
            str.append(arr[0])
            
            let url = URL(string: str)
            do {
                let data1 = try Data(contentsOf: url!)
                cell.img.image = UIImage(data: data1)
            
            } catch  {
                
            }
            
            
            
            return cell
      

        
        }
        else if indexPath.section == 1
        {
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
            let imag = UIImageView(frame: CGRect(x: 0, y: 0, width: 30, height: 30))
            imag.image = UIImage(named: "write")
            cell1.textLabel?.text = arr[1]
            
            cell1.accessoryView = imag
            
            
            
            
            
            
            return cell1
        }
        else if indexPath.section == 2
        {
            let cell2 = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath)as! userprofiletable2
          
            cell2.lbl?.text = "This name will be visible to your whatsapp contacts"
            cell2.backgroundColor = UIColor.lightGray
           /* cell2.lbl.text! = "This name will be visible to your whatsapp contacts"*/
            return cell2
        }
        else if indexPath.section == 3
        {
            let cell3 = tableView.dequeueReusableCell(withIdentifier: "cell3", for: indexPath)
                cell3.textLabel?.text = arr[2]
        
            return cell3
        }
        else
        {
            let cell4 = tableView.dequeueReusableCell(withIdentifier: "cell4", for: indexPath)
            cell4.textLabel?.text = arr[3]
            return cell4
        }
        
 
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0
        {
            return 238
            
        }
        else if indexPath.section == 2
        {
            return 90
        }
        return 60
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0
        {
            let f = storyboard?.instantiateViewController(withIdentifier: "pp")as! profilephoto
            self.navigationController?.pushViewController(f, animated: true)

            
        }
        else if indexPath.section == 1
        {
            
            let f = storyboard?.instantiateViewController(withIdentifier: "cn")as! changename
            self.navigationController?.pushViewController(f, animated: true)
            

        }
        else if indexPath.section == 3
        {
            
            let f = storyboard?.instantiateViewController(withIdentifier: "ps")as! pstatus
            self.navigationController?.pushViewController(f, animated: true)
            

        }
        else
        {
            let f = storyboard?.instantiateViewController(withIdentifier: "chngeno")as! chngenumber
            self.navigationController?.pushViewController(f, animated: true)
        }
        
    }
   
    @IBAction func nxt(_ sender: Any) {
   //     let f = storyboard?.instantiateViewController(withIdentifier: "set" ) as! setting
        self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
