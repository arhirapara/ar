//
//  chatcontroller.swift
//  chatapp
//
//  Created by MACOS on 14/11/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit
@objc protocol chatdelegate{
    @objc optional func strreturn(str:String)
}
class chatcontroller: NSObject {
    var delegate:chatdelegate?
    func chatinsert(obj:chatmodel,url1:String)
    {
        var dic:[String:String] = [:]
        
        dic["user_sendno"] = obj.usersendno
        dic["user_recvno"] = obj.userrecvno
        dic["chat"] = obj.chat
        dic["data_time"] = obj.datetime
        
        do {
            let dt = try JSONSerialization.data(withJSONObject: dic, options: [])
       
            let url = URL(string: url1)
            
            var request = URLRequest(url: url!)
            
            request.addValue(String(dt.count), forHTTPHeaderField: "Content-Length")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = dt;
            request.httpMethod = "POST"
            
            let session = URLSession.shared
            
            let datatask = session.dataTask(with: request, completionHandler: { (data1, resp, err) in
                
                let str = String(data: data1!, encoding: String.Encoding.utf8)
                
                DispatchQueue.main.async {
                    print(str!)
                    self.delegate?.strreturn!(str: str!)
                }
            })
           datatask.resume()
            
        } catch  {
            
        }
        
       
    }
}

@objc protocol dischatdelegate
{
    @objc optional func strreturn2(str:[Any])
}
class displaychat:NSObject
{
    var delegate:dischatdelegate?
    var brr:[Any] = []
    
    func showchat(obj:chatrecvmodel,url:String)
    {
        let u = "http://localhost/chatapp/chatrecv.php"
        let storybord = "user_sendno=\(obj.user_sendno)&user_recvno=\(obj.user_recvno)"
        
        let url1 = URL(string: u)
        var request = URLRequest(url: url1!)
        
        request.addValue(String(storybord.characters.count), forHTTPHeaderField: "Content-Length")
       request.httpBody = storybord.data(using: String.Encoding.utf8)
        request.httpMethod = "POST"
        
        let session = URLSession.shared
        
        let datatack = session.dataTask(with: request, completionHandler: {(data1, resp, err) in
            
            DispatchQueue.main.async {
               // let str2 = String(data: data1!, encoding: String.Encoding.utf8)
               // print(str2!)
                
                do
                {
                    let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:String]]
                    
                    for iteam in jsondata
                    {
                       var arr:[String] = []
                        let sender = iteam["user_sendno"]
                        arr.append(sender!)
                        
                        let chat = iteam["chat"]
                        arr.append(chat!)
                        
                        let rev = iteam["user_recvno"]
                        arr.append(rev!)

                        
                        let datetime = iteam["data_time"]
                        arr.append(datetime!)
                       
                        self.brr.append(arr)
                        //arr.removeAll()
                    }
                                   self.delegate?.strreturn2!(str:self.brr)
                }
                
                catch{
                    
                }
               
            }
            
            
            
            })
        datatack.resume()
    }
}
