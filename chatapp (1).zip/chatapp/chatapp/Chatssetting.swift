//
//  Chatssetting.swift
//  chatapp
//
//  Created by MACOS on 04/10/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class Chatssetting: UIViewController,UITableViewDelegate,UITableViewDataSource {
    let arr = ["Wallpaper","Chat backup","Chat history"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 1
        {
            let f = self.storyboard?.instantiateViewController(withIdentifier: "cbackup") as! chatbackup
            self.navigationController?.pushViewController(f, animated: true)
        }
        else if indexPath.row == 2
        {
            let f = self.storyboard?.instantiateViewController(withIdentifier: "chistory") as! chathistory
            self.navigationController?.pushViewController(f, animated: true)
        }
    }
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
