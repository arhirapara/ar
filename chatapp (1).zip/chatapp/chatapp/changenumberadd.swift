//
//  changenumberadd.swift
//  chatapp
//
//  Created by MACOS on 03/10/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class changenumberadd: UIViewController,updatepro,seldelegate{

    @IBOutlet weak var oldcode: UITextField!
    @IBOutlet weak var oldnumber: UITextField!
    
    @IBOutlet weak var newcode: UITextField!
    
    @IBOutlet weak var newnumber: UITextField!
    
    var arr:[String] = []
    var v:String = ""
  let dif = UserDefaults()
    override func viewDidLoad() {
        super.viewDidLoad()
       
        v = dif.value(forKey: "mob") as! String
        
        let obj = profileselect(mobile_no1: v)
        let dp = displaycontroller()
        dp.delegate1 = self
        dp.selectresult(obj: obj, url: "http://localhost/chatapp/select2.php")
        //

        // Do any additional setup after loading the view.
    }
    func strreturn1(str1: [Any]) {
        arr.removeAll()
        arr.insert(str1[0] as! String, at: 0) //name
        arr.insert(str1[2] as! String, at: 1) //status
        arr.insert(str1[4] as! String, at: 2) //code
        
        arr.insert(str1[5] as! String, at: 3) //Id
       arr.insert(str1[3]as! String, at: 4) // number
    }
    func returnstr2(str3: String) {
      let re = "\r\nRecord updated successfully"
    if  re == str3
    {
       dif.set(newnumber.text, forKey: "mob")
        
        
        
        let alt = UIAlertController(title: "Change number", message: "Your number chnged", preferredStyle: .alert)
        
        let ok = UIAlertAction(title: "Ok", style: .default, handler: {ok in
            let f = self.storyboard?.instantiateViewController(withIdentifier: "chat") as! chatfile
            self.navigationController?.popToViewController(f, animated: true)

        })
        
        alt.addAction(ok)
        self.present(alt, animated: true, completion: nil)
        }
        
        
    }
    @IBAction func done(_ sender: Any) {
        
        
       let oldc = "+" + oldcode.text!
        let oldn = oldnumber.text!
        let cn = oldc + oldn
        print(cn)
        let rn =  arr[2] + arr[4]
        print(rn)
        if rn == cn
        {
        let new = "+" + newcode.text!
       // let no = new + newnumber.text!
        //print(no)
    let obj = updateprofile(mobile_no1: newnumber.text, name1: arr[0], status1: arr[1], code1: new, id1: arr[3])
        let up = updatecontroller()
        up.delegate2 = self
        up.updateprofile(obj: obj, url:"http://localhost/chatapp/updateno.php")
    
        }
        else
        {
            let alt = UIAlertController(title: "Change number", message: "Enter Account Number", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler:{action in })
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
            
        }
        
    }
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
