//
//  profilemodel.swift
//  chatapp
//
//  Created by MACOS on 06/10/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class profilemodel: NSObject {
    
    var moblie_no:String
    var name:String
    var profile_pic:String
    var status:String
    var code:String
    init(moblie_no1:String,name1:String,profile_pic1:String,status1:String,code1:String) {
        self.moblie_no = moblie_no1
        self.name = name1
        self.profile_pic = profile_pic1
        self.status = status1
        self.code = code1
    }
 
    
}
class profileselect :NSObject {
    var moblie_no : String!
    
    init(mobile_no1:String!) {
        self.moblie_no = mobile_no1!
    }
}

class updateprofile: NSObject {

    var mobile_no : String!
    var name : String!
    var status :String!
    var code :String!
    var id :String
    
    init(mobile_no1:String!,name1:String!,status1:String!,code1:String!,id1:String!) {
        mobile_no = mobile_no1!
        name = name1!
        status = status1!
        code = code1!
        id = id1!
    }
}

class updatepic : NSObject
{
    var mobile_no :String!
    var profile_pic : String!
    init(mobile_no1:String!,profile_pic1:String!) {
        
        mobile_no = mobile_no1!
        profile_pic = profile_pic1!
    }
}
