//
//  custcellcollection.swift
//  chatapp
//
//  Created by MACOS on 01/10/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class custcellcollection: UICollectionViewCell {
    
    @IBOutlet weak var lbl: UILabel!
}
