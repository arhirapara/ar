//
//  userchat.swift
//  chatapp
//
//  Created by MACOS on 13/11/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class userchat: UIViewController,UITableViewDataSource,UITableViewDelegate,chatdelegate,dischatdelegate {

    var arr:[String] = []
    var na = ""
    var mob = ""
    var smob = ""
    var date1:Any = ""
    var chat:[Any] = []
    var time = Timer()
  //  var finalarr:[String] = []
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var chattxt: UITextField!
    
    @IBOutlet weak var navigbar: UINavigationBar!
    
    @IBOutlet weak var navitols: UINavigationItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        tbl.backgroundView = UIImageView(image: #imageLiteral(resourceName: "chat-1"))
        //tableview cell size chnge
        tbl.estimatedRowHeight = 600
        tbl.rowHeight = UITableViewAutomaticDimension
        //navigation tooles
        navitols.title = na
        //user defualt
        let dif = UserDefaults()
        smob = dif.value(forKey: "mob") as! String
        
       //recevied message
        
        let obj = chatrecvmodel(user_sendno1: smob, user_recvno1: mob)
        let rcp = displaychat()
        rcp.delegate = self
        rcp.showchat(obj: obj, url: "http://localhost/chatapp/chatrecv.php")
        
        // Do any additional setup after loading the view.
        //time
        
       // time = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.acti), userInfo: nil, repeats: false)
    }

    func numberOfSections(in tableView: UITableView) -> Int {
       return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chat.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     /*  let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! userchatcell
        let temp:[String] = chat[indexPath.row] as! [String]
        let sendno = temp[0]
        
        if sendno == smob
        {
            
            cell.textLabel?.textAlignment = .right
            cell.textLabel?.text = temp[1]
            cell.textLabel?.backgroundColor = UIColor.brown
         //   cell.te
        
           
        }
        else
        {
            cell.textLabel?.textAlignment = .left
            //cell.chatlbl.textAlignment = .right
            cell.textLabel?.text = temp[1]

        }
      
        return cell
*/
 
       let temp:[String] = chat[indexPath.row] as! [String]
        let sendno = temp[0]
        
        if sendno == smob
        {
           tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
           cell.textLabel?.textAlignment = .right
            cell.textLabel?.text = temp[1]
           /** let lbl = UILabel(frame: CGRect(x: self.view.frame.origin.x-10, y: 0, width: 20, height: self.view.frame.size.height))
            lbl.text = temp[1]
            self.view.addSubview(lbl)*/
            return cell
        }
        else
        {
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell1")
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
            cell1.textLabel?.textAlignment = .left
            cell1.textLabel?.text = temp[1]
           
            return cell1
        }
       
}
        
    @IBAction func chatbtn(_ sender: Any) {
        
        //arr.append(chattxt.text!)
        sysdate()
        let datetime = String(describing: date1)
        let obj = chatmodel(usersendnno1: smob, userrecvno1: mob, chat1: chattxt.text!, datetime1: datetime)
        
        let cp = chatcontroller()
        cp.delegate = self
        cp.chatinsert(obj: obj, url1: "http://localhost/chatapp/Chat.php")
        
       //display
        let obj1 = chatrecvmodel(user_sendno1: smob, user_recvno1: mob)
        let rcp = displaychat()
        rcp.delegate = self
        rcp.showchat(obj: obj1, url: "http://localhost/chatapp/chatrecv.php")
        tbl.reloadData()
        

    }
    
    func strreturn(str: String) {
        print(str)
    
      //  tbl.reloadData()
    }
    func strreturn2(str: [Any]) {
       
            chat = str
    
           
       tbl.reloadData()
        
    }
    func sysdate()
    {
        //system date time
        
        let date = Date();
        let dateFormatter = DateFormatter()
        
        dateFormatter.timeStyle = DateFormatter.Style.medium
        
        dateFormatter.dateStyle = DateFormatter.Style.medium;
        
        print(date)
        date1 = date
    }
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
       
    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

class userchatcell:UITableViewCell
{
    
    
    @IBOutlet weak var chatlbl: UILabel!
}
class userchatcell1:UITableViewCell
{
    
    @IBOutlet weak var chatrlbl: UILabel!
}
