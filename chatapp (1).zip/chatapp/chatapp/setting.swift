//
//  setting.swift
//  chatapp
//
//  Created by tops on 9/27/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class setting: UIViewController,UITableViewDelegate,UITableViewDataSource,prodelegate,seldelegate{
    @IBOutlet weak var tbl: UITableView!
   
    let arr = ["Account","Chats","Contacts","Help"]
    let img = ["account","chat","cont","help"]
    var info:[String] = ["name","account","HELLO"]
    
    var time =  Timer()
    override func viewDidLoad() {
        super.viewDidLoad()
        tbl.isScrollEnabled = false
        
        
        
        let dif = UserDefaults()
        let  mob = dif.value(forKey: "mob") as! String
    
        let char = mob
        print(char)
        let obj = profileselect(mobile_no1: char)
        let dis = displaycontroller()
        dis.delegate1 = self
        dis.selectresult(obj: obj, url: "http://localhost/chatapp/select2.php")
        
        
     //   dif.value(forKey: "mob")
       
   

        
        
    // viewWillAppear(true)
        // Do any additional setup after loading the view.
    }
   
    func strreturn1(str1:[Any]) {
        info.removeAll()
        info.insert(str1[0] as! String, at: 0)
      
         info.insert(str1[1] as! String, at: 1)
          info.insert(str1[2] as! String, at: 2)
        tbl.reloadData()
         
           }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
            return 1
        }
        else
        {
        return arr.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0
       {
        let cell1 =  tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ptable
            
        cell1.img.layer.cornerRadius = cell1.img.frame.size.width/2
        cell1.img.clipsToBounds = true
        cell1.name.text = info[0]
        //image
    
        var str1 = "http://localhost/chatapp/"
        str1.append(info[1])
        let url1 = URL(string: str1)
        do {
            let dt = try Data(contentsOf: url1!)
            
            cell1.img.image = UIImage(data: dt)
        } catch  {
            
        }
        cell1.status.text = info[2]
        
               return cell1
      
        }
        else
        {
            
            let cell =  tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)as! ptable1
            
            cell.img.layer.cornerRadius = cell.img.frame.size.width/2
            cell.img.clipsToBounds = true
          //  cell.textLabel?.text = arr[indexPath.row]
            cell.lbl.text = arr[indexPath.row]
            cell.img.image = UIImage(named: img[indexPath.row])
            return cell
            
        }
        
        
    }
   func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0
        {
            return 150.0
        }
        return 70.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 0
        {
            let f = self.storyboard?.instantiateViewController(withIdentifier: "up") as! userprofile
            self.navigationController?.pushViewController(f, animated: true)
    // tbl.reloadData()
        }
        else
        {
            if indexPath.row == 0
            {
            let f = self.storyboard?.instantiateViewController(withIdentifier: "acc") as! account
            self.navigationController?.pushViewController(f, animated: true)
            }
            else if indexPath.row == 1
            {
                let f = self.storyboard?.instantiateViewController(withIdentifier: "chatset") as! Chatssetting
                self.navigationController?.pushViewController(f, animated: true)

            }
            else if indexPath.row == 2
            {
                
                let f = self.storyboard?.instantiateViewController(withIdentifier: "cont") as! contacts
                self.navigationController?.pushViewController(f, animated: true)

            }
            else if indexPath.row == 3
            {
                let f = self.storyboard?.instantiateViewController(withIdentifier: "help") as! help
                self.navigationController?.pushViewController(f, animated: true)

            }
        }
        
    }
   func image()
   {
    
    }
    
    @IBAction func back(_ sender: Any) {
        
     //   let f = storyboard?.instantiateViewController(withIdentifier: "chat") as! chatfile
        self.navigationController?.popViewController(animated: true)
        
    }
       override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
