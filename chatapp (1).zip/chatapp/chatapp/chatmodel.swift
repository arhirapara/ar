//
//  chatmodel.swift
//  chatapp
//
//  Created by MACOS on 14/11/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class chatmodel: NSObject {
    var usersendno:String
    var userrecvno:String
    var chat:String
    var datetime:String
    
    init(usersendnno1:String!,userrecvno1:String!,chat1:String!,datetime1:String!) {
        usersendno = usersendnno1
        userrecvno = userrecvno1
        chat = chat1
        datetime = datetime1
        
    }
}

class chatrecvmodel:NSObject
{
    var user_sendno:String
    var user_recvno:String
    init(user_sendno1:String!,user_recvno1:String!) {
        self.user_sendno = user_sendno1
        self.user_recvno = user_recvno1
    }
}
