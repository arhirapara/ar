//
//  ViewController.swift
//  chatapp
//
//  Created by MACOS on 20/09/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: "backimage")?.draw(in: self.view.bounds)
        let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        self.view.backgroundColor = UIColor(patternImage: image)
       self.navigationController?.isNavigationBarHidden = true

     let dif =  UserDefaults()
        let  userid = dif.value(forKey: "mob") as! String
       // userid = "0"
       print(userid)
        
     if userid == userid
        {
            let f = storyboard?.instantiateViewController(withIdentifier: "chat") as! chatfile
            self.navigationController?.pushViewController(f, animated: true)
     }
       else
    {
            let f = storyboard?.instantiateViewController(withIdentifier: "view") as! ViewController
            self.navigationController?.pushViewController(f, animated: true)
            let dif = UserDefaults()
         //   dif.removeObject(forKey: "mob")
        }
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBAction func btn(_ sender: Any) {
        let f = storyboard?.instantiateViewController(withIdentifier: "start") as! start
        self.navigationController?.pushViewController(f, animated: true)

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

