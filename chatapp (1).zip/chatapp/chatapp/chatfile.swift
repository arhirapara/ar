//
//  chatfile.swift
//  chatapp
//
//  Created by MACOS on 20/09/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class chatfile: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var table: UITableView!

    var tbl = UITableView()
    var vw = UIView()
    
    var arr = ["New Group","New Broadcast","Settings"]
    var brr = ["sagar","ajay","raj","mahesh"]
    var crr = ["8140717806","9909645874","9689546985","7456321452"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        
        vw.frame = CGRect(x:0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        tbl.frame = CGRect(x: self.view.frame.width-160, y: self.view.frame.origin.y+70, width: 150, height: 150)
        tbl.separatorStyle = .none
        tbl.tag = 1
        tbl.delegate = self
        tbl.dataSource = self
        tbl.isScrollEnabled = false
                vw.addSubview(tbl)
        // Do any additional setup after loading the view.
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView.tag == 0
        {
        return 1
        }
        else
        {
            return 1
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       if tableView.tag == 0
       {
        return brr.count
        }
        else
       {
        return arr.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.tag == 0
        {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = brr[indexPath.row]
        return cell
        }
        else
        {
         tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cel")
        let cell1 = tableView.dequeueReusableCell(withIdentifier: "cel", for: indexPath)
            cell1.textLabel?.text = arr[indexPath.row]
            
            return cell1
        }
        
        }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       if tableView.tag == 0
            {
                let f = storyboard?.instantiateViewController(withIdentifier: "uchat") as! userchat
                f.na = brr[indexPath.row]
                f.mob = crr[indexPath.row]
                self.navigationController?.pushViewController(f, animated: true)
           // print(indexPath.row)
        }
        else
       {
        print(indexPath.row)
        if indexPath.row == 0
        {
            
        }
        else if indexPath.row == 1
        {
           /* for i in 0x1F601...0x1F64F {
                let c = String(describing: UnicodeScalar(i))
                print(c)
            }*/
        }
        else if indexPath.row == 2
        {
            let f = storyboard?.instantiateViewController(withIdentifier: "set") as! setting
            self.navigationController?.pushViewController(f, animated: true)
        }
        }
    }
    
    @IBAction func more(_ sender: UIBarButtonItem) {
        
   self.view.addSubview(vw)
        vw.isHidden = false
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
      
        self.vw.isHidden = true
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
