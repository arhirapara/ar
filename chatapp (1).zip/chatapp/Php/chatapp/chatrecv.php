<?php
    $con=new mysqli("localhost","root","","chatapp");
     $sendmob = $_POST['user_sendno'];
    $recvmob = $_POST['user_recvno'];
    $qu = "select * from chat where user_sendno = '$sendmob' or user_recvno = '$sendmob'order by data_time ASC";
    $rows = $con->query($qu);
    while($row = $rows->fetch_assoc())
    {
        $pp[]  = $row;
    }
    if (isset($pp))
    {
    echo json_encode($pp);
    }
    else
    {
        echo "not";
    }
    ?>
