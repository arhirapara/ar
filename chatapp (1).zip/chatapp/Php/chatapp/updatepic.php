<?php
    $conn = new mysqli("localhost","root","","chatapp");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $data = file_get_contents('php://input');
    
    $dt = json_decode($data);
    
   $mno = $dt->moblie_no;
  // $name = $dt->name;
   $img  = $dt->profile_pic;
   //$co  = $dt->code;
    define('UPLOAD_DIR', 'images/');
    
        $img = str_replace('data:image/png;base64,', '', $img);
        $img = str_replace(' ', '+', $img);
        $data = base64_decode($img);
        $file = UPLOAD_DIR . uniqid() . '.png';
        $success = file_put_contents($file, $data);
        print $success ? $file : 'Unable to save the file.';
    
    
   // $query="insert into Registr (mobile_no,name,profile_pic,code) values('$mno','$name','$file','$co')";
    $sql= "update Registr set profile_pic = '$file' where mobile_no = '$mno'";
   // $con->query($query);
    
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: ";
    }
 
    $conn->close();
    ?>
