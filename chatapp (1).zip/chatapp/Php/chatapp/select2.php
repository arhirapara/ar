<?php
    $con=new mysqli("localhost","root","","chatapp");
     $mob= $_POST['mobile_no'];
    $qu = "select * from Registr where mobile_no = '$mob'";
    $rows = $con->query($qu);
    while($row = $rows->fetch_assoc())
    {
        $pp[]  = $row;
    }
    if (isset($pp))
    {
    echo json_encode($pp);
    }
    else
    {
        echo "not";
    }
    ?>
