<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = “chatapp”;

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$mob= $_POST[‘mobile_no’];


//select * from tblemp where emp_name = '$emp_name' and emp_mob = '$emp_mob'"
//$sql = "SELECT id, firstname, lastname FROM std";

$sql = "select * from Registr where mobile_no = '$mob’";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo  " -mobile_no: " . $row[“mobile_no”];
    }
} else {
    echo "0 results";
}

mysqli_close($conn);
?> 