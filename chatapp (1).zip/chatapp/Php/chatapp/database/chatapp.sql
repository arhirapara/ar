-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 15, 2017 at 10:47 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `id` int(255) NOT NULL,
  `user_sendno` varchar(20) NOT NULL,
  `user_recvno` varchar(20) NOT NULL,
  `chat` varchar(6000) NOT NULL,
  `data_time` datetime(6) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `user_sendno`, `user_recvno`, `chat`, `data_time`) VALUES
(1, '8140717806', '9909645874', 'heyyyy', '2017-11-15 09:21:30.000000'),
(2, '8140717806', '9909645874', 'heyyyy', '2017-11-15 09:23:21.000000'),
(3, '8140717806', '9909645874', 'topa', '2017-11-15 09:23:21.000000'),
(4, '8140717806', '9909645874', 'nmstew', '2017-11-15 09:23:21.000000'),
(5, '8140717806', '9909645874', 'hello', '2017-11-15 09:27:01.000000'),
(6, '8140717806', '9909645874', 'hellosdds', '2017-11-15 09:27:01.000000'),
(7, '8140717806', '9909645874', 'dsfsfsddf', '2017-11-15 09:32:49.000000'),
(8, '8140717806', '9909645874', 'dsfsfsddfsdfsfs', '2017-11-15 09:32:49.000000'),
(9, '8140717806', '9909645874', 'huhr', '2017-11-15 09:38:02.000000'),
(10, '8140717806', '9909645874', 'huhrsdfsdfsd', '2017-11-15 09:38:17.000000'),
(11, '8140717806', '9909645874', 'helllooo', '2017-11-15 09:39:06.000000'),
(12, '8140717806', '9909645874', 'helllooodgbxcb', '2017-11-15 09:39:30.000000');

-- --------------------------------------------------------

--
-- Table structure for table `Registr`
--

CREATE TABLE IF NOT EXISTS `Registr` (
  `id` int(10) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `profile_pic` varchar(7000) NOT NULL,
  `status` varchar(1000) NOT NULL,
  `code` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Registr`
--

INSERT INTO `Registr` (`id`, `mobile_no`, `name`, `profile_pic`, `status`, `code`) VALUES
(2, '123456789', 'sp', 'images/59f02cae6d8cb.png', '', '+93'),
(3, '123123123', 'an', 'images/59f02e88ef616.png', '', '+93'),
(4, '54545454', 'sagg', 'images/59f02f1712386.png', '', '+355'),
(5, '12545454545', 'ankit', 'images/59f02ff31ae5b.png', 'hello', '+93'),
(6, '123221312', '321', 'images/59f03060a1bf1.png', '', '+93'),
(7, '98989898', 'wee', 'images/59f031139a996.png', '', '+54'),
(8, '9696969696', '32323', 'images/59f03186c3027.png', '', '+93'),
(9, '8140717806', '$PðŸ˜„ðŸ˜‰ðŸ˜‰ðŸ˜„ðŸ˜ŠðŸ˜Š', 'images/5a09284484815.png', 'I am Back', '+91');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Registr`
--
ALTER TABLE `Registr`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `Registr`
--
ALTER TABLE `Registr`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
