<?php
    $con = new mysqli("localhost","root","","chatapp");

    
    $data = file_get_contents('php://input');
    
    $dt = json_decode($data);
    
   $usno = $dt->user_sendno;
   $recvno = $dt->user_recvno;
   $cht   = $dt->chat;
   $datetime  = $dt->data_time;
    
    $query="insert into chat(user_sendno,user_recvno,chat,data_time) values('$usno','$recvno','$cht','$datetime')";
    
    $con->query($query);
    echo"done";
   
    ?>
