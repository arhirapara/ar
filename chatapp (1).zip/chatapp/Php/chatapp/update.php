
<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "chatapp";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
     $data = file_get_contents('php://input');
    $dt = json_decode($data);
    
    $mno = $dt->moblie_no;
    $name1 = $dt->name;
    $statu  = $dt->status;
    $co  = $dt->code;

  /*
    $mob= $_POST['mobile_no'];
    $statu = $_POST['status'];
    $nam = $_POST['name'];
    $cod = $_POST['code'];*/
   
  $sql = "update Registr set status = '$statu',name = '$name1',mobile_no = '$mno',code = '$co' where mobile_no = '$mno'";
    
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
    
    $conn->close();
    ?>
