//
//  ViewController.swift
//  D
//
//  Created by Kartum Infotech on 09/10/20.
//  Copyright © 2020 Kartum Infotech. All rights reserved.
//

typealias typeAliasDictionary               = [String: AnyObject]
typealias typeAliasStringDictionary         = [String: String]

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setData()
    }

    func setData()  {
//        let params = ["user_id":"1"] as typeAliasDictionary
//
//        var request = URLRequest(url: URL(string: "http://pwrpup.com/test/Api/upcoming_walks")!)
//        request.httpMethod = "POST"
//        request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
//        request.addValue("multipart/form-data", forHTTPHeaderField: "Content-Type")
//
//        let session = URLSession.shared
//        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
//            print(response!)
//            do {
//                let json = try JSONSerialization.jsonObject(with: data!) as! typeAliasDictionary
//                print(json)
//            } catch {
//                print("error")
//            }
//        })
//
//        task.resume()
        
        
        
        let parameters = [
          [
            "key": "user_id",
            "value": "1",
            "type": "text"
          ]] as [[String : Any]]

        let boundary = "Boundary-\(UUID().uuidString)"
        var body = ""
        var error: Error? = nil
        for param in parameters {
          if param["disabled"] == nil {
            let paramName = param["key"]!
            body += "--\(boundary)\r\n"
            body += "Content-Disposition:form-data; name=\"\(paramName)\""
            let paramType = param["type"] as! String
            if paramType == "text" {
              let paramValue = param["value"] as! String
              body += "\r\n\r\n\(paramValue)\r\n"
            } else {
              let paramSrc = param["src"] as! String
                let fileData = (try? NSData(contentsOfFile:paramSrc, options:[]) as Data) ?? Data()
              let fileContent = String(data: fileData, encoding: .utf8)!
              body += "; filename=\"\(paramSrc)\"\r\n"
                + "Content-Type: \"content-type header\"\r\n\r\n\(fileContent)\r\n"
            }
          }
        }
        body += "--\(boundary)--\r\n";
        let postData = body.data(using: .utf8)

        var request = URLRequest(url: URL(string: "http://pwrpup.com/test/Api/upcoming_walks")!,timeoutInterval: Double.infinity)
        request.addValue("ci_session=45fa2dcf8deea05d4769f6777448f8048d7ef78f", forHTTPHeaderField: "Cookie")
        request.addValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        request.httpMethod = "POST"
        request.httpBody = postData

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {
                print(String(describing: error))
                return
            }
            do {
                let json = try JSONSerialization.jsonObject(with: data) as! typeAliasDictionary
                print(json)
                if let dataFinal = json["response"] as? [typeAliasDictionary]{
                    print(dataFinal)
                }
            } catch {
                print("error")
            }
            print(String(data: data, encoding: .utf8)!)
        }

        task.resume()
    }
}

