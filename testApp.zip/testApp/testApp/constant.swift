//
//  constant.swift
//  testApp
//
//  Created by Piyush Vyas on 21/12/17.
//  Copyright © 2017 wos. All rights reserved.
//

class constant
{
    
    var caption: String = ""
    var international_number: String = ""
    var isLineShared: String = ""
  
  

}


