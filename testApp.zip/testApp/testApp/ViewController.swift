//
//  ViewController.swift
//  testApp
//
//  Created by Piyush Vyas on 21/12/17.
//  Copyright © 2017 wos. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController , UITableViewDelegate , UITableViewDataSource {

    override func viewDidLoad() {
        super.viewDidLoad()
        
      
 
        
        let session = URLSession.shared
        let url = "https://jyapi.togglewave.com/rcci.svc/getcontacts"
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let params:[String: AnyObject] = ["mynumber":"09512468722" as AnyObject,"apikey":"TEST" as AnyObject]
        
        do{
            request.httpBody = try JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
            let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
                if let response = response {
                    let nsHTTPResponse = response as! HTTPURLResponse
                    let statusCode = nsHTTPResponse.statusCode
                    print ("status code = \(statusCode)")
                }
                if let error = error {
                    print ("\(error)")
                }
                
                
                
                if let data = data {
                    do{
                        let jsonResponse = try JSONSerialization.jsonObject(with: data) as? NSDictionary
                        
                //   print(jsonResponse!.value(forKey: "getcontactsResult")!)
                        
                     
                       let newdata =  jsonResponse?.value(forKey: "data")  as? NSDictionary
                        
                       }catch _ {
                        print ("Json Format proble")
                    }
                }
            })
            task.resume()
        }catch _ {
            print ("Oops something happened buddy")
        }
        
        
        
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        return cell
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

